"""Tests for the registered parse pipelines."""

from __future__ import annotations

import re

import pytest

from parse_bench.inference.pipelines import get_pipeline, list_pipelines
from parse_bench.schemas.product import ProductType


def test_amazon_nova_with_layout_pipeline_enables_layout_mode() -> None:
    spec = get_pipeline("amazon_nova_2_lite_parse_with_layout")
    assert spec.config["mode"] == "parse_with_layout"


@pytest.mark.parametrize(
    "pipeline_name, provider_name",
    [
        ("reducto_nonagentic_change_tracking", "reducto"),
        ("reducto_agentic_table", "reducto"),
        ("reducto_agentic_chart", "reducto"),
        ("openai_gpt_5_4_reasoning_none_parse", "openai"),
        ("openai_gpt_5_4_reasoning_none_parse_file", "openai"),
        ("anthropic_sonnet_5_parse_with_layout", "anthropic"),
        ("google_gemini_3_6_flash_parse_with_layout", "google"),
        ("google_gemini_3_6_flash_no_thinking_parse_with_layout", "google"),
        ("google_gemini_3_7_flash_thinking_high_parse_with_layout_file", "google"),
        ("google_gemini_3_1_flash_lite_thinking_high_parse_with_layout_file", "google"),
        ("mistral_ocr_4_1", "mistral_ocr"),
        ("mistral_ocr_4_1_annotation", "mistral_ocr"),
        ("hpd_parsing_vllm_parse", "hpd_parsing"),
        ("nemotron_omni_30b_vllm", "nemotron_omni"),
        ("hunyuanocr_1_5", "hunyuanocr"),
        ("ovisocr2_vllm", "ovisocr2"),
        ("qwen3_8_flash_next_parse_with_layout", "qwen3_8"),
        ("qwen3_8_flash_next_thinking_parse_with_layout", "qwen3_8"),
        ("anyformat_standard", "anyformat"),
        ("anyformat_agentic", "anyformat"),
        ("anyformat_lite", "anyformat"),
        ("anyformat_flash", "anyformat"),
        ("wevisdoc_2b_vllm", "wevisdoc"),
        ("wevisdoc_4b_vllm", "wevisdoc"),
    ],
)
def test_ported_pipelines_are_registered(pipeline_name: str, provider_name: str) -> None:
    spec = get_pipeline(pipeline_name)
    assert spec.provider_name == provider_name
    assert spec.product_type == ProductType.PARSE


def test_reducto_variants_differ_only_in_documented_keys() -> None:
    base = get_pipeline("reducto").config
    assert base["agentic"] is False
    change_tracking = get_pipeline("reducto_nonagentic_change_tracking").config
    assert change_tracking == {**base, "formatting_include": ["change_tracking"]}
    table = get_pipeline("reducto_agentic_table").config
    assert table["agentic"] is True and table["agentic_scopes"] == ["text", "table"]
    chart = get_pipeline("reducto_agentic_chart").config
    assert chart["advanced_chart_agent"] is True and chart["agentic_scopes"] == ["text", "table", "figure"]


def test_qwen38_flash_next_pipelines_differ_only_by_thinking() -> None:
    off = get_pipeline("qwen3_8_flash_next_parse_with_layout").config
    on = get_pipeline("qwen3_8_flash_next_thinking_parse_with_layout").config
    assert off["enable_thinking"] is False
    assert on["enable_thinking"] is True
    assert {k: v for k, v in off.items() if k != "enable_thinking"} == {
        k: v for k, v in on.items() if k != "enable_thinking"
    }
    assert off["server_url_env"] == "QWEN3_8_FLASH_NEXT_SERVER_URL"


@pytest.mark.parametrize(
    ("pipeline_name", "server_url_env", "served_model_name"),
    [
        ("wevisdoc_2b_vllm", "WEVISDOC_2B_SERVER_URL", "wevisdoc-2b"),
        ("wevisdoc_4b_vllm", "WEVISDOC_4B_SERVER_URL", "wevisdoc-4b"),
    ],
)
def test_wevisdoc_pipelines_use_public_endpoint_variables(
    pipeline_name: str,
    server_url_env: str,
    served_model_name: str,
) -> None:
    spec = get_pipeline(pipeline_name)

    assert spec.provider_name == "wevisdoc"
    assert spec.product_type == ProductType.PARSE
    assert spec.config == {
        "server_url": "",
        "server_url_env": server_url_env,
        "served_model_name": served_model_name,
    }


def test_no_internal_only_pipeline_names_are_registered() -> None:
    # `llamaparse_agentic_granular_bboxes_staging` is a ParseBench-only pipeline,
    # so `_staging` is deliberately not in this list.
    internal = re.compile(r"^ours_|_dev$|_local$|mock")
    assert [name for name in list_pipelines() if internal.search(name)] == []


def test_self_hosted_pipelines_do_not_ship_internal_endpoints() -> None:
    for name in list_pipelines():
        config = get_pipeline(name).config
        for key in ("server_url", "endpoint_url"):
            value = config.get(key)
            if isinstance(value, str):
                assert "modal.run" not in value, f"{name}.{key} points at an internal deployment"


def test_hpd_parsing_uses_public_endpoint_configuration() -> None:
    config = get_pipeline("hpd_parsing_vllm_parse").config
    assert config["server_url_env"] == "HPD_PARSING_SERVER_URL"
    assert "server_url" not in config


@pytest.mark.parametrize(
    ("prefix", "model_suffixes"),
    [
        ("openai_gpt_5_6", ("sol", "terra", "luna")),
        ("openai_gpt_6", ("astra", "sol", "luna")),
    ],
)
def test_openai_reasoning_sweeps_route_only_max_through_responses(prefix: str, model_suffixes: tuple[str, ...]) -> None:
    efforts = {"none": "none", "low": "low", "med": "medium", "high": "high", "xhigh": "xhigh", "max": "max"}
    for suffix in model_suffixes:
        for name_effort, effort in efforts.items():
            name = f"{prefix}_{suffix}_reasoning_{name_effort}_parse_with_layout_file"
            if suffix == "astra" and effort == "none":
                assert name not in list_pipelines()
                continue
            spec = get_pipeline(name)
            assert spec.provider_name == "openai"
            assert spec.config["mode"] == "parse_with_layout_file"
            assert spec.config["reasoning_effort"] == effort
            assert spec.config.get("api", "chat") == ("responses" if effort == "max" else "chat")


@pytest.mark.parametrize("effort", ["low", "high"])
def test_opus_5_5_effort_pipelines_send_output_config_effort(effort: str, monkeypatch: pytest.MonkeyPatch) -> None:
    from types import SimpleNamespace

    from parse_bench.inference.providers.parse.anthropic import AnthropicProvider

    base = get_pipeline("anthropic_opus_5_5_parse_with_layout_file")
    spec = get_pipeline(f"anthropic_opus_5_5_effort_{effort}_parse_with_layout_file")
    assert spec.provider_name == base.provider_name
    assert spec.config == {**base.config, "effort": effort}

    calls: list[dict] = []

    def create(**kwargs):  # type: ignore[no-untyped-def]
        calls.append(kwargs)
        return SimpleNamespace(content=[], usage=None)

    monkeypatch.setenv("ANTHROPIC_API_KEY", "test-key")
    provider = AnthropicProvider(spec.provider_name, spec.config)
    provider._client = SimpleNamespace(beta=SimpleNamespace(messages=SimpleNamespace(create=create)))
    provider._parse_pdf_page_with_layout(b"%PDF-1.4")

    assert calls[0]["output_config"] == {"effort": effort}
    assert "thinking" not in calls[0]
    assert "temperature" not in calls[0]


def test_anyformat_pipelines_differ_only_by_tier() -> None:
    configs = {tier: get_pipeline(f"anyformat_{tier}").config for tier in ("standard", "agentic", "lite", "flash")}
    assert configs == {tier: {"mode": tier} for tier in configs}
    assert get_pipeline("anyformat_standard").per_file_timeout == 900.0
