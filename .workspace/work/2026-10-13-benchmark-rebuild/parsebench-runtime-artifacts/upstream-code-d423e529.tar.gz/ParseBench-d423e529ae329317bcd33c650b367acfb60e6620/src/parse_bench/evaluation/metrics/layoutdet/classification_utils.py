"""Classification utilities for layout detection evaluation.

This module provides functions for matching predictions to ground truth
and computing per-class precision/recall/F1 metrics.
"""

from collections import defaultdict
from collections.abc import Callable
from typing import Any

import numpy as np

from parse_bench.evaluation.metrics.layoutdet.iou import (
    compute_iou_matrix,
)
from parse_bench.evaluation.metrics.layoutdet.overlap import compute_layout_iou

OverlapFn = Callable[[dict, dict], float]


def _coerce_page_key(value: Any) -> int | None:
    if value is None:
        return None
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def _entry_dimension(value: Any) -> float | None:
    try:
        dimension = float(value)
    except (TypeError, ValueError):
        return None
    return dimension if dimension > 0 else None


def _entry_page_dimensions(
    entry: dict[str, Any],
    page_dimensions_by_number: dict[int, tuple[float, float]],
) -> tuple[float, float]:
    width = _entry_dimension(entry.get("page_width"))
    height = _entry_dimension(entry.get("page_height"))
    if width is not None and height is not None:
        return width, height

    page_key = _coerce_page_key(entry.get("page"))
    if page_key is not None:
        return page_dimensions_by_number.get(page_key, (1.0, 1.0))
    return (1.0, 1.0)


def _matching_page_dimensions(
    gt_entry: dict[str, Any],
    pred_entry: dict[str, Any],
    page_dimensions_by_number: dict[int, tuple[float, float]],
) -> tuple[float, float]:
    gt_width, gt_height = _entry_page_dimensions(gt_entry, page_dimensions_by_number)
    if (gt_width, gt_height) != (1.0, 1.0):
        return gt_width, gt_height
    return _entry_page_dimensions(pred_entry, page_dimensions_by_number)


def _bbox_cache_key(bbox: Any) -> tuple[float, float, float, float]:
    values = [float(value) for value in bbox]
    if len(values) != 4:
        raise ValueError(f"Expected bbox with 4 values, got {len(values)}")
    return values[0], values[1], values[2], values[3]


def rotated_overlap_fn(
    page_dimensions_by_number: dict[int, tuple[float, float]],
) -> Callable[[dict[str, Any], dict[str, Any]], float]:
    """Build cached rotated IoU matching with each page's physical aspect ratio."""

    def entry_key(entry: dict[str, Any]) -> tuple:
        angle = entry.get("r")
        return (
            _bbox_cache_key(entry["bbox"]),
            None if angle is None else float(angle),
            _entry_page_dimensions(entry, page_dimensions_by_number),
        )

    class RotatedOverlap:
        def __init__(self) -> None:
            self._matrix_cache: dict[tuple, np.ndarray] = {}

        def __call__(self, pred: dict[str, Any], gt: dict[str, Any]) -> float:
            return float(self.matrix([pred], [gt])[0, 0])

        def matrix(self, predictions: list[dict[str, Any]], ground_truth: list[dict[str, Any]]) -> np.ndarray:
            cache_key = (
                tuple(entry_key(pred) for pred in predictions),
                tuple(entry_key(gt) for gt in ground_truth),
            )
            cached = self._matrix_cache.get(cache_key)
            if cached is not None:
                return cached

            pred_boxes = np.array([pred["bbox"] for pred in predictions], dtype=float)
            gt_boxes = np.array([gt["bbox"] for gt in ground_truth], dtype=float)
            pred_angles = [pred.get("r") for pred in predictions]
            gt_angles = [gt.get("r") for gt in ground_truth]

            reference_pred = predictions[0] if predictions else {}
            page_widths: list[float] = []
            page_heights: list[float] = []
            for gt in ground_truth:
                page_width, page_height = _matching_page_dimensions(gt, reference_pred, page_dimensions_by_number)
                page_widths.append(page_width)
                page_heights.append(page_height)

            matrix = compute_layout_iou(
                gt_boxes,
                pred_boxes,
                gt_angles,
                pred_angles,
                page_widths=page_widths,
                page_heights=page_heights,
            ).T
            self._matrix_cache[cache_key] = matrix
            return matrix

    return RotatedOverlap()


def average_precision_score(y_true: np.ndarray, y_score: np.ndarray) -> float:
    """
    Binary average precision, matching ``sklearn.metrics.average_precision_score``.

    AP = sum_n (R_n - R_{n-1}) * P_n, where precision/recall are evaluated at each
    distinct score threshold (tied scores are grouped, as in scikit-learn).

    :param y_true: Binary labels, shape (N,)
    :param y_score: Confidence scores, shape (N,)
    :return: Average precision in [0, 1]; 0.0 if there are no positives
    """
    y_true = np.asarray(y_true, dtype=float).ravel()
    y_score = np.asarray(y_score, dtype=float).ravel()
    n_pos = float(y_true.sum())
    if len(y_true) == 0 or n_pos == 0:
        return 0.0

    order = np.argsort(-y_score, kind="stable")
    y_true = y_true[order]
    y_score = y_score[order]

    # Indices of the last element in each group of tied scores
    distinct = np.where(np.diff(y_score) != 0)[0]
    threshold_idx = np.concatenate([distinct, [len(y_true) - 1]])

    tps = np.cumsum(y_true)[threshold_idx]
    precision = tps / (threshold_idx + 1)
    recall = tps / n_pos
    prev_recall = np.concatenate([[0.0], recall[:-1]])
    return float(np.sum((recall - prev_recall) * precision))


def match_predictions_to_gt(
    pred_boxes: np.ndarray,  # (N, 4) xyxy format
    pred_scores: np.ndarray,  # (N,)
    pred_classes: np.ndarray,  # (N,) class indices
    gt_boxes: np.ndarray,  # (M, 4) xyxy format
    gt_classes: np.ndarray,  # (M,) class indices
    iou_threshold: float = 0.5,
) -> tuple[np.ndarray, np.ndarray]:
    """
    Match predictions to ground truth using IoU threshold.

    Uses greedy matching: predictions are processed in descending score order,
    each prediction matches the best available GT with same class and IoU >= threshold.

    :param pred_boxes: Prediction bounding boxes, shape (N, 4) in xyxy format
    :param pred_scores: Prediction confidence scores, shape (N,)
    :param pred_classes: Prediction class indices, shape (N,)
    :param gt_boxes: Ground truth bounding boxes, shape (M, 4) in xyxy format
    :param gt_classes: Ground truth class indices, shape (M,)
    :param iou_threshold: IoU threshold for matching (default 0.5)
    :return: Tuple of (y_true, y_score) where:
             - y_true: Binary array (N,) - 1 if prediction matches GT, 0 otherwise
             - y_score: Confidence scores (N,)
    """
    if len(pred_boxes) == 0:
        return np.array([]), np.array([])
    if len(gt_boxes) == 0:
        return np.zeros(len(pred_boxes)), pred_scores.copy()

    # Compute IoU matrix
    iou_matrix = compute_iou_matrix(pred_boxes, gt_boxes)

    # Sort predictions by score (descending)
    sorted_indices = np.argsort(-pred_scores)

    y_true = np.zeros(len(pred_boxes))
    matched_gt: set[int] = set()

    for pred_idx in sorted_indices:
        pred_class = pred_classes[pred_idx]

        # Find best matching GT with same class
        best_iou = 0.0
        best_gt_idx = -1

        for gt_idx in range(len(gt_boxes)):
            if gt_idx in matched_gt:
                continue
            if gt_classes[gt_idx] != pred_class:
                continue

            iou = iou_matrix[pred_idx, gt_idx]
            if iou >= iou_threshold and iou > best_iou:
                best_iou = iou
                best_gt_idx = gt_idx

        if best_gt_idx >= 0:
            y_true[pred_idx] = 1
            matched_gt.add(best_gt_idx)

    return y_true, pred_scores.copy()


def compute_per_class_metrics(
    predictions: list[dict],  # [{bbox, class_name, score}, ...]
    ground_truth: list[dict],  # [{bbox, class_name}, ...]
    class_names: list[str],
    iou_threshold: float = 0.5,
    *,
    overlap_fn: OverlapFn | None = None,
    page_key: str = "example_id",
) -> dict[str, dict[str, float]]:
    """
    Compute per-class precision, recall, F1 at given IoU threshold.

    :param predictions: List of predictions, each with 'bbox', 'class_name', 'score'
    :param ground_truth: List of ground truth, each with 'bbox', 'class_name'
    :param class_names: List of class names to evaluate
    :param iou_threshold: IoU threshold for matching (default 0.5)
    :return: Dict mapping class_name to metrics dict {precision, recall, f1, ap, support}
    """
    class_set = set(class_names)
    results: dict[str, dict[str, float]] = {}

    has_pages = any(page_key in entry for entry in predictions) or any(page_key in entry for entry in ground_truth)

    # Per-page matching to keep IoU matrices bounded by per-page box counts.
    predictions_by_page = defaultdict(lambda: defaultdict(list))  # type: ignore[var-annotated]
    ground_truth_by_page = defaultdict(lambda: defaultdict(list))  # type: ignore[var-annotated]

    for pred in predictions:
        if pred.get("class_name") not in class_set:
            continue
        page_id = str(pred.get(page_key, "__missing__")) if has_pages else "__all__"
        predictions_by_page[page_id][pred["class_name"]].append(pred)

    for gt in ground_truth:
        if gt.get("class_name") not in class_set:
            continue
        page_id = str(gt.get(page_key, "__missing__")) if has_pages else "__all__"
        ground_truth_by_page[page_id][gt["class_name"]].append(gt)

    page_ids = set(predictions_by_page.keys()) | set(ground_truth_by_page.keys())

    for class_name in class_names:
        total_true = 0
        total_false = 0
        total_support = 0
        all_y_true: list[int] = []
        all_y_scores: list[float] = []

        for page_id in page_ids:
            class_preds = predictions_by_page[page_id].get(class_name, [])
            class_gt = ground_truth_by_page[page_id].get(class_name, [])

            total_support += len(class_gt)
            if not class_gt:
                total_false += len(class_preds)
                all_y_true.extend([0] * len(class_preds))
                all_y_scores.extend([float(p["score"]) for p in class_preds])
                continue
            if not class_preds:
                continue

            y_true, y_scores = match_prediction_dicts_to_gt(
                class_preds,
                class_gt,
                iou_threshold=iou_threshold,
                overlap_fn=overlap_fn,
            )
            y_true_list = [int(v) for v in y_true.tolist()]
            y_score_list = [float(v) for v in y_scores.tolist()]

            true_count = int(np.sum(y_true))
            total_true += true_count
            total_false += int(len(class_preds) - true_count)
            all_y_true.extend(y_true_list)
            all_y_scores.extend(y_score_list)

        if total_support == 0:
            results[class_name] = {
                "precision": 0.0,
                "recall": 0.0,
                "f1": 0.0,
                "ap": 0.0,
                "support": 0,
            }
            continue

        total_false_neg = total_support - total_true
        precision = total_true / (total_true + total_false) if (total_true + total_false) > 0 else 0.0
        recall = total_true / (total_true + total_false_neg) if (total_true + total_false_neg) > 0 else 0.0
        f1 = 2 * precision * recall / (precision + recall) if (precision + recall) > 0 else 0.0

        if len(set(all_y_true)) > 1:
            ap = float(average_precision_score(np.array(all_y_true), np.array(all_y_scores)))
        else:
            ap = precision if all_y_true and all(v == 1 for v in all_y_true) else 0.0

        results[class_name] = {
            "precision": precision,
            "recall": recall,
            "f1": f1,
            "ap": ap,
            "support": total_support,
        }

    return results


def match_prediction_dicts_to_gt(
    predictions: list[dict],
    ground_truth: list[dict],
    *,
    iou_threshold: float,
    overlap_fn: OverlapFn | None = None,
) -> tuple[np.ndarray, np.ndarray]:
    """Match same-class prediction/GT dictionaries using axis-aligned or custom overlap."""
    if len(predictions) == 0:
        return np.array([]), np.array([])

    pred_scores = np.array([float(pred.get("score", 0.0)) for pred in predictions])
    if len(ground_truth) == 0:
        return np.zeros(len(predictions)), pred_scores.copy()

    if overlap_fn is None:
        pred_boxes = np.array([pred["bbox"] for pred in predictions])
        pred_classes = np.zeros(len(predictions), dtype=int)
        gt_boxes = np.array([gt["bbox"] for gt in ground_truth])
        gt_classes = np.zeros(len(ground_truth), dtype=int)
        return match_predictions_to_gt(
            pred_boxes,
            pred_scores,
            pred_classes,
            gt_boxes,
            gt_classes,
            iou_threshold,
        )

    overlap_matrix: np.ndarray | None = None
    matrix_fn = getattr(overlap_fn, "matrix", None)
    if callable(matrix_fn):
        overlap_matrix = matrix_fn(predictions, ground_truth)

    sorted_indices = np.argsort(-pred_scores)
    y_true = np.zeros(len(predictions))
    matched_gt: set[int] = set()

    for pred_idx in sorted_indices:
        pred = predictions[int(pred_idx)]
        best_iou = 0.0
        best_gt_idx = -1

        for gt_idx, gt in enumerate(ground_truth):
            if gt_idx in matched_gt:
                continue

            iou = float(overlap_matrix[int(pred_idx), gt_idx]) if overlap_matrix is not None else overlap_fn(pred, gt)
            if iou >= iou_threshold and iou > best_iou:
                best_iou = iou
                best_gt_idx = gt_idx

        if best_gt_idx >= 0:
            y_true[int(pred_idx)] = 1
            matched_gt.add(best_gt_idx)

    return y_true, pred_scores.copy()


def compute_map_at_thresholds(
    predictions: list[dict],  # [{bbox, class_name, score}, ...]
    ground_truth: list[dict],  # [{bbox, class_name}, ...]
    class_names: list[str],
    iou_thresholds: list[float] | None = None,
    *,
    overlap_fn: OverlapFn | None = None,
    page_key: str = "example_id",
) -> dict[str, float]:
    """
    Compute mAP at multiple IoU thresholds (COCO-style).

    :param predictions: List of predictions
    :param ground_truth: List of ground truth
    :param class_names: List of class names to evaluate
    :param iou_thresholds: List of IoU thresholds (default: [0.5, 0.55, ..., 0.95])
    :return: Dict with mAP@[.50:.95], AP50, AP75
    """
    if iou_thresholds is None:
        iou_thresholds = [0.5 + i * 0.05 for i in range(10)]  # [0.5, 0.55, ..., 0.95]

    # Compute AP at each threshold
    ap_per_threshold: list[float] = []
    ap50 = 0.0
    ap75 = 0.0

    for threshold in iou_thresholds:
        per_class = compute_per_class_metrics(
            predictions,
            ground_truth,
            class_names,
            iou_threshold=threshold,
            overlap_fn=overlap_fn,
            page_key=page_key,
        )

        # Mean AP across classes (only classes with support > 0)
        aps = [m["ap"] for m in per_class.values() if m["support"] > 0]
        mean_ap = float(np.mean(aps)) if aps else 0.0
        ap_per_threshold.append(mean_ap)

        if abs(threshold - 0.5) < 0.01:
            ap50 = mean_ap
        if abs(threshold - 0.75) < 0.01:
            ap75 = mean_ap

    # mAP@[.50:.95] is the mean across all thresholds
    map_50_95 = float(np.mean(ap_per_threshold)) if ap_per_threshold else 0.0

    return {
        "mAP@[.50:.95]": map_50_95,
        "AP50": ap50,
        "AP75": ap75,
    }
