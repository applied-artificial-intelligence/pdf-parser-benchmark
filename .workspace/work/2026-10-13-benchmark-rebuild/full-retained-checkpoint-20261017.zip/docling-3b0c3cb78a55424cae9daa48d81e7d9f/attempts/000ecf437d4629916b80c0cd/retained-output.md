## Key Information Document

## Purpose

This document provides you with key information about this investment product. It is not marketing material. The information is required by law to help you understand the nature, risks, costs, potential gains and losses of this product and to help you compare it with other products.

## Product

## AGCM Fund - Asia Dividend Fund

a sub-fund of AGCM Fund

RC1 (SEK) - LU2083136650

This product is authorised in Luxembourg.

## Manufacturer / Management company

Name:

FundRock Management Company S.A.

Contact details:

33, rue de Gasperich, L-5826 Hesperange, Luxembourg

Competent Authority:

Date of production www.fundrock.com/funds/ - Call +352 27 111 1 for more information.

The Commission de Surveillance du Secteur Financier is responsible for supervising the manufacturer in relation to this Key Information Document.

22/08/2024

## What is this product?

## Type

This product is a unit of a mutual fund qualifying as an undertaking for collective investment in transferable securities (UCITS).

## Term

This sub-fund has no maturity date. However, the management company may decide to close the sub-fund under certain circumstances.

## Objectives

The sub-fund aims to generate a long-term capital appreciation and dividends by investing in companies in Asia.

In order to achieve its objective, the sub-fund may invest in equity or equity-related securities of companies domiciled in Asia (including but not limited to China, Hong Kong, Taiwan, South Korea, Singapore,India, Indonesia, Malaysia, Thailand, the Philippines, Vietnam, Laos, Cambodia and Myanmar).

The sub-fund will normally not invest in companies domiciled in Japan.

The sub-fund invests in particular in companies that in the opinion of the Investment Manager are expected to have a high and sustainable dividend yield supported by sustainable growth in revenues and earnings. The sub-fund is aiming at a diversified portfolio, with no particular focus on an industry or capitalization of companies.

For its investments in equities or equity-related securities of companies domiciled in China, the sub-fund may invest its assets in China B-Shares, China H-Shares and up to 30% of its net assets in China AShares listed on mainland exchanges of Shanghai and Shenzhen. The sub-fund will invest and have direct access to certain eligible China A-Shares via the Stock Connect.

The sub-fund may invest in derivative instruments in order to mitigate risks.

The sub-fund may invest in any equity-related instrument on any regulated market in any OECD country outside Asia as long as a significant portion of the company's assets are based in Asia or a significant portion of the revenues are derived from Asia.

The sub-fund qualifies as an Article 8 financial product under SFDR (Sustainable Finance Disclosure Regulation). Further information about the ESG characteristics applied is available online at the website of the Investment Manager: www.agcm.se/en/documents/sustainability.

<!-- image -->

Benchmark: The portfolio is actively managed on a discretionary basis without reference to a benchmark.

## Intended retail investor

This product is offered to investors who may have basic or no knowledge and experience of investing in financial markets and also experienced investors. An investment in this product is designated to be a medium term investment and the investment horizon should ideally be at least three to five years. Investors should not expect to obtain short-term gains from such investment.

## Other information

Depositary: Skandinaviska Enskilda Banken. AB (publ) - Luxembourg Branch

Dividend income: This class is a capitalisation class meaning that income is reinvested.

Conversion right: The investor has the right to convert his investment in units in one sub-fund for units in the same sub-fund or in another sub-fund. The investor can obtain information about how to convert in the prospectus of the fund.

Segregation: The assets and liabilities of a sub-fund are segregated pursuant to the law so that the commitments and liabilities of one subfund do not affect the other sub-funds.

Additional information: Additional information about the fund, copies of its prospectus, the latest annual and semi-annual report and the latest prices of units may be obtained free of charge from the management company or on www.fundrock.com/funds/. The prospectus and the periodic reports are prepared for the entire fund and are available in English. The management company may inform you about other languages in which these documents are available.

This sub-fund was launched in 2020 and this unit class in 2020.

The reference currency of the sub-fund is expressed in SEK. The currency of the unit class is expressed in SEK.