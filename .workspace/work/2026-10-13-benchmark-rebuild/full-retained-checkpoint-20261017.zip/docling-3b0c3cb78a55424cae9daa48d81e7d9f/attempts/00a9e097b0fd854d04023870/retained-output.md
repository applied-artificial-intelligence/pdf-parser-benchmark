| *In each case, first-named   | *In each case, first-named   |
|------------------------------|------------------------------|
| is *Chairman A =             | Advisory (Non-voting)        |
| O =                          | Officers                     |
| P =                          | Public Members               |

## Council/ Executive

*Doug Spitzig O Janet Bradshaw Mike Davis Curtis Loucks Debbie McCulloch Brenda Schuster O Randy Wiser O Dennis Gorecki Adrienne Lindblad May Bridgewater P Kay Fergusson P

## Committees

## Awards and Honors (Joint Committee with RBSP)

Arlene Kuntz Darryl Leshko Janet Markowski Yvonne Shevchuk Ernest Uhryn Dean Bradley A Wayne Wurtz A

## Complaints

*Janet Bradshaw Darryl Leshko Scott Livingstone Margaret Wheaton May Bridgewater P Jeanne Eriksen A Wayne Wurtz A Lori Postnikoff A

<!-- image -->

## Crimes Against Pharmacy Task Force

Al Appenheimer Ian Gray Helen Hay Cintra Kanhai Suzann Klamot Brenda Mack Ron Mucha Jack Mullock Darcy Scherle Peter Walker *Ray Joubert A

## Discipline

*Bev Allen Mike Davis Doug Spitzig Randy Wiser Kay Fergusson P Ray Joubert A

## Professional Practice

| *Garry Guedo     | *Garry Guedo     |
|------------------|------------------|
| Barry Lyons      | Barry Lyons      |
| Janice Norfield  | Janice Norfield  |
| Debbie McCulloch | Debbie McCulloch |
| Yvonne Shevchuk  | Yvonne Shevchuk  |
| Linda Suveges    | Linda Suveges    |
| Patricia Brown   | A                |
| Karen Gossen     | A                |
| Brian Henderson  | Brian Henderson  |
| Vali Orchard     | A                |
| Betty Riddell    | A                |
| Bill Semchuk     | A                |
| Shelly Wagner    | A                |
| Randy Wiser      | A                |
| Jeanne Eriksen   | A                |

| Registration and                  |
|-----------------------------------|
| Licensing Policies *Mike Davis    |
| Carolyn Carruthers                |
| Lyn Rhode                         |
| Tracy Slobodian                   |
| Dale Toni                         |
| Margaret Wheaton                  |
| Vali Orchard A                    |
| Kimberley Smith A                 |
| Jeanne Eriksen A                  |
| Seamless Care                     |
| Task Force                        |
| *Shannan Neubauer Janet Bradshaw  |
| May Bridgewater P                 |
| Barb Evans                        |
| Lori Friesen                      |
| Jack Mullock                      |
| Linda Klassen A A                 |
| Ray Joubert                       |
| Appointees                        |
| CCCEP                             |
| Linda Suveges                     |
| Formulary Committee Cintra Kanhai |
| Primary Health Services Advisory  |
| Committee                         |
| Ray Joubert                       |
| Inter-Provincial                  |
| Regulatory Committee              |
| (IPRC)                            |
| Ray Joubert                       |

## National Association of Pharmacy Regulatory Authorities (NAPRA)

Janet Bradshaw

Pharmacy Examining Board of Canada (PEBC) Bev Allen

## University of Regina Senate

Arlene Kuntz

## University of

Saskatchewan Senate Betty Riddell

## Staff

Registrar-Treasurer Ray Joubert

Assistant Registrar Jeanne Eriksen

Field Officer Wayne Wurtz Lori Postnikoff

## Administrative Assistants

Paddy Dodge Pat Guillemin Cheryl Klein Bonnie Noels Tamarha Robbins