Belgium's temporary VAT exemption. Our forecast underestimated the impacts of these changes on 2024 deployment, so we realigned our expectations with 2024 growth.

In other markets, policy changes included switching from net metering to net billing to achieve more cost-effective deployment of distributed PV. While this switch lowers the remuneration value for the consumer, it incentivises consumption during peak hours and also reduces grid congestion as well as the amount of grid costs passed on to consumers. Because our forecast underestimated the impacts of these changes on 2024 deployment in Poland and parts of Belgium, we have revised our expectations downwards for these countries as well as for the Netherlands, which recently announced plans to also transition by 2027.

## Residential sector retail electricity prices and annual capacity additions in selected European countries, 2021-2024

<!-- image -->

IEA. CC BY 4.0.

Additional downward revisions reflect cuts to FITs in France, proposed tax-subsidy changes in Sweden, ongoing policy uncertainty in Switzerland, and weaker-thanexpected H1-2025 deployment in Germany. These downward revisions outweigh upward adjustments to 17 countries for which we underestimated growth in 2024. In some cases, we simply undervalued the business case despite falling power prices (Hungary, Austria and Greece), while in others (e.g. Ireland and Portugal) elevated prices and continued policy support maintained stronger-than-expected growth.

Offshore wind capacity is forecast to grow 57 GW by 2030; however, this is 9 GW (15%) less than what we projected in Renewables 2024. This reduction reflects an increasingly challenging business case for planned projects and extended project timelines. Rising costs, supply chain constraints and uncertainty around future electricity prices have raised concerns about project viability, impacting over 5 GW of the forecast.