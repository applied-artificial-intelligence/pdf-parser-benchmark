IF

CP

IF

SP

IF

CP

TEC

CP

EPI

SP

SP

TEC

Legend:

Legend:

## 2.5.2 OSI subindices

The subsections above have highlighted areas that require further attention if countries wish to strengthen overall e-government development (as reflected in their respective EGDI levels). In cases where improvements in online services provision (OSI values) are necessary, it is important to understand which specific aspects of this component require attention. The main Survey findings for each of the five OSI subindices are presented below.

193 UN Member States

193 UN Member States

Africa

Americas

Asia

Legend:

Africa

Americas

Asia

Legend:

193 UN Member States

Legend:

Europe

Africa

Oceania Legend:

Europe

Africa

Oceania

193 UN Member States

Americas

Africa

Asia

Americas

Europe

Asia

Oceania

Europe Linear (global OSI average)

Linear (global OSI average)

As shown in figure 2.9, the institutional framework (IF) is better developed than other aspects of online services provision in all regions. Content provision (CP) has the next highest subindex value, followed by services provision (SP), technical characteristics (TEC) and e-participation (EPI). At the regional level, Europe is leading in terms of average OSI and subindex values, followed by Asia, the Americas, Oceania, and Africa - the one exception being that the technical aspects of the OSI are slightly better developed in Africa than in Oceania. Linear (global OSI average) Linear (average OSI for Africa) Linear (average OSI for Asia) Linear (average OSI for Europe) 193 UN Member States Linear (average OSI for the Americas) Linear (global OSI average) Linear (average OSI for Africa) Linear (average OSI for Asia) Linear (average OSI for Europe) Linear (average OSI for Oaceania) 193 UN Member States Linear (average OSI for the Americas) Linear (average OSI for Africa) Linear (average OSI for Asia) Linear (average OSI for Europe) Linear (average OSI for Oaceania) Linear (average OSI for the Americas) Linear (global OSI average) Linear (average OSI for Africa) Linear (average OSI for Asia) Linear (average OSI for Europe) Linear (average OSI for the Americas) Linear (global OSI average) Linear (average OSI for Africa) Linear (average OSI for Asia) Linear (average OSI for Europe) Linear (average OSI for Oaceania) Linear (average OSI for the Americas) Linear (average OSI for Africa) Linear (average OSI for Asia) Linear (average OSI for Europe) Linear (average OSI for Oaceania) Linear (average OSI for the Americas)

Americas

Africa

Asia

Americas

Europe

Asia

Oceania

Europe

193 UN Member States

Figure 2.9 Values for OSI subindices (IF, CP, SP, TEC and EPI) at the regional and global levels, 2024 Linear (average OSI for Oaceania) Oceania Linear (average OSI for Oaceania) Oceania

0.8079

193 UN Member States

IF

0.8079

Linear (global average OSI)

Linear (global average OSI)

IF

0.6852

Africa

IF

0.6852

Africa

0.6644

0.8079

0.5606

0.8079

0.6644

0.5363

0.6644

0.4919

0.5606

0.5606

0.5363

0.00

TEC

EPI

EPI

0.5363

0.4919

0.00

0.4919

0.00

IF

CP

IF

SP

IF

CP

TEC

CP

SP

EPI

SP

TEC

0.8171

0.6730

0.8171

0.5797

0.8171

0.6730

0.5411

0.6730

0.5797

0.4736

0.5797

0.5411

0.00

TEC

EPI

EPI

IF

CP

IF

SP

IF

CP

TEC

CP

EPI

SP

SP

TEC

TEC

EPI

EPI

0.5411

0.4736

0.00

0.4736

0.00

0.9395

0.8501

0.9395

0.7688

0.9395

0.7263

0.8501

0.8501

0.6642

0.7688

0.7688

0.7263

0.00

0.7263

0.6642

0.00

0.6642

0.00

193 UN Member States

Linear (global average OSI)

<!-- image -->

Europe Linear (global average OSI)

Linear (average OSI for Europe)

Linear (average OSI for Oaceania) Oceania Source: 2024 United Nations E-Government Survey.

193 UN Member States Linear (global average OSI)

193 UN Member States Africa

0.8079

Africa

193 UN Member States Linear (global average OSI)

IF

Africa

1.00

1.00

1.00

1.00

1.00

1.00

1.00

1.00

1.00