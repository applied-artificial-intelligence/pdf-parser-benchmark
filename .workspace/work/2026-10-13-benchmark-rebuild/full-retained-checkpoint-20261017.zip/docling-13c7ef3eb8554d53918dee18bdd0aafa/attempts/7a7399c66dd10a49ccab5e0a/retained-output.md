Figure 2.34 Percentage of countries in special situations that have implemented organizational features of the OSI institutional framework subindex, 2024 Yes No MetrixMetrix Yes No MetrixMet Yes No MetrixMetr Yes No

<!-- image -->

Source: 2024 United Nations E-Government Surveys.

193 UN Member States Policies on open government data, e-participation, artificial intelligence, cloud computing, and protecting the public against misinformation, disinformation and/or fake news are found in about 3 out of 10 LLDCs, 2 out of 10 SIDS, and 1 out 10 LDCs.

Africa

Figure 2.35 Percentage of countries in special situations with legislative frameworks relevant to e-government development, 2024 Americas Very high EGDI High EGDI

Asia

<!-- image -->

Source: 2024 United Nations E-Government Surveys.

193 UN Member States

Africa

Americas

Asia

Europe

Oceania Middle EGDI

LLDCs

Yes No Metrix Yes No MetrixMetrix Yes No

Very high EGDI

High EGDI

Middle EGDI

Low EGDI

Very