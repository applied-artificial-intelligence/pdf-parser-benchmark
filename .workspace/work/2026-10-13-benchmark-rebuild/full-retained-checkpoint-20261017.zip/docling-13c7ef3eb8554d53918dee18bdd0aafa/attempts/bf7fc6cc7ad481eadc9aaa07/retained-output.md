Figure 2.3 Global and regional EGDI averages, 2022 and 2024

<!-- image -->

Sources: 2022 and 2024 United Nations E-Government Surveys.

It is noteworthy that the TII is the highest component index contributing to average EGDI values globally and regionally. This reflects the increased investment in digital infrastructure during the postCOVID-19 pandemic recovery process. Over the past two years, the average TII value has increased by 19.9 per cent globally (see table 2.1). The most significant regional increase is observed in Oceania (29.4 per cent), followed by Africa (27.8 per cent), Asia (25.5 per cent), the Americas (19.6 per cent), and Europe (9.9 per cent). These increases highlight the global emphasis on establishing a strong telecommunications infrastructure as a foundation for digital growth.

Table 2.1 Average global and regional values for the EGDI and its component indices, 2022 and 2024

| Average values for: - 193 UN Member - States   |   Average values for: - 2024 - 2022 |   EGDI - 0.6382 - 0.6102 | EGDI - 4.59%   |   OSI - 0.5754 - 0.5554 | OSI - 3.6%   |   TII - 0.6896 - 0.5751 | TII - 19.9%   |   HCI - 0.6494 - 0.7001 | HCI - -7.2%   |
|------------------------------------------------|-------------------------------------|--------------------------|----------------|-------------------------|--------------|-------------------------|---------------|-------------------------|---------------|
| Africa                                         |                                2024 |                   0.4247 | 4.8%           |                  0.3862 | 5.2%         |                  0.4534 | 27.8%         |                  0.4346 | -12.1%        |
| Africa                                         |                                2022 |                   0.4054 |                |                  0.3670 |              |                  0.3548 |               |                  0.4945 |               |
| Americas                                       |                                2024 |                   0.6701 | 4.1%           |                  0.5797 | 3.8%         |                  0.7345 | 19.6%         |                  0.6962 | -8.3%         |
| Americas                                       |                                2022 |                   0.6438 |                |                  0.5585 |              |                  0.6139 |               |                  0.7590 |               |
| Asia                                           |                                2024 |                   0.6990 | 7.7%           |                  0.6401 | 4.3%         |                  0.7740 | 25.5%         |                  0.6828 | -4.8%         |
| Asia                                           |                                2022 |                   0.6493 |                |                  0.6137 |              |                  0.6166 |               |                  0.7175 |               |
| Europe                                         |                                2024 |                   0.8493 | 2.3%           |                  0.7836 | 1.8%         |                  0.9227 | 9.9%          |                  0.8418 | -4.6%         |
| Europe                                         |                                2022 |                   0.8305 |                |                  0.7699 |              |                  0.8392 |               |                  0.8825 |               |
| Oceania                                        |                                2024 |                   0.5289 | 4.1%           |                  0.4378 | 4.2%         |                  0.4885 | 29.4%         |                  0.6603 | -9.5%         |
| Oceania                                        |                                2022 |                   0.5081 |                |                  0.4201 |              |                  0.3775 |               |                  0.7298 |               |

Sources: 2022 and 2024 United Nations E-Government Surveys.