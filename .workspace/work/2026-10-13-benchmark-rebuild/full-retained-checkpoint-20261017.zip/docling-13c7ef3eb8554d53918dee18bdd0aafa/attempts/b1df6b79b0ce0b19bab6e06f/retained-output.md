Among the countries with high EGDI values, 20 are in the Americas, 17 are in Africa, 14 are in Asia, 7 are in Europe, and 4 are in Oceania. The majority of countries with middle EGDI values are in Africa (28), followed by Oceania (8), Asia (5), and the Americas (3). Among the 11 countries with low EGDI values, 7 are in Africa, 3 are in Asia, and 1 is in the Americas.

All of the countries with low EGDI values in 2022 are still in the same group in 2024, and four other countries have moved from the middle to the low EGDI group.

A more detailed analysis of e-government development at the regional level is provided in chapter 3. Section 2.6 of this chapter includes an analysis of countries in special situations.

## Movement between EGDI groups and rating classes

Twenty-three countries have moved to a higher EGDI group. Ten countries in Asia (Armenia, Azerbaijan, Brunei Darussalam, Indonesia, Kuwait, Mongolia, Philippines, Qatar, Uzbekistan, and Viet Nam), three countries in the Americas (Colombia, Ecuador, and Mexico), two countries in Africa (Mauritius and South Africa), and two countries in Europe (Albania and the Republic of Moldova) have moved from the high to the very high EGDI group (see figure 2.5). Three countries in Africa (Eswatini, Libya, and Senegal), two in Asia (Myanmar and Pakistan), and one in Oceania (Vanuatu) have moved from the middle to the high EGDI group.

Figure 2.5 Movement of countries between EGDI groups during the period 2022-2024, by region (Number of countries)

<!-- image -->

Source: 2024 United Nations E-Government Survey.

These countries have made significant progress in their digital transformation journeys, focusing on enhancing their telecommunications infrastructure, improving online services, and investing in human capital development. They have implemented various strategies and initiatives to boost their digital capabilities, such as expanding broadband access, developing e-government platforms, and promoting digital literacy among their populations. These efforts have been instrumental in their advancement and upward movement in the EGDI rankings.