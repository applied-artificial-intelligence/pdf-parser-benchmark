Figure 2.11 Percentage of countries with legislative frameworks relevant to e-government development, 2024

<!-- image -->

Source: 2024 United Nations E-Government Survey.

## 2.5.4 OSI content provision subindex

In most countries (86 per cent), the Government provides information and services in multiple languages, which strengthens inclusiveness and facilitates access to information and online services in multilingual societies (see figure 2.12). However, fewer than half (47 per cent) proactively share web statistics on usage such as the number of new visits, total page views, or average time spent on site on their national portals. 193 UN Member States Americas Africa Africa (54 countries) 28% 35% Americas (35 countries) 57% 59% Asia (47 countries)

Open government data

information, disinformation or

fake news

48%

28%

Asia Europe 26% E-participation 33% Figure 2.12 Content provision on national portals, 2024 (Percentage of countries, by region)

24%

AI

22%

57%

39%

<!-- image -->

Source: 2024 United Nations E-Government Survey.

193 UN Member States Europ count

74%

52%

61%

59%

Very high EGDI

High EGDI

Middle EGDI

57%