## 2.5.3 OSI institutional framework subindex

The organizational aspects of the institutional framework, which orient users on engaging government agencies through the online platforms, are well developed across the board (see figure 2.10). All Member States except Belize* have fully operational national portals. The vast majority of countries (95 per cent) make the government organizational chart and information on the government structure available on these portals, 91 per cent provide the names and titles of the heads of government agencies, departments and ministries, 81 per cent furnish information on the national chief information officer (CIO) or the equivalent, and 75 per cent share links to subnational or local government agencies. More than 90 per cent of the countries have national portals that provide links to ministerial websites and offer sources of information on sector-specific policies.

Figure 2.10 Percentage of countries addressing various aspects of the institutional framework, 2024

<!-- image -->

Sources: 2024 United Nations E-Government Survey.

The legislative, policy and strategy aspects of the institutional framework are less consistently developed (see figure 2.11). Between 81 and 83 per cent of countries have national e-government strategies, policies or legislation on cybersecurity, data privacy, and data protection, 78 per cent require citizens to use a digital ID when accessing public services, and 76 per cent offer public access to legislation on the right of citizens to access government information. The shares are lower for legislation or policies on open government data (63 per cent), e-participation (51 per cent), protecting the public against misinformation, disinformation, and/or fake news (47 per cent), and frontier technologies such as cloud computing (44 per cent) and artificial intelligence (42 per cent). Regional disparities are more pronounced for these last five indicators; more than half of the countries in Asia and Europe have already adopted relevant legislation, policies or strategies, the average for the Americas is slightly above 30 per cent and that for Africa slightly below 30 per cent, and in Oceania the compliance rates range from 4 to 11 per cent.

Very high EGDI

High EGDI

Middle EGDI

Low EGDI

EDGI 2024 levels

Very high EGDI

High EGDI

Middle EGDI

Low EGDI

* At the time of the assessment for the Survey, the national portal of Belize was under review and inaccessible. To the extent possible, the assessment was conducted through various ministerial website