Figure 4.7 Implementation of content provision indicators in city portals: sectoral information

<!-- image -->

of the assessed portals, signaling an area in need of improvement. The availability of municipality budget information has improved but remains suboptimal at just under 58 per cent. More than two thirds of the city portals assessed now provide access to sports and cultural information and resources. The Government of Singapore 12 offers a range of online services to support immigrants, fostering community integration and cultural acclimatization. The portal includes resources such as Your Neighbourly Welcome Guide, which offers new residents insights into local culture and encourages community bonding by sharing stories from established residents. The suite of available programmes includes home visits, community learning activities, and the Singapore Citizenship Journey, culminating in a formal citizenship ceremony. Additionally, the portal features forums for residents to share opinions and facilitates annual meetings, allowing new immigrants to actively contribute to and benefit from community activities.

Figure 4.8 Implementation of content provision indicators in city portals: addressing everyday needs

<!-- image -->