The availability of public transportation information and services on city portals reflects a commitment to enhancing urban mobility and reducing traffic congestion. Cities recognize the importance of providing residents with convenient access to public transportation timetables, route maps, fare information, and payment options. By offering these services online, cities aim to improve the overall efficiency and accessibility of public transportation systems, encourage the use of sustainable transportation modes, and reduce reliance on private vehicles.

Figure 4.10 Implementation of services provision indicators in city portals

<!-- image -->

## Participation and engagement

As illustrated in figure 4.11, compliance rates for most of the LOSI participation and engagement indicators increased between 2022 and 2024. There has been notable progress made in feedback/ complaint submission, information on the public meetings of the municipal council, and participatory budgeting. Other indicators, such as e-voting, reporting incidents in public spaces, participatory land use planning, online deliberation processes, feedback on consultation processes, and announcing upcoming e-participation activities, have seen slight to moderate increases or have remained stable over the two-year period.

60%