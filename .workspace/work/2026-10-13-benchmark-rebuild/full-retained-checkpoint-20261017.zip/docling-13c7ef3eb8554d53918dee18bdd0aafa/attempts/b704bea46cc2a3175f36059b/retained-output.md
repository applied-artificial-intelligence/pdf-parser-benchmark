## E-participation in countries in special situations

Consistent with global trends, e-participation values remain the lowest among the five OSI subindices for countries in special situations. This is a clear indication that these countries are facing broad challenges in engaging citizens through digital platforms, which is crucial for inclusive and participatory governance. Enhancing e-participation in these regions will require not only investments in technology but also significant cultural and policy shifts to encourage and facilitate citizen engagement. Over the years UN DESA implemented and continues to support countries with various capacity building initiatives in the areas of digital government, participation and accountability, innovation and delivery of public services that contribute to the achievement of sustainable development goal 16 9 .

## Open government data (OGD)

Group averages indicating the proportion of countries in special situations that share information through dedicated OGD portals are comparable to the corresponding global average; between 63 and 81 per cent of the countries in the respective groups maintain OGD portals, and 50 to 68 per cent provide geospatial data. Most countries in these groups also share information about government expenditures, often in open formats. However, only 3 out of 10 countries in special situations allow members of the public to request or propose new open data sets, compared to about 5 in 10 countries at the global level. More than 70 per cent of LDCs, LLDCs and SIDS have not yet adopted open data licensing, and events such as hackathons around open data use are rare. Most OGD are not available in real time, and fewer than 2 in 10 countries have participatory budgeting mechanisms (see figure 2.36). Yes Machine-readable No Yes Machine-readable No Yes Machine-readable No Yes Machine-readable No

Figure 2.36 Percentage of countries in special situations with OGD portals and various aspects of open data governance

<!-- image -->

Source: 2024 United Nations E-Government Survey.

Note: The availability of OGD in machine-readable formats is indicated by the lighter shades of the same colours in the regional performance graphs.

* The availability of OGD in real time for both machine-readable and non-machine-readable data sets.

193 UN Member States

Africa

Americas

Asia

Europe

Oceania SIDS

LDCs Very high EGDI

High EGDI

Middle EGDI

Low EGDI

LLDCs LDC/LLDCs LDC/SIDS

EDGI 2024 levels

Very high EGDI

High EGDI

Very hi

High E

Middle