Cs IF

CP

SP

TEC

EPI

Figure 2.33 Average OSI subindex values for groups of countries in special situations relative to global averages, 2024

0.8079

0.6644

0.5606

0.5363

0.4919

0.00

LLDCs

IF

CP

SP

TEC

EPI

0.7725

0.5938

0.4680

0.4668

0.3960

0.00

SIDS

IF

CP

SP

TEC

EPI

0.6746

0.5075

0.4038

0.3902

0.3081

0.00

LDC/LLDCs

<!-- image -->

Source: 2024 United Nations E-Government Surveys.

Linear (global average OSI)

Linear (global average OSI)

Linear (average OSI for LDC/LLDC)

F

F

Overall, the legislative framework for advancing e-government is better developed in LLDCs, including those that are least developed, than in SIDS or LDCs (see figure 2.35). Most LLDCs have an e-government or digital government strategy (78 per cent), legislation or policy documents on cybersecurity (91 per cent), legal provisions for data protection (88 per cent), legislation governing freedom of information (78 per cent), and digital ID regulations (72 per cent). Fewer SIDS and LDCs (51 to 65 per cent) have these types of legislation in place, and the proportions are even lower for LDC/SIDS (between 13 and 65 per cent, depending on the type of legislation). Yes No Metrix Yes No Metrix Yes No Metrix Yes No Metrix Yes No Metrix SIDS LDCs LLDCs LDC/LLDCs LDC/SIDS Linear (average OSI for LDC/LLDC) Yes No Metrix Yes No Metrix Yes No Metrix Yes No Metrix Yes No Metrix SIDS LDCs LLDCs LDC/LLDCs LDC/SIDS

Africa

Americas

Asia

Europe

Oceania Africa Americas Asia Europe Oceania Very high EGDI

Very high EGDI

High EGDI

High EGDI

Middle EGDI

Middle EGDI

Low EGDI

Low EGDI

1.00

1.00

1.00