Chapter 5. Exorbitant Privilege
Figure 5.6. Poor countries finance the privilege throughasymmetric portfolios

Bottom 20% 20−40% 40−60% 60−80% Top 20%

0%
10%
20%
30%
40%
50%
60%
70%
80%
90%

100%

A L A L A L A L A L

1970–1999
Bottom 20% 20−40% 40−60% 60−80% Top 20%

0%
10%
20%
30%
40%
50%
60%
70%
80%
90%

100%

A L A L A L A L A L

2000–2025

Debt Equity FDI Reserves

Interpretation. This figure shows the decomposition of foreign assets (A) and liabilities (L) across country
income groups in two periods: 1970–1999 and 2000–2025. Rich countries (top 20%) hold fewer foreign
exchange reserves and issue fewer foreign direct investment (FDI) liabilities, both of which are low−return
components. Instead, they have increased their share of equity and FDI assets, which typically yield higher
returns. On the liability side, they continue to rely on debt issuance, which is safer and lower−cost due to their
strong credit ratings and reserve currency status. In contrast, poorer countries (bottom 80%) have portfolios
skewed toward reserves as assets and FDI as liabilities, both associated with lower net returns. Sources and
series: Nievas and Sodano (2025) and wir2026.wid.world/methodology.

Decomposition of assets (A) and liabilities (L)

Figure 5.7. Poorer countries face lower asset returns and higherliability costs

0%
1%
2%
3%
4%
5%
6%
7%
8%
9%

10%
11%

1980 1990 2000 2010 2020

A
ve

ra
ge

 r
et

ur
n 

pe
r 

in
co

m
e 

 g
ro

up
 (

%
),

 M
E

R

World

Bottom 20%

20%−40%

40%−60%

60%−80%

Top 20%

Returns on foreign assets

0%
1%
2%
3%
4%
5%
6%
7%
8%
9%

10%
11%

1980 1990 2000 2010 2020

World

Bottom 20%

20%−40%

40%−60%

60%−80%

Top 20%

Returns on foreign liabilities

Interpretation. These two panels compare the average return on foreign assets (left) and liabilities (right)
across countries grouped by per capita income levels. The top 20% richest countries consistently achieve higher
returns on their assets abroad, while facing lower average returns on their liabilities. In contrast, the bottom 80%
of countries not only face lower returns on assets but also pay significantly higher returns on liabilities. Only the
top 20% have managed to reduce liability costs significantly. All of this results in a positive return differential for
the richest countries and a negative differential for poorer countries, structurally transferring income from poor to
rich through global financial flows. Sources and series: Nievas and Sodano (2025) and
wir2026.wid.world/methodology.

Return to foreign assets and liabilities, 1970−2025

110