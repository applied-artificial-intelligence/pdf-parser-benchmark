86 

Figure 3.1 Proportion (%) of women in the EU among total employment, population of tertiary-

educated HRSTCs, and population of S&Es, 2017-2021 

 

Source: Eurostat – EU-LFS (online data code: lfsa_egan) & Human Resources in science and technology (online data 

code: hrst_st_ncat). 

Notes: Age group: 25-64 (for all indicators). Blue shading indicates gender balance (i.e. where women comprise between 

40 % and 60 % of a given population). 

 

 

 

  

53.3% 53.5% 53.7% 54.0% 54.1%

40.5% 41.0% 41.3% 41.2% 40.7%

46.0% 46.1% 46.2% 46.2% 46.4%

0%

10%

20%

30%

40%

50%

60%

2017 2018 2019 2020 2021

Gender 
balance 

Tertiary educated and 
employed as professionals 
or technicians (HRSTC) 

Employed scientists 
and engineers 

Total 
employment