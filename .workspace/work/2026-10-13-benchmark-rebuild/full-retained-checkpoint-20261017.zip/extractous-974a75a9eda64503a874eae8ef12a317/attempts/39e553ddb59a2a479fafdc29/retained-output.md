Clean Energy Market Monitor – March 2024  

PAGE | 19  

Clean energy deployment 

IE
A.

 C
C

 B
Y 

4.
0.

 

Electric car sales and avoided emissions 

  
IEA 2024. CC BY 4.0. 

Notes: “Avoided emissions” refers to avoided emissions in one year from cumulative deployment since 2019 to 2023.  

2.2 3.0

6.5

10.2

13.7

 5

 10

 15

2019 2020 2021 2022 2023

World

M
illi

on
 u

ni
ts

22

15

14

3

7

 10  20

China

United States

European Union

United Kingdom

Rest of world

Avoided emissions

Mt CO₂

1.1 1.1

3.3

6.0

8.1

 3

 6

 9

2019 2020 2021 2022 2023

China

M
illi

on
 u

ni
ts

0.3 0.3

0.6

1.0

1.4

0.5

1.0

1.5

2019 2020 2021 2022 2023

United States

M
illi

on
 u

ni
ts

0.4

1.0

1.7
2.0

2.4

 1

 2

 3

2019 2020 2021 2022 2023

European Union

M
illi

on
 u

ni
ts

1 3 12

48

82

 30

 60

 90

2019 2020 2021 2022 2023

India
Th

ou
sa

nd
 u

ni
ts