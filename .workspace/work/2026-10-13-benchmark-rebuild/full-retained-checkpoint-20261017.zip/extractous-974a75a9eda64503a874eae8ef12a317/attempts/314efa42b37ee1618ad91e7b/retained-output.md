 31 

OECD ECONOMIC OUTLOOK, VOLUME 2025 ISSUE 2 © OECD 2025 
  

• The Mexican economy is projected to recover slowly as inflation eases and further cuts to policy 

rates take effect. However, higher tariffs on exports to the United States and weak public demand 

are headwinds to growth, with real GDP projected to rise by 0.7% in 2025, 1.2% in 2026 and 1.7% 

in 2027. In Brazil, growth is anticipated to weaken in the near-term as investment slows in response 

to higher interest rates, though monetary policy easing through 2026 will support activity. After 

easing from 2.4% in 2025 to 1.7% in 2026, output growth is projected to recover to 2.2% in 2027. 

Global trade growth for 2025 is now expected to be 4.2%, reflecting stronger than expected front-loading 

in the first half of the year. This is being unwound only partially given the momentum of investment- and 

tech-related trade through 2025. Nonetheless, trade growth is projected to moderate to 2.3% in 2026 as 

the full effects of higher tariffs are felt, before recovering to 2.8% in 2027 as growth picks up. 

The composition of trade growth is different to the pre-pandemic period (Figure 1.18, Panel A), with the 

emerging-market economies accounting for a larger share, even as all regions grow more slowly. In 

particular, the share of trade accounted for by the South-East Asian economies is expected to rise in 

2026-27. In contrast, the contribution of China is projected to weaken slightly, as trade growth slows, and 

the contribution of advanced economies to global trade growth is expected to decline, especially that of 

Europe and the North American economies.  

Figure 1.18. Trade patterns are evolving with emerging markets becoming a key driver of growth  

 
Note: North America includes Canada, Mexico and the United States. Europe includes the 22 OECD countries which are members of the 

European Union, plus Iceland, Norway, Switzerland, Türkiye and the United Kingdom. South-East Asian economies include Hong Kong (China), 

Malaysia, the Philippines, Singapore, Chinese Taipei, Thailand, and Viet Nam. Other advanced economies include Australia, Israel, Japan, 

Korea and New Zealand. Statistical discrepancies mean that current account balances based on national data rarely equal zero at the world 

level.  

Source: OECD Economic Outlook 118 database; and OECD calculations.  

StatLink 2 https://stat.link/mhq1ks 

Global current account balances are projected to decrease slightly as a share of global GDP over the next 

two years (Figure 1.18, Panel B). In the United States, lower imports and reduced remittances linked to 

international migration, and continued strong growth in tech-related exports and services help to reduce 

the current account deficit from 2024 levels, despite a decline in export market performance. China’s 

continued export growth, coupled with weak domestic demand and a continued policy orientation towards 

import substitution is projected to result in a higher external surplus. Sizeable surpluses are also projected 

to persist in Germany, Japan, Korea and a number of smaller economies, including Denmark, Ireland, the 

Netherlands, Norway, Sweden, Switzerland and Thailand. There is little change in the current account 

surplus in the euro area as a whole.  

https://stat.link/mhq1ks