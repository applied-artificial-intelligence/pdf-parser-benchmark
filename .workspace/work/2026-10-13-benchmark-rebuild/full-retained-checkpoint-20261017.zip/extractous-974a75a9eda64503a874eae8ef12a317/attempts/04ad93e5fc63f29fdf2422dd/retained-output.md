REUTERS INSTITUTE FOR THE STUDY OF JOURNALISM / EXECUTIVE SUMMARY GRAPHS

Graph 28

PROPORTION WHO SAY EACH ACCESS POINT IS THEIR MAIN 
GATEWAY TO ONLINE NEWS (2018–22) – ALL MARKETS

Q10a. Thinking about how you got news online (via computer, mobile, or any device) in the last 
week, which of these was the **MAIN** way in which you came across news? Base: All markets 
2018–22 and total sample in each market (n ≈ 2000). Note: Number of markets grew from 37 in 2018 
to 46 in 2021–22.

32% 

23% 23%
28%

0%

25%

50% Social media access

Direct access to websites/apps

 20222021202020192018

Direct access to websites/apps Social media access

MAINLY DIRECT

Finland 65%

Norway 59%

UK 46%

MUCH LESS DIRECT

South Korea 5%

Brazil 11%

Mexico 11%

MAINLY SOCIAL

Thailand 59%

Philippines 51%

Kenya 51%

MUCH LESS SOCIAL

Japan 9%

Sweden 10%

Finland 11%

This year, we revived a question about how different groups access 
news first thing in the morning to give a sense of how news habits 
have changed since 2019. The next chart shows striking differences 
between countries. In Norway, Spain, Finland, and the UK, the 
smartphone is now the go-to route to news in the morning, with 
dependence on it growing substantially in the last three years. 
Radio remains an important part of morning routines in Ireland 
– even though it has been overtaken by the smartphone for the first 
time. Morning newspaper reading is still surprisingly popular in the 
Netherlands and Finland. Television remains a key influence in the 
US, France, and Italy and is the dominant medium in Japan. 

Across countries, almost half of under 35s (47%) say they accessed 
news first using a smartphone, compared with just a quarter (28%) 
of those aged 35 and older and just 15% of those aged 65 and older. 
Japan’s older population may explain why it is bucking wider trends. 

But what channels do people use when accessing news on a 
smartphone at the start of each day? Since 2019, we find that, 
across countries, social media (39%) have overtaken websites and 
apps (31%), followed by the smartphone home screen (12%) and 
aggregator apps like Apple News (9%). 

Main gateways to digital news 

We continue to monitor the main access points to online news, 
not just via a smartphone and not just first thing in the morning. 
Across all devices, our data show direct access to apps and 
websites becoming less important over time and social media 
becoming more important, partly due to their ubiquity and 
convenience. At an aggregate level, we have reached something 
of a tipping point this year, with social media preference (28%) 
surging ahead of direct access (23%). But these are cross-market 
averages and there are major differences between markets. 
Audiences in Nordic countries and the UK still have strong direct 
connections, while people in Japan and South Korea tend to 
access news via powerful aggregators and search engines – relying 
less on direct access. These differences, which we can perhaps 
treat as a proxy for the strength of news brands in a digital world, 
help explain why it may be easier to charge for online news in 
some countries and not others. 

REUTERS INSTITUTE FOR THE STUDY OF JOURNALISM / EXECUTIVE SUMMARY GRAPHS

Graph 27

0% 25% 50%

43

39

38

36

35

35

26

29

25

24

13

24

32

21

15

21

24

29

27

45

16

15

11

12

31

17

14

7

23

3

5

3

3

10

3

4

13

3

3

8

Japan

France

USA

Netherlands

UK

Ireland

Finland

Italy

Spain

Norway

PROPORTION WHO SAY EACH DEVICE IS THEIR FIRST WAY OF 
ACCESSING NEWS IN THE MORNING – SELECTED MARKETS

Q9c_new2016. What is the FIRST way you typically come across news in the morning? Base: Total 
sample in each market (n ≈ 2000).

Print Radio TV Smartphone

Was 44% 
in 2019

Was 27% 
in 2019

Was 28% 
in 2019

Was 31% 
in 2019

Was 27% 
in 2019

Was 26% 
in 2019

Was 32% 
in 2019

TV 
first

Mobile 
first

Reuters Institute for the Study of Journalism   |   Digital News Report 2022 23