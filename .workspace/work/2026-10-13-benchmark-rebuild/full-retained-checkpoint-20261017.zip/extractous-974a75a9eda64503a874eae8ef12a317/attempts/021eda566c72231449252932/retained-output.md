Among our sample, expectation of de-
motorization is not widespread; it is limited 
to Western Europe and densely populated 
areas in Asia (e.g., Singapore and Hong Kong). 
Expected de-motorization is essentially a 
wealthy, urban phenomenon, with high-quality 
public transportation a prerequisite. Three-
quarters (76%) of those in European cities with 
a population of over 5 million are prepared to 
give up their car, compared to 62% in towns with 
under 250,000 people. ADL’s “Future of Mobility” 
city ranking3 is led by cities such as Singapore, 
Stockholm, Amsterdam, and Copenhagen, 
which have highly mature, cost-effective public 
transport and strong support for alternative 
mobility types like cycling. 

Relatedly, there is an inverse correlation 
between city size and car usage. In cities 
with over 250,000 inhabitants, around half 
of respondents drive under 6,000 km a year. 
In smaller towns and suburban environments 
(under 250,000), people who drive between 
6,000 and 15,000 km are the majority. Two-thirds 
(67%) of those in towns with a population of 
under 10,000 drive over 6,000 km each year.

Young people expect the importance of having 
a car to be higher in 10 years, even in mature 
markets such as Europe and North America. Only 
the older age group (over 45) in Europe and North 
America expect to de-motorize as they age  
(refer back to Figure 3).

3 Van Audenhove, François-Joseph, et al. ”Future of Mobility 3.0: Reinventing Mobility in the Era of Disruption and Creativity.” Arthur D. Little, March 
2018.

WHAT DO DRIVERS WANT  
IN THEIR NEXT CAR?

When deciding on their next vehicle, customers 
in mature markets are much more likely 
to choose a used car compared to those in 
emerging regions, such as China and India  
(see Figure 4). This is partly aspirational in terms 
of a desire to own a new vehicle but is also due 
to the availability of quality used vehicles. 
Mature markets have a plentiful supply of a 
broad range of used cars, often sourced from a 
well-developed leasing market and backed by a 
trusted used vehicle distribution brand. These 
conditions drive higher trust in the quality of 
used vehicles and in used car sales channels.

C U S T O M E R S  I N  M AT U R E 
M A R K E T S  A R E  M U C H 
M O R E  L I K E LY  T O  C H O O S E 
A  U S E D  C A R  C O M PA R E D 
T O  T H O S E  I N  E M E R G I N G 
R EG I O N S

Figure 4. Future car ownership plans

Note: To facilitate the reading of this Report, where numbers are more than 20% above the global average, we highlight them in black/white bold. 
Where they are more than 20% below, we highlight them in red bold.  
Source: Arthur D. Little

Note: To facilitate the reading of this Report, where numbers are more than 10% points above the global average, we highlight them in 
black/white bold. Where they are more than 10% points below, we highlight them in red bold.
Source: Arthur D. Little

Figure 4. Future car ownership plans

78%
96% 90% 89% 84%

52% 61%
75%

17% 7% 10%

36%
32%

20%

1%
4%

Buy new car Buy used car Private leasing Company car Private car subscription Shared mobility service Other modes of transport

What is your plan regarding car ownership and/or use for your next car?

Global China SEA India ME Europe US NEA

1 0

R E P O R T:  T H E  F U T U R E  O F  A U T O M O T I V E  M O B I L I T Y,  2 0 2 4

https://www.adlittle.com/sites/default/files/viewpoints/adl_uitp_future_of_mobility_3.0_1.pdf