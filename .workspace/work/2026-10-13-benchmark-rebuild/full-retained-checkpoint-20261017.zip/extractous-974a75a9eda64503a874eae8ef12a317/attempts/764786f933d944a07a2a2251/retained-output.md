 17 

OECD EMPLOYMENT OUTLOOK 2024 © OECD 2024 
  

Infographic 1. Key facts and figures 

Cumulative % change in real wages between Q4 2019

and Q1 2024

The OECD-wide employment is expected to increase, but

growth is projected to slow from 1.7% in 2023 to around

0.7% per year over 2024-25.

In Q1 2024, yearly real wage growth was positive in 29 of the

35 countries for which data are available. However, real

wages were still below their Q4 2019 level in 16 of them.

20% of workers are in green-driven jobs (incl. jobs that support

‘green’ activities). Adding jobs in high-emission industries

means that over 25% of all jobs are set to be significantly

impacted by the net-zero transition.

More than a quarter of jobs will be

strongly impacted by net-zero transition

100

110

120

130

2000 2005 2010 2015 2020 2025

Projections

High emission industries represent a

small share of overall employment

% of total greenhouse gas (GHG) emissions and total

employment of high emission industries, 2019

% loss of earnings compared to non-displaced workers Required skill level

% among
total employment

High emission industries account for almost 80% of

GHG emissions, but represent only about 7% of

overall employment.

Workers in high-emission industries who lose their jobs

experience an average drop in annual earnings of 36%

over six years, compared to 29% in other industries.

Skill similarities across jobs make transitions feasible for all

workers, although low-skilled adults need more retraining.

Real wages are growing but remain below

pre-COVID levels in many OECD countries

Employment growth remains strong

but expected to slow

OECD-wide employment, index base 100 in 2000

Reskilling is key for moving away from

emission-intensive occupations

The cost of losing jobs in high-emission

industries is substantial

Green-driven jobs

GHG-intensive jobs

New green-driven jobsGHG-intensive jobs

Low-skill occupations

High-skill occupations

-60%

-40%

-20%

0%

-2 -1 0 1 2 3 4 5 6

0 10 20 30 40

Poland

Australia

OECD

Japan

Germany

US

-6 -4 -2 0 2 4 6 8 10

Poland

Portugal

UK

US

Germany

Spain

Australia

Problem solving

Social skills

Problem solving

Social skills

Very low Very high

Share of employment Share of emissions

7% 79%

Year relative to job loss

Low-emission industries

High-emission industries