176    

 

DO ADULTS HAVE THE SKILLS THEY NEED TO THRIVE IN A CHANGING WORLD? © OECD 2024 
  

Prevalence of under-skilling related to digital skills 

The 2023 Survey of Adult Skills included a new question on the types of skills that under-skilled workers 

feel they would need to improve to be well-matched to their jobs (Box 4.3). On average across participating 

OECD countries and economies, 42% of under-skilled respondents feel they need to improve their 

computer and software skills (see Table A.4.13 in Annex A). This is significantly more than for any other 

type of skill – perhaps an indication of the rapid changes to labour markets being brought about by artificial 

intelligence and digitalisation, and the urgency with which respondents feel they need to keep abreast with 

these trends. Other skills such as project management and organisational skills (26%), communication 

and presentation skills (26%), and teamwork or leadership skills (24%) are also cited by respondents as 

areas they most need to develop (see Table A.4.13 in Annex A).  

However, after taking into account the overall share of under-skilled respondents, the share of all workers 

stating that they lack sufficient computer and software skills is only 4% across OECD countries and 

economies. Japan (12%), Estonia (12%), Finland (11%) and Norway (10%) have the highest overall 

proportions of workers who lack the digital skills required for their current jobs (Figure 4.16). This is largely 

because these countries have higher shares of self-reported under-skilling. Cross-country differences 

reflect both the supply of skills (i.e. individuals already have strong digital skills) and the demand for such 

skills in the labour market (i.e. their jobs may not yet require advanced digital skills). Therefore, high levels 

of self-reported under-skilling may indicate not only a skill gap but also a greater awareness and desire to 

improve, highlighting the continued need for countries to invest in digital upskilling and training initiatives 

to keep pace with technological progress. 

Figure 4.16. Share of workers reporting inadequate computer and software skills for their job 

Employed adults aged 25-65 who are not self-employed  

 

Note: Does not include adults who were only administered the doorstep interview due to a language barrier (see Box 1.1 in Chapter 1 and 

Box 4.1). Figure plots the share of respondents who answered, "Some of my skills are lower than what is required by my job and need to be 

further developed," to the question, "Overall, which of the following statements best describes your skills in relation to what is required to do your 

 ob?", and marked “Computer and software skills” in response to the question, “Which skills were you thinking of when you answered this 

question?”.  Caution is required in interpreting results due to the high share of respondents with unusual response patterns. See the Note for 

Poland in the Reader’s Guide. 

Countries and economies are ranked in descending order of the share of all workers reporting inadequate digital skills. 

Source: Tables A.4.12 and A.4.13 in Annex A. 

 
a
p
a
n

E
s
to
n
ia

F
in
la
n
d

 
o
rw

a
y

S
w
e
d
e
n

 
e
w
  
e
a
la
n
d

S
in
g
a
p
o
re

G
e
rm

a
n
y

 
e
n
m
a
rk

F
le
m
is
h
 R

e
g
io
n
 (
 
E
 

 
o
re
a

 
e
th
e
rl
a
n
d
s

 
E
C
 
 a
v
e
ra

g
e

 
a
t 
ia

 
it
h
u
a
n
ia

U
n
it
e
d
 S

ta
te
s

Ir
e
la
n
d

C
a
n
a
d
a

C
h
ile

E
n
g
la
n
d
 (
U
 
 

C
 
e
c
h
ia

P
o
rt
u
g
a
l

F
ra
n
c
e

S
p
a
in

S
w
it
 
e
rl
a
n
d

H
u
n
g
a
ry

A
u
s
tr
ia

S
lo
 
a
k
 R

e
p
u
b
lic

It
a
ly

Is
ra
e
l

C
ro
a
ti
a

P
o
la
n
d
 

1 

12

10

8

 

 

2

0