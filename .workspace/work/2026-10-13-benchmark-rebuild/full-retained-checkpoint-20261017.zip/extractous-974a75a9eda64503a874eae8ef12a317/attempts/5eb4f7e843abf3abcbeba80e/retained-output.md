Resource Mix Changes 

2024 Long-Term Reliability Assessment  
27 

Solar PV Distributed Energy Resource Growth 
Behind-the-meter (BTM) solar PV generators are solar PV resources connected on the distribution 
system, such as residential rooftop solar systems. The rapid growth of BTM solar PV continues with 
cumulative levels expected to reach over 123 GW by the end of this 10-year assessment period (up 
from 89 GW reported in the 2023 LTRA, an increase of 38%). There are currently 58.7 GW of installed 
BTM solar PV across the North American BPS.  
 
BTM solar PV generators, like grid-connected solar PV, are also VERs. In large penetrations, their 
predictable change in output from the time of day contributes to steep ramps in demand. As the sun 
sets and output diminishes, grid resources must make up for the decrease in solar generation and 
increase in demand that was being served. The opposite ramp occurs during morning hours; it may 
be less impactful to reliability but can be challenging for grid-connected generator scheduling and 
dispatch. Figure 13 shows the current and projected BTM solar PV by area through 2034. 
 

 
Figure 13: Solar PV DER Capacity Existing and Planned through 2034 

 

Generation Retirements 
The total capacity of traditional baseload generation fuel types will continue to decline as older 
generators retire. Generators become confirmed for retirement according to various processes in 
place in the Interconnections, such as regional planning tariffs in the wholesale electricity market 
areas or the integrated resource planning process in vertically integrated states. Properly designed 
mechanisms can prevent generators from retiring before planners can study and address reliability 
issues that could occur.  
 
Currently, over 79 GW of fossil-fired and nuclear generating capacity is being retired over this 
assessment period (see Figure 14), a small decrease from the 83 GW in retirements reported in the 
2023 LTRA. This capacity includes generators that are confirmed for retirement through retirement 
planning processes or that have indicated plans to retire to an ISO/RTO or Planning Coordinator.  

 
Figure 14: Projected Generation Retirement Capacity through 2034 

 
Additional fossil-fired generator retirements are expected and would result in further loss of existing 
capacity. Generator Owners often announce plans to retire generator units before initiating the 

2023 LTRA Total 
Retirements 

…