Operating Cash Flow ($B)
Free Cash Flow ($B)

K E Y M E T R I C S T R A I L I N G 1 2 M O N T H S ( T T M )
(Unaudited)

Net Income ($B)
Adjusted EBITDA ($B)

Vehicle Deliveries 
(millions of units)

27

0.0

0.2

0.4

0.6

0.8

1.0

1.2

1.4

1.6

1.8

2.0

1Q
-2

02
2

2Q
-2

02
2

3Q
-2

02
2

4Q
-2

02
2

1Q
-2

02
3

2Q
-2

02
3

3Q
-2

02
3

4Q
-2

02
3

1Q
-2

02
4

2Q
-2

02
4

3Q
-2

02
4

4Q
-2

02
4

0

2

4

6

8

10

12

14

16

18

20

1Q
-2

02
2

2Q
-2

02
2

3Q
-2

02
2

4Q
-2

02
2

1Q
-2

02
3

2Q
-2

02
3

3Q
-2

02
3

4Q
-2

02
3

1Q
-2

02
4

2Q
-2

02
4

3Q
-2

02
4

4Q
-2

02
4

0

2

4

6

8

10

12

14

16

18

20

1Q
-2

02
2

2Q
-2

02
2

3Q
-2

02
2

4Q
-2

02
2

1Q
-2

02
3

2Q
-2

02
3

3Q
-2

02
3

4Q
-2

02
3

1Q
-2

02
4

2Q
-2

02
4

3Q
-2

02
4

4Q
-2

02
4