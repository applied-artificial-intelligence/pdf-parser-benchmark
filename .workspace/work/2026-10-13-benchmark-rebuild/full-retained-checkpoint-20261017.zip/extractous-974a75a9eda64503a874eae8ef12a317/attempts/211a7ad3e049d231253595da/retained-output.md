Verisk 2025 Global Modeled Catastrophe Losses 18 | © 2025 Verisk Analytics, Inc. All rights reserved. / verisk.com

It’s not yet clear whether regional environmental trends have specific causes.  
The amplitude and pattern of some regional trends align with expected end-of-the-
century impacts from global warming. However, this amplitude is larger than expected 
by the emerging understanding of how greenhouse gases would eventually affect severe 
thunderstorms in the long term. Some of these trends may reflect inherent variability in 
the ocean and atmosphere that spans decades. For instance, regional trends in severe 
thunderstorm environments show no global consistency that  
would point to a common cause.

The share of risk from frequency perils is increasing primarily because  
recent activity offers new data and clarity about elevated risk in certain 
geographic corridors. 

Verisk peril models reflect the state of the science from two perspectives: 
leveraging a variety of limited data sources and incorporating a process-level 
understanding of peril activity. This informs our view of near-present climate 
around the globe—that surprisingly persistent regional environmental factors 
drive elevated losses from frequency perils, thus complicating the discussion 
of how climate change affects trends in modeled catastrophe hazards.

12% increase in the contributions  
of frequency perils to the total 
modeled risk from 2025 over 2024

Note: 2024 USD adjusted for inflation and exposure growth. Some severe thunderstorm  
and winter storm events may also include losses from inland flood. 

Figure 4. Comparison of insured losses exceeding $1 billion by peril  
between 2015–2019 and 2020–2024 (Source: Verisk, Aon, Swiss Re)

Tropical Cyclone

Earthquake

Severe Thunderstorm

Winter Storm

Wildfire

Inland Flood