8

2025 Global Automotive Consumer Study | Key Findings: Global Focus Markets

Home Work On-street/public charging station Other

UK

80%

10%

11%

10%

11%

US

79%

Japan

72%

Germany India China Southeast Asia Rep. of Korea

2%

13%

14%

70%

18%

12%

63%

22%

15%

62%

28%

10%

61%

21%

17%

71%

20%

9%

Yes, dedicated Yes, shared with a neighbor/others No Don’t know

China

77%

15%

7%

India

41%

44%

US

40%

Germany UK Southeast Asia Japan

14%

58%

2%

33%

62%

5%

32%

58%

8%

28%

65%

4%

Rep. of Korea

19%

7%

25%

37%

56%

6%

1% 1% 1% 2% 2%

50%

The push to create public charging capacity may be somewhat overstated in many markets as a 
strong majority of EV intenders surveyed plan to charge their vehicle at home.

Expecting to charge electrified vehicle most often at…

Yet, many EV intenders surveyed in mature markets that plan to charge at home do not currently 
have access to a charger.

EV charger access among consumers who plan to charge their vehicle at home

Note: Percentages may not add up to 100 due to rounding.     
Q43. Where do you expect to charge your EV most often?
Sample size: n = 413 [China]; 304 [Germany]; 182 [India]; 64 [Japan]; 166 [Republic of Korea]; 1,223 [Southeast Asia]; 245 [UK]; 111 [US]

Note: Percentages may not add up to 100 due to rounding.  
Q44. Do you already have access to a charger at your residence?
Sample size: n = 260 [China]; 215 [Germany]; 128 [India]; 46 [Japan]; 102 [Republic of Korea]; 755 [Southeast Asia]; 195 [UK]; 88 [US]