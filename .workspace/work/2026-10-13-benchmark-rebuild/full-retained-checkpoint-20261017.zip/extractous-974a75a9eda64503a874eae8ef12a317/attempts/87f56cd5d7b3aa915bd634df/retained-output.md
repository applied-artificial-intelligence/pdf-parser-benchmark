 21 

OECD EMPLOYMENT OUTLOOK 2024 © OECD 2024 
  

Non-wage aspects of jobs also need to be monitored to understand trends in job quality in the wake of the 

COVID-19 pandemic and the recent cost-of-living crisis. Drawing on the conceptual framework developed 

by the OECD (Cazes, Hijzen and Saint-Martin, 2015[1]; OECD, 2014[2]) and then adopted by the G20 (G20, 

2015[3]), the chapter also provides an update on the three key indicators of job quality across countries – 

earnings quality, labour market security and quality of the working environment. 

The chapter is organised as follows: Section 1.1 reviews recent labour market developments across the 

OECD countries; Section 1.2 reports on recent wage developments, including an update on statutory 

minimum wages and negotiated wages; and finally, Section 1.3 presents the latest 

OECD job quality indicators and analyses trends in these indicators since 2015. Section 1.4 concludes 

with policy recommendations. 

1.1. Labour markets have proven resilient in the wake of adverse shocks 

Global GDP growth has been moderate, but relatively resilient in 2023 despite the negative shocks from 

Russia’s war of aggression against Ukraine and the sharp tightening of monetary policy to tackle high 

inflation. Growth was particularly strong in the United States and many emerging-market economies but 

saw a slowdown in most European countries (Figure 1.1). The attacks on ships in the Red Sea that started 

in Fall 2023, have raised shipping costs sharply and lengthened delivery times, disrupting production 

schedules and raising price pressures. According to the latest indicators, global GDP growth is projected 

to continue growing at a modest pace of 3.1% in 2024, the same growth as the 3.1% in 2023, followed by 

a slight pick-up to 3.2% in 2025 as financial conditions ease (OECD, 2024[4]). 

Figure 1.1. GDP growth has been moderate with significant divergence between countries 

Real GDP indexed to 100 in Q4 2019 in selected OECD countries, seasonally adjusted data 

 

Note: Euro Area refers to the 20 Eurozone countries. 

Source: OECD (2024), “Quarterly National Accounts”, OECD National Accounts Statistics (database), https://doi.org/10.1787/data-00017-en 

(accessed on 12 June 2024). 

StatLink 2 https://stat.link/glsrka 

85

90

95

100

105

110

OECD Euro Area Australia Japan Korea United States

https://doi.org/10.1787/data-00017-en
https://stat.link/glsrka