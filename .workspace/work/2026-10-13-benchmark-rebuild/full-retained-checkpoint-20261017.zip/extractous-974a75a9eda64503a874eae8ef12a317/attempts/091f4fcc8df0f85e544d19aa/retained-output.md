U.S. Property & Casualty and Title Insurance Industries – 2025 First Half Results   

 

 
 

© 2025 National Association of Insurance Commissioners [6] 

 POLICYHOLDERS’ SURPLUS 
Industry aggregated policyholders’ surplus (adjusted 
to eliminate stacking) reached an all-time high of $1.2 
trillion at June 30, 2025, a 6.2% increase compared to 
$1.13 trillion at December 31, 2024. The $54.5 billion 
net gain in the current period and the unrealized 
gains of $15.2 billion were primary factors.  
 
 RESERVES 
Loss and LAE reserves increased 3.9% since the prior 
year-end to $1.02 trillion at June 30, 2025, and was 
comprised of $856.3 billion in unpaid losses and 
$159.0 billion of unpaid LAE. Reserve leverage 
improved 1.8-points to 84.5% compared to 86.3% at 
the prior year-end attributable to the increase in 
surplus.  
 
The trend in net favorable loss reserve development continued with an overall redundancy of $13.1 billion in the first 
half of 2025. This consisted of a $76.3 billion redundancy in prior year IBNR loss and LAE reserves, partially offset by a 
$63.2 billion deficiency in prior year known case loss and LAE reserves.  
  
MUTUAL INSURERS FINANCIAL SNAPSHOT 
 

 
 
Financial stability and capital preservation are the primary goals of mutual insurers rather than growth as they prioritize 
policyholder interest and do not face significant pressure from investors. Mutual insurers have faced challenges with 
increased frequency and severity of weather-related activity, inflation, reinsurance market hardening, and equity 

For the six months ended June 30,

Chg. 2025 2024 2023 2022 2021

Net Written Premium 4.6% $83.6 $80.0 $69.6 $61.2 $57.3
Net Earned Premium 7.4% $81.8 $76.2 $64.9 $58.8 $55.0
Net Losses Incurred 3.3% $54.4 $52.7 $49.6 $41.8 $33.6
Loss Expenses Incurred 3.1% $7.3 $7.1 $6.5 $6.0 $5.8
Other Underwriting Expenses 3.5% $20.8 $20.1 $18.4 $16.4 $16.0
Net Underwriting Gain 78.6% ($0.8) ($3.8) ($9.8) ($5.4) ($0.3)
Net Inv Income Earned 9.4% $5.6 $5.2 $4.3 $4.1 $3.7
Realized Gains (Losses) (12.5%) $2.4 $2.8 $0.5 $0.7 $1.6
Policyholder Dividends (3.0%) $0.5 $0.5 $0.5 $0.5 $0.9
Net Income 59.5% $6.6 $4.1 ($4.6) ($0.5) $4.0
Unrealized Gains (Losses) (41.5%) $5.7 $9.7 $7.0 ($17.3) $14.2
Policyholder Surplus* 7.5% $308.6 $287.0 $268.6 $263.0 $268.8
Cash & S-T Inv 6.5% $491.4 $461.3 $427.7 $408.7 $415.9
Net Admitted Assets 6.2% $558.5 $525.9 $487.0 $462.8 $464.6
Loss Reserves 4.6% $105.3 $100.6 $90.1 $78.3 $72.8
LAE Reserves 5.0% $24.3 $23.2 $21.8 $20.6 $20.0
Operating Cash Flow (20.6%) $5.7 $7.2 $1.5 $0.4 $4.3

*Adjusted to Eliminate Stacking

U.S. Property/Casualty  Results - Mutuals ($in billions)

1,201,362 

$0

$200

$400

$600

$800

$1,000

$1,200

$1,400

'16 '17 '18 '19 '20 '21 '22 '23 '24 '25

Capital & Surplus ($M) Dec. 31, 2016-2024, 6/30/25