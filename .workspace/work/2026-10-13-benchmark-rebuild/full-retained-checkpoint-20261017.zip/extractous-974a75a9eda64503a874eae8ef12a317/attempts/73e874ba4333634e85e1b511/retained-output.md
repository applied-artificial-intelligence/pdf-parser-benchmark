Employment and Social Developments in Europe 2024 

44 

Box (continued) 
 

   

 

(Continued on the next page) 
 

 

Chart 2 

Median net wealth grew across the income distribution between 2010 and 2021 
Median household net wealth by income quintile, euro area average, 2021 USD PPP, 14 EU countries 

     

Note: Median household net wealth in 2021 EUR PPS. Median household net wealth calculated for: people in the bottom fifth of income earners (lowest quintile); people in 
the middle fifth of income earners (middle quintile); people in the top fifth of income earners (top quintile). 

Source: OECD calculations based on the HFCS, https://www.ecb.europa.eu/stats/ecb_surveys/hfcs/html/index.en.html 

 
 
 

Chart 3 

Wealth concentration increased after the financial crisis but decreased during COVID-19 
Average and standard deviation of wealth share of top 10% and bottom 50%, 2010-2021 

               

Note: Dispersion measured as standard deviation of wealth share by country. See Figure 1 note for more information. Standard deviation is a measure of cross-country 
variation, the higher the standard deviation, the higher the cross-country variation. 

Source: OECD calculations based on the HFCS. 

 
  

€ 0

€ 50 000

€ 100 000

€ 150 000

€ 200 000

€ 250 000

€ 300 000

€ 350 000

€ 400 000

€ 450 000

2010 2014 2017 2021

Lowest quintile Middle quintile Top quintile

46.0%
46.5%
47.0%
47.5%
48.0%
48.5%
49.0%
49.5%
50.0%
50.5%
51.0%

2010 2014 2017 2021

Panel A: Wealth share of the top 
10%

14 countries 19 countries

21 countries

0.05

0.055

0.06

0.065

0.07

0.075

0.08

0.085

2010 2014 2017 2021

Panel B: Dispersion - wealth share 
of top 10%

14 countries 19 countries

21 countries

6.0%
6.5%
7.0%
7.5%
8.0%
8.5%
9.0%
9.5%

10.0%
10.5%
11.0%

2010 2014 2017 2021

Panel C: Wealth share of the 
bottom 50%

14 countries 19 countries

21 countries

0.02

0.025

0.03

0.035

0.04

0.045

0.05

0.055

2010 2014 2017 2021

Panel D: Dispersion - wealth share 
of the bottom 50%

14 countries 19 countries

21 countries