113 

Figure 3.9 Distribution (%) of R&D personnel across occupations, all sectors (BES, GOV, 

HES), by sex, 2021 

 
 

Source: Eurostat – Research and development statistics (online data code: rd_p_persocc) and OECD –R&D 

personnel by sector and function. 

Notes: Definition differs, see metadata: FI (2021 - Researchers, ‘Technicians and other supporting staff’, Total - Women, 
Total); Break in time series: BE, SE (2021 - Researchers, ‘Technicians and other supporting staff’, Total - Women, Total); 
Estimated: EU-27 (2021 - All professional positions - Women, Total), UK (2018 - All professional positions - Women, Total); 
Provisional: DK (2019 - Researchers, ‘Technicians and other supporting staff’, Total - Women, Total); Difference in 
methodology: JP (2021 - All professional positions - Women, Total); Reference year differs: DK: 2019, UK: 2018, ME: 2019, 
MK: 2020, RU: 2020; Data not available EU-27, BE, DK, EL, FR, LV, LT, NL, FI, SE, NO, RU (Technicians, ‘Other supporting 
staff’ - Women, Men, Total), US, IL (All professional positions - Women, Men, Total). 

0                        10                      20                     30                       40                        50                      60                      70                      80                        90                     100