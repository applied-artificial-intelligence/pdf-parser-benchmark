 155 

OECD EMPLOYMENT OUTLOOK 2024 © OECD 2024 
  

Differences in wage losses tend to be firm-related rather than worker-related 

Wage losses upon re-employment may be either worker-related or firm-related. Worker-related wage losses 

stem from the loss of firm-specific skills and a decline in the quality of the match, whereas firm-related wage 

losses reflect a decline in the generosity of a firm’s wage policies (Lachowska, Mas and Woodbury, 2020[29]). 

Decomposing the contribution of wage losses to earnings losses into a worker- and a firm-related component 

suggests that firm-related wage losses account for most of the difference in wage losses between high- and 

low-emission industries, echoing the results of Barreto, Grundke and Krill (2023[8]). On average across 

countries, differences in average wage losses between high- and low-emission industries are entirely firm-

related (Figure 3.10). Indeed, in several countries worker-related losses to be smaller in high-emission 

industries. This is the case in France, Hungary, the Netherlands and Sweden. One possible explanation for 

this may be that workers in high-emission industries have lower skills and hence are less at risk of losing 

(firm-specific) human capital following job loss. Overall, these results suggest that displaced workers from 

high-emission industries undergo larger earnings losses in part because they were displaced from higher 

paying firms. This may mean that these workers move to less productive firms, firms where workers capture 

lower rents, or lose compensating wage differentials for physically demanding working conditions (Card et al., 

2018[46]; Sorkin, 2018[47]; Hirsch and Mueller, 2020[48]). Evidence for Portugal (not shown) suggests that 

displaced workers in high-emission industries move to less productive firms, while evidence from France by 

Brandily, Hémet and Malgouyres (2022[49]) shows that displaced workers may re-allocate to higher 

productivity firms that pay lower wages because of a loss in bargaining power.8 This loss in bargaining power 

is in line with the finding in Chapter 2 that workers employed in occupations concentrated in high-emission 

sectors are more likely to be covered by a collective bargaining agreement than other workers. 

Figure 3.10. Higher wage losses in high-emission sectors tend to be firm-related rather than 
worker-related 

Contribution of wage losses to the difference in overall earnings losses between displaced workers from high- and 

low-emission sectors, decomposed into differences in firm- and worker-related losses, average over six years 

following displacement, percentage points 

 

Note: Bars represent the contribution of wage losses to the overall difference in earnings losses between displaced workers from high-emission 
and low-emission industries on average over the six years after displacement (see Box 3.3). The bars are decomposed into the contribution of 
a firm-related component (e.g. firm wage policies) and a worker-related component (i.e. human capital, match quality) following Lachowska et al. 
(2020[29]). Countries are sorted based on the difference in wage losses between high- and low-emission sectors. The figure excludes Australia, 
Canada, Estonia and Norway due to missing information on daily wages. 
Source: National linked employer employee data, see Annex Table 3.B.1 for details. 

StatLink 2 https://stat.link/q3tfmg 

-10 -8 -6 -4 -2 0 2 4 6

SWE

NLD

DEU

PRT

DNK

Average

FIN

AUT

HUN

FRA

ESP

p.p.

Firm Worker Total (contribution of wage losses)

https://stat.link/q3tfmg