Contents 22Tokenized assets

3.2 Asset issuance

Equities

Public equities are shares of publicly traded 

companies listed on stock exchanges and 

offered to a broad investor base. The global 

public equity market was valued at nearly 

$115 trillion in 2023.10 The market 

capitalization of tokenized public stocks 

was estimated at nearly $16 million 

by March 2025.11

Current public equities markets in AEs are 

already highly efficient and benefit from 

decades of technology modernization and 

proven intermediary chains delivering financial 

services. Due to existing efficiencies in AEs, 

tokenizing public equities may not be 

prioritized over other asset classes.12

However, opportunities exist, particularly in 

EMEs, to improve efficiencies and provide 

access to equity markets.13

Source: RWA.xyz (2025)

F I G U R E  7

Tokenized stocks

Backed-issued stocks bCSPX, bCOIN and bNVDA represent almost 90% of tokenized stocks in value.

bCSPX bCOIN bNVDA sMSTR TSLA.d Others

$18M

$16M

$14M

$12M

$10M

$8M

$6M

$4M

$2M

$0M

Jan 23 Mar 23 May 23 Jul 23 Sep 23 Nov 23 Jan 24 Mar 24 May 24 Jul 24 Sep 24 Nov 24 Jan 25 Mar 25Sep 24

https://rwa.xyz