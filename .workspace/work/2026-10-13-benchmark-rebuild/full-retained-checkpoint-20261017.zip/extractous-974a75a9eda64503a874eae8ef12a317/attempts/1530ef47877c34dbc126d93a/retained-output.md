Renewables 2025 Chapter 1. Renewable electricity 
Analysis and forecasts to 2030 
 

PAGE | 49  I E
A.

 C
C

 B
Y

 4
.0

. 

While most countries are raising their renewable electricity 
goals outside of NDCs, overall global ambition is slightly lower 
than in last year’s analysis 
Although countries have so far been slow to submit their updated NDCs, many of 
their national plans already contain renewable capacity ambitions for 2030 or 
another indicator that can be used to estimate it, which could be used in their 
NDC 3.0. In fact, overall country ambitions for installed renewable power capacity 
in 2030 total roughly 7 500 GW. While this is 5% lower than our 2024 assessment, 
not all countries or technologies are following this trend.  

Since October 2024, nine countries have updated their national ambitions for 
2030. However, only six made significant changes (greater than 1%). Of these six, 
three raised their ambitions, while the other three lowered them. 

Global renewable electricity capacity ambitions by technology 

 
IEA. CC BY 4.0. 

Notes: Ambition changes correspond to 23 countries that represent  83% of global installed renewable capacity in 2024.  
 

The majority of the decrease in global ambition comes from the United States, 
where policy changes in January 2025 revoked the 2021 executive order that 
aimed for 100% clean energy by 2035. Other downward changes to 2030 goals 
come from Indonesia’s latest National Electricity Plan (RUKN 2025-2060), which 
is 20% less ambitious than its 2019 plan due to lower aims for solar PV. The latest 
energy plan for the Philippines (2023-2050) also envisions slightly lower installed 
capacity by 2030 than its previous plan, for both the reference and the clean-
energy scenario. However, reductions in total capacity do not always reflect 
diminished ambition, as some declines stem from revised assumptions on 
demand growth or technology performance. For example, the Philippines lowered 
its capacity figures but still maintains its previous ambition for a 35% share of 
renewables by 2030. 

0

1 000

2 000

3 000

4 000

5 000

6 000

7 000

8 000

9 000

Renewables
2024

Raised
ambition

Lowered
ambition

Renewables
2025

G
W

Not specified Others Wind Solar PV Hydropower

0

 500

1 000

1 500

2 000

2 500

3 000

Hydro-
power

Solar
PV

Wind Others Not
specified

Renewables
    2024

Renewables
    2025