10 European Innovation Scoreboard 2025

Figure 2: Innovation performance of the EU27 Member States in 2025, indexed to the EU 
in 2018

I
I

I
I

I
I

I
I

I
I
I

I
I

I
I
I

I
I

I
I

I
I

I
I
I

I
I

IRomania

Bulgaria

Latvia

Slovakia

Poland

Hungary

Croatia

Greece

Czechia

Lithuania

Cyprus

Portugal

Spain

Italy

Slovenia

Malta

EU

Estonia

France

Germany

Austria

Luxembourg

Belgium

Ireland

Finland

Netherlands

Denmark

Sweden

0 20 40 60 80 100 120 140 160

Summary innovation index in 2025 (indexed to the EU in 2018)

Emerging innovators

Moderate innovators

Strong innovators

Innovation leaders

I Score in 2024