X  Figure 6.6. Average annualized real wage growth by percentile of the wage distribution 
between 2006 and 2021 (or closest available year), by country income group (percentage)

Note: See box 6.1 for explanation of how these charts were created.

 Source: ILO estimates based on national survey data from 72 countries. See Appendix I for the sources of data and years 
of collection. The figures displayed in the charts were obtained using data from the earlier survey (T0 in Appendix I) and 
the most recent available survey (T1 in Appendix I).

-15

-10

-5

0

5

Av
er

ag
e 

an
nu

al
iz

ed
 re

al
 w

ag
e 

gr
ow

th
 (%

)

5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95
96-99

100

Percentile of the wage distribution

Low-income countries

-2

-1

0

1

2

3

Av
er

ag
e 

an
nu

al
iz

ed
 re

al
 w

ag
e 

gr
ow

th
 (%

)

Lower-middle-income countries

0

1

2

3

4

Av
er

ag
e 

an
nu

al
iz

ed
 re

al
 w

ag
e 

gr
ow

th
 (%

)

Upper-middle-income countries

0.5

1

1.5

2

Av
er

ag
e 

an
nu

al
iz

ed
 re

al
 w

ag
e 

gr
ow

th
 (%

)

High-income countries

5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95
96-99

100

Percentile of the wage distribution

5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95
96-99

100

Percentile of the wage distribution

5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95
96-99

100

Percentile of the wage distribution

55Global Wage Report 2024–25
6. The evolution of wage inequality over time