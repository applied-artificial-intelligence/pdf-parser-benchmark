11 

 
 
 
 
 

 
 

Figure 2. Association between public expenditure on education as a share of total public expenditure 
and as a share of GDP (2023) 

 

Notes:  Provisional data for BE, DE, ES, FR, PT, SK. See footnote 4 for IE. Pearson correlation coefficient (r=0.63) statistically 
significant at 1% level. 

Source:  Eurostat COFOG data. Online data code: [gov_10a_exp]. 

 
The bulk of public expenditure on education goes to schools. In 2023, school education received more 
than 70% of public expenditure on education at EU level. This is roughly equally split between, on the one hand, 
pre-primary and primary levels (35%) and, on the other hand, secondary level (37%), while tertiary education 
accounted for 16% of public expenditure. Those shares remained largely stable between 2019 and 2023 
(European Commission, 2022; European Commission, 2024a). The EU averages mask large differences among 
Member States (Figure 3). Those differences can be explained by many factors:  

• level of involvement of the general government in the education system;  
• enrolment levels;  
• the duration of compulsory education;  
• relative wages in the education sector;  
• class size and student-teacher ratios;  
• instruction time; and  
• the cost of teaching materials and facilities.  

At tertiary level, tuition fees and support for students are also determining factors.  

Staff costs account for almost two-thirds of public expenditure. 62% of public expenditure on education 
at EU level went to compensation of employees (i.e. wages and non-wage costs such as employers’ social 
contributions), ranging from 81% in Belgium to 43% in Sweden. Intermediate consumption (i.e. purchases of 
non-durable goods, such as teaching materials, and services needed to provide education, such as heating, 
electricity, cleaning and maintenance services) received 14% of expenditure. Gross capital formation (i.e. 
investment in acquiring fixed assets and durable goods, such as computers and buildings, and also including 
the depreciation of fixed assets) accounted for 8% of expenditure (Figure 4). Those shares remained largely 
stable between 2019 and 2023 (European Commission, 2022; European Commission, 2024a). 

 

https://ec.europa.eu/eurostat/databrowser/view/gov_10a_exp__custom_16025691/default/table?lang=en