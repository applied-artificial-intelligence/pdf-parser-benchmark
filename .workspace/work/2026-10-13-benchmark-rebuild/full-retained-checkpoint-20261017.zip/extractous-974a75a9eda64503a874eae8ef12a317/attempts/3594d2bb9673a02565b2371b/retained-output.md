2024 UN E-GovErNmENt SUrvEy

56

C
h

ap
ter 2

Figure 2.13 Distribution of EGDI levels relative to EPI levels for United Nations Member States, 2024

Although e-participation is the least advanced among the five OSI subindices (see figure 2.9), the global 
average EPI value has increased by 9 per cent, from 0.4450 to 0.4893, since 2022 (see figure 2.14). 

Source: 2024 United Nations E-Government Survey.

Figure 2.14 Average EPI values by region and percentage change between 2022 and 2024

Sources: 2022 and 2024 United Nations E-Government Surveys.

EDGI 2024  levels
Very high EGDI
High EGDI
Middle EGDI
Low EGDI

Very high EGDI
High EGDI
Middle EGDI
Low EGDI

193 UN Member States

Americas

Africa

Asia

Europe

Oceania

Africa Americas Asia Europe Oceania 193 UN member states

0.00

0.25

0.50

0.75

1.00

0.29730.2595

12.73%

0.47360.4253

10.19%

0.54040.5024

7.02%

0.72470.6631

8.51%

0.37480.3474

7.30%

0.48930.4450

9.06%

Africa
Americas
Asia
Europe
Oceania
193 UN member states

EPI average 2022

EPI average 2024

EPI average 2024
Africa
Americas
Asia
Europe
Oceania
193 UN member states

EPI average 2024  Africa  Americas  Asia  Europe  Oceania  193 UN member states

EDGI 2024  levels Very high EGDI    High EGDI Middle EGDI Low EGDI

ALB
ARE

ARG

ARM AUS

AUT

AZE BEL

BGR

BRA

BRN

CAN

CHN
DEU

DNK

ECU

FIN

FRA

GEO

GRC

HRV

HUN

IDN

KWT

LTU

MDA

MUS

NLD

POL

QAT

ROU

VNM

AND

ATG

BGD

BHS

BIH

BRB

BTN

BWA

CIV

DMA

DOM

DZA

GAB

GRD

GTM

GUY

IND

IRN

KHM

KNA

LBN

LCA

LKA MAR

MCO

MDV

MKD

NIC

NPL

PAK

RWA

SEN

SMR

TJK

TON

AGO

BEN

BLZ

COD

COG CUB

DJI

ETH

GIN

GMB

GNB

HND

IRQ

KIR

LBR

LSO

MDG
MLI

MRT

MWI

NRU

SLB

STP

SYR

TLS

TUV

UGA

CAF HTI

NER

SOM
TCD

y = 1.04443x-0.176424
R-Squared = 0.731916
p-value < 0.0001

0.000.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.951.00

EGDI 2024

0.0

0.1

0.2

0.3

0.4

0.5

0.6

0.7

0.8

0.9

1.0

EP
I 2

02
4

correlation line