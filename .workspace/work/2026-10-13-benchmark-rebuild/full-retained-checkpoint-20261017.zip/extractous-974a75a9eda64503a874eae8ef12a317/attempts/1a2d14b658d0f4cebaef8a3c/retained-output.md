5  Swiss Re Institute  Unseasonal fires trigger above-trend first-half 2025 natural catastrophe insured losses   

well as the Caribbean.10 For coastal communities, preparation and 
advance disaster resilience are essential to minimise the impact. 

But that is not all that can lead to deviation from trend. There 
could be major losses from the full spectrum of perils, such as 
summer/autumn large scale floods across the world. Current 
Mediterranean sea surface temperatures are 3°C above the 
historic average, the warmest on record. This could lead to 
higher-than-usual rainfall levels in autumn, potentially triggering 
large-scale floods.11 There may also be more wildfires in North 
America and in other regions. 

Historically, the great majority of wildfire losses occur in the 
second half when dry fuel on the ground is at its peak: as 
already stated, the LA County fires were unseasonal and to this 
end, an exception. Catastrophe losses fluctuate greatly year-on-
year, mostly due to random natural weather variability. Amid year-
on-year loss volatility, exposures are still rising. Long-term growth 
of catastrophe insured losses is mostly driven by economic 
development and urbanisation, often in hazardous regions such 
as by WUI and along the coast, and also construction costs rising 
more rapidly than overall inflation. Hazard intensification in 
changing climates like longer and harsher wildfire seasons, and 
more intense rainfall may alter loss seasonality patterns and add 
to the overall losses. All of those factors will continue to underpin 
steep growth in insured losses over the longer term, with some 

above-average years when unpredictable severe weather hits in 
high exposure locations, but also some below-average ones. 

Authors 
Dr Chandan Banerjee 
Lucia Bevere 
Dr Shilpa Gahlot 
Dr Mahesh H Puttaiah 
  
The authors would like to thank Dr Erik Lindgren, Elisabeth Viktor 
and Dr Rogier de Jong for their contributions to the report.

Deputy managing editor 
Dr Thomas Holzheu 
  
Managing editor 
Dr Jerome Jean Haegeli

©2025 Swiss Reinsurance Company Ltd. All rights reserved.

Swiss Re. All rights reserved. Although all the information used in this study was taken from reliable sources, Swiss Re does not accept any responsibility for the accuracy 
or comprehensiveness of the information given or forward looking statements made. The information provided and forward-looking statements made are for informational 
purposes only and in no way constitute or should be taken to reflect Swiss Re’s position, in particular in relation to any ongoing or future dispute. In no event shall Swiss Re 
be liable for any loss or damage arising in connection with the use of this information and readers are cautioned not to place undue reliance on forward-looking statements. 
Swiss Re undertakes no obligation to publicly revise or update any forward-looking statements, whether as a result of new information, future events or otherwise. 

References
1  SITUATION UPDATE No. 10 - M7.7 Mandalay Earthquake, AHA Centre, 23 

April 2025.
2  See 2025 Fire Season Incident Archive, CAL FIRE
3  Mapping Change in the Wildland Urban Interface, 1990-2020, Silivis Lab, 2025, 

based on Radeloff et. al. Rapid growth of US wildland-urban interface raises 
wildfire risk, Proceedings of the National Academy of Sciences, vol. 115, 2018.

4  7 lessons learned from the California wildfires for European insurers, Swiss Re, 
7 July 2025. 

5  Producer Price Indexes, Bureau of Labor Statistics, June 2025. 
6  The effects of climate change on hail storms, nature reviews earth & 

environment, vol 2, 9 February 2021.

7  sigma 1/2024, Natural catastrophes in 2023: gearing up for today’s and 
tomorrow’s weather risks, Swiss Re Institute.

8  Extreme heat grips Europe,World Meteorological Organization, 3 July 2025. 
The term “heat dome” refers to the phenomenon of high-pressure systems that 
trap hot air towards the surface preventing it from rising and cooling.

9  sigma 1/2025, Natural catastrophes: insured losses on trend to USD 145 billion 
in 2025, Swiss Re Institute.

10  The current trend estimate of USD 150 billion for 2025 full-year losses is at 2025 
prices. In sigma 1/2025, published in April, we cited a figure of USD 145 billion, 
based on 2024 prices.

11  Hurricane Katrina: a watershed event for insurance, Swiss Re Institute, 23 June 
2025.

Figure 9: Global insured losses from natural catastrophes (USD bn, 2025 prices)

Source: Swiss Re Institute

0

50

100

150

200

202520232021201920172015201320112009200720052003200119991997

Editable field 2023 - with outline

Editable field 2023 - without outline

FY TrendSecond halfFirst half

Hurricanes Harvey, Irma, MariaEarthquakes Japan & NZ,
Thailand floodHurricanes Katrina, Rita, Wilma

https://ahacentre.org/situation-update/situation-update-no-10-m7-7-mandalay-earthquake-23-april-2025/
https://ahacentre.org/situation-update/situation-update-no-10-m7-7-mandalay-earthquake-23-april-2025/
https://www.fire.ca.gov/incidents/2025
https://silvis.forest.wisc.edu/wp-content/uploads/sites/379/2018/10/Radeloff_2018_PNAS_SI.pdf
https://silvis.forest.wisc.edu/wp-content/uploads/sites/379/2018/10/Radeloff_2018_PNAS_SI.pdf
https://www.bls.gov/news.release/pdf/ppi.pdf
https://www.bls.gov/news.release/pdf/ppi.pdf
https://wmo.int/media/news/extreme-heat-grips-europe