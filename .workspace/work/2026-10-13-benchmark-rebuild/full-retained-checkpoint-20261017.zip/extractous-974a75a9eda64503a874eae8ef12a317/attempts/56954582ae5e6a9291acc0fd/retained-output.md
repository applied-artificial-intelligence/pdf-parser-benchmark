 21 

OECD ECONOMIC OUTLOOK, VOLUME 2025 ISSUE 2 © OECD 2025 
  

fallen elsewhere (Figure 1.9, Panel B). The updated effective estimates for Canada and Mexico now assume 

that 80% of goods imported into the United States will be USMCA-compliant. 

Figure 1.8. Estimated US effective tariff rates 

 

Note: Estimates based on trade policy announcements as of 14 November 2025 and calculated using weights based on product level data for 
US imports by country in 2024. These take account of country-specific tariff rates and sector-specific changes due to a 25% tariff rise for listed 
cars, parts, trucks and buses; a 50% tariff rise on steel, aluminium and copper products; and zero-rated general goods as well as those related 
to semiconductors. Europe, Japan and Korea face a maximum 15% tariff on cars and parts, and timber, and 0% tariffs are applied to civil aviation 
products, generic pharmaceuticals and certain natural resources). The United Kingdom faces a 25% tariff rise on steel and aluminium, 7.5% for 
British cars within the annual quota, 10% on timber products, and duty-free civil aviation products. China, Brazil and India face additional country-
specific tariffs, with varying application across products. Data classifications are based on product-level lists published by the US administration. 
Source: United States International Trade Commission; US Census Bureau, and OECD calculations. 

StatLink 2 https://stat.link/qxnj8w 

The share of duty-free imports is generally higher for imports from Canada and Mexico than elsewhere across 

a range of goods (Figure 1.10, Panel A). Taking the share of duty-free goods as a proxy for USMCA compliance, 

around 60% and 53% of car imports for Mexico and Canada respectively are USMCA compliant. For steel and 

aluminium, however, Canada has a compliance rate of just 33% compared to 66% for Mexico. For goods 

excluding imports of cars and parts, steel and aluminium, and items exempted from tariffs, compliance rates 

are 93% and 90% for Canada and Mexico, respectively. 

Overall, these compliance rates result in US imports of cars and parts from Canada and Mexico currently 

incurring duties of 12% and 11% respectively, slightly less than half the 27% being charged on imports from 

many other countries (Figure 1.10, Panel B). For steel and aluminium, Mexican imports incur duties of 15% of 

import values, whilst those from Canada incur duties of 32%, close to the 33% incurred by imports from the rest 

of the world (Figure 1.10, Panel C). These rates will rise as the 50 percentage point tariff on steel and aluminium 

has been effective since late August 2025.  

As a result of these changes in compliance across sectors, the estimated increase in the aggregate US effective 

tariff rate on imports from Canada and Mexico has declined. Currently, these are estimated to be 4.8% and 

5.4% respectively, down from 12.5% and 14.8% based on developments up to mid-May. Incorporating these 

two changes, the estimated aggregate effective US tariff rate is approximately 3 percentage points lower than 

it otherwise would be, reflecting the importance of US trade with Canada and Mexico.  

__________ 

1. These trade agreements also included a number of other commitments, relating to investment and regulation. 

https://stat.link/qxnj8w