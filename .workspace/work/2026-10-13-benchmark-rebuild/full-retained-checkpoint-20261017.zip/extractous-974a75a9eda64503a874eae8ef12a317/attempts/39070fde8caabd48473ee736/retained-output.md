REUTERS INSTITUTE FOR THE STUDY OF JOURNALISM / EXECUTIVE SUMMARY GRAPHS

Graph 7

PROPORTION WHO AVOID NEWS FOR EACH REASON –  
BY POLITICAL LEANING – USA

Q1di_2017ii. Why do you find yourself actively trying to avoid the news? Base: All who avoid news 
often, sometimes, or occasionally in USA. Left =327, Right= 336.

0% 25% 50% 75%

54

29

49

65

14

15

3

57

41

23

20

22

18

9

Right

Left 

Hard to follow/
understand

Leads to
arguments

Nothing I can
do about it

News is untrustworthy
or biased

Too much politics
or COVID-19 news

Worn out by the
amount of news

Brings down
my mood

Left Right

These findings will be particularly challenging for the news 
industry. Subjects that journalists consider most important, such 
as political crises, international conflicts, global pandemics, and 
climate catastrophes, seem to be precisely the ones that are 
turning some people away from news – especially amongst  
those who are younger or harder to reach. 

Many news organisations are embracing approaches such as 
solutions journalism around subjects like climate change, that 
aim to give people a sense of hope or personal agency. Others are 
looking to find ways to widen the agenda to softer subjects or 
make news more relevant at a personal level, but there will be a 
limit to how far journalists can go – or should go – to make the 
news more palatable.

News is too hard for many people to work out

One other important data point relates to the difficulty that 
many younger audiences, and less educated groups, have in 
understanding journalism as currently practised. In countries 
such as Australia, the United States, and Brazil, around 15%  
of younger avoiders say they find news hard to follow –  
a much higher proportion than older news consumers. 

I do sometimes finish reading articles maybe more 
stressed about a situation, or sometimes just confused.
Female, 24, UK

This could relate to the complexity of the language or assumed 
knowledge often contained in news reports. But the increase in 
news consumption via social media or word of mouth through 
friends and family, may also be playing a part. News is often 
accessed by young people in more fragmented ways, meaning that 
people sometimes miss key context that was previously carefully 
packaged into linear narratives by the mainstream media.

During the COVID-19 crisis (and now Ukraine) we saw many news 
organisations using explainer and Question & Answer formats to 
try to address these issues on websites and via social media to 
engage younger and less educated audiences. Our data suggest this 
process needs to go much further.

For further analysis see Section 2.3: The Changing News Habits and 
Attitudes of Younger Audiences

REUTERS INSTITUTE FOR THE STUDY OF JOURNALISM / EXECUTIVE SUMMARY GRAPHS

Graph 8

PROPORTION OF NEWS AVOIDERS WHO STRUGGLE TO 
UNDERSTAND THE NEWS – BY AGE – SELECTED MARKETS

Q1di_2017ii. Why do you find yourself actively trying to avoid the news? Base: Under 35s/35s and 
over who avoid news: Australia = 428/963, Brazil = 559/1053, Denmark = 283/648, Finland = 260/705, 
France = 319/1075, Germany = 333/950, Ireland = 367/999, Italy = 279/1080, Japan = 235/825, Spain = 
336/1035, UK = 386/1310, USA = 450/987.

0% 25%

4

6

5

7

6

3

7

4

4

2

2

6

16

15

15

11

11

11

11

10

10

8

6

6

Over 35

Under 35

Italy

UK

Finland

Ireland

Germany

Japan

Denmark

Spain

France

USA

Brazil

Australia
U35

35+

Reuters Institute for the Study of Journalism   |   Digital News Report 202214