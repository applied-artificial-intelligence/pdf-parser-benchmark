Cash from operations for select energy companies

billion real 2024 dollars

Petroleum and Liquid Fuels Markets Team | Financial Review 2024                                               

May 2025

Cash from operations decreased by 9% from 2023 to 2024

Data source: Evaluate Energy

Note: Select energy companies includes 158 global oil and natural gas companies. The Appendix contains the full list of companies.

$0

$100

$200

$300

$400

$500

$600

$700

$800

$900

$1,000

2015 2016 2017 2018 2019 2020 2021 2022 2023 2024

13

Lower crude oil and natural 

gas prices contributed to 

lower cash from operations 

in 2024 compared with 

2023.