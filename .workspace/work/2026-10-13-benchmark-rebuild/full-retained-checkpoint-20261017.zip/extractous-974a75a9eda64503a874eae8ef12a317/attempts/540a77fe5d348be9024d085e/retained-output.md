The BEAT | June 2025

Valuation Analysis

EQUITIES

Source: FactSet as of 5/31/25. NTM P/E is market price per share divided by expected earnings per share over the next twelve months. Data provided is for informational use only. See 
end of report for important additional information. Forecasts/estimates are based on current market conditions, subject to change, and may not necessarily come to pass.

Regions/Styles: Current NTM P/E vs. 10-Year High, Low, Average

34

S&P 500 Russell 2000

Russell 1000 

Growth

Russell 1000 

Value MSCI World

MSCI World ex 

USA Small Cap MSCI EAFE MSCI EM MSCI Europe

MSCI AC  

Asia Pac

High Date 8/20 6/20 8/20 3/21 8/20 8/20 8/20 1/21 6/20 1/21

Low Date 12/18 9/22 2/16 9/22 12/18 9/22 9/22 10/18 9/22 12/18

High

Current
Average

Low

MSCI World 

Current P/E 
18.4

23.9 23.5

15.2 17.0
15.1 14.2

12.1
14.1 13.6

22.9

63.5

32.7

17.6

21.2
19.7

17.6
15.7

17.4 17.4

14.4 15.2
16.8

12.1
13.5

11.3 11.0 10.1 10.5 11.3

21.3
23.3

27.5

16.6

19.1

13.5 14.6
12.1

14.4 13.9

0.0

10.0

20.0

30.0

40.0

50.0

60.0

70.0