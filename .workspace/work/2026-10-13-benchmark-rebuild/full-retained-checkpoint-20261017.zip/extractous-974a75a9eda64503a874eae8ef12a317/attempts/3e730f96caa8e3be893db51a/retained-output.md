149

C
h

ap
ter 4

Chapter 4 • LoCaL e-Government DeveLopment 

Figure 4.12 Implementation of e-government literacy indicators in city portals

included in the lOSI assessment, allowing for feasible comparisons between 2022 and 2024 data. 
As seen in figure 4.12, progress has been made in several areas, with rates of compliance increasing 
for indicators such as real-time communication functionality, the availability of information on online 
services use, privacy policies, online user support features, portal authentication, internal search 
mechanisms, and the integration of social networking features in government portals. These advances 
reflect a commitment to enhancing accessibility and engagement for the users of online services.

Many members of society remain digitally disconnected and are in danger of being left behind in 
a world that is rapidly moving online. Providing free Internet access at the local level is crucial for 
ensuring inclusion. The availability of physical spaces for accessing online services varies across cities. 
Some municipalities offer service centres or “digital islands” within government offices, facilitating 
access to online services and often providing personal assistance. Vienna is one city that offers digital 
islands and provides support for users of online services. Belmopan, in Belize, boasts numerous free 
mobile Wi-Fi hotspots. Public libraries often serve as hubs for accessing online services, with free 
Wi-Fi widely available in many cities. While some cities have dedicated spaces for digital access, such 
as community centres or libraries, others lack clear evidence of facilities for public Internet access. 
Notably, some cities provide free Wi-Fi in public spaces such as parks, squares and metro stations, 
further enhancing connectivity. These varied efforts to ensure public Internet access underscore the 
importance assigned to digital inclusion in modern governance.

Technology 

As illustrated in figure 4.13, there have been improvements in most of the lOSI technology indicators 
since 2022. Notably, compliance rates have increased for mobile device accessibility (from 70 to 76 per 
cent), the ease with which portals can be found (from 73 to 77 per cent), and browser compatibility 
(from 75 to 78 per cent). Indicators such as the availability of internal advanced search mechanisms, 
foreign language support, and navigability have also registered improvement. However, compliance 
rates have dropped slightly for alignment with display standards, markup validation standards, and 
accessibility standards. As an example of the technological advancements being made, the Beijing 
Municipal Government Service centre website has introduced easy-access and senior-friendly features 
such as text-to-speech functionality, large fonts, and customizable colours, along with a one-stop 
service zone to simplify access to various services for individuals with disabilities and the elderly. 
These enhancements are intended to make government services more accessible and user-friendly 
for special groups, ensuring a more satisfying online experience for a wider range of consumers.

19%

31%

37%

38%

46%

46%

52%

67%

69%

17%

31%

34%

38%

40%

43%

49%

64%

65%

0% 10% 20% 30% 40% 50% 60% 70% 80%

Real-time communication

Open data policy

Information on online services use

Facilitation of free Internet access

Privacy policy

Online user support

Portal authentication

Internal search mechanism

Social networking features

2022 2024