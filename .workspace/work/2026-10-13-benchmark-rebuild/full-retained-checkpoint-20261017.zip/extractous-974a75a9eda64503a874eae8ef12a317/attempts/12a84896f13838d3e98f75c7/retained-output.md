Chapter 7. Global Taxation of Multi-Millionaires
Figure 7.1. A more progressive tax system is needed in order toreduce political capture by the very rich

0%
2%
4%
6%
8%

10%
12%
14%
16%
18%
20%
22%
24%

19
60

19
70

19
80

19
90

20
00

20
10

C
ha

rit
ab

le
 d

on
at

io
n 

sh
ar

e 
of

 
th

e 
to

p 
0.

01
%

 in
 th

e 
U

.S
.

United States

United States

0%

10%

20%

30%

40%

50%

60%

P0−
P10

P10
−P

20

P20
−P

30

P30
−P

40

P40
−P

50

P50
−P

60

P60
−P

70

P70
−P

80

P80
−P

90

P90
−P

10
0

P
er

ce
nt

ag
e 

of
 to

ta
l p

ol
iti

ca
l 

 d
on

at
io

ns
 b

y 
in

co
m

e 
de

ci
le

France South Korea

France and South Korea

Interpretation. Private giving is increasingly concentrated at the top. In the U.S., the top 0.01% have starkly
increased their share of charitable contributions since 1960, reaching more than 20% in 2012. In France and
South Korea (2013–2021), political donations are dominated by the richest 10% who donate much more than
any other income group. These patterns suggest rising top−end inequality translates into unequal influence over
philanthropy and politics. Sources and series: Cagé (2024).

Donations in the U.S. (1960−2012) and France and South Korea (2013−2021)

Regressivity at the top
One of the most important facts highlightedin this report is that tax progressivity breaksdown precisely where it should mattermost: at the very top of the distribution.While tax systems are designed to appearprogressive, effective rates often fall sharplyfor multi-millionaires and billionaires oncewe compare total taxes paid against theirfull economic income. Large parts of topincomes escape taxation.Figure 7.2 illustrates one of the mainparadoxes of modern tax systems: while taxcodes in high-income countries are oftendesigned to be progressive, they becomeregressive at the very top of the distribution(see Zucman (2024)). Regressivity emergesbecause the income tax fails at the top. InFrance and the Netherlands, billionaires’effective income tax rate drops to near zerobecause of tax avoidance. In the UnitedStates, anti-avoidance rules keep billionairerates somewhat higher, but they still fallsharply compared to upper-middle groups.Tax avoidance primarily operates throughtwo channels (see Alstadsæter et al. (2023)

and Zucman (2024)): (i) delaying or avoidingdividend distributions and capital gainsrealizations, and (ii) using holding companiesand similar legal structures to accumulateearnings tax-free.Figure 7.3 situates this regressivity inhistorical perspective. Over the past threedecades, global multi-millionaire wealth hassoared, tripling relative to world income(see Alstadsæter et al. (2023)). In 1995, theglobal top 0.001% held assets equivalentto 12% of global income. Three decadeslater, their share has nearly tripled, reaching33% by 2025. Put differently, about sixtythousand individuals now control wealthworth one-third of the world’s combinedincome. Tax systems meant to fundpublic goods and reduce inequality insteadreinforce concentration at the very top.Unless corrected, regressivity at the top willcontinue to erode both fiscal capacity anddemocratic cohesion.

131