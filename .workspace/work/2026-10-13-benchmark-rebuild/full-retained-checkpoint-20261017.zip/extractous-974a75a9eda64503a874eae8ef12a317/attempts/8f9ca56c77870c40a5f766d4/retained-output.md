36 
 

 

3. Adequacy of the lending volume and authorised capital stock 
 

The evolving economic environment in the euro area and the evolution in the ESM instruments will 

determine future needs for ESM resources. Based on the following assessment, and in line with the 

latest review completed by the BoG in June 2022, a sufficient level of the ESM lending capacity should 

be maintained to uphold the confidence in the euro area financial architecture.   

A large part of the total ESM lending capacity remains available to provide support for preserving 

the euro area financial stability, if required. The ESM available lending capacity out of the €500 billion 

maximum amount has decreased from €461 billion in 2012 to €422 billion in April 2024, reflecting the 

financing provided under the financial assistance to Cyprus, Greece and Spain. The remaining lending 

capacity is set to fall, assuming the full ratification of the revised ESM Treaty where it is foreseen that 

€68 billion will be earmarked for the backstop to the SRF (Figure 7). Absent of any new programmes, 

under the current repayment schedules of the beneficiary Member States, a gradual increase in the 

available lending capacity is then projected until 2060 (€432 billion), at which point the only 

committed portion of the ESM lending capacity would be under the common backstop, assuming that 

the facility is extended by then.41 

Figure 7. 
ESM remaining lending capacity 
(in € billion) 

 

Source: ESM  
Note: The maximum lending volume of the ESM is €500 billion. From 2023, the data points are projections based on current 
repayment schedules of beneficiaries of ESM financing. The distance between the curves from 2023 reflects the possible 
introduction of an up to €68 billion backstop of the SRF by the ESM, which is subject to full ratification of the revised Treaty. The 
backstop is added under the assumption that the current size of its nominal cap (€68 billion) is not revised in the future. 
 
 

The combined lending capacity of the ESM and EFSF managed to support euro area financial stability 

in the past while the maximum lending capacity has slightly declined against macroeconomic 

aggregates over the period. At the ESM’s inception in 2012, the BoG set the maximum lending volume 

at €500 billion and confirmed the combined lending ceiling of the ESM and the EFSF at €700 billion 

(Figure 8). As of July 2013, the EFSF may no longer engage in new financing programmes, leaving the 

remaining ESM lending capacity as the main component of the euro area safety net. In the absence of 

 
41 The initial availability period of the backstop facility shall be ten years, and will be extended automatically for further ten-
year periods, except under the circumstances envisaged in the European Stability Mechanism Guideline on the backstop 
facility to the SRB for the SRF, Article 12. 

250

300

350

400

450

500

2012 2016 2020 2024 2028 2032 2036 2040 2044 2048 2052 2056 2060 2064 2068

Under Current Treaty Ratification of Revised Treaty in 2024