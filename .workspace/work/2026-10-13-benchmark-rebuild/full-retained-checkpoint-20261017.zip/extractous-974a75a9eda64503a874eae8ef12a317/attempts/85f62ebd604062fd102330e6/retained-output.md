(o0, · · · , on−1) ∈ Se as follows:

FF 0,··· ,Fn−1(se) = (F0
F 0 , · · · ,Fn−1

Fn−1), (2)

where n is the number of agents, F i = {j0, · · · , jk−1} ⊂ I
is an arbitrary ordered agent index set, and F i

F i is the indi-
vidual formation viewed by i-th agent, defined as

F i
F i = (Dij0 , · · · , Dijk−1). (3)

From the definition, the formation of the exploration state
se contains all the difference information of (i, j) agent pairs
for all i ∈ I, j ∈ F i. From now on, we denote the formation
as F for better clarity.

Finally, we can define a formation-based binary relation
on the exploration state space as

∼F := {(s1, s2) ∈ Se × Se | F(s1) = F(s2)}, (4)

and we can easily prove that ∼F is an equivalence relation
on the exploration space Se by Lemma 1.
Lemma 1 (Formation-based equivalence relation). The bi-
nary relation ∼F is an equivalence relation on the explo-
ration space Se, i.e., two exploration states s1 and s2 in the
exploration state Se are equivalent under ∼F if F(s1) =
F(s2).

Proof) Proof of Lemma 1 is provided in Appendix B.
Here, the dimension of formation F is nk and the dimen-

sion of exploration space is nd. k depends on the selection of
F i, but in most cases, the observation dimension d is much
larger than k. Thus, we can efficiently reduce the dimen-
sion of search space. In addition, based on the equivalence
relation ∼F , the agents explore the exploration states in di-
verse formations without visiting the equivalent states that
have the same formation, and it can further reduce the search
space and enables better exploration as shown in Figure 2.

Formation-aware Exploration Objective
In this subsection, we propose a formation-aware explo-
ration objective to explore states in diverse formations as

H(Ft)︸ ︷︷ ︸
(a)

+
1

n(k + 1)

n−1∑
i=0

∑
j∈F i+

I(F i
F i,t+1; z

j
t |τ

F i+

t , z
F i+\{j}
t ),︸ ︷︷ ︸

(b)

where F i+ = F i ∪ {i}, aF indicates the set {ai|i ∈ F},
H(X) = −p(X) log p(X) is the information entropy of a
random variable X , and I(X;Y ) = H(X) − H(X|Y ) is
the mutual information between random variables X and Y .

In the exploration objective, (a) is the entropy of for-
mations, so maximizing (a) encourages the agents to visit
states in diverse formations as illustrated in Figure 1(a).
Here, maximizing (a) can be accomplished by visitation
count-based exploration (Ostrovski et al. 2017). We define a
formation-based count exploration reward rexpt = 1√

N(Ft)
,

then agents get higher rewards if they visit rarely visited for-
mations. In order to count the number of formation N(Ft),
we use round(·) method to discretize the formation Ft, and
then count the visitation number in the discretized bins. A
detailed explanation for counting is provided in Appendix
A. However, agents are partially observable in MARL, so

visiting diverse formations by maximizing (a) can be a chal-
lenging problem if the agents do not know the formation in-
formation at all. Thus, we consider an additional formation-
aware objective (b), which is the mutual information be-
tween the latent variable zjt , ∀j ∈ F i+ and the next for-
mation F i

F i,t+1, where the trajectory τ jt , the trajectories

τF
i+

t \{j} and the latent variables z
F i+\{j}
t of other agents

are given. Then, maximizing (b) guides the i-th agent to be
aware of not only its own next formationF i

F i,t+1 but also all

formations F j
F j ,t+1, ∀j s.t. i ∈ F j to which i-th agent be-

longs as illustrated in Figure 1(b). Thus, we maximize both
(a) and (b) to make agents visit exploration states in diverse
formations while recognizing their formations well.

In order to maximize (b), we derive an evidence lower
bound for the mutual information term based on the varia-
tional inference approaches (Kingma and Welling 2014; Li
et al. 2021), and then we will maximize the evidence lower
bound to increase the mutual information.

Lemma 2 (Evidence lower bound). Mutual information (b)
can be lower-bounded as

I(F i
F i,t+1; z

j
t |τF

i+

t , z
F i+\{j}
t ) ≥

EFi
Fi,t+1

,zj
t∼qϕe

[
log qϕf

(F i
F i,t+1|τ

F i+

t , zF
i+

t )

− log p(F i
F i,t+1|τ

F i+

t , z
F i+\{j}
t )

]
,

(5)

where qϕf
(·|τF i+

t , zF
i+

t ) is an arbitrary posterior distribu-
tion, and ϕf and ϕe parameterize the distributions qϕe

and
qϕf

, respectively.
Proof) Proof of Lemma 2 is provided in Appendix B
In the proof of Lemma 2, zjt is averaged over the distri-

bution qϕe(·|τF
i+

t , z
F i+\{j}
t ), but it makes difficult to uti-

lize the latent variable zjt in the decentralized execution
setup since j-th agent cannot exploit the other agent’s tra-
jectory information. Thus, for practical implementation, we

𝝏𝑳𝒈

𝝏𝝓𝒈

Gradient 
Flipping

−𝝀
𝝏𝑳𝒈

𝝏𝝓𝒆

𝑳𝒈

Encoder
𝝓𝒆

𝝉𝒕
𝒊

𝒛𝒕
𝒊

Buffer

𝐏𝐫𝐞𝐝𝐢𝐜𝐭𝐢𝐨𝐧
𝐌𝐒𝐄 𝐋𝐨𝐬𝐬 𝑳𝒇

෠ℱ
𝑭𝒊,𝒕+𝟏
𝒊 ℱ

𝑭𝒊,𝒕+𝟏
𝒊

𝝏𝑳𝒇

𝝏𝝓𝒇

𝝏𝑳𝒇

𝝏𝝓𝒆

𝑳𝒇

𝐑𝐞𝐜𝐨𝐧𝐬𝐭𝐫𝐮𝐜𝐭𝐢𝐨𝐧
𝐌𝐒𝐄 𝐋𝐨𝐬𝐬 𝑳𝒈

ො𝝉𝒕
𝒊𝝉𝒕

𝒊

Decoder
𝝓𝒈

𝒛𝒕
𝒊

Decoder
𝝓𝒇

𝒋 ∈ 𝑭𝒊𝒛𝒕
𝒋
,

Figure 4: F-Net Architecture