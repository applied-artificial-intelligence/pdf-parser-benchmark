28 Swiss Re Institute sigma 1/2023 Appendix 1: 2022 – the year in review

Primary and secondary perils
Hurricane Ian brought the share of insured losses from primary perils to 57% in 2022, 
from a previous 10-year average of 37%. 

Figure 21  
Insured catastrophe losses, 1970–2022, in USD billion at 2022 prices

Source: Swiss Re Institute

0

20

40

60

80

100

120

140

160

180

200

202120182015201220092006200320001997199419911988198519821979197619731970

Earthquake/tsunami Weather-related catastrophes Man-made disasters

Hurricanes
Katrina, Rita, Wilma

Hurricanes
Ike, Gustav

Japan,
NZ earthquakes,

Thailand flood

Hurricane
Sandy

Hurricanes
Harvey, Irma, Maria

Hurricane Ian

Hurricanes Ivan, 
Charley, Frances

Hurricane
Andrew

Winter
Storm Lothar WTC

Hurricane
Ida

Figure 22  
Global insured losses from primary and secondary perils in USD billion at 2022 prices

Source: Swiss Re Institute

0

25

50

75

100

125

150

175

202120182015201220092006200320001997199419911988198519821979197619731970

Primary perils (incl secondary effects)Secondary