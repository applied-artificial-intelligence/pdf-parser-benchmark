142    

OECD EMPLOYMENT OUTLOOK 2024 © OECD 2024 
  

3.1.1. Emissions are highly concentrated in specific sectors accounting for just 7% of 

employment 

High-emission industries, as defined in this chapter, account for about 80% of total GHG emissions across 

the OECD. There is some moderate variation across countries due to differences in the national energy 

mix, the size of high-emission industries and emission regulations. For instance, while high-emission 

industries in France and the Slovak Republic emit slightly less than 70% of national GHG emissions, the 

same sectors emit slightly more than 90% in the Czech Republic, Denmark, Greece, Finland, Iceland and 

Norway (Figure 3.2). Despite their significant contribution to emissions, high-emission industries employ 

only about 7% of the total workforce on average among OECD countries, suggesting that emissions are 

highly concentrated (Figure 3.2). Importantly, this fact implies that any future reductions in emissions will 

be concentrated in a comparatively small segment of the labour market. This is particularly true in Ireland, 

the Netherlands and the United Kingdom, where the share of the workforce in high-emission sectors is just 

below 5%, but even in Poland, the country with the highest share, where 79% of emissions is concentrated 

in industries representing 12% of the workforce. 

Figure 3.2. High-emission industries are responsible for most emissions but employ only a fraction 
of the workforce 

Share of GHG emissions and employment in high-emission industries by country, 2019* 

 

Note: * Data refer to 2016 and to CO2 emissions for Mexico and the United States. Average across 26 OECD countries shown. Agriculture is 

excluded. 

Source: OECD National Accounts and Eurostat Air Emissions Accounts. 

StatLink 2 https://stat.link/ejxuol 

3.1.2. Employment in high-emission industries has been declining and the decline is 

expected to accelerate in the years to come 

Reducing GHG emissions can be achieved by reducing economic activity in high-emission sectors as well 

as by changing the production technology within these sectors – see also OECD (2023[14]). Both processes 

require restructuring that may involve job losses and arising opportunities. Alongside previous declines in 

GHG emissions, employment in high-emission industries has indeed been shrinking substantially in 

EU countries during the period 2000-19, while employment in other sectors has continued to expand (see 

Figure 3.4) – in some cases also through green investment coupled with the explicit aim of creating quality 

0

10

20

30

40

50

60

70

80

90

100

0

2

4

6

8

10

12

14

16

18

20

Share in total emissions, %Share in employment, %

Share in employment Share in emissions (right scale)

https://stat.link/ejxuol