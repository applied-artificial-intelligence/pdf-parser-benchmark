PERSPECTIVE ECONOMICS 

4. Investment 

4.1. Investment to Date 

Dedicated UK semiconductor companies have secured a total of £1.7bn in grants and 

fundraisingsxii. This includes £291m in grants and £1.4bn in fundraisings. Forty-four 

companies have secured fundraisings, with approximately 70% of total fundraisings having 

been secured by five companies.  

Figure 4.1 shows the value of fundraisings secured by dedicated semiconductor companies 

within their latest fundraising rounds. N.B. previous fundraising values are not shown and 

totals therefore do not sum to the total £1.4bn. 

Figure 4.1 – Latest Fundraisings 

 

Source: Beauhurst (all latest fundraisings, 2007 - 2023) 

4.1.1. Investment by Stage of Evolution 

Just under three quarters of total fundraisings have been secured by growth-stage 

semiconductor companies. The value of grants secured by dedicated companies is more 

evenly spread across stages of evolution, including notably higher proportions secured by