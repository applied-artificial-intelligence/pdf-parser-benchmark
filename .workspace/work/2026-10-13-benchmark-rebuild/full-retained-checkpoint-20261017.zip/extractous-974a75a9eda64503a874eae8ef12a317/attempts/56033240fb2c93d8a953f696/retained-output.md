Historical Outcomes – CEO and Other NEO Compensation Growth 
vs. BlackRock’s Financial Growth
The contents of this section are supplemental to, and not intended to replace, the Pay Versus Performance disclosure 
made pursuant to Item 402(v) of Regulation S-K beginning on page 103. 

Our assessment and pay determination process has resulted in disciplined pay levels that have been outpaced by 
BlackRock’s financial and market value growth over time. This is demonstrated by the 3% annualized growth in CEO 
Total Annual Compensation and 3% annualized growth in average non-CEO NEO Total Annual Compensation since 
2014, during which time BlackRock’s Revenue, Operating Income, as adjusted, EPS, as adjusted, and Assets Under 
Management (AUM) have grown 6-10% per year. BlackRock has achieved annualized Total Shareholder Return of 14% 
per year over the period. 

10-Year BlackRock Annualized Growth Rates

3%
CEO Total Annual

Compensation

3%
Average Non-CEO 

NEO Total
Annual Compensation

6%
Revenue 

6%
Operating Income,

as adjusted(1)

8%
EPS, as 

adjusted(1)

10%
AUM

14%
Total 

Shareholder
Return

(1) See Annex A for further information on as adjusted items and reconciliations to GAAP.

The graph below reflects BlackRock’s financial growth as well as CEO total compensation decisions during the period 
from 2015 to 2024.

CEO Pay vs. Financial Growth

(1) Please see Annex A for reconciliations with GAAP for 2024, 2023 and 2022, our Form 10-K for the year ended December 31, 2023 
for reconciliations with GAAP for 2021, 2020 and 2019 and our Form 10-K for the year ended December 31, 2019 for 
reconciliations with GAAP for 2018, 2017, 2016 and 2015.

Executive Compensation

64 BLACKROCK, INC. 2025 PROXY STATEMENT