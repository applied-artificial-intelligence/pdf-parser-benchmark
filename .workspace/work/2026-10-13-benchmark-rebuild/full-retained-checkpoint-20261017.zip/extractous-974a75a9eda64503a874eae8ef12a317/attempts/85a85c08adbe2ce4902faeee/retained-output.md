TABLE VII: Lorentzian-fit parameters of ISGQR strength distributions in the Sn isotopes, as

extracted from MDA. The results from TAMU work, where available, are provided for compari-

son [19, 21].

Target EISGQR (MeV) Γ (MeV) EWSRa Reference

112Sn 13.4 ± 0.1 7.0± 0.5 1.08± 0.04 This work

13.48+0.15
−0.14 4.90+0.22

−0.27 0.88+0.14
−0.13 TAMU

114Sn 13.2 ± 0.1 6.8± 0.4 1.25± 0.05 This work

116Sn 13.1 ± 0.1 6.4± 0.4 1.12± 0.04 This work

13.50 ± 0.35 5.00 ± 0.30 1.08± 0.12 TAMU

118Sn 13.1 ± 0.1 6.6± 0.3 1.08± 0.03 This work

120Sn 12.9 ± 0.1 7.0± 0.7 1.04± 0.04 This work

122Sn 12.8 ± 0.1 7.8± 0.6 1.25± 0.04 This work

124Sn 12.6 ± 0.1 7.7± 0.9 1.13± 0.04 This work

12.72+0.11
−0.11 4.20+0.32

−0.03 0.89+0.15
−0.10 TAMU

aOnly statistical uncertainties are included; systematic errors, mostly from DWBA calculations, are ∼20%.

that are significantly closer to the experimental values, in particular with the surface pairing

forces and the SKM* interaction (K∞ ∼ 215 MeV) [78]. Thus, while pairing effects lower the

ISGMR excitation energies, one still needs to reduce the K∞ value by ∼10% for achieving

a reasonable agreement with the experimental data.

A very intriguing possibility in explaining the “softness” of the Sn isotopes has been

offered very recently by Khan [79, 80]. The author asserts that, in analogy with the

mutually-enhanced-magicity (MEM) effect observed in predictions of masses with different

energy-density functionals [81, 82], the ISGMR energy in the doubly-magic nuclei might be

anomalously higher. The obvious implication is that the calculations using interactions that

are successful in describing the ISGMR in the doubly-magic nucleus 208Pb would necessarily

overestimate the ISGMR energies in the open-shell nuclei. If this effect is manifested in any

significant way, the energy of the ISGMR in the non-doubly-magic Pb isotopes, 204Pb and

206Pb, would be measurably lower than that in 208Pb [80]. In the only measurement of the

ISGMR in 206Pb reported so far [83], this conjecture does not appear to hold. Still, precise

21