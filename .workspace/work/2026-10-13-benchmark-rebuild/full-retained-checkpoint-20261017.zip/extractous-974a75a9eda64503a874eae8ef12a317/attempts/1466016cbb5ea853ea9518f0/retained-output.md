As corporate attention wavers, consumer demand for authentic and responsible environmental action is intensifying. Climate 

anxiety is growing rapidly, especially in regions that are increasingly affected by extreme weather events. Sixty-one percent 

of consumers say they are more concerned about climate change than they were just two years ago, often because of direct 

personal experiences26.

The Future of ESG: Trust, Technology, and Consumer 
Expectations

6.3.

Source : Bain & Company, The Visionary CEO’s Guide to Sustainability, 2024. 26

Figure 1: When asked, most consumers say their concerns about climate change have increased in the past two years
Q : How have your climate change concerns changed over the past two years?

Percentage of respondent

100%

0
Overall US UK Nethelands Germany France Italy Japan Brazil China Indonesia

My concerns have intensifed/increased My concerns have not changed My concerns have subsied/decreased

61%
51% 52% 50% 51%

59%
70% 62%

78%
62%

73%

31%
42% 40% 39% 37% 33%

24% 34%
17%

28%
19%

8% 8%8%7% 6% 4% 4%8% 11% 12% 10%

In parallel, public trust is shifting: smaller businesses are now seen as more genuine and committed to sustainable practices 

than large corporations. This perception is beginning to influence behavior across sectors— for example, according to a Bain & 

Company survey conducted with 500 B2B buyers, 36% would stop working with suppliers that fail to meet their sustainability 

expectations27. ESG is no longer just about meeting regulations; it has become a key driver of trust among increasingly 

skeptical and climate-conscious stakeholders.

26 Bain & Company, The Visionary CEO’s Guide to Sustainability, 2024, https://www.bain.com/globalassets/noindex/2024/bain_report_the_visionary_ceos_
guide_to_sustainability-2024.pdf.
27Bain & Company, The Visionary CEO’s Guide to Sustainability, 2024, https://www.bain.com/globalassets/noindex/2024/bain_report_the_visionary_ceos_
guide_to_sustainability-2024.pdf

Nextcontinent

nextcontinent.net

2025 Business Outlook: Challenges & Opportunities for Consulting Firms

25