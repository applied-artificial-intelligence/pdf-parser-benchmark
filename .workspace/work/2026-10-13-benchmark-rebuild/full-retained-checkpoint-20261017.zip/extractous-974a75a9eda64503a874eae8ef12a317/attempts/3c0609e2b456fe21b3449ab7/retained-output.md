8 Source data: Table 9

$125B

$129B

$63B
$80B

$76B

$79B

$117B

Month of November 2024: $669B

$250B

$206B

$108B

$165B

$179B

$160B

$185B

Fiscal Year 2025 to Date: $1,253B

2024 2025

O
ct

N
ov

D
ec Ja
n

Fe
b

M
ar

A
pr

M
ay Ju
n

Ju
l

A
ug

S
ep O
ct

N
ov

$0B
$100B

$200B

$300B

$400B

$500B

$600B

$700B

$800B

$900B

$1,000B

O
ut
la
y 
A
m
ou
nt

Figure 7. Outlays of the U.S. Government, by Source, Fiscal Year 2025

Social Security Income Security National Defense

Net Interest

Other

Medicare Health

*Disclaimer: Other category is subject to change due to negative balances held.

Figure 8. Monthly Outlays of the U.S. Government, by Source, Fiscal Years 2024 and 2025

Social Security

Medicare

Income Security

Health

National Defense

Net Interest

Other

"Other" Includes: Administration of Justice, Agriculture, Community and Regional Development, Education, Training, Employment, and
Social Services, Energy, General Government, General Science, Space, and Technology, International Affairs, Natural Resources and
Environment, Transportation, Undistributed Offsetting Receipts, Veterans' Benefits and Services.
Note: Details may not add to totals due to rounding