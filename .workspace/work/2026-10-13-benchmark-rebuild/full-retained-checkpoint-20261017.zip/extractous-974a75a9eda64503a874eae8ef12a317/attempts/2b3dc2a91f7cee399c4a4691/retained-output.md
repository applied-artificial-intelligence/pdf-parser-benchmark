Clean Energy Market Monitor – March 2024  

PAGE | 15  

Clean energy deployment 

IE
A.

 C
C

 B
Y 

4.
0.

 

Wind capacity additions and avoided emissions 

 
IEA 2024. CC BY 4.0. 

Notes: “Avoided emissions” refers to avoided emissions in one year from cumulative deployment since 2019 to 2023. 

59

108
95

74

117

 30

 60

 90

 120

2019 2020 2021 2022 2023

World

G
W

487

99

95

18

131

 250  500

China

United States

European Union

India

Rest of world

Avoided emissions

Mt CO₂

26

70

48
37

74

 20

 40

 60

 80

2019 2020 2021 2022 2023

China

G
W

9

15 14

9

6 5

 10

 15

2019 2020 2021 2022 2023

United States

G
W

10 10
12

15
16

 5

 10

 15

 20

2019 2020 2021 2022 2023

European Union

G
W

2.2

1.1

1.6 1.8

2.7

 1

 2

 3

2019 2020 2021 2022 2023

India
G

W