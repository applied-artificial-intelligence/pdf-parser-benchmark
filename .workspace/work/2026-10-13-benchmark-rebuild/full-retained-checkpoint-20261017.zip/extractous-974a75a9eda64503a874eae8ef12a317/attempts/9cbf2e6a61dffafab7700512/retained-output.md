67

C
h

ap
ter 2

Chapter 2 • Global trends in e-Government

Figure 2.26 Percentage of countries providing sector-based information and services online and through  
 mobile channels and SMS alerts, 2024

Source: 2024 United Nations E-Government Survey.

The proportion of countries providing services for people in vulnerable situations has risen from 45 
to 70 per cent in Oceania and from 44 to 56 per cent in Africa. However, the share of countries that 
offer fully digitalized services is only 21 per cent in Oceania and 5 per cent in Africa. 

2.5.8 Sector-specific online information and services: sharing via mobile technologies

Online services specifically relating to health, education, employment, environment, justice, and 
social protection can be found on the portals of 58 to 74 per cent of the countries surveyed (see 
figure 2.26), and most of these services are easily accessible through mobile technologies and 
applications (apps). Services relating to education, health, and employment are the most prevalent 
and are available in almost three quarters of the countries surveyed. Services relating to justice (63 
per cent), social protection (63 per cent), and environment (58 per cent) are found on the portals of 
fewer countries. Although Governments still use SMS alerts to inform people about sector-specific 
services or important issues, this practice is not very common; 44 per cent of countries still utilize 
SMS for health sector alerts, but for the other five sectors the corresponding proportions range from 
19 to 28 per cent.

2.5.9 Technology subindex

At the time the 2024 Survey assessments were carried out, all countries except Belize had accessible 
national portals, and 98 per cent of those portals could be found by search engines. Most government 
portals (97 per cent) have a “contact us” page and utilize Hypertext Transfer Protocol Secure (HTTPS) 
to provide a safe experience for users (see figure 2.27). In 91 per cent of the countries assessed, the 
portals have been developed using responsive web design (a 3 per cent increase since 2022), and in 
89 per cent the portals are updated at least once a month (a 6 per cent increase). Most portals have 
a sitemap (74 per cent) and offer “advanced search” options (56 per cent); it should be noted that 
the proportion of countries offering the latter has declined (from 58 per cent) since 2022.

EDGI 2024  levels
Very high EGDI
High EGDI
Middle EGDI
Low EGDI

Very high EGDI

High EGDI

Middle EGDI

Low EGDI

193 UN Member States

Americas

Africa

Asia

Europe

Oceania

Very high EGDI
High EGDI
Middle EGDI
Low EGDI

74%

72%

58%

72%

63%

63%

77%

70%

61%

72%

65%

63%

14%

16%

13%

2%

20%

11%

28%

24%

22%

44%

19%

25%

Education

Employment

Environment

Health

Justice

Social protection

Availability of services Accessibility of services via mobile device (browser or app) Availability of SMS alerts