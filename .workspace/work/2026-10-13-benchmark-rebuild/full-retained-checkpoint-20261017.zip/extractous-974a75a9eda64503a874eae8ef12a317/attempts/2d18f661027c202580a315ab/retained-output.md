Chapter 1. Global Economic Inequality
Figure 1.1. The world is becoming richer

1,000

2,000

5,000

10,000

1,000

2,000

5,000

10,000

1800 1825 1850 1875 1900 1925 1950 1975 2000 2025

Ye
ar

ly
 p

er
 c

ap
ita

 n
at

io
na

l i
nc

om
e 

€ 
(a

t 2
02

5 
P

P
P

),
 lo

g 
sc

al
e

W
orld P

opulation

National income World population

Per capita income and population, 1800−2025

Interpretation. World population increased from 1 billion in 1800 to 8 billion in 2025, corresponding to an average
annual growth rate of about 0.9% per year. Yearly income per person increased from about €900 in 1800 to about
€14,000 in 2025, a multiplication by about 16 (corresponding to average annual growth rate of about 1.2% per
year). Sources and series: Gómez−Carrera et al. (2025), Nievas and Piketty (2025), and
wir2026.wid.world/methodology.

only 556 million individuals, roughly the sizeof the combined adult populations of theUnited States, Pakistan, and Brazil.
Looking more closely at the very top,the numbers become even smaller buthighly significant. The top 1% includesabout 56 million adults, similar to the adultpopulation of the United Kingdom. Thetop 0.1% (5.6 million adults) is similar insize to the total population of Singapore.The top 0.01% amounts to 556,000 adults,about the total population of Genoa inItaly. The top 0.001%, or 56,000 adults,could all fit inside a football stadium. Goingfurther, the top 0.0001% (around 5,600adults) would fill a concert arena, the top0.00001% (560 adults) a theater, andthe top 0.000001% (56 adults) a singleclassroom. These comparisons will helpillustrate just how concentrated the verytop of the distribution is, and they will serveas a reference throughout the report tohelp readers grasp the magnitude of globalinequality.

Extreme and rising income inequality
Keeping these figures in mind, Figure 1.3illustrates the extent of global inequality. Thetop 10% (about 560 million adults) receives53% of global income, while the bottom50% (roughly 2.8 billion adults) captures only8%. The contrast becomes even sharperwhen we zoom into the right-hand panel:the top 1%, a group of just 56 millionpeople, earns 2.5 times more than the entirebottom half of humanity. Put differently,a population comparable to the UnitedKingdom’s receives more income than agroup as large as the combined populationsof China, India, the United States, Indonesia,Nigeria, Brazil, and Russia.

If we look beyond these broad groupsand zoom in further still, the concentrationof income becomes even starker. Figure 1.4highlights the concentration of income evenmore clearly. The third column shows thatthe top 0.1% earns as much as the entirebottom 50%. This means that a group ofpeople no larger than the population ofSingapore takes in the same income ashalf of the world’s population. At the veryextremes, inequality becomes staggering:
36