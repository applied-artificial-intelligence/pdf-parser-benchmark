Commenced business as 
Rajoo Engineers Pvt. Ltd. at 
Manavadar, a small village 
in Junagadh Dist.  to 
manufacture mechanical 
cutting- sealing machines.

Ve n t u r e d  i n t o  t h e  
manufacture of blown 
film lines and delivered 
first PPTQ blown film line.

Launched monolayer 
b l o w n  f i l m  l i n e , 
christened FOILEX

Launched the first 
ever blown film line 
to manufacture 
c h e m i c a l l y  
foamed PE films

Launched the first ever 
sheet  l ine fo r  H IPS,  
christened LAMINA

Ra j o o  i n t r o d u c e d  
India's first ever Foamed 
PVC profile line and 
delivered to the pioneer 
in this field, M/S Trio 
Polymers, Junagadh

Begun operation at Rajkot. 
Entered  into a technical 
collaboration with a British 
Company. went public and 
the issue was over subscribed 
by nearly 24 times.

1986 1988 1989 1990 1991 1994 1995 1996 19971992

Made an entry into 
the In te rnat iona l  
market with maiden 
export of a blown film 
line to tanzania

Introduced the 
first Indian co-
extrusion feed 
b l o c k  f o r  
multilayer sheet 
line

Introduced the first 
ever indigenously 
d e s i g n e d  a n d  
d e v e l o p e d  
Oscillating Haul-off 
system for blown 
f i lm l i nes  and  
d i sp layed  a t   
Plastindia  1994.

introduced the first 
i n d i g e n o u s l y  
desined extruder 
i n c o r p o r a t i n g  
g rooved feed 
b u s h ,  b a r r i e r  
screw and cross-
h o l e  m i x i n g  
section.

Introduced Internal 
Bubble Cooling(IBC) 
System for blown 
film lines

Introduced the first 
i n d i g e n o u s l y  
designed wide width 
blown film line for  a  
lay-flat  width  of  
3000  mm MULTIFOIL

Exported country's 
first “CE” marked 
machine to the 
British market

Launched Asia's first 
ever  chemical l y 
foamed sheet line 
f o r  E P E  w a d s 
christened FOMEX

7 th
38  ANNUAL REPORT : 2024-2025 www.rajoo.com

3
8
 Y

EA
R
S 

O
F 

LE
A

D
ER

SH
IP