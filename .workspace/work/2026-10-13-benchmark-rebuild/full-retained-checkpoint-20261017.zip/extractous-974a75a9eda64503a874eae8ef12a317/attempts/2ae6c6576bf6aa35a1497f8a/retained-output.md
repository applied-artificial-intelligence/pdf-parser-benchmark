The Print Overlay display appears:

Print Overlay

Overlay . . . . . . . . . . : STATIONE
Library . . . . . . . . . : OVLLIB

Type choices, press Enter.

Output queue . . . . . . . . *JOB Name, *JOB
Library . . . . . . . . . Name, *LIBL, *CURLIB

Copies . . . . . . . . . . . 1 1-255
Print fidelity . . . . . . . *CONTENT *CONTENT, *ABSOLUTE

Bottom
F3=Exit F5=Refresh F12=Cancel

The print overlay function allows you to print an overlay on an IPDS printer.

From this display, you can specify the name of an output queue, the number of
copies, and print fidelity.

The following table describes the Print Overlay display.

Table 73. Print Overlay display fields
Field Name Description

Overlay Shows the name of the overlay to be printed.
Library Shows the name of the library in which the overlay resides.
Output queue Specifies the name of the output queue in which the spooled file will

be created.

The possible values are:

*JOB Specifies the output queue specified in the job description
associated with this job is used.

This is the default value.

output-queue-name
Specify the name of the output queue to be used.

Library Specifies the name of the library to locate the output queue. The
possible predefined values are:

*LIBL The library list is used to locate the output queue.

*CURLIB
The current library for the job is used to locate the output
queue. If no library is specified as the current library for the
job, library QGPL is used.

library-name
Specify the library where the output queue resides.

Copies Specify the number of copies you want to print. The range of valid
values is 1 to 255.

Chapter 19. Work with Overlays Function 345