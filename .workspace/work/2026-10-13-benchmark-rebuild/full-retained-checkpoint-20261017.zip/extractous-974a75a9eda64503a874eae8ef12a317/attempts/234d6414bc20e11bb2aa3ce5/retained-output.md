8

MC turnover trend by Service Lines (2021-23)

In 2023, in the European panel, Sales & Marketing (+20.7%) and Technology (+15.6%) have been the two fastest 
growing service lines.
Sales & Marketing, after a top growth in 2021 and a relevant slow down in 2022, is again the fastest growing 
service line.
People & Change, after a top growth in 2022, is experiencing a major decline (-11.5%) in spite of an overall MC 
market that is growing double digits.
Technology, Strategy and Operations are experiencing a more stable growth path, with highlighting that many 
clients are leveraging on technology – namely digital technologies – to redefine their post-pandemic strategies 
and operations.
Finance & Risk, after a record growth in 2020 and a decline in 2021, is also back to a more stable growth trend 
in 2022 and 2023.

Sales & Marketing 

Technology

Finance & Risk

Strategy 

Operations

People & Change

-5.0% 0.0% 5.0% 10.0% 15.0% 20.0% 25.0% 30.0% 35.0%

MC turnover trend by Service Lines (European panel 2021-23)

11.2%
9.3%

11.0%

11.1%
10.6%

15.6%

22.0%
10.9%

13.5%

6.1%
20.7%

30.6%

15.1%
13.1%

-1.2%

30.3%
10.8%

-11.5%

SERVICE LINE** European panel
trend in 2023*

European panel
trend in 2022*

European panel
trend in 2021*

Sales & Marketing 20.7% 6.1% 30.6%

Technology 15.6% 10.6% 11.1%

Finance & Risk 15.1% 13.1% -1.2%

Strategy 13.5% 22.0% 10.9%

Operations 11.0% 9.3% 11.2%

People & Change -11.5% 30.3% 10.8%

202120222023

Source: Our elaborations on MC turnover split by service lines – feaco survey 2021-2023.
* The European panel includes only 9 European countries of the feaco survey as detailed data for Spain and Slovenia are missing. 
These 9 countries represent 69% of the European GDP. Data from Ukraine have not been included in the European panel.
** The “Other” service line is not reported in the above table as it is not a homogenous category, and its trend would not convey 
a clear information on the actual market dynamics.

-10.0%