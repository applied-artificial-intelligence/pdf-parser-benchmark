U.S. Liability Management Transactions:  
Quarterly Update Through Q4 2025 

 

CreditSights.com   9 

 
Figure 2 

 

III. Litigation Updates  

 

A summary of the most notable ongoing court cases relating to liability management through Q4 

2025 (and into Q1 2026) follows: 

 

STG Logistics (NY Sup. Ct, County of New York; Bankr. D.N.J.): STG Logistics’ fall 2024 LMT ran 

the gamut of LMT structures, and included drop-down, tiered non-pro rata exchanges, and double 

dip components. Despite closing with roughly 93% participation from existing creditors, two 

holdouts, Audax and Siemens Financial, sued the company, participating lenders, and Antares (as 

agent) alleging a variety of breach of contract claims, as well as claiming a violation of New York’s 
fraudulent transfer law (the Uniform Voidable Transactions Act), and a breach of the implied 

covenant of good faith and fair dealing. Defendants filed motions to dismiss in spring 2025 (including 

on the basis that the plaintiff lack standing due to the credit agreement’s no action clause) and oral 
arguments were held before Judge Anar Patel of the Supreme Court of New York in August 2025. In 

a victory for plaintiffs, Judge Patel ruled on January 5, 2026, that most of the plaintiffs’ claims would 

survive the motion to dismiss (with the notable exception of a fraudulent transfer claim). As noted 

above, the company filed for bankruptcy protection on January 12, 2025 in the District of New 

Jersey with a $150 mn DIP in place and a prearranged plan to shed 91% of its funded debt load. 

See also Five Notable Arguments Worth Paying Attention to in STG Logistics’ LMT Litigation and 

STG Logistics – Plaintiffs Survive the Motion to Dismiss Largely Unscathed. 

2.50

2.75

3.00

3.25

3.50

3.75

4.00

4.25

4.50

1
Q

1
8

2
Q

1
8

3
Q

1
8

4
Q

1
8

1
Q

1
9

2
Q

1
9

3
Q

1
9

4
Q

1
9

1
Q

2
0

2
Q

2
0

3
Q

2
0

4
Q

2
0

1
Q

2
1

2
Q

2
1

3
Q

2
1

4
Q

2
1

1
Q

2
2

2
Q

2
2

3
Q

2
2

4
Q

2
2

1
Q

2
3

2
Q

2
3

3
Q

2
3

4
Q

2
3

1
Q

2
4

2
Q

2
4

3
Q

2
4

4
Q

2
4

1
Q

2
5

2
Q

2
5

3
Q

2
5

4
Q

2
5

PE-Backed │ All Loans

Source: Covenant Review, a Fitch Solutions Company

More Protective

Average Covenant Review Documentation Score of Institutional New-Issue Loans by Quarter