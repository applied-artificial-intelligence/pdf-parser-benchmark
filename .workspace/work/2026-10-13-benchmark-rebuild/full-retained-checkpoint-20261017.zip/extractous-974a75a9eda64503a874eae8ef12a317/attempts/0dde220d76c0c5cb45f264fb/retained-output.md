GOVERNANCE 

INPUTS THE ABB WAY

Financial
• Disciplined capital allocation 
• Robust risk management frameworks  
• Long-term financial stability 

Intellectual 
• Best of global technology with local 

engineering
• Technology leadership in digital 

transformation

Natural
• Reduction of environmental impact 

through waste management, 
reduced emissions and eco-friendly 
materials

• Emphasis on resource efficiency 
in manufacturing processes and 
customer solutions

Social and Relationship
• CSR and community development 

programs
• Industry collaboration through 

forums, partnerships and 
knowledge-sharing

Manufactured
• Manufacturing locations – 5
• Shop floors – 25
• Sales offices - 28
• Advanced production facilities 

and smart factories leveraging 
automation and AI

Human
• Skilled workforce and leadership 

talent 
• Learning and development programs
• Safe and inclusive workplace culture

USING THE INPUTS, WE RUN OUR BUSINESS ACTIVITIES 
IN LINE WITH OUR OPERATING MODEL, THE ABB WAY

CATERING TO 23 MARKET SEGMENTS

High: > 20% market growth Moderate: 7-20% market growth 

Railways 
& Metro 

Electronics Warehouse 
& Logistics 

Power 
Distribution 

Buildings & 
Infrastructure 

Renewables Automotive Water & Wastewater Datacenter 

DIVERSE BUSINESSES PORTFOLIO

Electrification Motion Process Automation

PURPOSE

BUSINESS  
MODEL 

O
P

E
R

A
T

IN
G

 CONTEXT

MATERIA

L T
O

P
IC

S
R

O
B

U
S

T
 G

O

V
ERNANCE

D
I

G
I

T
A

L
IZ

A

T
ION FOCUS

RISK M
A

N

A
G

E
M

E
N

T

STRONG PRESE
N

C
E

 A
C

R
O

S
S

Q
U

A
L

IT

Y FIRST
DECENTRA

LIZ
E

D
 S

E
T

U
P

Value Creation Model

38

ABB India Limited | Integrated Annual Report 2024