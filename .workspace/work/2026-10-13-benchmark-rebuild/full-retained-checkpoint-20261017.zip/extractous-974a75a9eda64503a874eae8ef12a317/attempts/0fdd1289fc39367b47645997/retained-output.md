Outlook for this 
fiscal year
Respondents’ average outlook for 
their firm’s fiscal year compared to 
the previous fiscal year skews slightly 
optimistic, with 44% who are optimistic.

Very pessimistic

Somewhat pessimistic

Neutral

Somewhat optimistic

Very optimistic

Interest rates and their impact on the economy

US presidential elections/geopolitical uncertainty

Rise of AI

Effects of hybrid work models on our organization

Increasing threat of cyberattacks

Rise of industrial automation

Rise of green resources and sustainable technology

Commercial real estate market

Other

44%  
are optimistic

26%  
are pessimistic

What is your outlook on your firm’s overall performance 
this fiscal year compared to last fiscal year?

What are the key external factors influencing your overall 
outlook for this fiscal year? (Select all that apply)

Outlook for current fiscal year (%)

Key external factors influencing outlook (%)

Source: Heidrick & Struggles US professional services partner compensation survey, 2024, n=142

Source: Heidrick & Struggles US professional services partner compensation survey, 2024, n=144

3

80

23

56

30

52

8

34

22

7

10

11

11

9

Future outlook 
and expectations

For this year’s report, given the 
unpredictability of the economy and 
professional services market, we asked 
respondents to share their expectations 
for the current fiscal year—whether they 
are optimistic, neutral, or pessimistic, 
and what external factors are most 
contributing to that outlook. 

Unsurprisingly, interest rates, AI, and 
the US presidential election and 

geopolitical uncertainty seem to be 
top of mind for everyone, regardless of 
their general outlook. What was more 
notable was respondents’ outlook 
regarding the effects of hybrid work 
models on their organizations. Those 
with a pessimistic outlook cited the 
effects of hybrid work only 13% of the 
time, while those with an optimistic 
outlook cited hybrid 27% of the time. It 
is encouraging to see that new working 

norms are more often a cause for a 
positive outlook, especially following so 
many years of uncertainty and conflict.

Regardless of these factors, our survey 
respondents’ average outlook for 
their firm’s fiscal year compared to 
the last year skews slightly optimistic. 
Respondents at smaller firms, those 
with between $1 billion and $5 billion 
in revenue, were the most optimistic.

External factors 
contributing to outlook
Regardless of respondents’ general 
outlook, interest rates and their impact 
on the economy is the top key external 
factor influencing respondents’ outlook. 
This is unsurprising given the effect 
interest rates have on all of consulting. 

It is also notable that the top three 
external factors influencing respondents’ 

Diverse region, inclusive workforces: Diversity and inclusion policy and practice in Asia PacificHEIDRICK & STRUGGLES

17