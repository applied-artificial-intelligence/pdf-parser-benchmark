34 35

Stakeholder Engagem
ent

Financial Capital:
Natural Capital

Hum
an Capital

Social Capital
Intellectual Capital

Ab
ou

t t
he

 R
ep

or
t

FY 2024-25Sustainability Report FY 2024-25 Sustainability Report
Le

ad
er

sh
ip

 In
si

g
h

ts
R

es
p

on
si

b
le

 B
an

ki
n

g
Ap

pr
oa

ch
 to

 g
ov

er
na

nc
e

St
ra

te
gy

Ab
ou

t t
he

 B
an

k

Partnership for Carbon Accounting Financials (PCAF)

In February 2025, SBI became a signatory to the Partnership for Carbon 
Accounting Financials (PCAF) which will ensure that its reporting 
continues to align with globally accepted standards, enhancing the 
credibility and acceptability of disclosures and reports. Adoption of 
PCAF’s standardized approach enhances the credibility of our reporting 
on GHG intensity for business activities and foster greater transparency 
for stakeholders which will enable more informed decision-making 
and facilitate effective monitoring of the Bank’s progress toward 
sustainability goals.

SBI Green, a dedicated platform

SBI Green, a dedicated platform has been introduced on Bank’s website, 
bank.sbi, to provide information on various products & services offered, 
enable one touch application for any specific Green digital product/
services, disclosure of reports, policies or any other green activities for 
better visibility.

Environmental, Social and Governance (ESG) framework for 
rating borrowers on ESG criteria 
Acknowledging material impact of ESG parameters of an entity on Sustainability of its operations, 
the Bank has developed a framework for rating Corporate borrowers on ESG parameters. This 
applies to borrowers (existing/prospective) in India with existing/proposed total exposure with SBI 
of above ₹ 100 crore (for listed borrowers) and above ₹ 250 crore (for unlisted borrowers). 

The following parameters are taken into account and monitored under the ESG criteria:

Formation of Green Clubs 
Green Clubs have been introduced at select outfits as an empowering mechanism for Branches 
/ Employees to adopt, participate and take up eco-friendly and sustainable activities and projects 
within the Bank which will help in reducing the carbon footprints in internal operations and to 
engage with and influence the neighbourhood communities for adoption of climate friendly 
and sustainable practices for a greener and cleaner planet. Various eco-friendly activities such as 
energy, paper and water saving initiatives, waste management, and awareness programs such as 
Green community outreach program  may be undertaken  by the branches/employees at select 
operating units. The performance of the Green Club Units is evaluated on various measurable and 
non-measurable parameters on a quarterly basis.

 Company’s energy 
consumption

 Emission of GHG gases

 Water usage and 
disposal of toxic water

 Solid waste 
management

 Emission reduction 
initiatives

 CSR contribution

 Turnover rate of employees

 Employee skill 
development

 Inclusive growth

 Equitable development

 Privacy and data security

 Negative news such 
as strike, protests and 
lockouts

 Business Responsibility 
reporting

 Composition of the 
company’s Board

 Financial 
disclosures

 Adherence 
to regulatory 
guidelines

 Related party 
transaction 
disclosures

 Ethical standards

 History of fraud 
default

Environmental 
concerns

Social  
concerns

Governance  
concerns

Green Reward points
The Bank also offers Green Reward Points to its customers, which can be redeemed for credit to 
SBI Green Fund, the proceeds of which is utilized for sustainable activities like tree plantation, 
installation of water harvesting units, construction of Bio-toilets, and Covid care activities etc.

Loans at foreign offices
Aligned with the Bank’s domestic initiatives, Foreign Offices are also pursuing green lending, 
climate finance, sustainable development projects, renewable energy, etc, demonstrating their 
broad engagement with sustainable finance.  Foreign Offices have integrated sustainable lending 
into their loan policies, in alignment with the Bank’s guidelines, local regulations, and global 
market practices. Foreign offices are striving to reduce their carbon footprints in their lending 
portfolio. They play a  vital role in supporting Indian corporates in their journey towards Net Zero 
by facilitating sustainable  Finance in Foreign Currency through External Commercial Borrowings 
(ECBs).The ECB & Syndication department at IBG is continuously exploring opportunities for ESG 
loans within the Bank’s approved framework.

Foreign Offices are actively participating in Green Loans, Social Loans, and Loans with 
Sustainability-linked pricing. Foreign Offices have extended 76 loans with an outstanding amount 
of USD 1,724 million under sustainable finance.

Type of Loan Number of Loans
Outstanding Amount  

(USD million)

Green & Social 22 170.16

Sustainability-linked Pricing 54 1,553.63

Total 76 1,723.79

Types of loans extended by Foreign Offices