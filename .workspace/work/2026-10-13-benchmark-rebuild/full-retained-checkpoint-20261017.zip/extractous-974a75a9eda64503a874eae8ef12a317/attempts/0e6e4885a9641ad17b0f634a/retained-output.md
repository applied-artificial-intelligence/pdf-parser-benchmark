2 
 

Deal and the Single Market Strategy. It builds on the reports by former Prime Minister Letta 
on the Single Market5, former Prime Minister Draghi on competitiveness6, and former 
President Niinistö on preparedness7. It responds to calls from businesses to put competitiveness 
at the core of the EU’s agenda8. 

Figure 1: Evolution of labour productivity in the EU and other advanced economies  

 
Source: AMECO database. GDP per capita in purchasing power parities (PPP) per hour worked. Values 
indexed with EU at 100 in 2023. 
 
With its 22 Key Performance Indicators (KPIs)9, the report provides an analysis of the 
key drivers of the EU’s long-term competitiveness and productivity, as well as the state 
of the Single Market. It provides a basis for discussion with Member States and the European 
Parliament, allowing to take stock of the Single Market and the EU’s competitiveness as part 
of an annual progress review10, following up on a request of the European Council11 building 
on the 2023 Communication on Long-term competitiveness of the EU12. It is supported by two 
Staff Working Documents providing additional data coverage and analysis related to the KPIs, 
an overview of resilience measures by selected global players, and a monitor of industrial 
ecosystems. These elements are complemented by the Single Market and Competitiveness 
Scoreboard featuring an additional 150 indicators13.  

The report identifies strengths to build on and weaknesses to address. It starts from an 
assessment of the functioning of the Single Market and moves on to take stock of the EU’s 
competitiveness along the three axes of the Competitiveness Compass. It examines the EU’s 
progress in closing the innovation gap. The report then presents the state of play of drivers 
advancing the decarbonisation of industry and investment. Finally, the report looks at progress 
in strengthening economic security and reducing dependencies.  

 
5  Former Prime Minister Letta, “Much more than a Market”. 
6  Former Prime Minister Draghi, “The future of European competitiveness – A competitiveness strategy for Europe”.  
7  Former President Niinistö, “Enhancing the European Union’s Resilience for Future Uncertainties”. 
8  Calls from the business community include, for example, the Antwerp Declaration for a European Industrial Deal. 
9  This year’s edition of the report departs from the 17+2 KPIs from the 2024 ASCMR, complementing with alimited 

number of additions to deepen the analysis in areas of crucial interest. 
10  Communication ‘The Single Market at 30’ (COM(2023)162). 
11  The European Council (EUCO) Conclusions of December 2022 asked the Commission to present a strategy at EU level 

to boost competitiveness and productivity.  
12  Communication ‘Long-term competitiveness of the EU: looking beyond 2030’(COM(2023) 168). 
13  European Commission, Single Market Scoreboard. 

https://www.consilium.europa.eu/media/ny3j24sm/much-more-than-a-market-report-by-enrico-letta.pdf
https://commission.europa.eu/topics/strengthening-european-competitiveness/eu-competitiveness-looking-ahead_en
https://commission.europa.eu/document/download/5bb2881f-9e29-42f2-8b77-8739b19d047c_en?filename=2024_Niinisto-report_Book_VF.pdf
https://antwerp-declaration.eu/
https://single-market-economy.ec.europa.eu/publications/single-market-30_en
https://www.consilium.europa.eu/en/meetings/european-council/2022/12/15/
https://commission.europa.eu/system/files/2023-03/Communication_Long-term-competitiveness.pdf