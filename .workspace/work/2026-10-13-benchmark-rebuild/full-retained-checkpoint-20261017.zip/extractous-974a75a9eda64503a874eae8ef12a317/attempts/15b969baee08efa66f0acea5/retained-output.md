As of December 31, 2003, there remained 72,534 shares for which options may be granted in the future under the 1997 Stock Incentive Plan. The following
table summarizes information about stock options outstanding at December 31, 2003:

OPTIONS OUTSTANDING OPTIONS EXERCISABLE
WEIGHTED WEIGHTED WEIGHTED

AVERAGE AVERAGE AVERAGE
NUMBER REMAINING EXERCISE NUMBER EXERCISE

RANGE OF EXERCISE PRICES OUTSTANDING CONTRACTUAL LIFE PRICE EXERCISABLE PRICE

$6.875-$14.063 143,100 5.3 years $ 11.53 112,000 $ 11.04

$14.875-$22.50 85,000 4.2 years $ 18.28 85,000 $ 18.28

$26.13-$31.39 59,500 5.3 years $ 30.15 20,000 $ 27.72

287,600 217,000

Pro forma information regarding net income and income per share as required by SFAS No. 123 has been determined as if the Company had accounted
for its stock options under the fair value method of that statement. The fair value for these options was estimated at the date of grant using a Black-Scholes
option pricing model with the following weighted average assumptions for 2003, 2002 and 2001:

2003 2002 2001

Risk-free interest rate 3.2% 2.7% 5.2%

Dividend yield 0.0% 0.0% 0.0%

Volatility factor 39.1% 50.3% 33.0%

Expected life 7 years 2.7 years 7 years

The resulting estimated weighted average fair values of the options granted in 2003, 2002 and 2001 were $13.51, $7.25 and $7.06, respectively.

The Black-Scholes option pricing model was developed for use in estimating the fair value of traded options which have no vesting restrictions and are fully
transferable. In addition, option valuation models require the input of highly subjective assumptions, including expected stock price volatility. All options
grants in 2003, 2002 and 2001 occurred prior to the declaration of dividends by the Company.

R E V E N U E S  F R O M  M A J O R  C U S T O M E R S

The Company had one major customer which represented approximately $9.1 million (14.4 percent), $7.4 million (12.4 percent) and $11.0 million
(19.1 percent) of the Company’s operating revenues during the years 2003, 2002 and 2001, respectively.

I N D U S T R Y  S E G M E N T  A N D  G E O G R A P H I C  I N F O R M A T I O N

The Company operates in one reportable industry segment: designing, developing, manufacturing and marketing products for the medical and health care
industry and has no foreign operating subsidiaries. The Company’s product lines include pressure relief valves and inflation systems, which are sold primarily
to the aviation and marine industries. Due to the similarities in product technologies and manufacturing processes, these products are managed as part of
the medical products segment. The Company recorded incidental revenues from its oxygen pipeline, which totaled approximately $950,000 in each of the
years of 2003, 2002 and 2001. Pipeline net assets totaled $2.6 million at December 31, 2003 and 2002. Company revenues from sales to parties outside the
United States totaled approximately 26, 25 and 33 percent of the Company’s total revenues in 2003, 2002 and 2001, respectively. No Company assets are
located outside the United States. A summary of revenues by geographic territory for the three years 2003, 2002 and 2001 is as follows (in thousands):

YEAR ENDED DECEMBER 31,
2003 2002 2001

United States $ 46,721 $ 44,454 $ 38,805

Canada 8,620 6,938 10,635

United Kingdom 1,547 1,693 2,182

Other 5,915 6,448 5,983

Total $ 62,803 $ 59,533 $ 57,605

19

9

10