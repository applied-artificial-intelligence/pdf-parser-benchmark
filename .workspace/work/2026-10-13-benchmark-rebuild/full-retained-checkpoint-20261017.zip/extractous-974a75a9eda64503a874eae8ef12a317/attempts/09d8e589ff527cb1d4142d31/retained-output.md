The race for scale in AI, which peaked between 2019 and 2021, has slowed, with Google’s 
1.6 trillion parameter Switch-C setting the record back in 2021.11 Although GPT-4 and similar 
models have not surpassed this record, their typical model size is increasing. Since Meta’s 
LLaMa model leak in February 202312, the proliferation of smaller AI models (five to 70 billion 
parameters) has surged, particularly in the open-source community. This “missing middle” 
category is now a hotbed for innovation, as these models are small enough for researchers 
and individuals to explore with high-end personal hardware. 

Transforming data centers with AI accelerators 
AI adoption, particularly the shift from predictive to generative AI, is leading to burgeoning 
demand for semiconductors, specifically AI accelerators and high-bandwidth memory (HBM). 
Traditional machine learning models and smaller neural networks in the sub-500M weight 
class, such as YOLO-v5, are being replaced by larger models in the 5B–70B weight class, 
such as Phi, Gemma, and Mistral-7B. As AI computing demand surges, NVIDIA’s data center 
business is expected to generate more than $80 billion this year, despite not all revenue 
being strictly related to compute or AI. This projection is particularly striking given that, prior 
to its standout 2Q23 results, the company’s total revenue was less than half of that figure. 

The rapid growth in demand for AI silicon, especially in data centers, has shifted the traditional 
relationship between CPUs and co-processors such as GPUs or domain-specific ASICs. 
Increasingly, CPUs are becoming the business logic co-processors for GPUs, or are acting 
as orchestrators for a diverse range of specialized accelerators (see Exhibit 15). 

Exhibit 15 

AI processors market for cloud and data center, 2021–2029 ($bn) 

50% 

74% 

80% 

116 

84% 

130 

84% 

141 

85% 

150 

81% 

152 

93 

35 

6 

2021 

10 

2022 2023 2024F 2025F 2026F 2027F 2028F 2029F 

AI processor revenue 

% of data center TAM 

Source: Omdia Q3 2024 

PwC | State of the Semiconductor Industry    28