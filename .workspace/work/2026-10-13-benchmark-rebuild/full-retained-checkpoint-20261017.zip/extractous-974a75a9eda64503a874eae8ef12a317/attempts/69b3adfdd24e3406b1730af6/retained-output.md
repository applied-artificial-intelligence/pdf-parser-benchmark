The BEAT | June 2025

With Recent Developments, Have We Reached Peak Tariff De-escalation?

TOP THEMES

Source: Bloomberg, Yale Budget Lab, MSIM. As of May 20, 2025. For illustrative purposes only. Not a recommendation to buy or sell any security. It is not possible to invest directly in an 
index. The views and opinions expressed are those of the portfolio management team at the time of writing/of this presentation and are subject to change at any time due to market, 
economic, or other conditions, and may not necessarily come to pass.  Forecasts/estimates are based on current market conditions, subject to change, and may not necessarily come to 
pass. Past performance is not indicative of future results.

With the May 12th temporary pause/reduction of tariffs on China, the overall average effective tariff rate (as estimated by the 

Yale Budget Lab) fell by just over 10%, down to 17.8% on a pre-substitution basis. With the recent de-escalation with China 

proving to be much more significant than market expectations, further reductions seem less likely.

Following the Recent Trade Deal With China, Have We Reached Peak Tariff De-escalation?

Average pre/post-substitution effective tariff rate (%), as estimated by the Yale Budget Lab

6

10

12

14

16

18

20

22

24

26

28

30

3/
15

/2
02

5

3/
17

/2
02

5

3/
19

/2
02

5

3/
21

/2
02

5

3/
23

/2
02

5

3/
25

/2
02

5

3/
27

/2
02

5

3/
29

/2
02

5

3/
31

/2
02

5

4/
2/

20
25

4/
4/

20
25

4/
6/

20
25

4/
8/

20
25

4/
10

/2
02

5

4/
12

/2
02

5

4/
14

/2
02

5

4/
16

/2
02

5

4/
18

/2
02

5

4/
20

/2
02

5

4/
22

/2
02

5

4/
24

/2
02

5

4/
26

/2
02

5

4/
28

/2
02

5

4/
30

/2
02

5

5/
2/

20
25

5/
4/

20
25

5/
6/

20
25

5/
8/

20
25

5/
10

/2
02

5

5/
12

/2
02

5

5/
14

/2
02

5

5/
16

/2
02

5

5/
18

/2
02

5

5/
20

/2
02

5

Pre-Substitution Average Effective Tariff Rate Post-Substitution Average Effective Tariff Rate

Pre-Liberation day

April 2nd Announcement

April 9th Delay, China Escalation

US/China 
De-escalation