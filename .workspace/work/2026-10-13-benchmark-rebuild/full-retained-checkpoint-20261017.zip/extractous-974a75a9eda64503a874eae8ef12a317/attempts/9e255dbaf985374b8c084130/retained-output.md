4 Swiss Re sigma No 1/2021

Last year’s loss experience reaffirmed the significant threat presented by secondary perils. Secondary perils caused 
more than 70% of insured losses from all natural catastrophes (USD 81 billion) in 2020.1 Accumulated losses from 
many small- and mid-size events made it the fifth-costliest year on record in insured loss terms. The main drivers were 
SCS and wildfires in the US and Australia. In all regions where extreme weather events occurred, the experience was 
shaped by the complex interplay of natural-world phenomena, including climate change, and socio-economic trends. 

Secondary and primary peril loss developments 
The term primary perils references catastrophes of larger scale, notably tropical 
cyclones, earthquakes and European winter storms. Events tend to be less frequent, 
but resulting losses can be extreme. We use secondary perils as an umbrella term 
for natural catastrophes that typically generate losses of low to medium magnitude, 
but that can happen relatively frequently. These include “independent secondary 
perils” such as SCS (including thunderstorms, hail and tornadoes), drought, wildfire, 
snow, flash floods and landslides. Primary perils can also trigger causally-linked 
consequential losses, for instance from heavy rains in the wake of a tropical cyclone, 
a storm surge induced by a winter storm, or fire outbreak after an earthquake. We 
consider these to be “secondary effects of primary perils” that also fall into the 
secondary perils bucket. Losses from primary and secondary perils have both risen 
continuously since 1970 (see Figure 1).

The largest annual insured loss total from independent secondary peril events –  
USD 62 billion – occurred in 2011, the year of devastating floods in Thailand and 
high-loss tornado outbreaks in the US. More recently, three of the four costliest 
secondary perils years occurred during 2017–2020. Primary perils are well-
monitored risks and the re/insurance industry’s modelling capabilities of these 
exposures are strong. Their secondary effects, however, are not always fully 
captured. Likewise, independent secondary events are often also not fully monitored 
nor modelled. Given the rise of their associated losses in absolute terms, secondary 
perils need to be better understood for the purpose of more complete risk 
assessment and sustainable underwriting of natural catastrophe risks overall.

1   Unless otherwise stated in the text, all loss numbers in the report as inflation-adjusted.

Secondary perils are high frequency, 
low- to medium-severity events.

Figure 1  
Annual primary and secondary peril insured losses since 1970 (USD billion) at 2020 prices, and share of secondary 
peril in total insured losses (five-years accumulated)

Source: Swiss Re Institute 

0

25

50

75

100

125

150

175

20202015201020052000199519901985198019751970

0%

20%

40%

60%

80%

100%

In
su

re
d 

lo
ss

es

Se
co

nd
ar

y 
pe

ril
s 

sh
ar

e

Independent secondary perils 5-years accumulatedPrimary perils Secondary perils share:Secondary effects of primary perilsInsured losses:

Primary perils are better understood 
than secondary peril risks.

Exploring the secondary perils universe