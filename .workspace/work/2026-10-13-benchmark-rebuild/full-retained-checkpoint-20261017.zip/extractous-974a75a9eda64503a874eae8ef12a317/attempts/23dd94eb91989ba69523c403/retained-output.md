 129 

OECD EMPLOYMENT OUTLOOK 2024 © OECD 2024 
  

Annex Figure 2.C.13. The incidence of job strain is lower in new and emerging and green-enhanced 
skills green occupations even when controlling for the job characteristics 

Marginal effect of the job strain indicator on the share of green-driven occupations, controlling for main individual 

and job characteristics, 2021 for EU-OECD countries and 2015 for the United States 

 

Note: The chart reports the point estimate (and 95% confidence intervals) of the percentage difference in the incidence of each type of green-

driven occupation between job strained and not strained workers. Estimates are obtained from a linear regression with the inverse hyperbolic 

sine of the share of each type of green-driven occupation within all, high, medium or low-skilled occupations as dependent variable and including 

a job strain dummy, the share of 1-digit ISCO occupations, educational attainment (3 classes), gender, age (3 classes), sectors (5 categories), 

and country dummies as explanatory variables. Standard errors are clustered on the dimensions of variability of the dependent variable. The 

reported point estimates and confidence intervals refer to the estimated coefficient of the job strain dummy and are expressed in percentage of 

the untransformed dependent variable. The sample excludes Agriculture. 

Reading: Controlling for demographic and job characteristics, the percentage share of green new and emerging occupations is, on average, 

12% lower among strained employees, i.e. employees whose number of job demands exceeds the number of job resources. 

Source: Secretariat’s estimates based on version 24.1 of the O*NET database and the European Working Conditions Telephone Survey 2021 

and the American Working Conditions Survey 2015. 

StatLink 2 https://stat.link/vgu8as 

-40

-30

-20

-10

0

10

20

30

Green-driven occupations Green new and emerging
occupations

Green-enhanced skills
occupations

Green increased demand
occupations

GHG-intensive occupations

%

https://stat.link/vgu8as