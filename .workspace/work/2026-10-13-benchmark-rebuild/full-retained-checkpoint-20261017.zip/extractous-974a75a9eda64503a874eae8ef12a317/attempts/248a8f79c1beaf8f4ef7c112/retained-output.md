114  

DO ADULTS HAVE THE SKILLS THEY NEED TO THRIVE IN A CHANGING WORLD? © OECD 2024 

Figure 3.5. Long-term trends in literacy proficiency  

Average literacy proficiency scores in IALS and Cycles 1 and 2 of the Survey of Adult Skills 

Note: Adults aged 16-65; does not include adults who in Cycle 2 were only administered the doorstep interview due to a language barrier, to 

maximise the comparability across cycles (see Box 1.1 in Chapter 1 and Box 3.2). *Caution is required in interpreting results due to the high 

share of respondents with unusual response patterns. See the  ote for Poland in the Reader’s Guide. 

Source: Statistics Canada (2024[12]), International Adult Literacy Survey (IALS),  https://www150.statcan.gc.ca/n1/  (accessed on 23 September 

2024); OECD (2018[4]; 2015[5]; 2012[6]), Survey of Adult Skills (PIAAC) databases, http://www.oecd.org/skills/piaac/publicdataandanalysis/ 

(accessed on 23 September 2024); Table A.3.23 (L) in Annex A. 

 mproving  egative  but flattening improving

 lat  lat  decreasing

310

290

2 0

2 0

230

210

199 1998 2002 200 2010 201 2018 2022

Score

 ear

 ositive  flattening
310

290

2 0

2 0

230

210

199 1998 2002 200 2010 201 2018 2022

1998 2002 200 2010 201 2018 2022199 1998 2002 200 2010 201 2018 2022  ear 199 

199 1998 2002 200 2010 201 2018 2022  ear 199 1998 2002 200 2010 201 2018 2022

Score

310

290

2 0

2 0

230

210

Score

310

290

2 0

2 0

230

210

Score

310

290

2 0

2 0

230

210

Score

310

290

2 0

2 0

230

210

Score

 ump s aped

Finland

Canada

Ireland

C echia

 etherlands

Italy

England (U  

 ew  ealand

Poland 

Hungary

Flemish Region ( E 

United States

Chile

 enmark
 orway

Germany

Sweden

https://www150.statcan.gc.ca/n1/pub/89m0016x/89m0016x2024001-eng.htm
http://www.oecd.org/skills/piaac/publicdataandanalysis/