10 Swiss Re Institute sigma 1/2023 In perspective: 2022 and longer-term trends

Up-trend reaffirmed, and set to continue

Insured losses from natural catastrophes have been on a long-term upward trajectory for 
much longer than the last six years. Since 1992, the average annual trend growth of 
losses has been 5‒7% (see Figure 6). In the period 2012‒2016, losses were at a lower 
annual mean, but there has been a return to said trend growth over the last six years and 
we expect this to continue. We project that irrespective of year-on-year volatility, insured 
losses will continue to grow at trend, even when real-time amplifying factors such as 
high inflation subdue. 

Starting from 2017, average annual insured losses from natural catastrophes have been 
above USD 110 billion, more than double the average of USD 52 billion over the previous 
5-year period. This marks a notable step-up in the scale of losses after the 2012‒2016 
period of benign losses. Asset value accumulation in an area struck by an extreme 
weather or other natural catastrophe can spark heavy financial losses. Another factor 
has been changes in construction costs. Of late, aging infrastructure vulnerabilities and 
inflationary pressures have boosted repair costs. And, with demand-supply imbalances 
of materials and labour still in play in the post COVID-19 era, we expect construction 
costs to remain elevated into 2023, further inflating repair and reconstruction costs. This 
will impact attritional losses and further augment property losses over the next two years 
at least. Hazard intensification will likely play a bigger contributory role to rising losses in 
the coming decade also. With the world getting warmer, findings from scientific 
research infer that climate change effects on loss frequency and severity will intensify.

We also expect, irrespective of below-average loss years, that annual insured losses will 
average more than USD 100 billion from hereon. Our expectation is supported by other 
parties: for example, Verisk recently modeled the global insured average annual loss as 
USD 123 billion.14 In any one year losses can be higher or lower depending on whether 
natural catastrophe events do or do not strike urban and more populated areas. A case in 
point, had Hurricane Ian last year made landfall in the Tampa Bay area as many 
predictions were showing, the resulting losses would have been much higher. There is 
no reason to anticipate that this, nor peak-loss disasters like Hurricane Katrina in 2005, 
will not happen again in the future. The takeaway is to not underestimate loss potential 
on account of a year or period of below trend growth.

14 Global Modelled Catastrophe Losses, Verisk, 2022.

We expect that average insured losses 
from natural catastrophes will continue to 
grow by 5‒7% annually.

Figure 6  
Growth in global natural catastrophe insured losses in USD billion (2022 prices) 

Source: Swiss Re Institute

0

25

50

75

100

125

150

175

200

2022202020182016201420122010200820062004200220001998199619941992

TrendEarthquakes Weather-related

Since 2017, average annual insured losses 
have exceeded USD 110 billion.

Losses of more that USD 100 billion 
annually are here to stay.

https://www.air-worldwide.com/siteassets/Publications/White-Papers/documents/2022_Global_Modeled_Catastrophe_Losses.pdf