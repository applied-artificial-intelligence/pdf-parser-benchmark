2024 UN E-GovErNmENt SUrvEy

76

C
h

ap
ter 2

Figure 2.33 Average OSI subindex values for groups of countries in special situations relative to global  
 averages, 2024

Overall, the legislative framework for advancing e-government is better developed in llDcs, 
including those that are least developed, than in SIDS or lDcs (see figure 2.35). Most llDcs have 
an e-government or digital government strategy (78 per cent), legislation or policy documents on 
cybersecurity (91 per cent), legal provisions for data protection (88 per cent), legislation governing 
freedom of information (78 per cent), and digital ID regulations (72 per cent). Fewer SIDS and lDcs 
(51 to 65 per cent) have these types of legislation in place, and the proportions are even lower for 
lDc/SIDS (between 13 and 65 per cent, depending on the type of legislation).  

Source: 2024 United Nations E-Government Surveys.

Americas

Africa

Asia

Europe

Oceania

Very high EGDI
High EGDI
Middle EGDI
Low EGDI

0.2791

0.3261

0.3672

0.4444

0.6875

0.3598 0.5754

0.00 0.25 0.50 0.75 1.00

EPI

SP

TEC

CP

IF

LDC/LLDCs
Linear (average OSI for LDC/LLDCs)
Linear (global average OSI)

0.4919

0.5363

0.5606

0.6644

0.8079

0.5754

0.00 0.25 0.50 0.75 1.00

EPI

TEC

SP

CP

IF

193 UN Member States Linear (global average OSI)

Yes No Metrix Yes No Metrix Yes No Metrix Yes No Metrix Yes No Metrix
SIDS LDCs LLDCs LDC/LLDCs LDC/SIDS

LDC/LLDCs
Linear (average OSI for LDC/LLDC)
F

Linear (global average OSI)

0.1969

0.2169

0.2344

0.3333

0.4750

0.2407 0.5754

0.00 0.25 0.50 0.75 1.00

EPI

SP

TEC

CP

IF

LDC/SIDS
Linear (average OSI for LDC/SIDS)
Linear (global average OSI)

0.3081

0.3902

0.4038

0.5075

0.6746

0.4076 0.5754

0.00 0.25 0.50 0.75 1.00

EPI

TEC

SP

CP

IF

SIDS

Linear (average OSI for SIDS)
Linear (global average OSI)

0.2569

0.2878

0.3667

0.4272

0.6284

0.3264 0.5754

0.00 0.25 0.50 0.75 1.00

EPI

SP

TEC

CP

IF

LDCs
Linear (average OSI for LDCs)
Linear (global average OSI)

EPI

TEC

SP

CP

IF

LLDCs
Linear (average OSI for LLDCs)
Linear (global average OSI)

0.3960

0.4668

0.4680

0.5938

0.7725

0.5754

0.00 0.25 0.50 0.75 1.00

0.4885

Americas

Africa

Asia

Europe

Oceania

Very high EGDI
High EGDI
Middle EGDI
Low EGDI

0.2791

0.3261

0.3672

0.4444

0.6875

0.3598 0.5754

0.00 0.25 0.50 0.75 1.00

EPI

SP

TEC

CP

IF

LDC/LLDCs
Linear (average OSI for LDC/LLDCs)
Linear (global average OSI)

0.4919

0.5363

0.5606

0.6644

0.8079

0.5754

0.00 0.25 0.50 0.75 1.00

EPI

TEC

SP

CP

IF

193 UN Member States Linear (global average OSI)

Yes No Metrix Yes No Metrix Yes No Metrix Yes No Metrix Yes No Metrix
SIDS LDCs LLDCs LDC/LLDCs LDC/SIDS

LDC/LLDCs
Linear (average OSI for LDC/LLDC)
F

Linear (global average OSI)

0.1969

0.2169

0.2344

0.3333

0.4750

0.2407 0.5754

0.00 0.25 0.50 0.75 1.00

EPI

SP

TEC

CP

IF

LDC/SIDS
Linear (average OSI for LDC/SIDS)
Linear (global average OSI)

0.3081

0.3902

0.4038

0.5075

0.6746

0.4076 0.5754

0.00 0.25 0.50 0.75 1.00

EPI

TEC

SP

CP

IF

SIDS

Linear (average OSI for SIDS)
Linear (global average OSI)

0.2569

0.2878

0.3667

0.4272

0.6284

0.3264 0.5754

0.00 0.25 0.50 0.75 1.00

EPI

SP

TEC

CP

IF

LDCs
Linear (average OSI for LDCs)
Linear (global average OSI)

EPI

TEC

SP

CP

IF

LLDCs
Linear (average OSI for LLDCs)
Linear (global average OSI)

0.3960

0.4668

0.4680

0.5938

0.7725

0.5754

0.00 0.25 0.50 0.75 1.00

0.4885