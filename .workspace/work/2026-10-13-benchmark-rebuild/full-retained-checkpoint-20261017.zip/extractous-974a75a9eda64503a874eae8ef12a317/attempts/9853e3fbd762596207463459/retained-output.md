Highlights 
of FY2022

DIVERSIFIED AND RESILIENT 
PORTFOLIO ACROSS GEOGRAPHY, 

ASSET CLASS AND INDUSTRIES

TENANTS' INDUSTRIES 
BY MONTHLY RENTAL INCOME

Technology1 42.2%

Logistics & Supply Chain Management 11.8%

Biomedical Sciences 9.3%

Others 36.7%

1 Includes Information & Communications Technology,  
Data Centres, Engineering, Electronics and e-Commerce.

Note: All information as at 31 December 2022.

ROBUST OPERATIONAL 
PERFORMANCE

HEALTHY 
BALANCE SHEET

SUSTAINABILITY 
EFFORTS

Portfolio occupancy 
reached a high of

94.6%
Aggregate 

Leverage at 

36.3%
FY2022 Distribution 
per Unit increased

3.5% y-o-y

Achieved average rent 
reversions of

8% during FY2022

Moody's 

A3
Credit Rating

Achieved
3-star rating

for GRESB Real Estate 
Assessment

Achieved
A rating

for GRESB Public Disclosure 
for third consecutive year

PORTFOLIO 
BY ASSET VALUE By Geography   By Segment

Singapore 62%

United States 15%

Australia 14%

United Kingdom / Europe 9%

Business Space 40%

Life Sciences 8%

Logistics 25%

Industrial 19%

Data Centres 8%

Business 
Space and 
Life Sciences1

48%Industrial and 
Data Centres3

27%

Logistics2
25%

S$16.4B
Asset Value

1 Comprises properties which were previously classified as business and science parks in Singapore; 
suburban offices in Australia; business park and office properties in the US.

2 Includes Courts Megastore and Giant Hypermart which were previously classified as integrated 
development, amenities and retail (IDAR) segment.

3 Comprises properties which were previously classified as high-specifications and light industrial 
segments (includes Aperia which was previously under the IDAR segment).

CapitaLand Ascendas REIT4