2024 UN E-GovErNmENt SUrvEy

150

C
h

ap
ter 4

Figure 4.13 Implementation of technology indicators in city portals

The importance of search engines cannot be overstated. Growing numbers of people needing 
services or information are turning to search engines and generative AI tools such as chatGPT and 
copilot for assistance. In the present context, the ability to find city portals easily on the first result 
page produced by a search engine is crucial. This ensures that residents and visitors can swiftly access 
important information and services provided by municipal governments. It is worth noting that, 
across a wide range of countries, city portal links consistently appear among the top results from 
popular search engines such as Google, Bing and Yahoo. Search engine visibility is key to ensuring 
seamless access to municipal services and information.

4.3 Smart cities for sustainable development 

A smart city for sustainable development embodies a vision of urban progress aligned with the 
principles of inclusivity, safety, resilience, and sustainability articulated in SDG 11. cities that offer 
numerous opportunities and promote prosperity can also face challenges such as poor health 
conditions and environmental degradation. The integration of digital technologies in urban 
infrastructure and services is essential for addressing these and other challenges. By leveraging digital 
innovations, cities can better meet the needs of residents, enhancing overall liveability, workability 
and sustainability. The lOSI underscores the importance of digital technologies in empowering local 
officials to improve urban conditions and meet the evolving needs of communities. This emphasis on 
digital empowerment aligns with the broader goal of creating cities that are not only technologically 
advanced but also inclusive, resilient and environmentally sustainable. Towards that end, the lOSI 
can serve as a tool for measuring e-government progress within cities.

A number of smart city initiatives have been undertaken worldwide. It is important to note that there 
is no universally agreed-upon definition of a smart city. The digital transformation of urban spaces is 
a dynamic process or journey rather than a static destination; with the rapid advances in technology, 
cities can continuously evolve and improve their smart capabilities. UN DESA, through its lOSI 
assessments since 2018, has been instrumental in highlighting various smart city initiatives but has 
not provided definitive guidelines on what constitutes a smart city. ITU offers the following definition: 
“A smart sustainable city is an innovative city that uses information and communication technologies 
(IcTs) and other means to improve quality of life, efficiency of urban operation and services, and 

4%

5%

5%

24%

43%

46%

76%

77%

78%

5%

4%

6%

22%

44%

42%

70%

73%

75%

0% 10% 20% 30% 40% 50% 60% 70% 80% 90%

Alignment with display standards

Alignment with markup validation standards

Alignment with accessibility standards

Internal advanced search mechanism

Foreign language support

Navigability

Mobile device accessibility

Ease of portal �nding

Browser compatibility

2022 2024