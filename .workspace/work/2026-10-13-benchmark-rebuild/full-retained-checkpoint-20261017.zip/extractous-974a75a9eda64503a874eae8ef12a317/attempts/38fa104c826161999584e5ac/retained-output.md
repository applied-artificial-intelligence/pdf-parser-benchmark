www.acea.auto 16 

COMMERCIAL VEHICLES 

REGISTRATIONS 

Global 

In 2024, North America led with a 1.7% increase in sales compared to 2023, reaching 4 

million units and representing a 30% market share. In contrast, Europe saw a growth of 

5.7%, totalling 2.5 million units and capturing an 18% market share. Greater China9 

experienced a decline of 5.9%, with sales dropping to nearly 3 million units, yet maintaining a 

substantial 22% market share. 

The truck segment followed, with Greater China holding a stable market at 1 million units, a 

slight increase of 0.9%, commanding a 34% market share. North America and Europe saw 

declines in truck sales, decreasing by 1.9% and 7%, respectively. South Asia experienced a 

notable drop of 7.8%, while South America saw an 8.1% increase. 

In the bus segment, Greater China led with a 29% increase in sales to 120,997 units, 

capturing a 31% market share. South Asia saw a 14.5% rise to 96,949 units, while Europe 

experienced a 7.3% growth to 60,625. North America faced a 4% decline to 55,322 units.  

Figure 4. Global new commercial vehicles and bus sales10 

 

SOURCE: S&P GLOBAL MOBILITY 

 
9 Includes Mainland China, and Taiwan 
10 Based on production type for North America region. Europe includes the EU, EFTA, the United Kingdom, and other countries, 

notably Belarus, Bosnia-Herzegovina, Kazakhstan, North Macedonia, Russia, Serbia, Türkiye, Ukraine, and Uzbekistan