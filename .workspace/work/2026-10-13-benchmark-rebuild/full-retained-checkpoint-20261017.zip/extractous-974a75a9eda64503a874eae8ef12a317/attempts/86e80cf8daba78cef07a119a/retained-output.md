154    

 

DO ADULTS HAVE THE SKILLS THEY NEED TO THRIVE IN A CHANGING WORLD? © OECD 2024 
  

Figure 4.2. Relationship between education, numeracy and labour-market outcomes 

Change in likelihood for a one-standard-deviation increase in years of education or numeracy proficiency 

 

Note: Adults aged 25-65 not in formal education; does not include adults who were only administered the doorstep interview due to a language 

barrier (see Box 1.1 in Chapter 1 and Box 4.1). In addition to numeracy and years of education, estimates account for age, gender, immigrant 

background, parental education and whether one lives with a partner or has children. Darker colours denote differences that are statistically 

significant at the 5% level. *Caution is required in interpreting results due to the high share of respondents with unusual response patterns. See 

the Note for Poland in the Reader’s Guide. 

Countries and economies are ranked in descending order of the percentage effect of a one-standard-deviation increase in numeracy proficiency. 

Source: Tables A.4.3 (L, N, A) and A.4.5 (L, N, A) in Annex A. 

The link between skills, education and employment is weaker in 2023 than it was ten years ago, when data 

from the first cycle of the survey were collected in most of the countries and economies taking part. One 

possible explanation for this is the tighter conditions prevailing in most labour markets in 2022-23 compared 

to 2011-12. In a tight labour market, people find work more easily, meaning that even individuals with low 

skills may succeed in getting hired. Figure 4.3 explores this hypothesis, by plotting the change in the 

unemployment rate between the two cycles (on the x-axis) against the change in the relationship between 

numeracy skills and the probability of being employed (on the y-axis). Overall, it shows that a fall in the 

unemployment rate is accompanied by a corresponding fall in the estimated effect of numeracy skills on 

 umeracy ears of education

U
n
it
e
d
 S
ta
te
s

It
a
ly

E
n
g
la
n
d
 (
U
 
 

C
 
e
c
h
ia

 
e
th
e
rl
a
n
d
s

A
u
s
tr
ia

Ir
e
la
n
d

 
o
rw

a
y

G
e
rm

a
n
y

F
in
la
n
d

C
a
n
a
d
a

 
it
h
u
a
n
ia

 
e
w
  

ea
la
n
d

F
ra
n
c
e

E
st
o
n
ia

F
le
m
is
h
 R

e
g
io
n
 (
 
E
 

P
o
la
n
d
 

 
E
C
 
 a
v
e
ra

g
e

 
a
t 
ia

C
ro
a
ti
a

S
w
e
d
e
n

Is
ra
e
l

S
p
a
in

S
w
it
 
e
rl
a
n
d

H
u
n
g
a
ry

 
e
n
m
a
rk

P
o
rt
u
g
a
l

S
lo
 
a
k
 R
e
p
u
b
lic

 
a
p
a
n

 
o
re
a

C
h
ile

S
in
g
a
p
o
re

It
a
ly

S
w
e
d
e
n

S
p
a
in

E
n
g
la
n
d
 (
U
 
 

 
o
rw

a
y

E
s
to
n
ia

C
a
n
a
d
a

 
e
w
  

e
a
la
n
d

G
e
rm

a
n
y

S
w
it
 e

rl
a
n
d

 
a
t 
ia

 
it
h
u
a
n
ia

C
 
e
c
h
ia

U
n
it
e
d
 S

ta
te
s

 
E
C
 
 a
v
e
ra

g
e

F
in
la
n
d

S
in
g
a
p
o
re

C
h
ile

 
o
re
a

S
lo
 a

k
 R
e
p
u
b
lic

C
ro
a
ti
a

P
o
la
n
d
 

Is
ra
e
l

A
u
s
tr
ia

P
o
rt
u
g
a
l

Ir
e
la
n
d

H
u
n
g
a
ry

 
a
p
a
n

 
e
n
m
a
rk

F
le
m
is
h
 R

e
g
io
n
 (
 
E
 

 
e
th
e
rl
a
n
d
s

F
ra
n
c
e

12

10

8

 

 

2

0

 2

Percentage points  .  i eli ood of being active in labour mar et  instead of inactive 

 

 

2

0

 2

Percentage points B.  i eli ood of being employed  instead of unemployed