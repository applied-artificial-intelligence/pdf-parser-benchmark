Equity Award Valuation Assumptions: BPIP award grant date fair values are calculated using the stock price as of the 
grant date assuming target performance. Adjustments to these values have been made using the stock price and 
projected vesting assumptions as of each subsequent measurement date, assuming actual performance relative to the 
applicable performance targets through the applicable measurement date and target performance for years in the 
performance period beyond the applicable measurement date (based on the award determination matrix for the BPIP 
award granted in the January following the applicable measurement date). RSU values represent fair values which are 
calculated using the stock price as of each measurement date. Stock options represent performance-based option 
awards with vesting contingent on the NEOs’ continued service and BlackRock’s achievement of a stock price hurdle 
and positive Organic Revenue Growth. Stock option fair values for measurement dates prior to when the price hurdle 
was achieved are calculated by a Monte Carlo simulation model with an embedded binomial lattice model, which 
accounts for the risk of non-achievement. For stock option fair values occurring after the achievement of the price 
hurdle, the values are calculated by a binomial lattice model only. The stock option binomial lattice modelling uses a 
consistent set of valuation inputs (including BlackRock stock price, volatility, and dividend rates, market risk free rate, 
and the options’ strike price and term) which have been updated as of each measurement date, as applicable. 

(3) Represents the cumulative Total Shareholder Return (“TSR”) of BlackRock for the periods ending on December 31, 2024, 2023, 
2022, 2021 and 2020, respectively, based on an initial fixed investment of $100 in BlackRock common stock on December 31, 
2019. For 2024, represents the five-year TSR (2020-2024), for 2023, represents the four-year TSR (2020-2023), for 2022, 
represents the three-year TSR (2020-2022), for 2021, represents the two-year TSR (2020-2021) and for 2020 represents the one-
year TSR (2020). 

(4) Represents the cumulative TSR of the S&P U.S. BMI Asset Management & Custody Banks Index (as reported in BlackRock’s Annual 
Report on Form 10-K) for each of the periods ending on December 31, 2024, 2023, 2022, 2021 and 2020, respectively, based on an 
initial fixed investment of $100 in BlackRock common stock on December 31, 2019. For 2024, represents the five-year TSR 
(2020-2024), for 2023, represents the four-year TSR (2020-2023), for 2022, represents the three-year TSR (2020-2022), for 2021, 
represents the two-year TSR (2020-2021) and for 2020 represents the one-year TSR (2020). 

(5) Reflects net income attributable to BlackRock, Inc. in the Company’s Consolidated Statements of Income included in BlackRock’s 
Annual Reports on Form 10-K for each of the fiscal years ended December 31, 2024, 2023, 2022, 2021 and 2020, respectively. 

(6) BlackRock’s Company-Selected Measure is Operating Margin, as adjusted. For reconciliation with GAAP for 2022-2024, please see 
Annex A. For reconciliation with GAAP for 2020 and 2021, please see page 37 of BlackRock’s Annual Report on Form 10-K for the 
year ended December 31, 2022. 

Relationship between Compensation Actually Paid and Performance Measures 
Disclosed in the Pay Versus Performance Table
The following chart shows that the “compensation actually paid” to our CEO and average “compensation actually paid” 
to our other NEOs for each of the 2020, 2021, 2022, 2023 and 2024 fiscal years align to trends with BlackRock’s and 
our peer group’s (S&P U.S. BMI Asset Management & Custody Banks Index) TSR over the same period. BlackRock 
maintained a relatively consistent TSR premium relative to our peer group.

Compensation Actually Paid vs. TSR

C
om

pe
n

sa
ti

on
 A

ct
ua

lly
 P

ai
d 

($
 m

ill
io

n
s)

Total Sh
areh

older R
eturn

(FY
E

 2019 In
dexed to $100)

$56.9
$65.3

($5.8)

$26.9

$56.5

$36.2 $39.2

($12.5)

$20.0

$36.6

$147.21

$190.47

$151.62

$178.70

$231.05

$115.88   

$171.06

$128.15

$168.44

$232.43

2020 2021 2022 2023 2024

($20)

$0

$20

$40

$60

$80

$100

$120

$140

$0.00

$50.00

$100.00

$150.00

$200.00

$250.00

 
Compensation
Actually Paid to CEO

 
Average Compensation
Actually Paid to Non-CEO NEOs

Total Shareholder
Return

Peer Group Total
Shareholder Return

Executive Compensation

BLACKROCK, INC. 2025 PROXY STATEMENT 105

https://www.sec.gov/ix?doc=/Archives/edgar/data/0001364742/000095017023004343/blk-20221231.htm