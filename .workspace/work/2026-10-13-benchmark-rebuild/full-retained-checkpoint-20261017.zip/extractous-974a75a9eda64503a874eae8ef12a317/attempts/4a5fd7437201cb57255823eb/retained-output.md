74    

OECD EMPLOYMENT OUTLOOK 2024 © OECD 2024 
  

Figure 2.1. One in seven workers report heat-related discomfort in Europe and the United States 

Percentage of employment who declare to be exposed to high temperature at least half of their working time, 2015 

 

Note: Those who declare to be exposed to high temperature which make them perspire even when not working at least half of their working 
time are classified as at-risk. The shares are the predictions in May, obtained by running a regression of the exposure to heat at country 
level on the share of respondents by month of interview. For Panel A, the average is unweighted. For Panel B, averages are unweighted 
and include Austria, Belgium, Czechia, Denmark, Estonia, Finland, France, Germany, Greece, Hungary, Ireland, Italy, Latvia, Lithuania, 
Luxembourg, the Netherlands, Norway, Poland, Portugal, the Slovak Republic, Slovenia, Spain, Sweden, Switzerland, the United Kingdom 
and the United States. Youth are those aged from 15 to 24, prime from 25 to 54, and senior from 55 and above. For urbanisation, the 
United States is not included. 
Source: Secretariat’s calculations based on data from European Working Conditions Survey (Eurofound) and American Working Conditions 
Survey (RAND Corporation). 

StatLink 2 https://stat.link/852oij 

Occupational safety and health (OSH) regulations in OECD countries already cover aspects related to 

temperature, heat stress and extreme weather at work. However, some countries, often with the direct 

involvement of social partners, have adapted the legislation to the specific challenges related to climate 

change (e.g. Lithuania) or developed specific OSH programmes and tools (e.g. Germany, Lithuania, 

0

5

10

15

20

25

30

W
om

en

M
en

Y
ou

th

P
rim

e

S
en

io
r

Lo
w

-s
ki

lle
d

M
id

dl
e-

sk
ill

ed

H
ig

h-
sk

ill
ed

Lo
w

M
id

dl
e

H
ig

h

R
ur

al

U
rb

an

S
ub

ur
ba

n
Gender Age Occupation Education Urbanisation

%
B. OECD27 average by workers' characteristic

0

5

10

15

20

25

30

%
A.Country average

https://stat.link/852oij