© 2025 Swiss Re. All rights reserved.

4  Swiss Re Institute  Unseasonal fires trigger above-trend first-half 2025 natural catastrophe insured losses   

costs). Post-pandemic inflation made reconstruction significantly 
more expensive. For example, in the US, construction costs rose by 
35.64% from January 2020 to June 2025, directly impacting 
property claims costs.4 There is also evidence that SCS activity has 
been increasing in specific regions and  another factor contributing 
to losses is vulnerability of exposed assets.5 Like solar power 
systems on roof tops, the number of installations of which have 
risen rapidly, increasing exposure vulnerability.6 Although SCS 
losses have so far been below trend in 2025, there is no reason to 
believe that they will not continue to rise over the long run.

June marks the end of the peak of severe thunderstorm activity 
across the central US. On average at least 70% of the losses from 
this peril originate in the first half of the year and historically, first-
half losses from SCS have never been below 50% of the full-year 
total (see Figure 7 opposite). That said, significant severe weather 
activity might continue through the year and large events can 
happen in the second half too, also outside of the US. The US is 
particularly prone to SCS due to its geography, but large-scale 
cost events can happen in Europe too, as in the case of Italy in 
July 2023. 

Not over yet: all it takes is one major hit 

The second half of the year started with the lingering warming 
effects of a major heat dome that in late June brought temperatures 
in excess of 40°C in western and central Europe.7 These led to 
wildfire outbreaks in many countries, also going into the second 
half. Meanwhile, torrential rains in the US led to catastrophic flash 
flooding in central Texas in July, another signal of what severe 
weather conditions could bring in the second half of the year. With 
the US season for SCS past its peak, the focus for the second half 
shifts to the North Atlantic hurricane season (TCNA), the high point  
typically coming in early September. Historically, second-half year 
insured losses have been higher but also more volatile than in the 
first. In the past 30 years, 60% of the total natural catastrophe 
insured losses originated in the second half on average (see 
Figure 8 opposite), mostly on account of costly TCNA activity in the 
third quarter (2004, 2005, 2008 and 2017 and 2022). 

Global insured losses from natural catastrophes have been 
growing at a long-term trend rate of 5‒7% annually in real terms 
(see Figure 9 below).8 If this trend holds, we estimate that insured 
losses from natural disasters this year will approach USD 150 

billion, in 2025 prices.9 Our estimate of the first-half loss is past 
the mid-point of this outcome. With first-half insured losses above 
trend and catastrophe activity typically higher in the second half, 

total insured losses for the full year could exceed our projection. 

Second-half losses can deviate from trend in any year depending  
foremost on the intensity of storms in the TCNA season. Latest 
meteorological forecasts predict near- to above-average activity 
in 2025, with three to five major (Saffir-Simpson Category 3 and 
above) hurricanes, compared to a long-term average (since 1950)
of 3. Generally speaking, higher activity increases the chance of a 
severe hit. However, for insurers (and exposed communities), the 
key factor determining the scale of losses is where a hurricane 
hits. A storm that hits coastal locations with high value 
concentration can happen in any season, regardless of how much 
activity is predicted. And it can take just one severe event to 
cause significant damage, as was the experience with Hurricane 
Andrew in 1992, a year of otherwise limited activity. This year’s 
20th anniversary of Hurricane Katrina serves as a further reminder 
that tropical cyclones, in particular major hurricanes, pose 
substantial risk to the east and Gulf Coasts of North America, as 

Figure 6: Global insured losses from SCS in 1H (USD bn, 2025 prices)

Source: Swiss Re Institute

0

10

20

30

40

50

First-half SCS

Trend

20252021201720132009200520011997

Editable field 2023 - with outline

Editable field 2023 - without outline

TrendFirst half SCS

Figure 7: Global insured losses from SCS in 1H and 2H, %

Source: Swiss Re Institute

0

20

40

60

80

100

Second half

First half

20242020201620122008200420001996

Editable field 2023 - with outline

Editable field 2023 - without outline

First half Second half

Figure 8: Average global insured losses (USD billion), and share of 
losses (%), from natural catastrophes by quarter and peril (1995‒2024; 
2025 prices)

Source: Swiss Re Institute

0

5

10

15

20

25

30

35

4Q3Q2Q1Q

16%

44%

22%
18%

European winter stormsWildfiresOther secondary

FloodsEarthquakesCyclonesConvective storms