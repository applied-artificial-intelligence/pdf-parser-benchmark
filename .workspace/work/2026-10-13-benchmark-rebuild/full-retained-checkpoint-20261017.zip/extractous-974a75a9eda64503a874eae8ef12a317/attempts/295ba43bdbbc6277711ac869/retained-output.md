Chapter 5. Exorbitant Privilege
Figure 5.1. The U.S. exorbitant privilege has evolved into astructural privilege of the rich world

The centrality of the U.S. dollar, and now other currencies, 

in the global financial system allows rich economies to borrow

at very low rates.

−5%
−4%
−3%
−2%
−1%

0%
1%
2%
3%
4%
5%
6%
7%

1970 1975 1980 1985 1990 1995 2000 2005 2010 2015 2020 2025

E
xc

es
s 

yi
el

d 
as

 %
 

of
 c

ou
nt

ry
 G

D
P,

 M
E

R

BRICS

China

Eurozone

Japan

Russia

United States

Excess yield (assets−liabilities) as % of country GDP, 1970−2025

Interpretation. This graph shows excess yield income, defined as the difference between the return on foreign
assets and liabilities, as a share of national GDP. The figure shows that the exorbitant privilege once exclusive to
the United States has become a broader rich−world phenomenon. The United States maintains a substantial
privilege of 2.2% in 2025. The Eurozone follows with 1% by 2025. Japan stands out with a privilege of 5.9% by
2025. In contrast, BRICS countries face a consistent burden of around 2.1%, highlighting their role as net
providers of capital to wealthier economies. Notes. Positive values represent income gains from financial
privilege; negative values represent financial burden. BRICS countries comprise Brazil, Russia, India, China, and
South Africa. Sources and series: Nievas and Sodano (2025) and wir2026.wid.world/methodology.

20% of countries consistently recordpositive income flows. Meanwhile, thebottom 80% are persistent net debtors andface negative income balances, reinforcingtheir disadvantage.
Rich countries are global financial rentiersby political design, not because of marketdynamics
Figure 5.5 to Figure 5.7 reveal why theexorbitant privilege has persisted andextended: the global financial and monetarysystem has been deliberately structuredto favor advanced economies. Theirrole as issuers of reserve currencies, thecomposition of their external portfolios,and the cost asymmetries between assetsand liabilities combine to make them globalfinancial rentiers.Figure 5.5 documents a foundation ofthis privilege: currency dominance. Overthe last few decades, the U.S. dollar hasremained the predominant medium of tradeinvoicing, financial asset denomination,and central bank reserves. The euro has

also become, to a lesser extent, a majorplayer since its creation. Other currenciesplay only marginal roles. This institutionalinequality ensures persistent demand fordollar- and euro-denominated assets. Thisleads to persistently lower borrowing costsfor the U.S. and Eurozone, whereas othereconomies are more exposed to debtin foreign currencies and vulnerable toexchange rate fluctuations.Figure 5.6 highlights the compositionof cross-border portfolios. Rich countrieshold equity and foreign direct investmenton the asset side, which typically havehigher returns, while their liabilities arepredominantly low-cost debt securities.Poorer countries show the mirror image:they hold large shares of reserves, safe butlow-yielding, while issuing liabilities in theform of high-cost debt and inward foreigndirect investment (FDI). This asymmetrymeans that even when poorer countriessave and accumulate foreign assets, thoseassets generate little return, while theirliabilities remain costly.Figure 5.7 complements this picture by
105