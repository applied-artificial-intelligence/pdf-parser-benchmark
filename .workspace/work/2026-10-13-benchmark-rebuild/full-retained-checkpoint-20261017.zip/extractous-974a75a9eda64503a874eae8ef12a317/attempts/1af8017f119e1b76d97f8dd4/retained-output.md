 17 

OECD ECONOMIC OUTLOOK, INTERIM REPORT MARCH 2025 © OECD 2025 
  

Figure 9. Further trade fragmentation would harm global growth prospects 
Simulation of a rise of 10 percentage points in US tariffs on non-commodity imports from all countries and 10 
percentage points higher tariffs on non-commodity imports from the United States by all countries 

 
Note: Illustrative scenario of the impact of 10% US tariffs on non-commodity imports and retaliation from all countries. See technical appendix 
for details of the shocks considered. 
Source: OECD calculations using the NiGEM global macroeconomic model and the OECD METRO model. 

22. A second, and related, downside risk is that inflation remains stickier than otherwise anticipated, 

prompting more restrictive monetary policy. A catalyst may be increased tariff rates having more persistent 

effects on goods inflation by pushing up inflation expectations. Currently tight labour markets in many 

economies may also make it more likely that a spike in prices feeds higher nominal wage demands. 

However, such risks may be tempered by the fact that short-term household inflation expectations 

generally re-anchored through the past few years. Nonetheless, as discussed earlier, the extent of this re-

anchoring has varied across countries and the recent turn upwards in household inflation expectations in 

a few economies bears close monitoring.  

23. A resurgence of inflation or downside surprises to economic growth could trigger a rapid repricing 

in financial markets and a further rise in market volatility. Asset valuations are still stretched in some 

segments despite recent moderation and low risk premia suggest that shocks could translate rapidly into 

falling asset prices with broader systemic effects. The latter could be exacerbated in some markets with 

high equity market concentration and large-scale passive portfolio management (a strategy which tracks 

the returns of an established market benchmark). Any increase in risk premia could also cause stress in 

bond markets and private credit markets amid high debt levels and substantial refinancing needs over the 

next two years.  

24. There are also various upside risks to the forecasts that would push economic growth higher if 

they were to transpire. The baseline scenario assumes that significantly higher bilateral tariff rates are 

sustained throughout the projection period in Canada, China, Mexico and the United States. A reversal of 

these restrictions, or steps towards a broader agreement to lower tariff barriers from current levels would 

push economic growth higher and reduce inflation relative to the baseline. A peaceful resolution of conflicts 

in Europe and the Middle East could also reduce geopolitical uncertainty and improve confidence, 

providing a stronger tailwind for spending and investment. One other potential catalyst for improved 

sentiment could be a further decline in global energy prices, with an excess supply of oil on global markets 

expected this year. Recently announced plans in several economies and at the EU level implying an 

increase in debt-financed government spending, including on defence, are not included in the baseline 

projections, but would also contribute to stronger near-term economic growth if realised.