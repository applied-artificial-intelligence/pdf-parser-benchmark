Selective news avoidance and its implications

While the majority of people across countries remain engaged 
and use the news regularly, we find that many also increasingly 
choose to ration or limit their exposure to it – or at least to 
certain types of news. We call this behaviour selective news 
avoidance and the growth of this activity may help to explain 
why consumption levels have mostly not increased, despite the 
uncertain times in which we live. The proportion that says they 
avoid the news, sometimes or often, has doubled in Brazil (54%) 
and the UK (46%) since 2017 – and also increased in all other 
markets (see next chart). This type of selective avoidance seems 
to be less widespread in Northern European countries such as 
Germany (29%), Denmark, and Finland (20%), as well as in some 
Asian countries such as Japan (14%).
REUTERS INSTITUTE FOR THE STUDY OF JOURNALISM / EXECUTIVE SUMMARY GRAPHS

Graph 5

0% 25% 50% 75%

54

46

42

41

41

36

35

34

29

20

20

14

34

35

41

32

29

33

33

36

25

15

17

11

27

24

38

30

30

29

26

28

24

14

18

6

2022

2019

2017

Japan

Finland

Denmark

Germany

Italy

Spain

France

Australia

Ireland

USA

UK

Brazil

PROPORTION WHO SOMETIMES OR OFTEN ACTIVELY AVOID 
THE NEWS (2017–22) – SELECTED MARKETS

Q1di_2017. Do you find yourself actively trying to avoid news these days? Base: Total 2017–22 
samples (n≈2000).

2017

2019

2022

Personalities (incl. celebrities and influencers)
Ordinary people
Other/None

38%
All country average 

(was 29% in 2017)

Selective news avoiders give a variety of reasons for their behaviour. 
Across markets, many respondents say they are put off by the 
repetitiveness of the news agenda – especially around politics  
and COVID-19 (43%), or that they often feel worn out by the news 
(29%). A significant proportion say they avoid news because they 
think it can’t be trusted (29%). Around a third (36%), particularly 
those who are under 35, say that the news brings down their 
mood. Others say the news leads to arguments they would rather 
avoid (17%), or leads to feelings of powerlessness (16%). A small 
proportion say they don’t have enough time for news (14%) or that 
it is too hard to understand (8%).

Concerns about the news having a negative effect on their mood 
are higher amongst avoiders in the United Kingdom (55%) and 
United States (49%) than they are elsewhere.

I actively avoid things that trigger my anxiety and things 
that can have a negative impact on my day. I will try  
to avoid reading news about things like deaths  
and disasters.
Male, 27, UK

Truthfully, I don’t like to dwell too much on the 
mainstream news. I find sometimes it can be  
repetitive and negative. 
Female, 19, UK

Political allegiances can also make a striking difference to why 
people choose to avoid news. In the United States, those who 
self-identify on the right are far more likely to avoid news because 
they think it is untrustworthy or biased, but those on the left are 
more likely to feel overwhelmed, carry feelings of powerlessness, 
or worry that the news might create arguments.

REUTERS INSTITUTE FOR THE STUDY OF JOURNALISM / EXECUTIVE SUMMARY GRAPHS

Graph 6

MOST COMMON REASONS FOR NEWS AVOIDANCE –  
ALL MARKETS

Q1di_2017ii. Why do you find yourself actively trying to avoid the news? Base: All who avoid the 
news often, sometimes, or occasionally. All markets = 64,120.

43%
say there is too 
much politics 
and COVID-19 

36%
say news has 

negative effect 
on mood

29%
say they are worn 

out by amount 
of news 

29%
say the news is 
untrustworthy 

or biased 

17%
say it leads to 
arguments I’d 
rather avoid

16%
say there is nothing 

I can do with the 
information

Reuters Institute for the Study of Journalism   |   Digital News Report 2022 13