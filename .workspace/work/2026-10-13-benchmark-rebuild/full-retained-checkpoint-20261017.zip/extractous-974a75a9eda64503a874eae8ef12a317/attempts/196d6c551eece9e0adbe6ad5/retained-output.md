Notes to the Consolidated Financial Statements
Dollar amounts are in thousands of Canadian dollars (except share and per share amounts)

10. Other Current Assets

As at December 31, 
2013

December 31, 
2012

Prepaid property tax $1,389 $1,282

Prepaid insurance 376 335

other prepaids 720 704

restricted cash 6,818 9,979

$9,303 $12,300

 Restricted cash consists of security deposits, funds held in trust and property tax reserves.

11. Accounts Payable and Other Liabilities

As at December 31, 
2013

December 31, 
2012

accounts payable $6,024 $7,450

mortgage interest payable 2,162 1,924

accrued payables 5,015 7,606

rent received in advance 915 808

Dividends payable 2,638 2,609

Taxes payable 1,451 ‑

security deposits 4,195 3,677

Promissory note payable 255 255

$22,655 $24,329

12. Mortgages and Loans Payable
 

As at             December 31, 2013   December 31, 2012   
Weighted 

Average Interest
Debt 

Balance
Weighted 

average interest
Debt 

Balance

mortgages and loans payable

   Fixed rate 4.05% $694,789 4.44% $621,397

   Variable rate 4.18% 3,853 4.13% 2,802

Vendor financing 7.10% 488 6.85% 882

Total $699,130 $625,081

current 153,589 105,369

Non‑current 545,541 519,712

$699,130 $625,081
 

Mortgages are collateralized by a first charge on the properties of the Company and vendor mortgages are collateralized by either a 
second charge on the property and/or a general corporate guarantee. 

 As of December 31, 2013, unamortized deferred financing costs of $11.9 million (December 31, 2012 ‑ $9.6 million) and mark‑to‑market 
premiums on mortgages assumed on acquisition of $1.7 million (December 31, 2012 – $1.7 million) are netted against mortgages and 
loans payable.

K i l l a m  P r o P e r t i e s  i n c  |  2 0 1 3  8 3