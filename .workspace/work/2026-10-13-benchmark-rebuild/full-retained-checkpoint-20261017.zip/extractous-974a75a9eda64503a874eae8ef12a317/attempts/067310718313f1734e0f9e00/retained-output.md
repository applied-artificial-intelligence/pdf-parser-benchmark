17

2025 Global Automotive Consumer Study | Key Findings: Global Focus Markets

As global trade policies shift, encouraging a more regional approach to vehicle manufacturing footprints 
and supply chains, consumer sentiment differs among respondents when it comes to whether local manu-
facturing is an important criteria for choosing a vehicle.

Importance of next vehicle to be manufactured locally

Note: Percentages may not add to 100 due to rounding.  
Q40. How would you most prefer to pay for public EV charging?
Sample size: n= 371 [China]; 295 [Germany]; 194 [India]; 103 [Japan]; 213 [Republic of Korea]; 1,163 [Southeast Asia]; 112 [US]

Most preferred mode of payment

As some original equipment manufacturers (OEMs) continue to explore the potential for ‘agency’ retail 
models, surveyed consumers in India and China are more receptive to the concept of buying a vehicle 
directly from the manufacturer compared to consumers in Japan. Also, surveyed consumers in some mar-
kets are signaling a high level of interest in purchasing vehicle insurance directly from the manufacturer.

Q61. To what extent are you interested in acquiring your next vehicle directly from the manufacturer (via an online process)?  
Q60. The next time you acquire a vehicle, how interested would you be in purchasing insurance directly from the vehicle manufacturer? 
Sample size: n = 939 [China]; 1,306 [Germany]; 882 [India]; 637 [Japan]; 906 [Republic of Korea]; 5.028 [Southeast Asia]; 1,314 [UK]; 937 [US]

49%

36%

15%

10%

28%

19%

13%

10%

29%

31%

45%

34%

31%

27%

22%

19%

14%

22%

24%

39%

24%

33%

39%

31%

8%

11%

16%

17%

17%

21%

26%

41%

UK

Germany

Japan

Rep. of Korea

US

Southeast Asia

China

India

Not important Somewhat important Important Very important

34%

38%

40%

46%

46%

59%

72%

76%

Japan

Germany

UK

US

Rep. of Korea

Southeast Asia

China

India

Percentage of surveyed consumers who would be interested in acquiring 
vehicle directly from the manufacturer

Percentage of surveyed consumers who would be interested 
in purchasing insurance directly from the manufacturer

32%

37%

41%

42%

55%

71%

76%

82%

Germany

Japan

US

UK

Rep. of Korea

Southeast Asia

China

India

Note: Percentages may not add up to 100 due to rounding.  
Q31. To what extent is it important that your next vehicle be locally manufactured (i.e., manufactured in your country or region)?
Sample size: n = 939 [China]; 1,306 [Germany]; 882 [India]; 637 [Japan]; 906 [Republic of Korea]; 5,028 [Southeast Asia]; 1,315 [UK]; 937 [US]