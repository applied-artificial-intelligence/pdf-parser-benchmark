49

2Social, Societal and Environmental Responsibility
 

2

2021 UNIVERSAL REGISTRATION DOCUMENT DASSAULT SYSTÈMES

 › Sustainability Compass Objectives

Unless mentioned, all targets are by 2025

EX
PERIENCE THE CHANGE

H
A

R
M

O
N

IZE O
U

R PORTFOLIO COLL
ABORA

TE
 W

IT
H

 S
TA

K
EH

O
LD

ER
S

stakeholders engaged
(employees, suppliers, clients, NGOs…)

5,000

Hold
a sustainable innovation

Event
every year

full-time equivalent

5 tons 
of CO2–eq 

of Women in
Executive team, 

30% Women among
People Managers

40%
of trained employees

on ethics and compliance, 
85% employees Pride

& Satisfaction

95%

CARBON 
NEUTRALITY 

by 2040

of our new licenses revenues generated
by Sustainable Solutions

2/3

integrated in 3DEXPERIENCE
by 2022

Life Cycle
Assessment

We aim to work in partnership 
with customers, employees, and other 
stakeholders to accelerate the change

We focus on providing the tools 
and the inspiration for our customers 

to innovate sustainably

We embed sustainability
 in our Company

Our employees are one of the Company’s most precious assets.  
They are at the heart of our mission and long‑term development. 
We believe that our purpose fosters their pride and satisfaction 
in their achievements and contributions. Sharing the same 
values is of capital importance as they underpin the employees’ 
daily interactions within the Company, with its customers and 
more broadly in its ecosystem. They are Dassault Systèmes’ 
distinctive feature, making everyone eager to join us, to work 
together and grow. To this intent, we engage our employees in 
a culture of open contribution and feedback through our new 
ways of working and we empower them to achieve ethically 
and collectively. Diversity and the creation of inclusive teams 
are part of our objectives to reach harmony around meaningful 

projects, to enable mutual enrichment of knowledge and to 
encourage creativity.

Dassault Systèmes is committing to climate change mitigation 
and adaptation. We set greenhouse gas emissions reductions 
targets, approved by the Science‑Based Targets initiative 
(see paragraph 2.5.4 “Monitoring progress: Climate Metrics 
and Targets”). We became a founding member of both the 
European Green Digital Coalition and the Digital with Purpose 
movement, in addition to signing on to the United Nations 
Global Compact (see the Communication On Progress in 
section “Cross‑reference tables”). On the occasion of COP26, 
the Company released its first Life Cycle Assessment data 
intelligence solution globally on the evaluation of the product 
life cycle’s carbon impact.