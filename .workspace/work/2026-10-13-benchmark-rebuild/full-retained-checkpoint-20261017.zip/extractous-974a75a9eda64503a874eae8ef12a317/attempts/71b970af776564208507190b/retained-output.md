10    

OECD ECONOMIC OUTLOOK, INTERIM REPORT MARCH 2025 © OECD 2025 
  

5. A series of recently announced trade policy measures will have implications for the economic 

outlook if sustained. The United States has raised tariff rates on merchandise imports from China by 

20 percentage points, with China taking targeted retaliatory action, and increased tariffs on imports of steel 

and aluminium from all countries, some of whom have introduced targeted retaliatory measures. The 

United States has also announced an increase of 25 percentage points in bilateral tariff rates on 

merchandise imports from Canada and Mexico (alongside a lower 10 percentage point tariff rate increase 

on imports of energy products from Canada, and potash from both Canada and Mexico). Currently, these 

higher tariffs apply only to imports that are not compliant with the United States-Mexico-Canada Agreement 

(USMCA) but they are set to apply to all imports from early April. Canada has raised tariffs on selected 

imports from the United States in response and announced plans to broaden the range of products affected 

from April. Mexico has not introduced any specific trade policy changes, but has stated a general intention 

to retaliate if the broader tariff increases planned by the United States go ahead as announced. Such tariffs 

are likely to be particularly costly for Canada and Mexico due to their greater openness to trade, and high 

proportion of trade with the United States (Figure 3). Broader trade policy reviews are also under way in 

the United States and due to be completed by early April. 

6. If the announced trade policy actions persist, as assumed in the projections, the new bilateral tariff 

rates will raise revenues for the governments imposing them but will be a drag on global activity, incomes 

and regular tax revenues. They also add to trade costs, raising the price of covered imported final goods 

for consumers and intermediate inputs for businesses. The impact of higher costs will be amplified where 

inputs cross borders several times and duties are incurred at each stage, as is the case in the integrated 

North American market. An agreement that would ease trade tensions, and potentially even lower existing 

trade barriers, would be welcome and help to improve policy certainty and growth prospects. 

Figure 3. The direct impact of merchandise trade tensions varies across countries 

Distribution of merchandise export volumes in 2024 

 

Note: Merchandise export volumes as a share of GDP volumes based on 2024 data, except for Argentina, India, Mexico and Saudi Arabia where 
data are for 2023, and Türkiye where data are for 2021. Bilateral trade shares based on OECD estimates for 2021. 
Source: OECD Interim Economic Outlook 117 database; OECD Balanced International Merchandise Trade Statistics; and OECD calculations.