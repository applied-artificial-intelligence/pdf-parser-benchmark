X  Figure 2.1. Annual average economic growth measured as GDP in constant 2015 prices, 
2006–24 (percentage)

Source: IMF 2024b.

-0.4

-6

-4

-2

0

2

4

6

8

10

Re
al

 G
D

P 
gr

ow
th

 (%
)

2006
2007

2008
2009

2010
2011

2012
2013

2014
2015

2016
2017

2018
2019

2020
2021

2022
2023

2024

World Advanced economies Emerging and developing economies

5.3 5.3

2.9

5.2

4.0
3.3 3.4 3.5 3.4 3.3

3.8 3.6
2.9

6.6

3.6 3.3 3.2

7.8 8.1

5.6

2.5

7.2

6.1
5.2

4.9 4.7
4.3 4.4

4.8 4.7
3.7

-1.8

7.0

4.0 4.4 4.2

3.1
2.8

0.3

-3.4

3.1

1.8
1.2 1.5

2.1 2.4
1.8

2.6 2.3
1.9

-4.0

6.0

2.9

1.7 1.8

-2.7

economies, government gross debt in emerg-
ing and developing economies has continued 
to increase in recent years, going from 65 per 
cent in 2020 to 70 per cent in 2024.

The difficulty seen among emerging and 
developing economies to revert to pre- 
pandemic levels of public debt reflects their 
limited fiscal leeway, and the further increase 
in gross government debt in recent years 
can be partially attributed to the rise in debt- 
service costs due to historically high interest 
rates and a strong US dollar (IMF 2023). For 
many developing countries, higher interest 
rates in advanced economies also translated 
into capital outflows, which led to a depletion 
of foreign exchange reserves and higher bor-
rowing costs.

 X  Figure 2.2. Government gross debt as a share of GDP, 2006–24 (percentage)

Source: IMF 2024b.

73 71

78

91

97
101

105 104 103 103 105 103 102 103

122

115
110 109 109

37 36 33
38 37 37 37 38 40

44
49 51 52

55

65 64 64
69 70

30

40

50

60

70

80

90

100

110

120

130

Sh
ar

e 
of

 G
D

P 
(%

)

2006
2007

2008
2009

2010
2011

2012
2013

2014
2015

2016
2017

2018
2019

2020
2021

2022
2023

2024

World Advanced economies Emerging and developing economies

Rising geopolitical tensions, particularly the 
war in Ukraine and the Israel–Hamas con-
flict, could continue to restrict international 
trade and deteriorate international relation-
ships, thus weighing on growth prospects. 
In the longer term, climate change remains a 
threat to sustainable growth for all countries. 
Developing countries are particularly affected 
by climate change, in the form of increasingly 
frequent extreme weather events, with dev-
astating effects on private and public infra-
structure, disruptions to output and business 
continuity, and reduced productivity.

 ▶2.2.  
Evolution of  
public debt
Steep increases in public debt were seen in 
advanced economies in 2020 due to unprec-
edented spending to support firms and 
households during the COVID-19 pandemic 
and the subsequent cost-of-living crisis. 
Following this rapid increase, public debt sub-
stantially declined up to 2022 and then stabi-
lized. Even so, the debt-to-GDP ratio (that is, 
government gross debt) in advanced econo-
mies is projected to remain higher than 
pre-pandemic levels at 109 per cent in 2024 
(figure 2.2). While the surge in public spend-
ing in emerging and developing economies 
during the COVID-19 pandemic was more 
modest than what was seen in advanced 

6 Global Wage Report 2024–25
2. The global economic and labour market context