3 Building an Engaged and Thriving Workplace

We endeavour to nurture High Performing and Innovative teams with 
trust and care. Throughout the year, our utmost priority has been to 
continuously listen to our members’ needs and aspirations and align our 
people practices to support their holistic well-being and growth.

Expanding the list of campuses to 
diversify our campus talent pipeline;

Over the past years, we moved from annual HR-owned engagement surveys 
towards frequent quarterly supervisor-owned pulses on a Stanford-research 
backed global Engagement Platform – Glint by LinkedIn, Microsoft Company. 

Identifying and hiring differently-abled 
candidates by partnering with specialist 
recruitment partners;

In addition, we conduct frequent monthly pulses with our field forces to ensure 
high engagement and business performance. 

Building internal leaders’ capability 
through Inclusive Hiring certification;

Our second career programme 
‘Phoenix’ provides opportunities to 
individuals with career breaks. Phoenix 
is one of the few gender-neutral 
programmes in the industry and seeks 
to tap into a larger talent pool and 
skill-mix;

Marico’s Neo Mama network enables 
new or expecting mothers to address 
various life stage challenges by 
leveraging the network.

Diversity intelligence and sensitization

Diversity thrives in an environment that 
is enabling and where each individual 
is able to bring their perspectives and 
beliefs to work. In order to foster a culture 
of inclusion we regularly sensitise and 
create awareness around topics related 
to diversity and inclusion, to build a 
workplace where every individual has an 
equal chance to excel. 

In the past year, we have created more 
awareness about visible Allyship and 
have focused on onboarding members 
across teams and geographies, who are 
passionate about Inclusion and Diversity 
and are keen to champion I&D goals.

Inclusive Hiring Practices

At Marico, we are determined to 
provide equal employment opportunities 
to candidates, irrespective of diverse 
backgrounds. Here is how:

A Member communication and engagement 

Differentiated outcomes

i We continued the frequency and rigour of leadership connects 
through Townhalls, Facetimes and Organisation Communication 
events for regular two-way communication with members.

ii In line with our member-first philosophy, member engagement has 
been at the top of our agenda - we believe and have established 
a strong correlation of Attrition and Business Performance with 
member engagement. We have empowered supervisors with full 
visibility and ownership of their team’s engagement.

of our members voiced their 
opinion to make Marico a 
future-ready workplace. 

Supervisors regularly track insights 
and drive their team’s engagement 
through Glint tool 

of our members deeply resonate with 
the organisation’s purpose, illustrating 
a strong alignment with their work and 
organisational objectives.

through the year, 6 points 
above global benchmark. 

We maintained a consistently high 
member engagement score of 

85%

>85%

91%

83

of our members affirm that Marico 
cultivates an environment of innovation. 

of our members expressed confidence in 
receiving the necessary support by their 
supervisors.

of our members acknowledged that 
Marico provides great opportunities to 
learn and grow.

of our members express strong sense of 
belonging with Marico. 

90%

87%

86%

86%

iii Amber - CEO’s personal digital 
assistant is a Chatbot developed 
to communicate with our new 
members and take regular feedback 
from them. Amber enhanced our 
connect with new members and 
ensured their sustained engagement 
with respective teams and the 
organisation as a whole.

B Be The Impact with Marico – 
Member Volunteering Drive 

At Marico, we support our members’ 
aspirations to live their purpose 
and leave a positive mark on 
society. In this context, our signature 
volunteering programme ‘Be the 
Impact Drive’ enabled organisation-
wide participation of our members 
in volunteering efforts that enabled 
social change. We aspire to achieve 
1 hour of volunteering each year by 
every Mariconian.

Key highlights of the initiatives and 
the impact generated through member 
volunteering -

A. Volunteers from Marico participated 
in a clean-up drive and over 790 
kgs of waste was collected by 
Mariconians across locations.

B. Volunteers supported in planting 
14,684 trees through various 
initiatives under #SteptemberLeague.

C. With an aim to contribute to 
environmental sustainability 
and community well-being, we 
organised tree planting initiatives to 
commemorate significant events and 
milestones such as joining of new 
employees to the organisation or at 
the instance of employees reaching 
significant milestones in their 
careers.

A. Mental Wellbeing We have 
extended an EAP service to 
members, providing them round-
the-clock access to a plethora of 
self-help tools, resources and online 
counselling options. In addition, 
in-person counselling sessions and 
seminars were conducted by industry 
experts across locations. Virtual 
tournaments and challenges were 
conducted, encouraging members to 
disconnect from work and reconnect 
once rejuvenated.  

B. Physical Wellbeing : In collaboration 
with a healthcare provider, we 
offered members and their families 
easy access to doctors, pharmacies 
and laboratories. In addition to 
this, an on-site doctor was made 
available for easy consultation and 
medical check-ups were also carried 
out across locations.   

C. Financial Well-being Support was 
extended to members about taxation, 
financial planning, investments and 
so on in partnership with specialised 
service providers. 

D. Social Wellbeing Marico members 
participated in “September 
League, a virtual run to promote 
well-being and a healthy heart. 
A total of 14,684 trees were 
planted at the end of the league. 
Additionally, our annual flagship 
program, "Chamakta Sitara," was 
organized to honour the children 
of our members for their exemplary 
performance in academics and 
extracurricular activities at the 
district, state, national, and 
international levels during the last 
academic year.

Holistic Wellness 

At Marico, we strive to foster a culture 
where members feel supported, valued 
and empowered to take charge of their 
well-being. Keeping this in mind, we 
design all our policies and build systems 
which enable holistic well-being of our 
members. Our members are provided 
easy access to resources and are 
encouraged to seek support from the 

ecosystem. The wellness theme for the 
year is ‘Discover, Balance and Bliss’ 
which encourages members to explore 
and nurture their mental, physical, 
financial and social well-being. 

In tegrated Annual Repor t  2023-24 • Corporate Overview • Statutory Reports • Financial Statements

M a r i c o  L i m i t e d
122 123