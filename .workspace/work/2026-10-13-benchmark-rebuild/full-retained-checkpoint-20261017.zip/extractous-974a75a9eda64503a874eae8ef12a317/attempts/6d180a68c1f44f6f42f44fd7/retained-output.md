Executive Summary
Figure 5. Women persistently receive lower labor income thanmen everywhere

40%
36%

16%

40%
37%

20%

28%

34%

Gender parity

0%

10%

20%

30%

40%

50%

60%

Middle East 
& North 

Africa

South &
Southeast

Asia

Sub−
Saharan

Africa

East 
Asia

Latin 
America

Russia &
Central 

Asia

Europe North 
America

& Oceania

F
em

al
e 

la
bo

r 
in

co
m

e 
sh

ar
e 

(%
)

1990 2000 2010 2020 2025

Female labor income shares, 1990−2025

Interpretation. This figure shows the evolution of the female labor income share between 1990 and 2025 across
world regions. In 2025, female workers earn about 16% of total labor income in the Middle East & North Africa,
but about 40% in North America & Oceania and Europe. At the global level, women earned 27.8% of labor income
in 1990 and 28.2% in 2025. While some progress has been made, gender parity remains distant in all regions.
Sources and series: Neef and Robilliard (2021), Gabrielli et al. (2024), and wir2026.wid.world/methodology.

Political cleavages and democracy
Economic divides do not stop at themarketplace; they spill directly into politics.Inequality shapes who is represented, whosevoices carry weight, and how coalitions arebuilt, or fail to be built. Figure 15 showshow the traditional class-based alignmentof politics in Western democracies hasbroken down.3 In the mid-20th century,lower-income and less educated voterslargely supported left-wing parties, whilewealthier and more educated groups leanedright, creating a clear class divide and risingredistribution.

Today, that pattern has fractured. First,education and income now point in differentdirections (see Figure 15), making broadcoalitions for redistribution far harder tosustain. This evolution can be accounted forby the fact that educational expansion hascome with a complexification of the classstructure. For example, many high-degreebut relatively low-income voters (e.g.,teachers or nurses) currently vote forthe left, while many voters with lowerdegrees but relatively higher income (e.g.,

self-employed or truck drivers) tend to votefor the right.
The even more striking evolution is therise of territorial divides within countries.In many advanced democracies, gapsin political affiliations between largemetropolitan centers and smaller townshave reached levels unseen in a century(see Figure 16). Unequal access to publicservices (education, health, transportation,and other infrastructures), job opportunities,and exposure to trade shocks has fracturedsocial cohesion and weakened the coalitionsnecessary for redistributive reform.
As a consequence, working-class votersare now fragmented across parties on bothsides of the aisle or left without strongrepresentation, which limits their politicalinfluence and entrenches inequality. In orderto reactivate the redistributive coalitionsof the postwar era, it is critical to designmore ambitious policy platforms benefitingall territories, as they successfully did in thepast.
This fragmentation erodes the politicalfoundations needed to tackle inequality

17