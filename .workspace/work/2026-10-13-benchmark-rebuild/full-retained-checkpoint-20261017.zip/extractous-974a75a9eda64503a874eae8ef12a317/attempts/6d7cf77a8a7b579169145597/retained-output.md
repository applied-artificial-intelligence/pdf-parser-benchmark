 183 

 

DO ADULTS HAVE THE SKILLS THEY NEED TO THRIVE IN A CHANGING WORLD? © OECD 2024 
  

Figure 4.19. Relationship between wages and mismatches, by type of mismatch 

Change in gross hourly wages associated with mismatches  

 

Note: Employed adults aged 25-65 who are not self-employed; does not include adults who were only administered the doorstep interview due 

to a language barrier (see Box 1.1 in Chapter 1 and Box 4.1). Mismatch measures are defined in Table 4.2 and Box 4.3. Estimates account for 

age, gender, immigrant background, parental education, whether one lives with a partner or has children, work experience, use of numeracy 

skills at work, industry and occupation. Wages are (log) gross hourly earnings for employed and self-employed individuals, including bonuses, 

in PPP-adjusted 2022 USD. *Caution is required in interpreting results due to the high share of respondents with unusual response patterns. 

See the  ote for Poland in the Reader’s Guide. 

Countries and economies are ranked in descending order of the effect of mismatches on wages. 

Source: Table A.4.16 of Annex A. 

It
al
y

P
o
la
n
d 

A
us

tr
ia

S
w
ed

e
n

 
or
ea

C
ro
at
ia

F
in
la
nd

C
 e

ch
ia

 a
p
an

 
at
 i
a

E
st
o
n
ia

F
ra
n
ce

 
et
he

rl
an

ds

 
o
rw

ay

C
an

ad
a

 
E
C
 
 a
v
er
a
g
e

 
en

m
a
rk

G
e
rm

an
y

Ir
el
a
nd

Is
ra
e
l

H
un

g
a
ry

F
le
m
is
h 
R
e
g
io
n 
( 

E
 

S
pa

in

S
lo
 a

k 
R
ep

u
bl
ic

P
o
rt
ug

al

 i
th
ua

n
ia

S
w
it 

e
rl
a
nd

 
e
w
  
ea

la
nd

E
ng

la
n
d 
(U

 
 

U
ni
te
d 
S
ta
te
s

S
in
g
ap

or
e

C
h
ile

 

0

  

 12

 18

 2 

 

12

 

0

  

 12

 18

 

 

0

  

 12

 18

 2 

 

 .  ver  ualification
 
or
ea

 i
th
ua

n
ia

P
o
la
nd

 

S
lo
 a

k 
R
ep

ub
lic

It
a
ly

 a
p
an

F
le
m
is
h 
R
e
gi
o
n 
( 

E
 

S
in
g
a
po

re

Is
ra
e
l

 
et
he

rl
a
nd

s

C
hi
le

 
at
 i
a

C
ro
at
ia

 
E
C
 
 a
ve

ra
g
e

C
 e

ch
ia

 
e
nm

ar
k

S
w
e
de

n

G
er
m
a
ny

H
un

g
a
ry

P
or
tu
ga

l

A
us

tr
ia

E
st
o
ni
a

C
an

ad
a

S
w
it 

e
rl
a
nd

 
or
w
ay

U
ni
te
d 
S
ta
te
s

F
ra
n
ce

F
in
la
nd

 
ew

  
ea

la
nd

S
p
ai
n

Ir
el
a
nd

E
ng

la
nd

 (
U
 
 

B.  ver s illing

C
 e

ch
ia

C
h
ile

Ir
el
an

d

 
e
th
e
rl
an

ds

F
le
m
is
h 
R
eg

io
n 
( 

E
 

E
st
on

ia

 
o
rw

ay

 
or
e
a

F
in
la
n
d

S
w
e
de

n

 
ew

  
ea

la
n
d

F
ra
n
ce

C
ro
at
ia

 
en

m
a
rk

A
us

tr
ia

 
E
C
 
 a
ve

ra
g
e

 i
th
ua

n
ia

G
e
rm

an
y

S
w
it 

er
la
n
d

S
lo
 a

k 
R
ep

ub
lic

P
or
tu
g
al

P
ol
a
nd

 

S
in
g
ap

or
e

C
an

ad
a

H
u
ng

ar
y

 a
pa

n

It
a
ly

 a
t 
ia

S
p
ai
n

E
ng

la
nd

 (
U
 
 

U
ni
te
d 
S
ta
te
s

Is
ra
el

C.  ield of study mismatc