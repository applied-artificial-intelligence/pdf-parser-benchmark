Yes No It varied too much to say Don’t know/prefer not to say

Note: Numbers may not sum to 100%, because of rounding.

Source: Heidrick & Struggles US professional services partner compensation survey, 2024, n=144

Overall

$1.00bn–$5.00bn

$5.01bn–$20.00bn

More than $20.00bn

Less than $1.00bn

27 12 2140

39 26 926

42 1531 12

24 9 2938

15 9 1858

By firm revenue

In your most recent fiscal year, did your firm pay a premium 
to attract or retain diverse consultants at any level?

Diverse talent (%) There was an overall decline in 
reported premiums paid to attract 
diverse consultants compared to 
2022. This decrease in the investment 
in diverse hiring is disappointing, 
and we hope to see the trend 
reverse itself in future surveys.

2024 US PROFESSIONAL SERVICES PARTNER COMPENSATION SURVEY

16