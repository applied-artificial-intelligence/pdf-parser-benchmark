16White Paper, sponsored by Google Cloud  
April 2023   |   IDC #US50419123

The Digital Customer Journey for Manufacturers

Table of Contents

■ Very limited  ■ Early stages  ■ Preconfigured  ■ End to end  ■ Orchestrated

10% 40%20% 30% 60%50%

Breaking down organizational silos . . . . . . . . . 

Integrating offline data/CRM . . . . . . . . . . . . . . . . . 

Accessing partner/channel and  
ecosystem data . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 

Offering digitally centric products  
and services . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 

Addressing cybersecurity concerns . . . . . . . . . 

Upskilling/reskilling teams  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .

Using data to create or adopt  
new business models . . . . . . . . . . . . . . . . . . . . . . . . . 

Using real-time data and feedback  
to help drive more business . . . . . . . . . . . . . . . . . . 

FIGURE 4

First-Party Data/Integration Priorities by Maturity Level
What are your top priorities around data and integration to drive better manufacturing outcomes?
(% of respondents)

n = 1,514; Source: IDC’s Manufacturing Customer Experience Survey, September 2022
For an accessible version of the data in this figure, see Figure 4 Supplemental Data in Appendix 2.