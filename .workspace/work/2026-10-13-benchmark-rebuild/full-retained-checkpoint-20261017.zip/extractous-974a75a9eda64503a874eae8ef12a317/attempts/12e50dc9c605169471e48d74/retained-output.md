It is important to note that high levels of disconnection are not 
evident everywhere. The proportion consuming none of our listed 
news sources weekly is limited in Portugal (2%) and Finland (2%) and 
extremely rare in South Africa (1%), Nigeria (<1%), and Kenya (<1%), 
even though we also see growing pressure on traditional sources  
of news such as print and television news in these countries. 

REUTERS INSTITUTE FOR THE STUDY OF JOURNALISM / EXECUTIVE SUMMARY GRAPHS

Graph 3

PROPORTION THAT USED EACH SOURCE OF  NEWS IN THE 
LAST WEEK (2013–22) – GERMANY 

Q3. Which, if any, of the following have you used in the last week as a source of news? 
Base: Total 2013–22 samples (most n ≈ 2000). Note: No data for 2014 due to a scripting error  
in the survey. The figure for no news would have been 4% without a methodology change where 
we previously excluded those who said they consumed no news in last month.

TV Print Online (incl. social media)
Social media Radio news

60% 

18% 

51% 

1% 

63% 

82% 

65% 

39% 

5% 

32% 

68%

26%

0%

25%

50%

75%

100% Radio news
None of these 

Social media
Online (incl. social media)
Print
TV

 2022202120202019201820172016201520142013

None of these 

Falling interest in the news

Disconnection is just one sign of the difficulties of engaging some 
audiences in a more digital environment. At the same time we find 
that the proportion that says they are very or extremely interested in 
news has fallen sharply over time across markets – a trend that has 
accelerated despite the continuing COVID-19 pandemic. This year  
we find news interest lower in the vast majority of countries in our 
survey. In some countries, such as Argentina, Brazil, Spain, and the 
United Kingdom, these falls have been going on for some time, while 
in the United States we see a slightly different pattern. Interest 
remained high during the Trump years but seems to have declined 
significantly since Joe Biden became president. Today, less than half 
of our sample (47%) say they are very or extremely interested in 
news compared with 67% in 2015. 

Again, it is important to note that there are some countries that buck 
these trends or where declines are happening more slowly. These 
include richer Central/Western European nations where there has 
been less political or economic turmoil over the past few years.

These data suggest two different but related problems. First, the 
emergence of a minority of people who are active online, many of 
them younger or less well educated, but who have become largely 
disconnected from the news, perhaps because they don’t feel that it 
is relevant to their lives. And then, separately, we find a more 
generalised decline in news interest and consumption affecting a 
much bigger group, which may relate to structural changes in the 
way the news is distributed, such as the shift to online, the nature of 
the news cycle itself, or both.

REUTERS INSTITUTE FOR THE STUDY OF JOURNALISM / EXECUTIVE SUMMARY GRAPHS

Graph 4

PROPORTION WHO ARE VERY OR EXTREMELY INTERESTED IN NEWS (2015–22)

Q1c. How interested, if at all, would you say you are in news? Base: Total 2015–22 samples (n≈2000).

Selected countries with largest falls

Selected countries with more stable levels

0%

25%

50%

75%

100%

20222017 20222015 20222015 20222015 20222015

0%

25%

50%

75%

100%

20222015 20222016 20222016 20222015 20222015

77%

48%

82%

57%

56%

51%

59%

50%

74%

57%

85%

55%

70%

43%

57%

55%

67%

47%

64%

67%

0%

25%

50%

75%

100%

20222017 20222015 20222015 20222015 20222015

0%

25%

50%

75%

100%

20222015 20222016 20222016 20222015 20222015

77%

48%

82%

57%

56%

51%

59%

50%

74%

57%

85%

55%

70%

43%

57%

55%

67%

47%

64%

67%

Argentina

Germany

Brazil

Sweden

Spain

Switzerland

UK

Netherlands

USA

Finland

Reuters Institute for the Study of Journalism   |   Digital News Report 202212