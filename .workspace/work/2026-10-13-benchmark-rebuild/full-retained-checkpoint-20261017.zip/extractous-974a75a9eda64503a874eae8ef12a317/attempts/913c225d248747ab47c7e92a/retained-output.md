 137 

 

DO ADULTS HAVE THE SKILLS THEY NEED TO THRIVE IN A CHANGING WORLD? © OECD 2024 
  

Figure 3.20. Change in the gaps in literacy and numeracy proficiency between men and women  

Adjusted and unadjusted change between cycles in the mean score difference between men and women (Cycle 2 

minus Cycle 1) 

 

Note: Adults aged 16-65; does not include adults who in Cycle 2 were only administered the doorstep interview due to a language barrier, to 

maximise the comparability across cycles (see Box 1.1 in Chapter 1 and Box 3.2). Unadjusted changes in the proficiency gap are the changes 

in the difference between the two contrast categories across the cycles. Adjusted changes are obtained by subtracting the coefficients of 

regression models estimated separately for each cycle. These coefficients show the difference between the categories in each cycle after 

accounting for: immigrant background, age, educational attainment, parental education and language spoken at home. Darker colours denote 

differences that are statistically significant at the 5% level. *Caution is required in interpreting results due to the high share of respondents with 

unusual response patterns. See the  ote for Poland in the Reader’s Guide. 

Countries and economies are ranked in ascending order of the unadjusted change in the gap in literacy. 

Source: OECD (2018[4]; 2015[5]; 2012[6]), Survey of Adult Skills (PIAAC) databases, http://www.oecd.org/skills/piaac/publicdataandanalysis/  

(accessed on 23 September 2024); Tables A.3.5 (L), A.3.5 (N), A.3.6 (L) and A.3.6 (N) in Annex A. 

Ad ustedUnad u sted

P
ol
a
nd

 

S
lo
 a

k 
R
ep

ub
lic

E
ng

la
n
d 
(U

 
 

C
an

ad
a

 
en

m
a
rk

F
in
la
nd

It
al
y

C
 e

ch
ia

S
pa

in

 a
pa

n

F
ra
n
ce

A
us

tr
ia

U
ni
te
d 
S
ta
te
s

 
or
e
a

S
w
e
de

n

F
le
m
is
h 
R
e
gi
o
n 
( 

E
 

Ir
el
a
nd

 
or
w
ay

E
st
o
ni
a

G
e
rm

an
y

 
et
he

rl
a
nd

s

 i
th
ua

n
ia

S
in
g
ap

or
e

Is
ra
e
l

C
h
ile

 
ew

  
ea

la
n
d

H
un

g
a
ry

P
ol
a
nd

 

S
lo
 a

k 
R
ep

ub
lic

E
ng

la
nd

 (
U
 
 

C
an

ad
a

 
en

m
a
rk

F
in
la
n
d

It
a
ly

C
 e

ch
ia

S
pa

in

 a
pa

n

F
ra
n
ce

A
us

tr
ia

U
ni
te
d 
S
ta
te
s

 
or
e
a

S
w
e
de

n

F
le
m
is
h 
R
eg

io
n 
( 

E
 

Ir
el
an

d

 
o
rw

ay

E
st
on

ia

G
e
rm

an
y

 
e
th
e
rl
an

ds

 i
th
ua

n
ia

S
in
g
ap

or
e

Is
ra
el

C
h
ile

 
ew

  
ea

la
n
d

H
u
ng

ar
y

10

 

0

  

 10

 1 

10

 

0

  

 10

 1 

 .  iteracy

B.  umeracy

   Round, Cycle 1:

http://www.oecd.org/skills/piaac/publicdataandanalysis/