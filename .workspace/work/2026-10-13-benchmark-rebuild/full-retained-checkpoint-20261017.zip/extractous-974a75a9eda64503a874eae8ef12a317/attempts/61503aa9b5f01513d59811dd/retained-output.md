2024 Long-Term Reliability Assessment  
31 

Demand Trends and Implications 
Demand and Energy Projections 
Electricity peak demand and energy growth forecasts over the 10-year assessment period continue to 
climb higher than at any point in the past two decades. The aggregated assessment area summer peak 
demand forecast is expected to rise by over 132 GW, and aggregated winter peak demand forecasts 
are increasing by 149 GW. The growth rates of forecasted peak demand (see Figure 17) and energy 
(see Figure 18) continue to rise sharply since the 2022 LTRA, reversing an almost two-decade trend of 
falling or flat growth rates. See Figure 17 for seasonal peak demand growth over the current and prior 
assessment periods and Figure 18 for net energy growth. A map of the primary demand drivers for 
the North American BPS is illustrated for each assessment area in Figure 19.  
 
Electrification and Demand Growth 
Electrification of household appliances (e.g., heat pumps for household heating) and projections for 
electric vehicle growth over this assessment period are components of the demand and energy 
estimates provided by each assessment area. Since the 2023 LTRA, peak season CAGR has risen in all 
assessment areas except two: NPCC-Maritimes’ winter CAGR fell from 0.98% to 0.63% and WECC-BC’s 
winter CAGR fell from 1.05% to 0.28%. Rising peak demand forecasts are contributing to the lower 
reserve margins projected for nearly all assessment areas.  
 
Large Commercial and Industrial Loads 
Increasing amounts of large commercial and industrial loads are connecting rapidly to the BPS. 
Emerging large loads, such as data centers (including crypto and AI) and hydrogen fuel plants, present 
unique challenges to forecasting and planning for increased demand. Earlier this year, NERC’s RSTC 
established a Large Loads Task Force to better understand the reliability implications of growth in 
large loads and develop solutions.  
 

 
Figure 17: 10-Year Summer and Winter Peak Demand Growth and Rate Trends 

 

 
Figure 18: Net Energy for Load Growth and Rate Projections