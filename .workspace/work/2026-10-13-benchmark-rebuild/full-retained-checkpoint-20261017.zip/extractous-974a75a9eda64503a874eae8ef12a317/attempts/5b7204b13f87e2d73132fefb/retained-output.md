 37 

OECD EMPLOYMENT OUTLOOK 2024 © OECD 2024 
  

Figure 1.14. Real wages in low-pay industries have performed relatively better in most countries 

Percentage change in real hourly wages between Q4 2019 and Q1 2024 

 

Note: Real wages are obtained by deflating nominal wages by consumer price inflation (all items) which are adjusted, for the purpose of this 

analysis, using the X-13ARIMA-SEATS Seasonal Adjustment Method. Industries are ranked by the median wage in 2019 in the European 

Structure of Earnings Survey (SES). The ranking of industries is broadly consistent when 2019 data on median wages from the Current 

Population Survey of the United States are used. Low-pay industries (LP) include Accommodation and food service, Administrative and 

support service, Arts, entertainment and recreation and Wholesale and retail trade. Middle-pay industries (MP) include Transportation and 

storage, Manufacturing, Other service, Real estate activities and Construction. High-pay industries (HP) include Human health and social 

work, Education, Professional activities, Information and communication and Finance and insurance. Average employment shares by industry 

over the four quarters of 2019 are used for aggregation and thus small inconsistencies between changes in wages by industry and changes in 

average wages are possible. Statistics refer to the percentage change in real hourly wages between Q4 2019 and Q4 2023 for Australia, Canada, 

Costa Rica, Japan, Korea, Mexico, the Netherlands, New Zealand, the United Kingdom and the United States. OECD is the unweighted average 

of the 33 OECD countries shown in this chart (not including Chile, Colombia, Israel, Switzerland and Türkiye). 

†: There are missing industries: Arts, entertainment and recreation is not included for the United States; Human health and social work and 

Education are not included for France. 

‡: Average weekly earnings are used for the United Kingdom. Moreover, wages in the public sector are excluded for Costa Rica, Japan, Korea, 

Mexico, the United Kingdom and the United States. 

Source: OECD calculations based on the Wage Price Index (Australian Bureau of Statistics) for Australia; Fixed weighted index of average 

hourly earnings for all employees (Statistics Canada) for Canada; Encuesta Continua de Empleo (Instituto Nacional de Estadística y Censos, 

Costa Rica) for Costa Rica; the wages and salaries component of labour cost index by NACE Rev. 2 activity (Eurostat) for European countries; 

Monthly Labour Survey (Japanese Ministry of Health, Labour and Welfare) for Japan; Labour Force Survey at Establishments (Korean Ministry 

of Employment and Labour) for Korea; Nacional de Ocupación y Empleo, Encuesta Telefónica de Ocupación y Empleo, Encuesta Nacional de 

Ocupación y Empleo Nueva Edición (Instituto Nacional de Estadística y Geografía, Mexico) for Mexico; Labour Cost Index (Statistics 

New Zealand) for New Zealand; Swiss Wage Index (Swiss Federal Statistical Office) for Switzerland, Monthly Wages and Salaries Survey (UK 

Office for National Statistics) for the United Kingdom; and Employment Cost Index (U.S. Bureau of Labor Statistics, retrieved from FRED) for 

the United States; OECD (2024), “Prices: Consumer prices”, Main Economic Indicators (database), https://doi.org/10.1787/0f2e8000-en 

(accessed on 18 June 2024). 

StatLink 2 https://stat.link/ph6ri2 

Results by education for the five countries with available data also provide additional support for a general 

pattern of wage compression, especially at the bottom of the distribution (Figure 1.15). Between 2019 and 

2023, real wage growth was stronger for the low- and mid-pay groups by education in four of the 

five countries (Costa Rica, Mexico, the United Kingdom, and the United States). Canada was the only 

country among those with available data where real wages grew more for the highest educated. 

-10

-5

0

5

10

15

20

G
R

C

P
O

L

K
O

R

IS
L

U
S

A
†

O
E

C
D

D
E

U

JP
N

F
R

A
†

N
LD

N
O

R

E
S

P

N
Z

L

F
IN

C
Z

E

S
V

N

LU
X

B
E

L

C
A

N

D
N

K

IT
A

LV
A

A
U

T

C
R

I

M
E

X

P
R

T

S
V

K

G
B

R
‡

IR
L

S
W

E

LT
U

H
U

N

A
U

S

E
S

T

LP> HP & MP LP> HP only LP> MP only LP < HP & MP

%

High-pay (HP) Middle-pay (MP) Low-pay (LP)

21 2521

https://doi.org/10.1787/0f2e8000-en
https://stat.link/ph6ri2