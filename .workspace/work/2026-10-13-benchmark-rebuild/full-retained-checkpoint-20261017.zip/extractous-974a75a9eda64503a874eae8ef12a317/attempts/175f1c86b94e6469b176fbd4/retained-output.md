2025 Professional Services Maturity™ Benchmark  Client Relationships Pillar 
  

 

 

© 2025 Service Performance Insight, LLC www.workday.com/professionalservices 115 

increased revenue and profit margins. This is the first year SPI Research has analyzed maturity levels 
concerning these specific questions, so we can expect even more data in the next year.  

5-Year Client Relationships Trends 

SPI Research identified three key trends in client relationships, as shown in Figure 25, which are critical 
performance indicators for the Client Relationships pillar. While it's encouraging that over 30% of the 
clients for the PSOs in this study were new, there was a decline in annual PS revenue growth in 2024, 
accompanied by increased discounts. Professional services experienced year-over-year revenue growth 
exceeding 10% for many years, but there have been challenges following the COVID-19 pandemic. It's 
essential to monitor these two KPI trends to prevent further deterioration in performance. 

Figure 25:  Client Relationships Trends of Note 

Source: SPI Research, February 2025 

Table 117 provides an overview of benchmark surveys conducted over the past five years. It reveals that 
most Client Relationship metrics reached their peak performance in 2021. During this time, the market 
began to improve as PSOs adapted their marketing and sales strategies in response to the pandemic, 
which led to a surge in consulting demand. 

However, in 2023 and 2024, the market faced challenges due to economic uncertainty, the upcoming U.S. 
elections, and their potential impact on the country. While the deal pipeline showed improvement in 2024, 
indicating positive prospects for 2025, the percentage of deals won and the backlog at the start of the 
quarter declined. This suggests that Professional Services has not fully recovered in the market yet. 

Table 117:  Client Relationships Pillar 5-year Trend 

Key Performance Indicator (KPI) 5-year avg. 2020 2021 2022 2023 2024 

Year-over-year change in PS revenue 8.7% 8.7% 10.6% 10.4% 7.8% 4.6% 

Current clients - existing services 55.5% 56.2% 58.9% 53.7% 52.3% 57.9% 

Current clients - new services 15.3% 15.6% 13.6% 17.0% 16.4% 12.8% 

New logo clients - existing services 19.3% 18.1% 18.1% 19.0% 20.6% 21.0%