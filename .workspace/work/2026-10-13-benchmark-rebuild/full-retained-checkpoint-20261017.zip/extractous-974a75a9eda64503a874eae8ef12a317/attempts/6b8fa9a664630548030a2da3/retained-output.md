A4 | Monday, February 2, 2026 P W L C 10 11 12 H T G K R F A M 1 2 3 4 5 6 7 8 9 O I X X * * * * * THEWALL STREET JOURNAL.

WASHINGTON—President
Trump’s lawsuit against the
government that he runs pres-
ents a mind-bending minefield
of conflicts that could end
with the president’s appoin-
tees approving a federal pay-
out to him.

Trump is simultaneously
supervising the private attor-
neys demanding at least
$10 billion in damages over
the past disclosure of his tax
records, while also overseeing
the senior Justice Department
attorneys with authority to
settle the case and authorize a
payment.
“This creates the risk of

the most collusive lawsuit of
all time, because it is ulti-
mately the president suing a
defendant whom he says has
to do whatever he directs,”
said Peter Keisler, who served
as acting attorney general in
the George W. Bush adminis-
tration.
Trump, two of his sons and

his businesses sued the gov-
ernment in federal court in
Miami last week, arguing that
they were harmed when for-
mer IRS contractor Charles

By Richard Rubin,
C. Ryan Barber and
Annie Linskey

U.S. NEWS

Littlejohn illegally disclosed
their tax information to the
New York Times and ProPub-
lica in 2019 and 2020.
“Defendants have caused

Plaintiffs reputational and fi-
nancial harm, public embar-
rassment, unfairly tarnished
their business reputations,
portrayed them in a false
light, and negatively affected
President Trump, and the
other Plaintiffs’ public stand-
ing,” the lawsuit said.
Littlejohn, who is serving a

five-year sentence in federal
prison, pleaded guilty in 2023
and said he intentionally
leaked Trump’s information
before the 2020 election. The
disclosures showed Trump
regularly reported losses and
paid just $750 in federal in-
come taxes in 2016 and in
2017. Littlejohn also disclosed
tax data of thousands of other
wealthy Americans.
Trump said on Saturday

that he recognized the
“strange position” created by
the lawsuit he filed and said
he would likely donate pro-
ceeds from a settlement to
charities such as the American
Cancer Society.
“If I pay myself, that some-

how will never look good,” he
said. “Nobody cares how much
if it goes to good charities. So
you settle by giving charities a
lot of money. And I think
we’re going to do something
like that.”
The Justice Department

hasn’t yet responded to
Trump’s lawsuit, which was

assigned to Judge Kathleen
Williams, an appointee of for-
mer President Barack Obama.
The Treasury Department and
Internal Revenue Service
didn’t comment.
On one crucial question,

there’s already a conflict be-
tween the president’s stance
and the government’s previ-
ously stated position. If Little-
john was an IRS employee, the
government can be sued. If he
was a contractor, Trump can’t
sue the government.
Trump’s lawsuit notes Lit-

tlejohn’s vast access to tax-
payer information and day-to-
day supervision by IRS
employees as evidence that he
was effectively a government
employee. In a separate case
brought by billionaire Ken
Griffin in 2022, a federal judge
let that argument proceed
through early stages of litiga-
tion. That case was settled
with an apology from the gov-
ernment to Griffin, before the
judge reached a decision.
The DOJ argued then that

Littlejohn wasn’t an IRS em-
ployee. It reiterated that posi-
tion as recently as two
months ago—during the
Trump administration.
“At all times, Mr. Littlejohn

was a contractor who wrong-
fully disclosed taxpayer return
information,” the government
wrote in a November 2025
court filing in Maryland. “The
United States cannot be held
liable for his illegal conduct.”
Moreover, Littlejohn’s ille-

gal conduct happened during

Trump’s first term. That is,
the plaintiff’s complaints
about IRS failures and negli-
gence pin the blame on offi-
cials who were supervised by
that very plaintiff.
Normally, Justice Depart-

ment tax attorneys who focus
on this area of the law would
handle the case. They would
likely raise several challenges
to Trump’s claims beyond ar-
guing that Littlejohn wasn’t
an IRS employee.
The government could also

argue that Trump filed the
case too late, said Francesca
Ugolini, former chief of the
appellate section in DOJ’s tax
division.
The statute says suits can

be filed within two years of the
“date of discovery” of the dis-
closure. The first New York
Times story stemming from

Littlejohn’s disclosure was
published in September 2020,
though the documents’ prove-
nance wasn’t clear then. Little-
john was charged in September
2023. Trump, who broke a tra-
dition of voluntary-tax-return
disclosure by presidents and
candidates, filed the lawsuit
exactly two years after receiv-
ing a formal IRS notice about
the unauthorized release.
Another point of contention

would be the damages calcula-
tion. The $10 billion figure
isn’t punitive damages. In-
stead, it’s a $1,000-per-disclo-
sure level specified in the law,
multiplied by an estimate of
the number of times that
Trump’s tax information was
published or broadcast.
However, the law specifies

$1,000 for each unauthorized
disclosure. The government
could argue that the only un-
authorized disclosures were
the ones that Littlejohn made.
Ugolini said the DOJ’s

model should be its handling
of Hunter Biden’s tax-disclo-
sure suit against the govern-
ment. While his father was
president, the son sought
damages for comments by IRS
agents who were raising con-
cerns to Congress about the
handling of the government’s
criminal investigation into
him.
“The career attorneys at

DOJ were allowed to handle
the case in the normal way,
raising defenses for the United
States,” said Ugolini, now at
SouthBank Legal.

Hunter Biden pleaded
guilty to tax crimes in 2024.
He dropped the lawsuit
against the government last
April, just months after his fa-
ther pardoned him and Trump
returned to the White House.
Another potential route is a

settlement.
Trump has filed other law-

suits seeking billions of dol-
lars in damages, including one
against the publisher of The
Wall Street Journal. His gov-
ernmental power can create
incentives for defendants to
settle. Since his 2024 election
victory, Disney’s ABC News,
Meta Platforms, Alphabet’s
YouTube and Paramount
Global—the owner of CBS—
have agreed to multimillion-
dollar payments to settle liti-
gation initiated by Trump.
The tax case is distinct be-

cause Trump doesn’t just have
leverage over the defendants.
He has control. Trump has
separately filed administrative
claims demanding millions of
dollars from the Justice De-
partment over past criminal
investigations into him.
Asked in October about re-

porting that he was seeking
more than $200 million,
Trump appeared to acknowl-
edge the awkwardness of pur-
suing payment from the gov-
ernment he leads.
Trump said then that he

was “damaged very greatly”
and would give any money to
charity. He said on Saturday
that he still needs to work out
a settlement in that matter.

Trump Straddles Both Sides of IRS Suit
President is plaintiff,
but also oversees
people who could
decide on a payout

on Democrats in the House, a
person familiar with the mat-
ter said. That meant the cham-
ber couldn’t quickly pass the
package on Monday through a
fast-track provision on a two-
thirds vote, and would instead
have to go through the “rule”
process that would push a vote
until Tuesday at the earliest.
Jeffries said the Senate vote

was a step in the right direc-
tion but argued that House
Democrats weren’t a part of
any Senate deal. He ticked off a
series of changes demanded by
Democrats, such as a higher
threshold for searches and ar-
rests, mandated use of body
cameras and a ban on masks.

Jeffries echoed calls from
many Democrats who say even
two weeks of funding for DHS
is too much. Some Democrats
have called for Immigration
and Customs Enforcement to
be eliminated altogether, after
a month in which immigration
agents surged into Minneapo-
lis, fatally shooting two U.S.
citizens to death and prompt-
ing protests.
“The administration can’t

just talk the talk. They need to
walk the walk. That should be-
gin today—not in two weeks,
today,” Jeffries said on Sunday
on ABC.
Johnson, in an interview on

Fox News, dismissed the calls

for no masks and a require-
ment for judicial warrants for
apprehensions and searches,
but he did speak in favor of
body cameras on ICE officers.
In a separate appearance on
NBC, Johnson said some of the
Democrats’ conditions “are ob-
viously reasonable and should
happen. But others are going to
require a lot more negotiation.”
The House Democrats’ deci-

sion to play hardball has thrown
new uncertainty into resolving
the partial shutdown. Just last
month, Johnson celebrated
passing the final six of the 12
annual individual spending bills
and sent them to the Senate, a
rare occurrence in recent de-

cades when terms like omnibus
became commonplace. But an-
ger over the death of Pretti
made the path to passage more
difficult, prompting the Senate
to change the House package
and send it back this week.
Johnson’s tiny vote margin

gives any one or two GOP
members leverage if they want
changes or concessions. John-
son as soon as Monday will
swear in Christian Menefee, a
Democrat who won a special
election to represent Texas’
18th Congressional District af-
ter Rep. Sylvester Turner’s
death last year. That will bring
the majority to 218-214.
And the expected vote

comes as some conservatives
aren’t happy with the two-
week extension of the DHS bill,
instead wanting a four- to six-
week extension. The conserva-
tive House Freedom Caucus in
a letter to Trump on Tuesday
backed the efforts of ICE and
urged the administration to
“use all tools necessary.” Other
GOP lawmakers have said they
would demand that the VOTE
Act—a measure that imposes
stricter requirements for vot-
ing, among other changes—be
included in any package.
Activists and rank-and-file

Democrats have rallied around
denying ICE any funding.
“I’m not a no. I’m a firm

no,” said Ro Khanna (D., Calif.)
on NBC. “I just in good con-
science cannot vote to give
more money to ICE agents as
they’re violating our constitu-
tional rights,” he said.
Trump last week moved to

pull back on his administra-
tion’s immigration-enforce-
ment campaign, including re-
placing the leader of the
Minneapolis operation. But he
hasn’t made clear what kind of
changes he would accept on
immigration-enforcement prac-
tices. The White House, like
many congressional Republi-
cans, had initially pushed for
administration changes or ex-
ecutive actions, rather than
new law passed by Congress.
On Saturday night, Trump

backed ICE and gave a warning
to protesters. “If they do any-
thing bad to our people then
they will have to suffer,” he
said. Asked about body cam-
eras for immigration agents, he
said Sunday: “We’ll be talking
about that in the near future.”
Some Democrats said they

became further dug in on op-
posing any ICE funding after
Trump returned to his more
forceful rhetoric against pro-
testers, and continued to back
Homeland Security Secretary
Kristi Noem, who many Demo-
crats and some Republicans
have said should resign.
The partial shutdown that

started Saturday morning af-
fects the agencies attached to
the six bills that haven’t yet
passed the House, including
DHS and the departments of
Defense and Transportation. In
departments where funding
lapses, federal employees are
set to be furloughed or work
without pay until funding is
restored. Federal employees
typically get back pay when a
shutdown ends.

them that we need to imple-
ment the president’s play call,”
giving the White House time to
discuss changes to DHS with
Democrats.
House Republicans will have

to swallow frustration over
what they see as being painted
into a corner by Democrats,
and some have floated their
own demands. Asked if he ex-
pects Trump to help twist
arms to get the necessary sup-
port, the GOP leader replied:
“I’m sure he will get on the
phone with them.”
The Senate on Friday

passed the bipartisan plan
struck between Senate Demo-
crats and the White House to
fund the government, just days
after the killing of Alex Pretti
by immigration agents in Min-
neapolis the previous weekend.
But with the House out and
not returning until Monday, a
funding lapse was triggered
Saturday morning.
While the Senate vote drew

the support of Minority Leader
Chuck Schumer (D., N.Y.) and
about half of the Senate Demo-
cratic caucus, House Minority
Leader Hakeem Jeffries (D.,
N.Y.) told Johnson in a phone
call on Saturday not to count

ContinuedfromPageOne

Funding
Runs Into
Pushback

videos, called NAND, as well as
the memory used to run apps
quickly, called DRAM. By the
end of this year, the price of
DRAM will quadruple from
2023 levels, and NAND will
more than triple, estimates
TechInsights.
Howard estimates that Ap-

ple could pay $57 more for the
two types of memory that go
into the base-model iPhone 18
due this fall compared with
the base model iPhone 17 cur-
rently on sale. For a device
that retails for $799, that
would be a big hit to profit
margins.
Apple’s purchasing power

and expertise in designing ad-
vanced electronics long made
it an unrivaled Goliath among
the Asian companies that
make most of the iPhone’s
parts and assemble the device.
Apple spends billions of

dollars a year on NAND, for in-
stance, people familiar with
the figures said, likely making
it the single biggest buyer
globally. Suppliers flocked to
win Apple’s business, hoping
to leverage its know-how and
prestige to attract other cus-
tomers.
These days, however, “the

companies now pushing the
boundaries of human‑scale en-
gineering are the ones like
Nvidia,” said Ming-chi Kuo, an
analyst with TF International
Securities.

against the iPhone maker.
Apple signs long-term con-

tracts for memory, but it has
used its heft to squeeze suppli-
ers. Its contracts have empow-
ered it to negotiate prices as
often as weekly, and to even
refuse to buy any memory
from a supplier if Apple didn’t
view the price as favorable,
people familiar with its mem-
ory purchases said. To boost
leverage with suppliers, Apple
even began stocking more in-
ventory of memory. That was
atypical for Cook, who nor-
mally cuts inventory to the
bone to maximize Apple’s cash
flow.
Apple is fighting not only

for current deliveries but also
for the attention of engineers
at suppliers. Glass scientists
who worked on developing the
smoothest and lightest smart-
phone displays are now also
spending time on specialized
glass for packaging advanced
AI processing chips, industry
executives said.
Makers of sensors and

other gizmos inside the iPhone
are winning new business
from AI companies such as
OpenAI that are developing
their own hardware.
Still, suppliers said they

were far from giving up on
business with Apple. Working
with Apple is a form of educa-
tion, they said, because it re-
mains one of the most de-

manding and disciplined
customers in the industry.
TSMC, the Taiwanese chip

manufacturer, has built suc-
cessive generations of its most
advanced chips with Apple as
its lead customer, relying on
the big predictable demand for
iPhones. Now that TSMC is do-
ing more business with Nvidia
and other AI companies, peo-
ple with knowledge of the chip
supply chain said Apple was
exploring whether some lower-
end processors could be made
by someone other than TSMC.
One of Apple’s biggest

profit spinners is selling extra
memory for far more than the
memory chips cost the com-
pany. Last fall, Apple discon-
tinued the iPhone Pro model
with 128 gigabytes of storage.
Customers who want that
model must now start at 256
gigabytes and pay $100
more—the type of move that
could be repeated this year to
help Apple offset higher costs,
wrote Craig Moffett, an ana-
lyst at Moffett Nathanson, in
an investor note.
However, Apple isn’t ex-

pected to raise the price of its
next iPhone models over simi-
larly equipped iPhone 17s, said
Kuo, the analyst.
News Corp, owner of The

Wall Street Journal, has a
commercial agreement to sup-
ply news through Apple ser-
vices.

tor Manufacturing, Nvidia
Chief Executive Jensen Huang
said on a podcast. Apple had
been TSMC’s biggest customer
by a wide margin for years.
TSMC is the world’s leading
manufacturer of advanced
chips for AI servers, smart-
phones and other computing
devices.
Spokesmen for Apple and

TSMC declined to comment.
The big computers that

handle AI tasks don’t look like
the smartphones consumers
own, but many companies sup-
ply components for both. In
particular, memory chips are
in short supply as companies
such as OpenAI, Alphabet’s
Google, Meta, Microsoft and
others collectively spend hun-
dreds of billions of dollars to
build AI computing capacity.
“The rate of increase in the

price of memory is unprece-
dented,” said Mike Howard, an
analyst for research firm
TechInsights. That applies
both to the flash memory
chips that store photos and

ContinuedfromPageOne

Apple’s
Margins
Threatened

Demand for AI hardware is
poised to keep growing rap-
idly. Apple’s spending growth
is modest in comparison with
what is being spent to fill up
AI data centers, even though it
is breaking records with huge
sales of the iPhone 17.
Samsung Electronics and

SK Hynix are raising the price
of a type of DRAM chip for
Apple, people familiar with
Apple’s supply chain said. Big
AI companies pay generously
and are willing to lock in sup-
ply and make upfront pay-
ments, giving the South Ko-
rean chip makers leverage

FY2023 ’24 ’25 ’26

0

2

4

6

$8Price per gigabyte for DRAM, themain
systemmemory in AI servers and
smartphones, quarterly

2020 ’21 ’22 ’23 ’24 ’25

0

10

20

30

40

50

60%High Performance Computing* Smartphone

Proportion of revenue bymarket segment, quarterly

Sources: TechInsights (price per gigabyte for DRAM); TSMC (revenue)
*Includes AI-related chips

Projections

President Trump speaking at
Mar-a-Lago on Sunday.

AL
DR
AG
O/
GE
TT
Y
IM
AG
ES

House Minority Leader Hakeem Jeffries (D., N.Y.) is seeking to rein in immigration agents’ tactics.

GR
AE
M
E
SL
OA
N/
BL
OO
M
BE
RG

NE
W
S

P2JW033000-5-A00400-16DDF61078D