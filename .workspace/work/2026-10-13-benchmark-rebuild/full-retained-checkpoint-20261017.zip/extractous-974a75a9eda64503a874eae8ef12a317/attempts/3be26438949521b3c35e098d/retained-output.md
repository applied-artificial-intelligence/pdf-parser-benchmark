232024 STATE OF THE U.S. SEMICONDUCTOR INDUSTRY

THE GLOBAL  
SEMICONDUCTOR MARKET
Over the past three decades, the semiconductor industry has 
experienced rapid growth and delivered enormous economic impact. 

Chip performance and cost improvements made possible the evolution from 

mainframes to PCs in the 1990s, the Web and online services in the 2000s, 

and the smartphone revolution in the 2010s. Innovation in AI, electric 

vehicles, and industrial manufacturing will drive continued growth in the 

chip market through the next decade. By 2030, AI alone is projected to 

contribute more than $15 trillion to the global economy. Semiconductors 

have become essential to our modern world, which is why long-term market 

demand for semiconductors remains strong.

The 2023 market was down through the first 

half of the year but strong sales to auto, 

industrial, and AI propelled a rebound in the 

second half of the year.

Following a sales record year of $574.1 billion 

in 2022, global semiconductor sales in 2023 

decreased by 8.2% to $526.9 billion. Sales 

were slow in the first half of 2023 but grew 

consistently in the second half of the year, 

largely due to increased demand for chips in 

AI, autos, and industrial applications. Sales 

during the first half of 2024 increased by 19.2% 

compared to sales during the first half of 2023.

Estimates from the World Semiconductor 

Trade Statistics (WSTS) project worldwide 

semiconductor industry sales will increase to 

$611 billion in 2024, a 16% increase compared to 

2023. Notwithstanding the short-term cyclical 

downturn the market faced in 2023, long-

term growth prospects for this foundational 

technology remain promising.

0

100

200

300

400

500

600

700

'01 '02 '03 '04 '05 '06 '07 '08 '09 '10 '11 '12 '13 '14 '15 '16 '17 '18 '19 '20 '21 '22 '23 '24E

-8.2% '22/'23

GLOBAL SEMICONDUCTOR SALES ($B)