4 
 

Inflation 

Inflation, measured by the consumer price index (CPI), reflects changes in the prices of commonly purchased 

goods and services. Global inflation spiked to ~8.7% in CY2022. The increase in global crude oil and commodity 

prices, along with COVID-19 supply chain disruptions, have driven inflation, prompting countries to raise interest 

rates in response. Global inflation has eased to ~6.8% in CY2023, with a projected rate of ~5.9% for CY2024. 

Pre-pandemic inflation was ~3.5% in CY2019. 

 

India’s CPI inflation is expected to drop from ~5.4% in CY2023 to ~4.6% in CY2024, and ~4.2% in CY2025. In 

the USA and Germany, inflation is projected to fall from ~4.1% and ~6.0% in CY2023 to ~2.9% and ~2.4% in 

CY2024, reaching ~2.0% in CY2025. China’s inflation may rise from ~0.2% in CY2023 to ~2.0% in CY2025. 

 

Exhibit 1.3: Global Inflation Rate, Average Consumer Price Index (%) of Key Economies (CY) 

 

Source: IMF projections, Technopak Analysis 

Note: For India, CY2017 data refers to FY2018 and so on 

 

1.2 Overview of Indian Economy 
 

India’s GDP and GDP Growth (Real and Nominal)- Historical, Current & Projected Trajectory 

India is ranked fifth in the world in terms of nominal gross domestic product ("GDP") for FY2024 and is the third-

largest economy in the world in terms of purchasing power parity ("PPP"). India is projected to be a USD 6.5 

trillion economy by FY2029 and is anticipated to become the third largest economy, surpassing Germany, and 

Japan in terms of Nominal GDP. 

 

Exhibit.1.4:  India’s GDP at Current Prices (Nominal GDP) (in USD trillion) and GDP Growth Rate (%) (FY) 
 

 
 

Source: RBI, Technopak Analysis 

Note: 1 USD = INR 80 
 

 

 
 

 

 
 

 

1
.1

1
.2

1
.4

1
.6 1
.7 1
.9 2
.1 2
.4 2
.5

2
.5 2
.9 3
.4 3
.7

5
.8 6

.5

13.8% 12.9%
11.4%

10.3%

11.6% 11.5%
10.3%

6.4%

-1.2%

16.9% 16.9%

8.8%

12.0% 12.1%

-5.0%

0.0%

5.0%

10.0%

15.0%

20.0%

0.0

1.0

2.0

3.0

4.0

5.0

6.0

7.0

2012 2013 2014 2015 2016 2017 2018 2019 2020 2021 2022 2023 2024E 2028P 2029P

GDP (USD Tn) GDP Growth Rate(%)

Country 2017 2018 2019 2020 2021 2022 2023 2024E 2025P 2026P 2027P 2028P 

USA 2.1% 2.4% 1.8% 1.2% 4.7% 8.0% 4.1% 2.9% 2.0% 2.1% 2.1% 2.1% 

China 1.6% 2.1% 2.9% 2.5% 0.9% 2.0% 0.2% 1.0% 2.0% 2.0% 2.0% 2.0% 

Japan 0.5% 1.0% 0.5% 0.0% (0.2%) 2.5% 3.3% 2.2% 2.1% 2.0% 2.0% 2.0% 

Germany 1.7% 1.9% 1.4% 0.4% 3.2% 8.7% 6.0% 2.4% 2.0% 2.0% 2.0% 2.0% 

India 3.6% 3.4% 4.8% 6.2% 5.5% 6.7% 5.4% 4.6% 4.2% 4.1% 4.0% 4.0% 

UK 2.7% 2.5% 1.8% 0.9% 2.6% 9.1% 7.3% 2.5% 2.0% 2.0% 2.0% 2.0% 

France 1.2% 2.1% 1.3% 0.5% 2.1% 5.9% 5.7% 2.4% 1.8% 1.8% 1.8% 1.8% 

Brazil 3.4% 3.7% 3.7% 3.2% 8.3% 9.3% 4.6% 4.1% 3.0% 3.1% 3.0% 3.0% 

Australia 2.0% 1.9% 1.6% 0.9% 2.8% 6.6% 5.6% 3.5% 3.0% 2.7% 2.7% 2.6% 

World 3.3% 3.6% 3.5% 3.2% 4.7% 8.7% 6.8% 5.9% 4.5% 3.7% 3.5% 3.4%