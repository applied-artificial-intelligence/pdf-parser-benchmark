Employment and Social Developments in Europe 2024 

80 

 

Chart 3.4 

School education receives the largest share of public expenditure on education 
Weighted average EU share of government expenditure on education, by education level, 2012-2022 

  

Note: School education includes (pre-)primary and secondary levels. Further categories of public expenditure on education not included in the chart are post-secondary non-tertiary 
education, education not definable by level, subsidiary services to education, research and development (R&D) education, and education not elsewhere classified. 

Source: Eurostat [gov_10a_exp]. 

Click here to download chart. 

 
PISA outcomes point to worsening basic skills in the EU over time, with potential negative impacts on 
EU competitiveness and wage developments in the longer term. The average PISA score across reading, 
mathematics and science subjects decreased by 10 points since the last wave in 2018, and by 18 points over the 
last 10 years in the EU (Chart 3.5). (157) While this declining pattern was also observed in other industrial 
countries (with the average PISA score dropping by 9 points since 2018 and 19 points since 2012 in OECD 
countries on average), the EU performed quite poorly compared to other advanced economies such as the US, the 
UK, Canada or Japan. In 2022, for example, it had the highest percentage of underachievers across all three 
subjects, and one of the lowest shares of top performers among those countries. Although PISA outcomes had 
already started to decline prior to the COVID-19 pandemic, learning losses during lockdowns might have 
intensified this downward trend among other possible factors. Box 3.3 presents a case study on Italy, showing the 
persistent impacts of COVID-19 pandemic school disruptions on student achievement, with learning losses still 
significant in 2021 and 2022. 
 

Chart 3.5 

Basic skills and efficiency of cumulative expenditure on education per student decreased post-COVID-19 pandemic 
Average EU PISA score across reading, mathematics and science, and PISA EU efficiency score, 2012-2022 

  

Note: PISA efficiency score measures the number of PISA points produced by USD 1 000 (expressed in purchasing power parity (PPP)) of cumulative expenditure on education per 
student, following the methodology in European Commission (2023d). It is calculated as 1 000 x (average PISA score over reading, mathematics and science)/cumulative 
expenditure per student from age 6-15 (in USD, PPP), and can be interpreted as an approximate measure of the pay-off from additional expenditure for a school education system. 
Yearly averages for Member States for which data are available. 

Source: OECD PISA data for 2012, 2015, 2018, 2022. 

Click here to download chart. 

 
 

 
(157) To approximate the average annual pace of learning among 15-year-olds, OECD (2023) used 20 score points in PISA as a common 

benchmark for all countries. However, this benchmark should not be used to convert the differences across countries and changes over 
time in PISA scores as years-of-schooling equivalents, given differences in the pace of learning at a given age, organisation of schooling, 
resources invested in education, and quality of education across countries, as well as possible changes in the pace of learning over time. 

0%

20%

40%

60%

80%

100%

2012 2013 2014 2015 2016 2017 2018 2019 2020 2021 2022

Pre-primary and primary Secondary Tertiary

0

3

6

9

470

480

490

500

2012 2015 2018 2022

PISA average score (left axis)

PISA efficiency score (right axis)

https://ec.europa.eu/employment_social/empl_portal/publications/Esde2024/xls/Chap3/Chap3-Chart-3.4.xlsx
https://ec.europa.eu/employment_social/empl_portal/publications/Esde2024/xls/Chap3/Chap3-Chart-3.5.xlsx