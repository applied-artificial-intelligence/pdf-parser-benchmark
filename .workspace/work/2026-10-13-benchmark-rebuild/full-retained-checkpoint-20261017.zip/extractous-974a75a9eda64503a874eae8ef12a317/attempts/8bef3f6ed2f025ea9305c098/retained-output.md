GIE_AXA_Internal

FY23

2.5

FY24

Commercial
lines

AXA XL 
Reinsurance

Retail 
lines

53.0
56.5

+7%

P&C | Remaining disciplined on pricing while accelerating volume growth
In Euro billion

GWP & Other Revenues

17

+6%

Change
o/w 

pricing1

o/w
volume2

+3% +3%

+10% +5% +5%

+7% +10% -3%

▶ Continued favorable pricing and higher volumes reflecting 
better customer retention and attractive margins

▶ Successful diversification at AXA XL Reinsurance towards 
Specialty and Casualty against a favorable industry pricing 
back-drop

▶ Pricing actions in the UK & Ireland and Germany to restore 
profitability completed

▶ +3% volume growth excluding UK & Ireland and Germany

Full Year 2024 Earnings Change at constant scope and FX. 
1. Price effect. 2. Includes exposure adjustments and mix & other effects.

34.9

19.1