 29 

OECD EMPLOYMENT OUTLOOK 2024 © OECD 2024 
  

1.1.4. Economic growth in the OECD is expected to remain unchanged in 2024 and 

strengthens modestly in 2025, with marginal increase in unemployment and slowdown 

of employment growth 

Global growth, which slowed in the second half of 2023, is expected to stabilise and then pick up slightly 

through 2024-25. In part, this reflects better momentum than expected in the United States and some 

emerging-market economies. Annual OECD GDP growth is projected to be at 1.7% in 2024 and edge up 

to 1.8% in 2025 (OECD, 2024[4]). 

The OECD-wide average unemployment rate is projected to rise marginally over 2024-25 to 5% in the 

fourth quarter of 2025 (Figure 1.7). The OECD-wide employment growth is expected to slow from 1.7% in 

2023 to around 0.7% per annum on average over 2024-25, below its 2000-19 trend (Figure 1.7). 

Figure 1.7. Employment in the OECD is projected to continue to grow in 2024 and 2025, with the 
unemployment rate also inching up slightly 

 

Note: (a) Actual value. (p) OECD projection. Euro Area refers to the 17 EU member states using the euro as their currency which are also 

OECD Member States. The 2000-19 trend refers to the average quarterly employment growth rate prevailing in Q1 2000 to Q4 2019. 

Source: OECD (2024[4]), OECD Economic Outlook, Volume 2024 Issue 1: Preliminary version, https://doi.org/10.1787/69a0c310-en. 

StatLink 2 https://stat.link/dwxjyq 

Significant uncertainty remains, however. Inflation may stay higher for longer, resulting in slower-than- 

expected reductions in interest rates and leading to further financial vulnerabilities. Growth could be 

disappointing in China, due to the persistent weakness of property markets or smaller than-anticipated 

fiscal support over the next two years. Another key downside risk to the outlook relates to the high 

geopolitical tensions, notably the uncertain course of Russia’s war of aggression against Ukraine, the 

evolving conflict in the Middle East, and the associated risks of renewed disruptions in global energy and 

food markets. On the upside, demand growth could prove stronger than expected, if households and firms 

were to draw more fully on the savings accumulated during COVID-19 (OECD, 2024[4]). 

1.2. Real wages are now growing in a number of countries but often remain 

below 2019 levels 

Headline inflation has fallen virtually everywhere primarily because of the partial reversal of the very large 

rise in energy prices over the previous two years and is expected to further ease.6 After peaking at 

100

105

110

115

120

125

130

B. Trend in employment
OECD Area, base 100 in 2000

Actual Projected 2000-19 trend

0

1

2

3

4

5

6

7

8

OECD Euro Area Australia Japan Mexico United
States

%

A. Unemployment rate 
Percentage of total labour force

Q4 2019(a) Q4 2023(a) Q4 2024(p) Q4 2025(p)

https://doi.org/10.1787/69a0c310-en
https://stat.link/dwxjyq