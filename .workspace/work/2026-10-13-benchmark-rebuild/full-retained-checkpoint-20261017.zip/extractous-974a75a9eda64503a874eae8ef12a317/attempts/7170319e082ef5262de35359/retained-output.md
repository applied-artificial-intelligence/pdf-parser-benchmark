 17 

 

A DECADE OF OECD COMPETITION TRENDS, DATA AND INSIGHTS © OECD 2025 
  

Figure 2.2. Total merger notifications (left) and the average annual growth rate (right) for OECD and 
Non-OECD jurisdictions, 2015-2024 

 

Note: Data based on the 59 jurisdictions in the OECD CompStats database that provided data for each of the variables for the period 2015-

2024. 

Source: OECD CompStats database 

Global trends in mergers and acquisitions in the past ten years have been impacted by macroeconomic 

dynamics and the correlation between merger notifications and variables such as GDP growth, inflation 

and interest rates is strong. Periods of strong GDP growth tend to spur deals, while periods of recession 

or slower growth dampen them (see Figure 2.3). The most impactful shock in the last decade was the 

COVID-19 pandemic, where OECD jurisdictions observed a decrease of -4.75% in their GDP (and OECD 

estimates for the decrease in the World’s GDP were around 3%  (OECD, 2020[14]; 2021[15]) that correlated 

with a drop in M&A activity in 2020 compared to 2019. This represented on average 10.3% fewer 

notifications, while the post pandemic rebound saw record deal volumes in 2021. This initial decline was 

observed in 70% of the jurisdictions in the sample, with Latin American jurisdictions being the ones that 

observed the biggest drop – as notifications fell more than 40% in Barbados, Ecuador, Panama and Chile. 

The subsequent recovery, which on average increased notifications by 40% in 2021 compared to 2020, 

was observed in 80% of those jurisdictions. In Latvia, the United States, Malta, the Slovak Republic and 

Greece, the increase was higher than 100% with respect to notifications in 2020.  

After the two years with significant changes, 2022 presented a mixed picture. In OECD jurisdictions 

notifications decreased, although they remained higher than the pre COVID-19 period, while in non-OECD 

jurisdictions they increased further. A sudden increase in the number of mergers notified in 2021, which 

directly impact merger reviews, may have impacted the resources that authorities had to dedicate to 

merger reviews.4 More mergers to assess require more time and, often, a more flexible allocation of the 

staff from other enforcement areas. Challenges on resource allocation, case prioritisation and the 

interaction between increased activity in one of the areas of work and the resources dedicated to others 

have raised concerns from competition authorities recently.5  

 0

2 000

4 000

6 000

8 000

10 000

12 000

14 000

2015 2016 2017 2018 2019 2020 2021 2022 2023 2024

OECD Non-OECD

Total number of merger notifications

-30% -20% -10% 0% 10% 20% 30% 40% 50%

2015/2016

2016/2017

2017/2018

2018/2019

2019/2020

2020/2021

2021/2022

2022/2023

2023/2024

Annual growth rateOECD Non-OECD