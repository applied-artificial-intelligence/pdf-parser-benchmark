102    

OECD EMPLOYMENT OUTLOOK 2024 © OECD 2024 
  

Figure 2.14. Among high-skill jobs, green-driven occupations have fewer fixed-term contracts 

Marginal effect of the fixed-term contract indicator on the share of green-driven occupations, by type of occupation 

and controlling for main individual and job (or last job) characteristics, 2015-19 

 

Note: The chart reports the point estimate (and 95% confidence intervals) of the percentage difference in the incidence of each type of green-

driven occupation between employees on fixed-term and open-ended contracts. Estimates are obtained from a linear regression with the inverse 

hyperbolic sine of the share of each type of green-driven occupation within all, high, medium or low-skilled occupations as dependent variable 

and including a fixed-term contract dummy, the share of 1-digit ISCO occupations, educational attainment (3 classes), gender, age (3 classes), 

sectors (5 categories), time and country dummies as explanatory variables. Except for the case of all occupations, regressions are estimated 

separately for high, medium, and low-skill occupations. “Total” indicates the full sample with all occupations. Standard errors are clustered on 

the dimensions of variability of the dependent variable. The reported point estimates and confidence intervals refer to the estimated coefficient 

of the fixed-term contract dummy and are expressed in percentage of the untransformed dependent variable. The sample excludes Agriculture 

and includes Austria, Belgium, Czechia, Denmark, Estonia, Finland, France, Germany, Greece, Hungary, Iceland, Ireland, Italy, Latvia, Lithuania, 

Luxembourg, the Netherlands, Norway, Poland, Portugal, the Slovak Republic, Slovenia, Spain, Sweden, Switzerland and the United Kingdom. 

Reading: Controlling for demographic characteristics and restricting the sample to high-skill occupations, the percentage share of high-skill, 

green new and emerging occupations is, on average, 39% higher among employees on open-ended than fixed-term contract. A higher incidence 

of a given type of occupation among employees on open-ended contract is indicative that the share of fixed-term contracts within that type of 

occupation is lower than in the other occupations included in the regression. 

Source: Secretariat’s estimates based on version 24.1 of the O*NET database and the Current Population Survey, for the United States and the 

EU Labour Force Surveys, for all other countries. 

StatLink 2 https://stat.link/xc4g6h 

One possible explanation of these results is that high-skill workers in green-driven occupations tend to 

have high-level positions in innovative startups or activities characterised by high average growth but also 

high failure rates and shakeouts, and therefore a relatively high risk of job destruction. Wage premia, 

however, likely compensate for the lack of labour market security. Moreover, high-skill, green-enhanced 

skills occupations are likely characterised by high rates of restructuring due to changing competences and 

work requirements – see Section 2.1.2. Workers unable to adapt to the new requirements may therefore 

find it difficult to maintain their employability.53 At the same time, some other (not green-driven) high-skill 

occupations, such as health professionals or software developers, have a relatively high share of fixed-

term contracts but still enjoy high labour market security (low unemployment rates) since they face strong 

labour demand. By contrast, the situation of workers in low-skill occupations is likely different: like their 

negative wage gap (see Section 2.3.1), their higher unemployment risk and incidence of fixed-term 

contracts probably reflect the weakness of their position in the labour market. 

-50

-40

-30

-20

-10

0

10

20

30

40

Total High-skill Medium-skill Low-skill Total High-skill Medium-skill Low-skill Total High-skill Medium-skill Low-skill

Green new and emerging occupations Green-enhanced skills occupations Green increased demand occupations

%

https://stat.link/xc4g6h