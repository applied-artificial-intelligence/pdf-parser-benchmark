84  D I G I T A L  P R O G R E S S  A N D  T R E N D S  R E P O R T  2 0 2 5  

FIGURE 5 .6 Share of workers with AI and GenAI skills, by educational attainment, 2024

0
HICs UMICs LMICs LICs HICs UMICs LMICs LICs

1
2
3
4
5
6
7
8
9
AI skills (%)

a. Supply of AI skills, excluding GenAI b. Supply of GenAI skills
GenAI skills (%)

Education level Education level
Below bachelor’s degree Bachelor’s degree Master’s degree Doctorate

0
0.2
0.4
0.6
0.8
1.0
1.2
1.4
1.6

Source: Original figures for this publication using calculations based on data from Lightcast (https://lightcast.io/). 
Note: AI = artificial intelligence; GenAI = generative artificial intelligence; HICs = high-income countries; LICs = low-income countries; 
LMICs = lower-middle-income countries; UMICs = upper-middle-income countries.

However, workers are significantly less likely to claim GenAI skills overall. Notably, workers 
in LMICs report GenAI skills more frequently than those in UMICs and HICs; this is largely 
attributable to sample bias, because a more elite segment of the workforce in poorer countries 
typically uses LinkedIn.

The supply of GenAI skills largely mirrors demand, being concentrated among ICT professionals, 
followed by administrative and commercial managers and business and administrative professionals 
across all country income groups. As of June 2025, an analysis of nearly 400 million individual 
career profiles globally revealed that one-quarter of all users claiming GenAI skills in HICs are ICT 
professionals. This share rises to one-third in LMICs (refer to figure 5.7, panel a). 

The top five broad occupations in which GenAI skills are concentrated include administrative 
and commercial managers, business and administrative professionals, chief executives, and 
production and specialized services managers, dovetailing with demand patterns. Among non-
ICT occupations, GenAI skills are most likely claimed by R&D managers, policy and planning 
managers, management and organizational analysts, survey and market research interviewers, 
human resources professionals, engineers, and advertising and marketing professionals (refer to 
figure 5.7, panel b). However, GenAI skill penetration in these roles remains low, typically ranging 
from 0.5 percent to 1.5 percent of all profiles. This limited uptake, even among highly exposed 
occupations, corroborates earlier findings that GenAI adoption is still in its nascent stages and has 
had minimal impact on skills demand and supply to date.

https://lightcast.io/