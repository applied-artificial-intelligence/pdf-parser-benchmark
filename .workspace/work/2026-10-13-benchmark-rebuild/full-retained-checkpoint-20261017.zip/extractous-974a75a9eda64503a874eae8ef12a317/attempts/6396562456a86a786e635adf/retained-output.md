Oil-sealed rotary vane vacuum pumps
The latest generation of oil­sealed rotary vane 
pumps has been refined to produce a better 
quality of vacuum while extending the pressure 
range over which the pump can operate. They 
are used in a wide variety of industrial, and 
research and development applications.

Dry vacuum pumps 
Dry pumps are oil­free pumping mechanisms  
to create vacuum environments. They use no 
lubricants within the pumping mechanism and 
have a series of available monitoring and control 
options. Dry pumps are used extensively in many 
semiconductor applications, as well as in indus­
trial processes such as metallurgy, coating, dry­
ing, mobile applications and solar. They are also 
used in scientific instruments such as scanning 
electron microscopes.

Turbomolecular pumps
In turbomolecular pumps, or turbo pumps, a  
turbine rotor spins rapidly to create vacuum. The 
defining feature of a turbo pump is the high rota­
tional speed. These pumps are typically used in 
conjunction with primary wet or dry pumps.  
They are commonly used in semiconductor appli­
cations, research and development, industrial 
applications, and high energy physics.

Dry vacuum pump for industrial applications

Integrated  
abatement  
system used  
in the semi­
conductor  
industry 

Turbomolecular 
pump for the  
semiconductor 
and flat panel  
industry

The Vacuum Technique business area offers an extensive range of vacuum 
and abatement solutions to the market. 

MANAGEMENT 
Vacuum Technique, January 1, 2025

Liquid ring vacuum pumps
Liquid ring pumps are equipped with a fixed 
blade impeller. As the impeller rotates, the liquid 
forms a ring around the circumference of the  
casing. Standard liquid ring vacuum solutions are 
perfect for use in humid, dusty, and dirty environ­
ments commonly found in industrial processes, 
including food and beverage, mining, chemicals, 
oil, steel, cement, plastics and textiles.

Abatement and integrated systems
Abatement systems are used to manage gases 
and other process by products from dry pump 
exhaust. Abatement is required to prevent 
adverse chemical reactions within production 
processes and to comply with strict regulatory 
emission controls. Abatement and integrated 
systems are primarily used in semiconductor,  
flat panel display, solar and LED applications. 

Cryogenic pumps 
Cryogenic pumps create vacuum by condensing 
(freezing) gas onto special arrays of cryogenically 
cooled surfaces within the pump envelope. The 
temperature of the surfaces can be below 
20K/–250°C to enable the capture of most gas 
species. Cryogenic pumps are used in a spectrum 
of high­technology research applications as well 
as in manufacturing of semiconductor, flat panel, 
and optical devices.

Business Area  
President  
Koen Lauwers

Vacuum Technique 
Service, President  
Eckart Roettger

Semiconductor  
Service, President  
Paul Neller

Semiconductor,  
President  
Martin Tollner

Semiconductor  
Chamber Solutions, 
President Tim Heger ¹

Scientific Vacuum, 
President  
Carl Brockmeyer 

Industrial Vacuum,  
President  
Andries Desiron

Principal product development and manu facturing 
units are located in: The United States, Mexico, the United 
Kingdom, Czech Republic, Germany, South Korea, China 
and Japan.

INNOVATIONS DURING 2024

Several new products were introduced during  
the year, including:

Polycold MC2200, the new chiller for industrial  
applications, offers high productivity, fast cooldown 
cycles, and up to 20% improved power efficiency 
compared to previous models.

Hydrogen Dilution (H2D-HPX), a new integrated 
vacuum and abatement system, was introduced.  
By diluting hydrogen from the production process, 
customers can benefit from lower energy consump­
tion and a lower carbon footprint.

Warden System, a new integrated vacuum and 
abatement system for the semiconductor market, 
specifically designed for safe handling in hazardous 
production processes.

The Leybold SOGEVAC SV55 BI² – SV70 BI², a  
new rotary vane pump for analytical applications, 
offers high energy efficiency and low noise level  
and is particularly designed for mass spectrometry 
applications.

Products and applications 

¹  As of February 1, 2025

Atlas Copco Group 2024   25

Introduction

This is Atlas Copco Group

The year in review

Business areas
Compressor Technique

•  Vacuum Technique

Industrial Technique
Power Technique

Sustainability report
Risks, risk management  
and opportunities
The Atlas Copco AB share
Corporate governance
Board of Directors
Group Management
Internal control over  
reporting

Financials

Other information

THE YEAR IN REVIEW – VACUUM TECHNIQUE