www.AFPonline.org    ©2014 Association for Financial Professionals, Inc. All Rights Reserved 5

AFP GUIDE: Data Visualization: How to Tell Number Stories with Pictures AFP GUIDE: Data Visualization: How to Tell Number Stories with Pictures

them to be handled, and what is their geographical loca-
tion? “You have to be able to answer the broader ques-
tions so people can discover more about the problem,” 
he said. “It’s a sort of partnership with the user.”

“It’s also important to try to tie in predictive analyt-
ics,” continued Wills. “If something happens, what is 
the total amount of money you’re predicted to lose, and 
should you be concerned about the average amount or 
the big amounts that are the outliers? That’s the data you 
choose to highlight and the context for the analytics. 
The measure of value or success of a visualization project 
is whether it helped answer the questions.” 

In order to be able to tailor the image to the audience, 
“You have to be asking the right questions,” said Amanda 
Pype, user researcher at Tableau Software, a leading visualiza-
tion software provider. “What do they want to know? The 
most important thing is to understand the audience and 
what they’re trying to get out of the data.” Also, use charts 
that they can easily understand, she advised. “You don’t want 
to spend 10 minutes explaining the chart.”

One key concern is the reliability of the forecast, 
according to Andrew Mosely, director at Metapraxis, a 
London-based visualization vendor. “Across all indus-

tries, the most common business question is: how cred-
ible are the forecasts of our business units?’’ said Mosely. 
“And when a forecast appears either too optimistic or 
overly pessimistic, how can our FP&A team present the 
data visually to support their dialogue with the business? 
Every business needs to be on top of its numbers. The 
challenge is finding out as soon as possible if you’re not 
going to make that forecast rather than being presented 
with an impossible last-minute challenge. Having time 
to take action puts you back in control.”

Metapraxis’ software contains a calculation engine that 
creates statistical scenarios, which are then presented vi-
sually to show trends and variances. Alternative scenarios 
are automatically created, against which you can test the 
management forecast, according to Mosely. “We call this 
visualization the ‘Windsock’ chart” (see below).

The “Windsock” chart tracks the evolution of the 
subsidiary’s updated year-end forecasts throughout the fi-
nancial year, comparing them against the annual budget, 
prior year performance and a statistical risk range. The 
chart shows that the current management forecast for 
Net Sales is at the very top of the current risk range and 
may be too optimistic. 

Western Europe Net Sales Windsock