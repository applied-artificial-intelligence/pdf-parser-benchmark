2023 Highlights

Governance

Issued
first global Modern Slavery 
Statement

Top 5%
of companies within the 
manufacture of basic precious 
and other non-ferrous metals 
industry according to EcoVadis

18
locations certified to 
Aluminium Stewardship 
Initiative (ASI) Performance 
Standard

Implemented
a new Supplier Site 
Collaboration program

Conducted
a portfolio-wide assessment 
of physical and transition 
risks of climate change across 
Alcoa's operations

Reported
against ICMM’s Social 
and Economic Reporting 
Framework for the first time

Social

Zero
worker fatalities

Listed 
as one of America’s Greatest 
Workplaces in 2023 by 
Newsweek magazine

32.7% 
of total workforce is diverse 
employees

19.1% 
female workforce

85 scored 
on the Human Rights 
Campaign Foundation’s 
Corporate Equality Index

US$4.1M 
invested in skills 
development programs 
benefitting local communities

US$5.9M
invested in communities through Alcoa Foundation 
grants and corporate giving programs

Environment

2.2%
decrease in CO2e  
emissions year-over-year

15.5%
reduction since 2015 
of bauxite residue land 
requirements*

87% 
of electricity powering 
our smelters came from 
renewable sources

9.7%
increase in spent  
pot lining diverted 
for recovery

Disclosed
performance against the Global Industry Standard 
on Tailings Management (GISTM) for facilities with 
the highest potential consequences

*Per metric ton of alumina produced.

4Alcoa 2023 Sustainability Report