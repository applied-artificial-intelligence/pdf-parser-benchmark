Clean Energy Market Monitor – March 2024  

PAGE | 17  

Clean energy deployment 

IE
A.

 C
C

 B
Y 

4.
0.

 

Nuclear capacity additions and avoided emissions 

 
IEA 2024. CC BY 4.0. 

Notes: “Avoided emissions” refers to avoided emissions in one year from cumulative deployment since 2019 to 2023.  

5.5
6.0 5.6

7.9

5.5

 2

 4

 6

 8

2019 2020 2021 2022 2023

World

G
W

74

20

15

9

44

 40  80

China

Korea
United Arab

Emirates
European Union

Rest of world

Avoided emissions

Mt CO₂

2.8

2.3
2.4

2.3

1.2 1

 2

 3

2019 2020 2021 2022 2023

China

G
W

0 0 0 0

1.3

0.5

1.0

1.5

2019 2020 2021 2022 2023

United States

G
W

0.0 0.0 0.0

1.7

0.5

0.6

1.2

1.8

2019 2020 2021 2022 2023

European Union

G
W

1.4

0.0 0.0

1.4 1.4

0.5

1.0

1.5

2019 2020 2021 2022 2023

Korea
G

W