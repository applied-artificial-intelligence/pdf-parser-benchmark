Renewables 2025 Chapter 1. Renewable electricity 
Analysis and forecasts to 2030 
 

PAGE | 43  I E
A.

 C
C

 B
Y

 4
.0

. 

are forecast to outpace distributed systems in upcoming years. Solar PV capacity 
overtook wind in 2022, and by 2025 both utility-scale and distributed solar PV each 
individually match wind capacity. 

Hydropower has long been the largest renewable electricity source in Latin 
America, and it continues to be critical in many countries across the region. 
Although the regional outlook for hydropower remains similar to last year, some 
markets still hold significant untapped potential. Colombia, for instance, is set to 
lead in new hydropower capacity, largely owing to completion of the 2.4-GW 
Ituango project. However, further large-scale hydropower development remains 
challenging due to environmental, social and financial constraints in multiple 
countries. 

In recent years, solar PV has gained increasing importance in Latin America's 
energy transition. Throughout the 2020s, it has taken on a leading role, surpassing 
wind in capacity additions. It will be the primary driver of renewable energy growth, 
with utility-scale projects contributing 41% and distributed systems accounting for 
33% of new capacity in 2025-2030. 

Net renewable capacity additions by technology in Latin America and the Caribbean, 
2010-2030 

 
IEA. CC BY 4.0. 

 

Three countries are forecast to provide more than 80% of renewable capacity 
expansion in Latin America over the forecast period. Brazil leads regional 
expansion, installing about half of the new capacity, and Mexico and Chile each 
contribute roughly 15% to the region’s overall growth. 

Overall, the regional forecast has been revised down slightly (by 3%). While this 
revision is modest, it masks more significant shifts at the country and technology  
 
 

0

 5

 10

 15

 20

 25

2010 2011 2012 2013 2014 2015 2016 2017 2018 2019 2020 2021 2022 2023 2024 2025 2026 2027 2028 2029 2030

N
et

 a
dd

iti
on

s 
(G

W
)

Hydropower Bioenergy Wind Solar PV Other renewables