Energy Technology Perspectives 2024 Chapter 1: The state of manufacturing and trade 
  

PAGE | 48 I E
A.

 C
C

 B
Y 

4.
0.

 

 Production of selected clean energy technologies and materials relative to 
domestic demand by country/region, 2023 

  
IEA. CC BY 4.0. 

Notes: Battery cells are for both electric vehicles and stationary storage. Steel includes crude steel as well as semi-finished 
and finished products. 

China is a net exporter of key clean energy technologies, while the European Union and the 
United States rely heavily on imports to meet domestic demand. 

The resilience of clean energy technology supply chains can be jeopardised by 
strong reliance on a very limited number of component suppliers. For example, an 
explosion at a polysilicon facility in China in 2020 put 8% of global polysilicon 
production capacity out of operation (IEA, 2022b). This was the largest of four 
polysilicon plant closures in 2020, the others resulting from flooding or technical 
problems. While each incident occurred at a different time, together they led to an 
estimated 4% decline in annual production in an already-tight polysilicon market, 
contributing to the near tripling of prices between 2020 and 2021. Vertical 
integration of supply chains can, in principle, enhance the resilience of supply 
chains – China’s wind turbine manufacturers were more resilient to commodity 
price fluctuations in 2022 in part due to vertical integration – though it may lead to 
greater dependence on a small number of suppliers (IEA, 2023c). 

0%

50%

100%

150%

200%

Solar PV
modules

Wind nacelles Battery cells Electric cars ICE cars Heat pumps Electrolysers

0%

50%

100%

150%

Alumina Aluminium Iron Steel Ammonia Fertilisers

China European Union United States Local demand