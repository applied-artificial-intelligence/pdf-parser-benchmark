 33 

OECD EMPLOYMENT OUTLOOK 2024 © OECD 2024 
  

That being said, the data for the months since the end of Q4 2023 point to an improvement in annual 

real wage growth in four of the seven countries with available data. This is generally driven by a decline 

in inflation rather than an increase in nominal wage growth. 

Data from wages advertised in job postings on the online platform Indeed show improving or stable real 

wage growth in all countries with available data, except Spain and the United States (Figure 1.11). 

Consistently with the results above, where real wage growth is increasing, this is mainly driven by a fall 

in inflation rather than a significant up-tick in nominal wage growth. In fact, these data point to a 

decrease in nominal wage growth in five of the eight countries with available data (Canada, France, 

Germany, Spain, and the United States). 

Figure 1.11. Posted wages point to a recent slowdown in nominal wage growth 

Year-on-year percentage change, three-month moving averages, from December 2023 to May 2024 

 

Note: The posted wages are the average year-on-year percentage changes in wages and salaries advertised by job postings on Indeed. 

Source: Indeed Wage Tracker (https://github.com/hiring-lab/indeed-wage-tracker); OECD (2024), “Prices: Consumer prices”, Main 

Economic Indicators (database), https://doi.org/10.1787/0f2e8000-en (accessed on 25 June 2024). 

StatLink 2 https://stat.link/guxrfj 

 

Box 1.3. Year-on-year growth in real negotiated wages has improved and remained negative 
only in a few countries in early 2024 

Real growth in negotiated wages has improved over the course of 2023 and remained negative only in 

a few countries (Figure 1.12). In Q1 2024, negotiated wages were increasing in real terms on an annual 

basis in Austria, Canada, the Euro Area, Germany, Italy, the Netherlands, and the United States but 

continued to slightly decline in Australia and Sweden and stabilised, after one year of steady growth, in 

Belgium (Annex Figure 1.C.2). These developments reflect a combination of factors, including the 

staggered and infrequent nature of collective bargaining, the delay between the date of completion of 

negotiations and the effective revisions of pay, the infrequent use of automatic indexation to inflation, 

and the strength of workers’ bargaining power (Araki et al., 2023[11])). Overall, as more rounds of 

negotiation take place affecting an increasing number of workers, real growth in negotiated wages turns 

positive in more countries for some time, recovering some of the lost ground. 

0

1

2

3

4

5

6

7

8

D
ec

 2
02

3

M
ay

 2
02

4

D
ec

 2
02

3

M
ay

 2
02

4

D
ec

 2
02

3

M
ay

 2
02

4

D
ec

 2
02

3

M
ay

 2
02

4

D
ec

 2
02

3

M
ay

 2
02

4

D
ec

 2
02

3

M
ay

 2
02

4

D
ec

 2
02

3

M
ay

 2
02

4

D
ec

 2
02

3

M
ay

 2
02

4

Canada France Germany Ireland Netherlands Spain United
Kingdom

United
States

%

Posted wage growth Inflation

https://github.com/hiring-lab/indeed-wage-tracker
https://doi.org/10.1787/0f2e8000-en
https://stat.link/guxrfj