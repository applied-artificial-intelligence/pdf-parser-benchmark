16  D I G I T A L  P R O G R E S S  A N D  T R E N D S  R E P O R T  2 0 2 5  

Still, MICs show disproportionately high GenAI adoption relative to their economic size. The share 
of US traffic to ChatGPT plummeted from 70 percent to 25 percent within 1 month after its debut, 
but middle-income economies contributed more than 50 percent of global traffic only 6 months 
later (refer to figure 1.3). MICs have a disproportionately high adoption rate of GenAI relative 
to their GDP, electricity consumption, and search engine traffic, although low-income economies 
remain underrepresented, accounting for less than 1 percent of global ChatGPT traffic.

Robust digital infrastructure, specialization in digital services, higher human capital, and a large 
youth population are key factors driving higher GenAI adoption at the country level. Specifically, 
higher fixed broadband penetration, faster internet speed, a large share of white-collar workers, 
comparative advantage in digitally deliverable services, widespread English fluency and digital 
skills, and a higher share of youth population predict higher GenAI adoption when GDP per capita, 
population, and internet penetration are controlled for.

The demographics of GenAI users as captured by Semrush3 reveal a clear skew toward young, 
highly educated men. Women account for only one-third of ChatGPT users, a stark contrast to the 
more balanced gender splits seen on platforms such as Google (48 percent female) and Wikipedia 
(52 percent female). The most-active GenAI user group is those ages 18–24, particularly for video-
based GenAI tools. Nearly half of chatbot users hold a college degree, exceeding the educational 
attainment of Google’s user base.

This gender gap in GenAI usage is significantly more pronounced than the global gender divide 
in internet use overall. According to International Telecommunication Union data, 70 percent of 
men are internet users worldwide, compared with 65 percent of women. In HICs and UMICs, 
this gap has nearly closed, with 94 percent of men and 93 percent of women online in HICs and 
81 percent of men and 80 percent of women online in UMICs. Around 32 percent of US men use 

FIGURE 1 .3 ChatGPT and GenAI traffic over time, by income level and country

Country 

0 10 20 30 40 50 60

France

United Kingdom

Mexico

Germany

Canada

Philippines

Indonesia

Brazil

India

As a share of US value (percent)

b. GenAI tra�c and other indicators

GenAI tra�c Search engine tra�c Electricity consumption GDP

a. ChatGPT tra�c, by income group

0

20

40

60

80

100

November 1,
2022

June 1,
2023

January 1,
2024

August 1,
2024

March 1,
2025

Percent

Date
LICsLMICsUMICsHICs

Sources: Liu, Huang, and Wang 2025; Liu and Wang 2024.
Note: GDP = gross domestic product; GenAI = generative artificial intelligence; GPT = general-purpose technology; HIC = high-income countries; 
LICs = low-income countries; LMICs = lower-middle-income countries; US = United States.