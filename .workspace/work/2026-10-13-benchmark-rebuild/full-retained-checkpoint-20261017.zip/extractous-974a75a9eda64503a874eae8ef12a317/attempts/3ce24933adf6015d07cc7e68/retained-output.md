MR LEE YI SHYAN
CHAIRMAN AND  
NON-INDEPENDENT  
NON-EXECUTIVE DIRECTOR 

Date of first appointment  
as a Director:
17 September 2019

Length of service as a Director  
(as of 31 December 2023):
4 years 3 months

Board Committee(s) served on:
• Nil

Academic & Professional 
Qualification(s):
• Bachelor of Engineering 

(Chemical), National 
University of Singapore

• Program for Management 
Development, Harvard 
Business School

• Tsinghua University 
Management Program

Present directorships  
(as of 1 January 2024):
Listed companies
• OUE Healthcare Limited 

(formerly known as OUE 
Lippo Healthcare Limited)

Other principal directorships
• Business China 

(Chairman)
• ICE Futures Singapore 

Pte. Ltd. (Chairman)
• Sino-Singapore Tianjin 

Eco-City Investment and 
Development Co., Ltd. 

• SPH Media Holdings  
Pte. Ltd. 

Major Appointments  
(other than directorships):
• OUE Limited (Executive 

Advisor to the Chairman)
• Keppel Corporation 

Limited (Advisor)
• Chinese Development 

Assistance Council 
(Member of the Board  
of Trustees)

Past Principal Directorships 
held over the preceding  
5 years (from 1 January 2019 
to 31 December 2023):
• OUE Hospitality REIT 

Management Pte. Ltd. 
(dissolved through a 
member’s voluntary 
winding up)

Others:
• Member of Parliament 

of Singapore, East Coast 
GRC (2006 - 2020)

• Senior Minister of State 
and Minister of State 
of several Government 
Ministries (from 2006  
to 2015) 

MR LIU CHEE MING
LEAD INDEPENDENT 
DIRECTOR

Date of first appointment  
as a Director:
17 September 2019

Length of service as a Director 
(as of 31 December 2023):
4 years 3 months

Board Committee(s) served on:
• Audit and Risk Committee 

(Member)

Academic & Professional 
Qualification(s):
• Bachelor of Business 

Administration, the former 
University of Singapore

Present directorships  
(as of 1 January 2024):
Listed companies
• GDS Holdings Limited  

(listed on The Stock Exchange 
of Hong Kong Limited and  
the Nasdaq Global Market  
in the United States)

• MGM China Holdings Limited 
(listed on The Stock Exchange 
of Hong Kong Limited)

Other principal directorships
• Platinum Holdings 

Company Limited
• The Singapore 

International School 
Foundation Limited

• Singapore Technologies 
Telemedia Pte Limited

• Constellar Holdings  
Pte. Ltd. 

• STT Communication 
Limited

• DBS Bank (Hong Kong) 
Limited

Major Appointments  
(other than directorships):
• Managing Director 

of Platinum Holdings 
Company Limited

• Singapore International 
School (Hong Kong) 
(Chairman of the Board  
of Governors)

Past Principal Directorships  
held over the preceding  
5 years (from 1 January 2019  
to 31 December 2023):
• Haitong Securities Co., 

Ltd (listed on The Stock 
Exchange of Hong Kong 
Limited and Shanghai  
Stock Exchange)

• OUE Hospitality REIT 
Management Pte. Ltd. 
(dissolved through a 
member’s voluntary  
winding up)

Others:
• Member of the Takeovers 

Appeal Committee under  
the Hong Kong Securities 
and Futures Commission 
(from May 1995 to  
March 2020)

• Deputy Chairman of the 
Takeovers and Mergers 
Panel (from April 2008  
to March 2020)

BOARD OF 
DIRECTORS

OUE REIT20