/ /

15

2018 2019 2020 2021 2022 2023201720162015 2024

100 97 99 96 94 93 93 97 100

100
118 129

140 141

166
183

194

129
151

174
191

99

195

198

129122115

114100

108

Evolution of the workforce, revenue and productivity 
(measured as revenue per employee) (2015= base of 100)

Source: AEC (Spanish Association of Consulting Firms)

2018 2020 20222016 20242015 2017 2019 2021 2023

3.2%

3.5%
3.6%

2.5%
2.0%

2.7% 2.5%

3.1%

2.3%

2.6%

5.3%
4.0%

-2.1%

2.5%
3.9%

4.4%

3.9%

3.5%

2.3%

9.4%

3.4%

8.9%

0.7%

11.9%

8.6%

6.3%
8.5%

3.4%

14.1%

0.4%

Workforce growth rate at Spanish consulting firms, of third-party employees 
in Spain and of employment in knowledge-intensive jobs in Spain (2015-2024)

Sources: Spanish consulting firm workforce: AEC (Spanish Association of Consulting Firms); third-
party employees registered with the Spanish Social Security system in Spain: Spanish Ministry of 
Labor and Social Economy Statistics Annual; knowledge-intensive employment: Eurostat.

Methodological change.

Consulting firm 
workforce

Third-party employees registered with 
the Spanish Social Security system

Knowledge-intensive 
employment

Revenue Productivity (revenue per employee)Workforce


	Botón 16: 
	Página 5: 
	Página 7: 
	Página 11: 
	Página 13: 
	Página 15: 
	Página 17: 
	Página 19: 
	Página 21: 
	Página 25: 
	Página 27: 
	Página 29: 
	Página 31: 
	Página 33: 
	Página 35: 
	Página 37: 
	Página 39: 

	  2: 
	Página 5: 
	Página 7: 
	Página 11: 
	Página 13: 
	Página 15: 
	Página 17: 
	Página 19: 
	Página 21: 
	Página 25: 
	Página 27: 
	Página 29: 
	Página 31: 
	Página 33: 
	Página 35: 
	Página 37: 
	Página 39: 

	Botón 17: 
	Página 5: 
	Página 7: 
	Página 11: 
	Página 13: 
	Página 15: 
	Página 17: 
	Página 19: 
	Página 21: 
	Página 25: 
	Página 27: 
	Página 29: 
	Página 31: 
	Página 33: 
	Página 35: 
	Página 37: 
	Página 39: