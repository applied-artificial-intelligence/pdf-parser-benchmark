Launched India's first PS 
foam extrusion line and 
vacuum forming machine 
and exported to Ghana

Developed Asia's first ever 
four extruder five layer 
barr ier sheet extrus ion 
system with Unitilt polishing 
roll stack assembly

Developed World's first ever 
four extruder five layer blown 
fi lm and sheet extrusion 
system for Laboratory of 
Reliance industries

L a u n c h e d 
Asia's first ever 
WPC line with 
70% sawdust 
processibility

Introduced PENTAFOIL 
five layer POD blown 
film line to re-define 
application segments 
and demonstrated 
live @ K-2016

L a u n c h  a  s k i l l 
development hub Rajoo 
Innovation Centre for the 
plastics extrusion industry 
(a first in Asia)

Launched HEPTAFOIL 
Seven Layer Co-extruded 
Blown Film Line in Plast 
I n d i a - 2 0 1 8  a n d 
demonstrated through 
Virtual Reality(VR)

Launched tilting 
m o u l d 
Thermoforming 
with stacking, 
counting and 
p a c k i n g 
s o l u t i o n , 
c h r i s t e n e d 
DISPOTILT

2008 2009 2010 2011 2012 2014 2015 2016 20182013

Va c u u m  f o r m i n g  
machine with mould : 
model RECR 7086 XPS 
received and award 
M a c h i n e r y  f o r  
packaging operations 
f rom IPMMI IMDIR 
2009.

Supplied Asia's First CE 
Compliance 7 Layer 
Fully Automatic Blown 
Film Line to Turkey

Developed Asia's 
first ever 65mm 
sheetline extruder 
for 180kg/hr output

La u n c h e d  D r i p 
irrigation pipe plant 
for round dripper, 
christened DRIPEX

Launched and 
displayed first ever 
fu l ly  automat ic 
H y b r i d  5  l a y e r 
blown f i lm and 
d i s p l a y e d  a t 
Pastindia La u n c h e d  D r i p 

irrigation pipe plant 
for flat dripper and 
became India 's 
largest supplier

Developed India's 
f i r s t  ever  PP  non 
woven fabric making 
machine christened 
FABREX

Wonderpack Merger 
: A Unified Approach 
for the benefit of the 
t h e r m o f o r m i n g 
Industry

Rajoo Engineers JV 
with Bausano of Italy 
:  p l a s t i c  p i p e 
m a n u f a c t u r i n g 
industry

Deve loped  CSD 
(Cylindrical Spiral 
Die) die head with 
r h e o l o g i c a l l y 
optimized melt flow 
path for blown film 
line

Developed Asia's first 
ever smallest 5 layer 
sheet line, displayed 
a t  K ,  Ge rmany  & 
awarded by IPMMI

Our Mentor Mr. C. N. 
Doshi awarded With 
Life time Achievement 
Award in recognition of 
his contribution to the 
innovation in plastics 
processing machinery 
segment and to the 
global plastic fraternity

L a u n c h e d  L A M E X 
Extrusion Coating & 
Lamination Line to meet 
the needs of the flexible 
packaging industry

Developed world's 
first smallest 3 layer 
b lown f i lm l ine, 
christened LABEX

India's first ever live 
demonst rat ions of 
cPVC Twin screw pipe 
plant with 250 kg/hr 
h a v i n g  p i p e  O D 
ranging from 250 - 
500mm, christened 
FLOWEX

L a u n c h e d  T w o 
extruder three layer 
blown film line to 
m e e t  h i g h l y 
competitive market 
of  bag making, 
c h r i s t e n e d 
MULTIFOILLiteLite

Launched Asia's 
f i r s t  e v e r  m o s t 
h i g h e s t  o u t p u t 
sheet  ex t ru s ion 
system amongst its 
class of l ines & 
d i s p l a y i n g  a t 
PlastIndia

Developed Asia's 
f i r s t  e v e r  a n d 
Rajoo's 21st five 
layer blown film line 
with elevated air 
ring and displaying 
at PlastIndia

9 th
38  ANNUAL REPORT : 2024-2025 www.rajoo.com

3
8
 Y

EA
R
S 

O
F 

LE
A

D
ER

SH
IP