20

2025 Global Automotive Consumer Study | Key Findings: Global Focus Markets

Consumers surveyed in both India and the United Kingdom are more concerned with the idea of an 
autonomous vehicle fleet when compared to surveyed consumers in Germany, Japan, or China. 

36%

41%

43%

44%

48%

52%

52%

63%

Germany

Japan

China

Rep. of Korea

Southeast Asia

US

UK

India

47%

51%

52%

64%

64%

65%

67%

74%

China

Germany

Japan

US

Southeast Asia

Rep. of Korea

UK

India

Q56. To what extent are you concerned with each of the following scenarios?
Sample size: n = 939 [China]; 1,306 [Germany]; 882 [India]; 637 [Japan]; 906 [Republic of Korea]; 5,028 [Southeast Asia]; 1,314 [UK]; 937 [US]

More than three quarters of surveyed consumers in India and China believe the addition of artificial  
intelligence in vehicle systems is beneficial. On the other hand, a quarter of surveyed consumers in  
Germany, the United States, and the United Kingdom remain skeptical about the technology.

Addition of artificial intelligence in vehicle systems

Note: Percentages may not add up to 100 due to rounding. 
Q62. To what extent do you think the addition of artificial intelligence in vehicle systems (e.g., voice activated features, autonomous driving) will be beneficial?
Sample size: n = 939 [China]; 1,306 [Germany]; 882 [India]; 637 [Japan]; 906 [Republic of Korea]; 5,028 [Southeast Asia]; 1,314 [UK]; 937 [US]

25%

21%

26%

26%

11%

6%

5%

5%

34%

37%

31%

29%

27%

22%

18%

13%

41%

42%

43%

45%

62%

72%

77%

82%

Germany

Japan

UK

US

Rep. of Korea

Southeast Asia

China

India

Not benefical Neutral Beneficial

Percentage of consumers concerned about fully autonomous 
robotaxi services operating where they live

Percentage of consumers concerned about commercial vehicles 
operating in a fully autonomous mode on the highway