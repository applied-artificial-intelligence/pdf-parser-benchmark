Employment and Social Developments in Europe 2024 

68 

Coefficient of variation adjusts standard deviation by developments in outcome mean over time and is therefore 
insensitive to level changes (e.g., a 50% increase in GDP per capita in all countries considered would not change 
the value of coefficient of variation). It measures variation relative to the mean rather than in absolute terms. 

Catching-up of worse performing Member States or regions (Beta convergence) 

Beta convergence assesses whether countries or regions that start with worse outcomes improve faster over 
time than those starting with better outcomes. Where this is the case, Member States or regions are considered 
converging. Conversely, if countries or regions with better initial outcomes improve faster than others over time, 
this signifies divergence.  

Beta convergence is estimated via a logarithmic regression model, which regresses the growth of an indicator 
over a certain period of time on its initial value. The specification of this model is as follows, 

ln�∆𝑦𝑦𝑖𝑖 ,𝑡𝑡� = 𝛼𝛼 + 𝛽𝛽 ln�𝑦𝑦𝑖𝑖,𝑡𝑡−1� + 𝜀𝜀𝑖𝑖,𝑡𝑡 

where yi,t is the indicator value in country i at a time t, Δyi,t is the growth rate of this indicator at time t, α and β 
are coefficients to be estimated and εi,t is the error term. 

Beta convergence exists if the estimated regression coefficient β is statistically significant and negative, i.e. if 
countries that performed worse at the start of the period of interest improved faster than those that started in 
better positions. In this report, whenever beta convergence is analysed, it is referred to as catching-up. 

Direction of convergence 

The report also considers the overall direction of convergence patterns: where convergence is accompanied by 
improvements in mean EU outcomes (increase in the mean for a maximisation indicator, such as employment 
rate, or decrease for a minimisation indicator, such as AROPE), this is defined as upward convergence. Where 
mean EU outcome deteriorates (decrease in the mean for a maximisation indicator and increase for a 
minimisation indicator), this is considered downward convergence. From an EU policy-making perspective, it is 
important to achieve upward convergence, i.e., improvement in average outcomes at EU level accompanied by 
reduced geographical disparities: 

A2.2. REGIONAL CONVERGENCE 
 

Chart A2.1 

Convergence patterns of economic gains differed across NUTS2 regions 
GDP per capita in EUR and their cross-regional variation (measured by standard deviation and coefficient of variation, hence adjusted by average EU GDP), EU-NUTS2 

            

Note: Standard deviation is a measure of cross-regional variation, the higher the standard deviation, the higher the cross-regional variation. The EU average levels are unweighted values 
representing an average NUTS2 region 

Source: DG EMPL calculations based on Eurostat dataset nama_10r_2gdp 

Click here to download chart. 

 
 

0

10

20

30

40

50

60

70

80

0

5000

10000

15000

20000

25000

30000

35000

40000

2007 2009 2011 2013 2015 2017 2019 2021

Average (left axis) Standard deviation (left axis)
Coeff of variation (right axis)

https://ec.europa.eu/employment_social/empl_portal/publications/Esde2024/xls/Chap2/Chap2-Chart-A2.1.xlsx