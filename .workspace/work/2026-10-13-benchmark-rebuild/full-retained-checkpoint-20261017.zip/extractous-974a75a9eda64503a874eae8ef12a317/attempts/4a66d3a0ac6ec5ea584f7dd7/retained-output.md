X  Figure 2.1. Annual average economic growth measured as GDP in constant 2015 prices, 
2006–24 (percentage)

Source: IMF 2024b.

-0.4

-6

-4

-2

0

2

4

6

8

10

Re
al

 G
D

P 
gr

ow
th

 (%
)

2006
2007

2008
2009

2010
2011

2012
2013

2014
2015

2016
2017

2018
2019

2020
2021

2022
2023

2024

World Advanced economies Emerging and developing economies

5.3 5.3

2.9

5.2

4.0
3.3 3.4 3.5 3.4 3.3

3.8 3.6
2.9

6.6

3.6 3.3 3.2

7.8 8.1

5.6

2.5

7.2

6.1
5.2

4.9 4.7
4.3 4.4

4.8 4.7
3.7

-1.8

7.0

4.0 4.4 4.2

3.1
2.8

0.3

-3.4

3.1

1.8
1.2 1.5

2.1 2.4
1.8

2.6 2.3
1.9

-4.0

6.0

2.9

1.7 1.8

-2.7

economies, government gross debt in emerg-
ing and developing economies has continued 
to increase in recent years, going from 65 per 
cent in 2020 to 70 per cent in 2024.

The difficulty seen among emerging and 
developing economies to revert to pre- 
pandemic levels of public debt reflects their 
limited fiscal leeway, and the further increase 
in gross government debt in recent years 
can be partially attributed to the rise in debt- 
service costs due to historically high interest 
rates and a strong US dollar (IMF 2023). For 
many developing countries, higher interest 
rates in advanced economies also translated 
into capital outflows, which led to a depletion 
of foreign exchange reserves and higher bor-
rowing costs.

 ▶2.3.  
Inflation rates
Particularly relevant to the real value of wages 
has been the acceleration of inflation rates, 
which peaked in 2022 when they reached 
8.6 per cent globally, 7.3 per cent in advanced 
economies and 9.6 per cent in emerging and 
developing economies.

Since then, global inflation has decreased 
from its peak, going from 8.6 per cent in 
2022 to 6.7 in 2023, and is predicted to reach 
5.8 per cent in 2024 (figure 2.3). However, the 
moderation of inflation is set to happen at 
different speeds across the globe. Projections 
indicate that in 2024 a decline is set to hap-
pen in advanced economies, where inflation 
is estimated at 2.6 per cent, while emerging 
economies will have to wait at least until 
2025 to see a marked slowdown in prices. 

 X  Figure 2.2. Government gross debt as a share of GDP, 2006–24 (percentage)

Source: IMF 2024b.

73 71

78

91

97
101

105 104 103 103 105 103 102 103

122

115
110 109 109

37 36 33
38 37 37 37 38 40

44
49 51 52

55

65 64 64
69 70

30

40

50

60

70

80

90

100

110

120

130

Sh
ar

e 
of

 G
D

P 
(%

)

2006
2007

2008
2009

2010
2011

2012
2013

2014
2015

2016
2017

2018
2019

2020
2021

2022
2023

2024

World Advanced economies Emerging and developing economies

7Global Wage Report 2024–25
2. The global economic and labour market context