Employment and Social Developments in Europe 2024 

78 

date, ten Member States (143) have reached the revised Barcelona participation target of 45% for this age group 
set at EU level, (144) while six countries recorded participation rates lower than 20% in 2022. (145) In the 
remaining Member States, between 20% and 45% of children participated in ECEC. The overall level of disparity 
between countries grew somewhat since 2014, despite evidence that some Member States with low participation 
rates caught up with others. (146) Low levels of participation in ECEC for some Member States call for higher 
investment. Box 3.2 provides an estimate of future investment needs in the EU assuming constant level of 
spending per participating child.  
 

Chart 3.2 

Growing ECEC participation accompanied by convergence in attending preschool education 
Proportion of children participating in ECEC, by age group and variation across countries, 2014-2022, EU-27 

  

Note: Data missing for Italy in 2020. 

Source: DG EMPL calculations based on EU-SILC data [datasets ilc_caindformal (for 2014) and ilc_caindform25 (from 2015 onwards)]. 

Click here to download chart. 

 
Young children from disadvantaged backgrounds are less likely to participate in ECEC, especially in 
some Member States. (147) In 2022, children facing different types of disadvantage (monetary poverty, 
material deprivation, low work intensity) had participation rates at least 10 pp lower than those from non-
disadvantaged backgrounds, regardless of the type of disadvantage (Chart 3.3). (148) However, this gap varied 
between Member States, with children at risk of poverty or social exclusion participating considerably less often 
(by more than 20 pp) in some Member States, (149) and at a similar rate or more often than those not at risk in 
others. (150) On average across all Member States, children who can benefit most from attending ECEC tend to 
participate least. (151) 

 
(143) Belgium, Denmark, Spain, France, Luxembourg, Malta, the Netherlands, Portugal, Slovenia, Sweden. 
(144) Specific targets apply to Member States that have not reached the 2002 Barcelona target of 33% participation for this age group. 
(145) Bulgaria, Czechia, Lithuania, Poland, Romania, Slovakia. 
(146) Beta coefficient is negative (-0.03) and statistically significant at 10% significance level. 
(147) (Employment Committee and Social Protection Committee, 2023). 
(148) Data for 2023 was not available at the time of writing. For analysis of earlier periods, see (European Commission, 2019b). 
(149) Belgium, France, Italy, the Netherlands, Spain. 
(150) Bulgaria, Denmark, Croatia, Hungary, Austria, Romania. 
(151) Convergence analysis cannot be carried out due to data limitations. 

25

30

35

40

45

a) Participation (0 to 2 years)

80

85

90

95

100

b) Participation (3 to CSA)

0

5

10

15

20

25

c) Cross-country variation

0 to 2 years 3 to CSA

https://ec.europa.eu/employment_social/empl_portal/publications/Esde2024/xls/Chap3/Chap3-Chart-3.2.xlsx