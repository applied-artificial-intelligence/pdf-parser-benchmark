 101 

OECD EMPLOYMENT OUTLOOK 2024 © OECD 2024 
  

Figure 2.13. Many low-skilled, green-driven occupations have worse labour market security than 
other low-skill occupations 

Marginal effect of labour market insecurity indicators on the share of green-driven occupations, by type of 

occupation and controlling for main individual and job (or last job) characteristics, 2015-19 

 

Note: The chart reports the point estimate (and 95% confidence intervals) of the percentage difference in the incidence of each type of green-driven 
occupation between unemployed and employed workers. Unemployed workers are classified according to their last occupation. Estimates are 
obtained from a linear regression with the inverse hyperbolic sine of the share of each type of green-driven occupation within all, high, medium or 
low-skilled occupations as dependent variable and including an unemployment dummy, the share of 1-digit ISCO occupations, educational 
attainment (3 classes), gender, age (3 classes), sectors (5 categories), time and country dummies as explanatory variables. Except for the case of 
all occupations, regressions are estimated separately for high, medium, and low-skill occupations. “Total” indicates the full sample with all 
occupations. Standard errors are clustered on the dimensions of variability of the dependent variable. The reported point estimates and confidence 
intervals refer to the estimated coefficient of the unemployment dummy and are expressed in percentage of the untransformed dependent variable. 
The sample excludes Agriculture and includes Austria, Belgium, Czechia, Denmark, Estonia, Finland, France, Germany, Greece, Hungary, Ireland, 
Italy, Latvia, Lithuania, Poland, Portugal, the Slovak Republic, Spain, Sweden, Switzerland, the United Kingdom and the United States. Unemployed 
workers with an unemployment spell equal to or longer than 7 years are excluded in all countries except in the United States. 
Reading: Controlling for demographic characteristics and job characteristics and restricting the sample to high-skill occupations, the percentage 
share of high-skill, green new and emerging occupations is, on average, 2.8% lower among the employed than among the unemployed (where 
data for the unemployed refer to the occupation in the last held job), although the difference is not statistically significant. A lower incidence of a 
given type of occupation among the employed than among the unemployed is indicative of lower labour market security for that type of occupation 
than for the other occupations included in the regression. 
Source: Secretariat’s estimates based on version 24.1 of the O*NET database and the Current Population Survey, for the United States and the 
EU Labour Force Surveys, for all other countries. 

StatLink 2 https://stat.link/yd270q 

One factor that may explain the divergent patterns of labour market security among different types of green-

driven occupations is the different incidence of fixed-term contracts. The evidence indeed suggests that, 

on average, fixed-term contracts are often associated with lower labour market security, and in particular 

a higher risk of job loss – see e.g. OECD (2014[15]).51 Consistent with this hypothesis, the labour market 

insecurity pattern concerning low-skill occupations presented in Figure 2.13 is mirrored by similar results 

as regards the type of contract. Within low-skill occupations, fixed-term contracts are, on average, more 

frequent among green increased demand and new and emerging occupations (by 24% and 26%, 

respectively), while the opposite is true for green-enhanced skills occupations (see Figure 2.14). By 

contrast, the patterns depicted in Figure 2.13 and Figure 2.14 diverge as regards high-skill occupations. 

Whatever their type, high-skill, green-driven occupations are systematically less frequent among 

employees with fixed-term contracts but no less frequent among the unemployed than other high-skill 

occupations, suggesting that contract type is not the main driver of labour market security in these high-

skill occupations. In other words, these results suggest that the typical worker in high-skill, green-driven 

occupations is more likely to hold an open-ended contract than workers in other high-skill occupations, and 

nevertheless has often no better labour market security.52 

-25

-15

-5

5

15

25

35

45

Total High-skill Medium-skill Low-skill Total High-skill Medium-skill Low-skill Total High-skill Medium-skill Low-skill

Green new and emerging occupations Green-enhanced skills occupations Green increased demand occupations

%

https://stat.link/yd270q