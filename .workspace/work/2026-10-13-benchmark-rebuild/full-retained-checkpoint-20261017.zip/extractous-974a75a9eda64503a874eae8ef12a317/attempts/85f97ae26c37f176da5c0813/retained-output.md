BIS Quarterly Review, December 2012 33
 

to other bonds, the possibility of total loss is part of the arrangement from 
inception, and is compensated ex ante by a higher coupon. 

Despite experts’ high expectations, the catastrophe bond market has remained 
relatively small. Bond issuance has never exceeded $7 billion per year, limiting the 
outstanding capital at risk to $14 billion (Graph 8). Very few catastrophe bonds have 
been triggered to date. The 2005 Gulf Coast hurricanes activated payouts from only 
one of nine catastrophe bonds outstanding at the time (IAIS (2009)). Likewise, the 
2011 Japan earthquake and tsunami triggered one known catastrophe bond, 
resulting in a payout of less than $300 million. Payouts to reinsurers from these 
bonds are small when compared to the sum of insured losses ($116 billion in 2005 
and $110 billion in 2011).  

The global financial crisis has also dealt a blow to this market. The year 2008 
saw a rapid decline in catastrophe bond issuance, reflecting generalised funding 
pressure and investor concern over the vulnerability of insurance entities. The crisis 
also demonstrated that securitisation structures introduce additional risk through 
linkages between financial entities. A case in point was the Lehman Brothers 
bankruptcy in September 2008. Four catastrophe bonds were impaired – not due to 
natural catastrophes, but because they included a total return swap with Lehman 
Brothers acting as a counterparty. Following Lehman’s failure, these securitisation 
arrangements were no longer fully funded, and their market value plunged. 
Investors thus learned that catastrophe bonds are not immune to “unnatural” 
disasters such as major institutional failures.13 

A further set of financial linkages arises with other financial institutions through 
cross-holdings of debt and equity. Insurance companies hold large positions in 
fixed income instruments, including bank bonds. At the same time, other financial 
entities own bonds and stocks in insurance companies. For instance, the two largest 
reinsurance companies stated in their latest (2011) annual reports that Warren 

 
13  Following this episode, sponsors of catastrophe bonds employed other types of collateral 

arrangements in lieu of total return swaps. There has recently been a shift towards the use of 
government bonds as collateral. 

Catastrophe bond issuance by type of risk1 Graph 8

USD bn

1  Data before 2003 are not broken down by type.    2  Includes mortality, peril, life and worldwide risks.    3  Values are year-to-date, thus 
the value for 2012 is not final. 

Sources: Artemis; Guy Carpenter.  

0

3

6

9

12

96 97 98 99 00 01 02 03 04 05 06 07 08 09 10 11 12

Earthquake
Weather

Weather/earthquake
Weather/mortality

Life and other2 Risk capital outstanding at year-end3