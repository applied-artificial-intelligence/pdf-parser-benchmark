13 

 
 
 
 
 

 
 

Figure 5. Public expenditure on education as a share of total public expenditure and of GDP in the 
EU-27 (2007-2023) 

 

Source:  Eurostat COFOG data. Online data code: [gov_10a_exp]. 

Since 2020, public expenditure on education increased considerably in the EU in nominal terms, but 
not after accounting for increases in price levels. Figure 6 shows that between 2007 (the last year before 
the Great Recession) and 2023, nominal (i.e. at current prices) public expenditure on education in the EU rose 
by almost 60%, recording an increase in all years but 2012. Around half of this rise took place after 2020, 
mostly due to increasing price levels. Real (i.e. at constant prices) 6 expenditure grew by around 15% over 2007-
2023, although with year-on-year declines in 2011, 2012, 2020 and 2022.7  

Education still takes up a smaller proportion of total public expenditure than it did before the 
Covid-19 pandemic. Figure 7 explains how the structure of total public expenditure changed between 2019 
and 2023. ‘Economic affairs’ jumped by 1.7 percentage points. The government measures to mitigate the 
economic impact of the Covid-19 pandemic (e.g. subsidies to support various productive sectors affected by 
Covid-related restrictions) caused the strong increases observed in 2020 and 2021. In 2022 and 2023, the 
financial impact of those measures was significantly reduced, but new measures to mitigate the impact of 
rising energy prices on productive sectors partly compensated that decrease (European Commission, 2025c). 
Among other larger expenditure functions,8 only ‘Health’ increased its share during the pandemic, because of 
the response to new public health needs, but then it reverted to pre-crisis values (European Commission, 2025d). 
Most other spending areas saw a decrease, and education is still 0.4 percentage points below its 2019 level. 

  

 
6  This report uses the price deflator for collective consumption expenditure of general government to convert public 

expenditure on education from current prices to 2015 constant prices. 
7  The average yearly increase in public expenditure on education in the EU between 2007 and 2023 was 2.9% in nominal 

terms and 0.9% in real terms.  
8  The increase in ‘Housing and community amenities’ from 1.2% of total public expenditure in 2019 to 2.4% in 2023 

mostly depends on capital transfers recorded for payable tax credits in Italy (European Commission, 2025e). 

https://ec.europa.eu/eurostat/databrowser/view/gov_10a_exp__custom_16025691/default/table?lang=en