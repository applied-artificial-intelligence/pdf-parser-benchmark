Compressor Technique
The overall demand for the business area’s equipment and services remained basically unchanged. A weaker 
order intake for equipment was compensated by a solid order development for the service business. The 
business area continued investing in product development, digital capabilities, and market presence, and  
a new division was created. In addition, 17 acquisitions were closed during the year.

Market development
The overall demand for equipment and service 
remained basically unchanged, with a slightly 
better development of the order intake in the first 
half of the year than in the latter part. In total, the 
order intake increased by 2% organically. 

Solid order growth was achieved for the service 
business in all regions. The order growth was 
driven by increased demand for spare parts, main­
tenance, repair services, and service contracts, 
which were supported by a rise in the number of 
connected products and a larger installed base in 
the market.

The order intake for equipment remained 
largely unchanged, with increased demand in 
Africa/Middle East and South America, while the 
demand in Asia, Europe, and North America 
weakened.

Orders for industrial compressors remained 
essentially unchanged, with a slightly better 
development for small and medium­sized com­
pressors than larger industrial compressors. The 
demand for gas and process compressors was 
solid, but the order intake did not fully reach the 
previous year’s high level. Order volumes 
decreased in all regions except Africa/Middle 
East, where orders increased significantly.

Market presence and organizational 
development
The business area continued to invest in innova­
tion during the year with increased investments 
in research and development. Several new inno­
vative products were introduced to the market. 
The product portfolio was expanded, particularly 
for applications related to compression of gases.  
By maintaining a focus on connected products 

Sales bridge Orders received Revenues

2023, MSEK 79 492 75 552
Structural change, % +1 +1

Currency, % –2 –2

Organic*, % +2 +5

Total, % +1 +4
2024, MSEK 79 976 78 259

* Volume, price and mix

Revenues, MSEK 
2023: 75 552 78 259
Operating profit margin
2023: 24.5% 25.2%
Return on capital employed
2023: 85% 85%

and data analytics, the business area enhanced 
its ability to assist customers with service.

Investments were also made to increase mar­
ket presence by adding more salespeople to the 
organization. The business area also strength­
ened its online market presence, resulting in an 
increase in digital sales leads. 

Multiple activities were conducted to enhance 
the business area’s digital capabilities and seize 
opportunities by leveraging AI (artificial intelli­
gence) across various domains, including R&D, 
finance, customer interaction, and order  
management, to mention a few. 

Throughout the year, the business area contin­
ued to support customers in their sustainability 
ambitions. In addition to developing and deliver­
ing a range of new energy­efficient products,  
the business area also established a dedicated 
organization focused specifically on helping cus­
tomers optimizing the energy efficiency of their 
existing compressor rooms.

To further strengthen its focus on growth, 
emphasizing an application­driven approach  
to meet customers’ needs, a new division was 
created, the Air and Gas Applications division. 

The business area continued to invest in its 
operational footprint during the year. Major 
investments were made in a production and  
R&D facility in Wuxi, China, a production and  
R&D facility in Talegaon, India, a compressor  
production facility in Istanbul, Türkiye, and in a  
service center for gas and process compressors 
in Houston, USA.

The business area also increased its presence 
in targeted markets and customer segments 
through a large number of acquisitions, see the 
following section.

The business area closed in total  
17 acquisitions in 2024:  
• Hycomp Inc.
• Ace Air (NI) Ltd.
• Druckluft­Technik­Nord GmbH
• Pacific Sales & Service, Inc.
• Zahroof Valves Inc.
• Tecturbo
• Baraghini Compressori S.r.l.
• AE Industrial Ltd.
• Emcovele S.A.
• Kingsdown Compressed Air Systems Ltd.
• Compressed Air Technologies, Inc.
• Danmil A/S
• Easy Filtration S.r.l.
• Arlógica Máquinas e Equipamentos, Lda
• Pennine Pneumatic Services Ltd.
• SCS Makina A.Ş
• Metalplan Equipamentos LTDA

For more information see page 110 or
www.atlascopcogroup.com.

Revenues, profits and returns
Revenues reached MSEK 78 259 (75 552), an 
organic increase of 5%. The operating profit 
increased by 7% to MSEK 19 716 (18 488), corre­
sponding to a margin of 25.2% (24.5). The mar­
gin was positively affected by currency and by 
the combination of volume, price and mix, while 
acquisitions had a negative effect on the operat­
ing margin. Return on capital employed was 
85% (85). 

0

20 000

40 000

60 000

80 000

20242023202220212020
0

10

20

30

40
MSEK %

Orders received, revenues and operating margin

Orders  
received

Revenues

Operating  
margin

Atlas Copco Group 2024   20

Introduction

This is Atlas Copco Group

The year in review

Business areas
•  Compressor Technique

Vacuum Technique
Industrial Technique
Power Technique

Sustainability report
Risks, risk management  
and opportunities
The Atlas Copco AB share
Corporate governance
Board of Directors
Group Management
Internal control over  
reporting

Financials

Other information

THE YEAR IN REVIEW – COMPRESSOR TECHNIQUE