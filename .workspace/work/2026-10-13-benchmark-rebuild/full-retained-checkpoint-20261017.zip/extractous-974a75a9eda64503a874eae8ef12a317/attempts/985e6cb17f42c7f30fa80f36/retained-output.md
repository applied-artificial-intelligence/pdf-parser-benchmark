PERCEPTIONS OF NEWS OUTLET POLARISATION

To complement our data on news audience behaviour, we also asked 
a new question this year on the extent to which people perceive 
the news landscape in their country to be polarised. Perceived 
polarisation is an established concept in political science, referring 
to the extent to which people believe political groups or parties to 
be different from one another – regardless of the actual similarities 
or differences in their policies. As such, we asked respondents: ‘In 
your view, how politically close together or far apart are the main 
news organisations in your country?’ with response options ranging 
from ‘Very far apart’ to ‘Very close together’. It is important to keep in 
mind that polarisation (which is normally seen as bad) shares some 
qualities (e.g., absence of homogeneity) with concepts like diversity 
and plurality (which are normally thought of as good). However, 
given that these typically refer to the extent to which all views are 
represented equally rather than the distance between groups, the 
question wording gets us closer to polarisation.

Perceived news outlet polarisation is highest in Poland (54%), 
Spain (49%), Thailand (48%), and Argentina (47%) where around 
half think that the main news organisations are politically quite far 
apart or very far apart. The lowest figures are in South Korea (15%), 
Portugal (16%), and Singapore (16%). At the regional level, perceived 
polarisation is, on average, lower in Northern Europe but higher in 
Southern Europe and Latin America. 

To some extent, these patterns map onto what we might expect 
based on rules about impartiality, levels of press freedom, and 
political parallelism – the degree to which the media outlets map 
onto political parties. And at least in the four countries we focus 
on in this chapter, levels of news audience polarisation match 
levels of perceived polarisation, with people in the UK and the US 
perceiving more polarisation than those in Germany and Norway. 
But there are also many reasons to expect people’s perceptions 
to diverge from our expectations. For example, we might infer 
from the hostile media phenomenon that people who believe 
the media to be biased against people like them might see news 
organisations as ‘all the same’ and thus close together – even if the 
media landscape itself is polarised. At the same time, people may 
believe there is more polarisation than there is because this is a 
narrative which has been reinforced by politicians and the media. 
In this sense, perceived polarisation is similar to trust in the news, 
whereby perceptions of trust and actual trustworthiness may be 
quite different, but people’s perceptions are nonetheless important 
to understand because they can have real consequences. 

CONCLUSIONS

In this chapter we have described how, perhaps contrary to 
expectations, news audience polarisation is often relatively low 
(especially outside of the USA), is broadly stable over time, and 
varies significantly by country. In many countries, new partisan/
alternative brands have entered the market, but because their 
audiences are typically small and because most people still gravitate 
towards established outlets, their influence on aggregate patterns 
of audience behaviour is minimal – and in some cases is offset by 
increasingly mixed/centrist audiences for larger brands. 

At the same time, we have seen how audiences for some individual 
outlets can change, even in a relatively short space of time. News 
organisations, many of which have become more audience-focused 
in recent years, may find it useful to monitor the changing left–
right profile of their audience, but this is just one of many possible 
dimensions along which they can map their users – both political 
and non-political. The challenge is identifying the most useful, and 
thinking through how audience profile relates to business and editorial 
strategy and the changing ways people arrive at and access news – and 
where this leaves them positioned in the national news landscape.

Stepping back, the overall picture we describe may offer some 
reassurance to those worried about the effects of digital media on 
society. But it is important to also keep in mind that, although patterns 
of audience behaviour may appear stable in the short term, the pattern 
over several decades may be very different. Furthermore, stability 
at the level of the mass public can also mask increasing polarisation 
among partisans. All this aside, even if audience behaviour changes 
little, news content from the same outlets may simultaneously be 
more partisan. And although smaller, more partisan outlets may have 
minimal direct reach, they may still exert indirect influence on political 
elites and media coverage. Audience behaviour certainly matters, but 
it is only one piece of a much larger puzzle.

REUTERS INSTITUTE FOR THE STUDY OF JOURNALISM / FURTHER ANALYSIS GRAPHS

Graph 11

PROPORTION WHO THINK NEWS ORGANISATIONS IN THEIR 
MARKET ARE POLITICALLY FAR APART – SELECTED MARKETS

Q_Polarisation. In your view, how politically close together or far apart are the main news 
organisations in your country? Base: Total sample in each market (n ≈ 2000).

0% 25% 50% 75% 100%

Thailand
Taiwan

Hong Kong
India

Philippines
Australia

Japan
Malaysia

Indonesia
Singapore

South Korea

Asia-
Pacific

48
38

36
33

32
29

26
23

18
16
15

Spain
Italy

Greece
Turkey

Croatia
Portugal

Southern 
Europe

49
42

39
38

22
16

Austria
Netherlands

France
Switzerland

Belgium
Germany

Western 
Europe

36
31
31

30
27

26

Poland 54
Hungary

Czech Republic
Slovakia

Romania
Bulgaria

Eastern 
Europe 44

28
27

24
20

UK
Sweden
Norway

Denmark
Finland
Ireland

Northern 
Europe

37
30

24
24

22
21

USA
Canada

North 
America

41
24

Argentina
Peru

Mexico
Chile

Colombia
Brazil

Latin 
America

47
43

37
32
32

23

Reuters Institute for the Study of Journalism   |   Digital News Report 2022 41