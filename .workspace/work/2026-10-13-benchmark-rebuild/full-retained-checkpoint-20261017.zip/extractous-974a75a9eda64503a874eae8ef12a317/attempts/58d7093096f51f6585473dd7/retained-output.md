20 

after the Great Financial Crisis. Manufacturing markups have not risen over the 
past twenty-five years. 

Figure 6: Some service sectors have experienced the steepest rise in average 
markups 

Average markups in Standard Industrial Classification (SIC) sectors. Ordinary Least 
Square (OLS) estimation of a Translog production function with materials as flexible 
input. Firm-level estimates are aggregated weighting by turnover. Data from Annual 
Respondents Database X (ARDx) 1997-2020 and Annual Business Survey (ABS) 
2021. GB only