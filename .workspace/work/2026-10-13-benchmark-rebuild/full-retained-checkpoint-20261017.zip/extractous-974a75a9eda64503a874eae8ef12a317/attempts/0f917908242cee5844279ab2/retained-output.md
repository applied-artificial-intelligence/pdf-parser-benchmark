14 
 

Exhibit 2.5: Number of Villages Electrified in India (CY) 

 
Source: Press Information Bureau (PIB) 
 
Electrification in India has increased over time with the support from schemes like DDUGJY, Saubhagya and 

IPDS, which has given the electrical market a major boost. It has opened new markets for companies in the 

white goods and FMEG industry, that can now sell their products into the rural parts of India as well. The 

expansion of rural electrification is expected to significantly increase the demand of electrical products, as new 

power lines and infrastructure need to be set up and maintained.  

 

2.4 Potential Growth Areas 
  
Rural Markets 

The rural market represents a significant opportunity for consumer durables due to its large demographic and 

emerging economic potential. Comprising approximately 65% of India's population, rural areas are poised to see 

substantial growth in both household income and consumption. Projections indicate that the average rural 

household income will reach INR 2.4 lakh by FY2025-26, reflecting an increase in purchasing power. Moreover, 

rural consumption is expected to grow at a CAGR of ~9.7% between CY2020 and CY2030, further underscoring 

the untapped potential of this market for companies in the consumer durables sector. As improving economic 

conditions enhance the financial capacity of rural consumers, businesses have a unique opportunity to cater to 

their evolving needs and preferences.  

 

Export Markets  

Indian consumer durables and appliances exports have grown significantly across key categories between CY2019 

and CY2023. Air conditioners led with a ~14% CAGR, reaching USD 314.2 million in CY2023. Washing 

machines and small kitchen appliances followed with CAGRs of ~15% and ~18%, respectively, while 

refrigerators grew modestly to USD 231.7 million. Fans recorded an ~11% CAGR, and water purifiers reached 

USD 167.9 million, showcasing India’s growing footprint in the global consumer durables market. 

The USA offers immense growth potential for Indian exports in consumer durables, particularly electronic goods, 

supported by a robust bilateral trade relationship. In FY2023, trade between the two nations reached a record USD 

128.78 billion. India’s total exports to the USA were valued at USD 78.54 billion in CY2023. Exports of consumer 

durables and appliances to the USA were notable, with air conditioners accounting for ~14% of India’s total air 

conditioner exports, while washing machines and fans represented ~31% and ~11%, respectively, of total exports 

in their categories. 

 

The consistent increase in exports to the USA underscores its critical role as a lucrative market for India, offering 

significant opportunities for further expansion. 

  

3,061 21,759
73,739

2,49,799

4,70,838
5,12,153

5,97,464

1950 1961 1969 1980 1990 2002 2022