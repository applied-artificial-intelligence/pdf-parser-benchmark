Globally, ride hailing usage occurs, on average, 
3.5 times per month, with usage being higher 
in all parts of Asia and lower in the US (2.9 
journeys) and Europe (2.3 journeys). Car sharing 
is the most popular new mobility service in the 
US, with users taking an average of 3.3 monthly 
journeys.

WHAT DRIVES ADOPTION OF 
NEW MOBILITY SERVICES?

When asked why they choose new mobility 
services, respondents listed flexibility (62%), 
cost (52%), and the environment (44%) as 
their top three reasons, as shown in Figure 8. 
Flexibility covers a range of areas — customers 
don’t need to own or maintain a vehicle, battle 
traffic in congested urban areas, or find 
parking; they can also switch easily between 
different transport modes. Flexibility is clearly 
the number one reason for using new mobility 
services everywhere outside Europe (where cost 
slightly outweighs it) and the US (where cost is 
almost as important as flexibility).

Income had a minor impact on the reasons for 
choosing new mobility services among urban 
respondents. However, cost unsurprisingly 
increased in importance for lower-income 
groups, while flexibility and environmental 
considerations decreased:

 - Very-high-income groups — 66% cited 
flexibility as the key reason, 47% said cost, 
and 51% cited the environment.

 - Low-income groups — 58% chose flexibility 
as a key factor, 55% cited cost, and 44% cited 
the environment.

When asked what changes to new mobility 
services would encourage people to give up their 
cars, the major areas respondents highlighted 
globally are cost (50%) and availability (44%). 
Twenty-eight percent would not give up their 
cars under any circumstances. There are 
significant regional differences: 77% of Chinese 
respondents require greater availability to 
replace their cars with mobility services; 75% 
of Indians cite improved ease of use; and nearly 
half (49%) of US respondents and 37% of those 
in Europe would not give up their car under 
any circumstances. Essentially, to increase 
the adoption of new mobility services, people 
require lower costs, higher availability, greater 
flexibility, improved reliability, and increased 
quality. This combination of requirements 
for higher service and lower cost typically 
makes the “shared” element of CASE unviable 
economically.

Figure 8. Reasons for choosing new mobility services

Source: Arthur D. Little

Source: Arthur D. Little

Figure 8. Reasons for choosing new mobility services

What motivates you to use new mobility services?
Only urban respondents 

China SEA India ME Europe US NEA

62%

52%
44%

73%

45%
51%

67%
59%

Global

71%

50%
56% 60%

49%
43%

49%51%

41%

56% 54%

34%

69%

44%

34%
44%

Flexibility Cost Environment

1 4

R E P O R T:  T H E  F U T U R E  O F  A U T O M O T I V E  M O B I L I T Y,  2 0 2 4