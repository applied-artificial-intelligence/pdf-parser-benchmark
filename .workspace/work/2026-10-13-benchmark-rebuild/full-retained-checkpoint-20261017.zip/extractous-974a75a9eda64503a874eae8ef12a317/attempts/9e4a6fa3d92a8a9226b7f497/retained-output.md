Chapter 3: The role of social investment 

91 

 

 
 

         

 

 

Box 3.6: Evaluation of job creation schemes in Ireland

In Ireland, two direct job creation schemes were found to have positive effects on earning outcomes for 
(mostly long-term unemployed) participants. The research found that, after initial lock-in effects, the Community 
Employment (CE) scheme, (1) which primarily targets people who have been unemployed for more than 12 months, 
has a positive impact on total annual earnings, raising the probability of any earnings in a given year and annual 
weeks of employment in the regular labour market. More specifically, CE participants earn around EUR 2 000 per year 
more than matched non-participants and work an average of four weeks longer per year. The Tús (Start) scheme, a 
community work placement scheme offering short-term work opportunities for long-term unemployed people, was 
also found to have a positive, albeit modest, impact on the number of jobseekers exiting the unemployment register, 
as well as a lasting positive effect on earnings (Chart 1). (2) 
 

Chart 1 

Women and younger jobseekers experience a greater boost in earnings following participation in Ireland’s Tús 
scheme 
Impact of Tús on earnings, by sex, unemployment duration and age 

  

Source: (OECD, 2024a) calculations based on Department of Social Protection administrative data. 

 
The two schemes have positive impacts on social outcomes, with different effects on specific groups of 
long-term unemployed people. Participation in CE reduces future reliance on disability allowance and enhances 
take-up of education subsidies, indicating that the scheme has possible broader health and engagement in education 
effects. Six years after starting CE, former participants are 6 pp less likely to receive disability allowance, compared 
to similar participants who did not enter the scheme. This impact is even stronger for older jobseekers. Younger CE 
participants seem to benefit more in respect of labour market outcomes. For the Tús scheme, women, and jobseekers 
under 30 experienced a slightly greater increase in their earnings (Chart 1). 

 
(1) CE is a public work programme and is one of the most widely used ALMPs for long-term unemployed people in Ireland. Its main 

objectives are to connect jobseekers with the labour market to increase employment levels and to promote social inclusion, as it 
seeks to reduce social isolation and social barriers for jobseekers. 

(2) (OECD, 2024a) 

-€500

€0

€500

€1 000

€1 500

€2 000

€2 500

-3 -2 -1 0 1 2 3 4 5 6 7 8
Outcome year

A. By sex
Total
Women
Men

-€500

€0

€500

€1 000

€1 500

€2 000

€2 500

-3 -2 -1 0 1 2 3 4 5 6 7 8
Outcome year

C. By age

Under 30 30 to 50

Over 50 Total

-€500

€0

€500

€1 000

€1 500

€2 000

€2 500

-3 -2 -1 0 1 2 3 4 5 6 7 8
Outcome year

B. By unemployment 
duration
One to three years
More than three years