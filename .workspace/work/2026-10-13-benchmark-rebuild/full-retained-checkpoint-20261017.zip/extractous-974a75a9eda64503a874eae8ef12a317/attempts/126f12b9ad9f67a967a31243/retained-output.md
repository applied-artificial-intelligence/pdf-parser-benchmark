4 Swiss Re Institute sigma No 1/2025  Key takeaways

Losses from primary perils remain an ever present risk and drive most deviations from trend
While losses from both primary and secondary perils are on an upward trajectory, history shows that annual losses from primary perils 
vary considerably from year-to-year, punctuated by peak loss years. In the past 30 years, there have been five such years where losses 
from primary perils were more than double the trend (>100% on X-axis). These years also happen to be years in terms of global losses 
from all natural catastrophe events were highest, affirming the strong influence of primary-peril losses. 

Distribution of annual losses from primary and secondary perils in % deviation from trend (1995 ‒ 2024)

Source: Swiss Re Institute

0

2

4

6

8

10

12

700%
675%

650%
625%

600%
575%

550%
525%

500%
475%

450%
425%

400%
375%

350%
325%

300%
275%

250%
225%

200%
175%

150%
125%

100%
75%

50%
25%0%

–25%
–50%

–75%

–100%

–125%

–150%

Primary perils Secondary perils

Deviations from tend

2011 1999 2004 2005

2011, 2017

Number of years

Exposure to natural catastrophe risks a key factor in driving claims costs 
Analysis of the link between catastrophe losses per policy and homeowner insurance prices at state level shows a strong correlation. 
States with highest exposures to natural catastrophes risks (according to insurance loss history), are also where, in general, 
homeowner premiums are highest. In states with higher average premiums, extremely high premium levels are localised. Like in 
Florida, for instance, where average premium per policy is amongst the highest of all states. In 11% of the Florida’s zip codes, premiums 
per policy were above USD 10 000. These are typically coastal zip codes with highest risk of storm surge and/or wind damage. 

Distribution of premium per policy in Florida at zip-code level, USD, 2022

Source: FIO Data, Swiss Re Institute

0

20

40

60

80

100

120

140

Premium per policy 2022

>150001450013500125001150010500950085007500650055004500350025001500

Number of zip codes in Florida

Premium per policy in USD