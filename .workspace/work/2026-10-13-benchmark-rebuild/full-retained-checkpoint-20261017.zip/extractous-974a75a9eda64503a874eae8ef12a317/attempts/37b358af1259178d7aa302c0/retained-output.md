12 
 

provided under the Scheme. Under PMAY-U, 1.18 crore houses have been sanctioned while more than 

85.5 lakh houses have already been constructed and delivered to the beneficiaries.  

 

Urbanisation and Smart Cities 

In the last decade, the urban population in India has grown at an annual rate of 2.4%. The urban population of 

India is projected to reach approximately 41% by CY2030 from 31% in CY2010. Further, the number of 

metropolitan cities in India are estimated to increase from 46 as per Census 2011 to 68 in CY2030.  

 

The Smart City Project was launched in June 2015 by GoI with a plan to build 100 smart cities across India,. As 

of 3rd July 2024, the 100 Cities have completed 7,188 projects (90% of total projects) amounting to INR 1,44,237 

crore as part of the mission. The balance 830 projects amounting to INR 19,926 crore are also in advanced stages 

of completion. On the financial progress, the mission has an allocated GoI budget of INR 48,000 crore for the 100 

Cities. As on date, GOI has released INR 46,585 crore (~97% of the allocated GoI budget) to 100 cities.. 

 

Climate Change and Built Environment 

At the UN Climate Change Conference in 2021, India committed to achieving net-zero emissions by 2070, aiming 

to reduce projected carbon emissions by 1 billion tonnes and decrease the carbon intensity of its economy by 45% 

by 2030. Transforming the built environment, which contributes nearly 40% of global energy-related greenhouse 

gas emissions, is central to achieving these targets. With rising heat levels and pollution in India driving the 

demand for consumer durables, the industry is pushing towards innovation and managing escalating energy needs 

sustainably.  With half of the buildings projected to exist in India by 2050 yet to be constructed, there is a 

significant opportunity to incorporate climate-friendly, energy-saving solutions into new developments. This 

alignment with sustainability goals highlights the critical role of consumer durables in addressing evolving 

consumer needs while mitigating climate impacts. 

 

One of the most effective solutions to combat climate change is to reduce greenhouse gas emissions and decrease 

reliance on fossil fuels. Harnessing renewable energy offers significant benefits in addressing climate change 

issues. India ranks 4th globally in renewable energy capacity, with notable achievements in wind and solar power. 

The country has set an ambitious target of 500 GW of non-fossil fuel-based energy by 2030, representing the 

world’s largest renewable energy expansion plan.India’s solar capacity has surged 30-fold in the past nine years, 

reaching 90.76 GW by September 2024, with a potential of 748 GW. The country’s renewable energy capacity 

has grown by 128% since FY2014, supported by initiatives such as the "Development of Solar Parks" scheme. 

 

Exhibit 2.4: Solar Energy Capacity Forecast (FY) 

 
Source: Secondary Research 

 

Policy Reforms 

Various policy reforms have been incorporated by GoI to boost production, exports and promote ease of doing 

business. Some of these policies include:  

 

• PLI Scheme: Under PLI scheme, GoI aims at achieving large-scale electronics manufacturing in India. 

Investment of INR 1.23 lakh crore has been realized till March 2024. There is a PLI Scheme specifically 

for white goods manufacturers in India under which, GoI proposes a financial incentive to boost 

domestic manufacturing and attract large investments in white goods manufacturing value chain, with 

an objective of removing sectoral disabilities, creating economies of scale, enhancing exports, creating 

a robust component ecosystem and employment generation. This scheme is expected to be implemented 

34.6 40.1
54.0

65.0

90.8

113.3

145.0

185.6

2020 2021 2022 2023 2024 2025P 2026P 2027P