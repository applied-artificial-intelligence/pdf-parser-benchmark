11 https://eu.usatoday.com/story/tech/2022/01/21/climate-change-misinformation-facebook-youtube-twitter/6594691001/

Levels of perceived misinformation around climate change 
and the environment are around three times higher in the 
United States (34%) than they are in Taiwan (10%) or Denmark 
(13%). Despite pledges to crack down, social media posts and 
videos denying climate change or disputing its causes remain 
widespread on Twitter, Facebook, YouTube, and TikTok, according 
to recent research.11

In this year’s report we find increased polarisation around climate 
change in a number of countries, including the United States, and 
identify the most important sources for climate change news with 
different groups. 

For further analysis see Section 2.6: How People Access and Think 
about Climate Change News

TEXT IS STILL KING BUT WHAT ROLE FOR ONLINE 
VIDEO?

Since the emergence of the internet, consumption on news websites 
(and apps) has primarily been about reading text articles. But that 
has begun to change with the growing supply of video news formats 
on social media.

Against this background, it is surprising to find that all age groups, 
on average, say they still prefer to read news online rather than 
watch it – and we have seen little change in underlying preferences 
since we last asked the question in 2019. Younger audiences, 
however, are significantly more likely to say they watch the news, 
perhaps because they are more exposed to networks like Facebook, 
Instagram, and TikTok. 

We do find significant market-level differences in preferences 
around reading or watching, partly conditioned by consumption 
patterns offline. We find markets with historic patterns of high 
newspaper consumption such as Finland and Japan near the top 
of the list in terms of reading preference, with low-newspaper-
circulation countries like Thailand and Brazil near the bottom. But 
other factors are also likely to be at play. Higher use of social media 
in general in Latin America (Mexico, Peru, Colombia, and Chile) 
as well as in parts of Asia-Pacific (Philippines and Taiwan) may be 
encouraging more video news use in these markets.

REUTERS INSTITUTE FOR THE STUDY OF JOURNALISM / EXECUTIVE SUMMARY GRAPHS

Graph 37

PROPORTION WHO MOSTLY READ NEWS IN TEXT – BY AGE 
– ALL MARKETS 

OPTQ11D. In thinking about your online news habits, which of the following statements applies 
best to you? Base: Total sample; all markets = 93,432. 

67

65

60

55

14

16

18

19

11

12

14

17

8

8

8

9

55+

35+

25-34

18-24

Mostly read Same Mostly watch Don’t know

0% 25% 50% 75% 100%

REUTERS INSTITUTE FOR THE STUDY OF JOURNALISM / EXECUTIVE SUMMARY GRAPHS

Graph 38

PROPORTION WHO MOSTLY READ NEWS IN TEXT – 
ALL MARKETS

OPTQ11D. In thinking about your online news habits, which of the following statements applies 
best to you? Please select one. Showing net of different option statements. Base: Total sample in 
each market (n ≈ 2000). 

Mostly read Same Mostly watch Don’t know

0% 25% 50% 75% 100%

6
6

12
6
7

11
17

10
11
8

12

9
8
9
6
8

10
16

7
4
8
9

15
6
11
8

21

6
9

18
14
10

8
6

6

5
6

6
5

8
8

6
6

11
10
12
8

9
11

10
8

15
10
10
11
13

12
9

12
11

13
13

18
14

10
17

10
17

10
16

22
19

16
15

18
20

22
24

26
24

7
10
12

6
15

11
15

12
6

15
19

16
20

13
11

15
13

18
16
17

16
17
17
18

11
24

20
22

13
18

16
19

21
18

14
24

22
20
22

15
17

21
24
23
23
25

85
79

78
76

74
74
74

72
71

70
69
69

68
68
67
67
67

66
66
65

64
63
63
63

61
61
61

60
60
60

58
58
58
58

56
56
55

54
53
53

51
50

47
47
47

45

Don’t know

Mostly watch

Same

Mostly read

Mexico

Philippines

Peru

Colombia

Brazil

Canada

USA

Chile

Taiwan

Kenya

Thailand

France

South Korea

Austria

India

Germany

Argentina

Italy

Hong Kong

Turkey

Romania

Australia

Switzerland

Slovakia

Malaysia

Spain

Singapore

Portugal

South Africa

Belgium

Ireland

Japan

Poland

Croatia

Indonesia

Nigeria

Bulgaria

UK

Netherlands

Greece

Sweden

Hungary

Denmark

Czech Republic

Norway

Finland 3

4

3

4

5
1

4

4

1

4
1

5

Reuters Institute for the Study of Journalism   |   Digital News Report 2022 27