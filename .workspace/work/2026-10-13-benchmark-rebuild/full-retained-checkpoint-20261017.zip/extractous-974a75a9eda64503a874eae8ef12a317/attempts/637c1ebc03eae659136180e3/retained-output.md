© 2025 Swiss Re. All rights reserved.

2  Swiss Re Institute  Unseasonal fires trigger above-trend first-half 2025 natural catastrophe insured losses   

The Palisades and Eaton wildfires in LA County were the costliest 
events of the first half, resulting in combined insured losses of 
USD 40 billion (preliminary estimates). That’s half of global first-
half losses insured losses. For all other major perils, also severe 
convective storms (SCS), losses were instead mostly below the 
January-June average of the previous five years (see Figure 3).

Figure 3: Global insured losses from natural catastrophes by peril in 
1H 2025 and previous half-year averages (USD bn, 2025 prices)

Source: Swiss Re Institute

0 10 20 30 40 50 60 70 80

Droughts

European winter storms

Wildfires

Other secondary perils

Floods

Earthquakes

Tropical cyclones

Severe convective storms

2025

5-year average
(2020–2024)

10-year average
(2015–2024)

30-year average
(1995–2024)

Droughts

Other secondary perils European winter stormsWildfires

Severe convective storms FloodsTropical cyclones Earthquakes

Economic losses from natural catastrophes in the first half of 
2025 were USD 135 billion, of which insurance covered about 
59% (see Figure 4). That’s higher than the previous 10-year 
average of 42% and reflects that much of the damage caused by 
disasters was in US and other regions of relatively high insurance 
penetration, and also that wildfire is widely covered in personal 
property covers. 

Figure 4: Global annual insured and uninsured losses from 
natural catastrophes in 1H (USD bn, 2025 prices)

Source: Swiss Re Institute

0

30

60

90

120

150

180

Uninsured losses (left)

Insured losses (left)

2025202420232022202120202019201820172016

0%

20%

40%

60%

Insured losses as a percentage of total economic losses (right)

Editable field 2023 - with outline

Editable field 2023 - without outline

37%

43%43%

33%

47%
50%

39% 39%

51%

59%

Uninsured losses (left)Insured losses (left)

Insured losses as a percentage of total economic losses (right)

The LA County fires were not the only major disaster in the first 
half. Another catastrophe was the magnitude 7.7 earthquake that 
struck Myanmar in March, claiming around 3 900 human lives, 
more than any other disaster.1 The quake struck densely 
populated regions of the country including Mandalay, its second 
largest city, and total economic losses are estimated to have been 
around USD 14 billion. There is no information on insured losses 
but, with low insurance penetration, these will likely be low 
relative to regions of higher risk protection uptake. The shock 
waves from the earthquake were felt as far away as in India, China 
and Thailand. In Bangkok, the seismic shakes caused a high-rise 
building under construction to collapse, claiming more lives. 
Bangkok sits on a basin of soft sediment that acts like as amplifier, 
increasing the intensity and duration of shaking and making even 
far-off earthquakes feel intense. For this reason, even though far 
away from active faults, Bangkok is exposed to loss potential from 
seismic activity. Preliminary estimates from the Thai General 
Insurance Association indicate insured losses in the country of 
USD 1.5 billion as a result of the earthquake. 

With earthquakes, location and ground conditions matter as 
much as magnitude with respect to damage caused. Many cities 
around the world including Mexico City, LA, Beijing and Tokyo are 
built on sedimentary basins and face elevated seismic risk on 
account of potential for amplified ground motions. Without proper 
building codes and adequate enforcement thereof, the increased 
shaking can cause severe structural damage and loss of life. 
Modern seismic hazard assessment including localised effects is 
needed to accurately assess the resilience of buildings to ground 
shakes, and the stringency of building codes required. Strong 
building codes reduce damage but are not always rigorously 
enforced. Risk models must account for basin effects to avoid 
underestimating loss potential. 

Non-seasonal wildfires account for half of the January-
June losses

In January 2025, two major wildfires burned close to 40 000 acres 
in LA County and destroyed more than 16 000 structures in the  
Palisades and Eaton neighbourhoods.2 A prolonged and dry Santa 
Ana wind with gusts reaching speeds of almost 100 mph, coupled 
with a lack of rainfall, created unseasonal and extreme fire-fuelling 
weather conditions. The area affected by the Palisades fire contains 
some of the densest concentration of high-value single-family 
residential property in the US. The resulting fires covered locations 
of high exposure, leading to exceptional losses. A very large 
number of structures were destroyed, more than 400% of the long-
term annual average, causing high losses in what was otherwise in 
terms of physical events an unremarkable fire season. For instance, 
in year to 19 June 2025, the number of acres burned in the 
California and the number of fire outbreaks were just 5% and 38% 
of the respective long-term yearly averages. 

According to Swiss Re estimates, as of July 2025 combined 
insured losses from the Palisades and Eaton firestorm(s) were 
USD 40 billion, by far the largest global insured wildfire loss 
event(s) to date, and among the top 10 costliest natural 
catastrophe insured loss events of all perils on sigma records. 
Total first-half insured losses for wildfire were the highest ever, 
surpassing even the previous full-year peaks for this peril by a 
significant margin (see Figure 5 below).