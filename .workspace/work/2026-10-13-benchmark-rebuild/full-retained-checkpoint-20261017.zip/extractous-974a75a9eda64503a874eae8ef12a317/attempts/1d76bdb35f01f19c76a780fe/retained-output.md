Regional Recaps

54

APAC

Figure 36: Map of notable Asia-Pacific (APAC) events in 2023   |  Data and Graphic: Gallagher Re

Figure 37: Asia-Pacific (APAC) natural catastrophe statistics  |  Data and Graphic: Gallagher Re

Singapore

Kuala Lumpur

Hong Kong

New Delhi

BangkokChennai

Mumbai

Jakarta

Beijing

Manila

Tokyo

Afghanistan Earthquakes
October sequence in Herat Province;

Four tremors measured at M6.3;
Total Fatalities: 1,489

Typhoon Doksuri
Record rainfall from storm's remnants

led to catastrophic inland flooding;
Eco: USD18.5bn  /  Ins: 1.7bn

Cyclone Michaung
Torrential rain & flooding in Chennai

Eco: USD1.9bn  /  Ins: USD240mn Cyclone Mocha
Category 4 landfall in Myanmar

Economic Loss; USD2.2bn

Japan: Seasonal Rains
Torrential rains in July led to

extensive flood damage
Insured Loss: USD350mn

Christchurch

Melbourne
Auckland

Brisbane

Sydney

Perth

North Island (NZ) Floods
Economic Loss: USD3.1bn

Insured Loss: USD1.9bn

Cyclone Gabrielle
Economic Loss; USD3.8bn

Insured Loss: USD1.8bn

Australia Summer Heat
Sydney: 43.5°C / 110.3°F on Dec 9

City's hottest day since 1929

Cyclone Jasper
Extensive flash flood damage in QLD;
2,252 mm / 88.66 in at Bairds;
Wettest Australia TC on record

Asia Oceania

Annual APAC Natural Peril Losses Aggregate APAC Weather / Climate Losses

5
Number of Asian Countries w/

All-Time Heat Records Set in 2023
Countries: CN, TH, VN, LA, SG

17
Number of Named Storms in the

2023 NW Pacific Typhoon Season;
Third-Fewest Since 1980

Notable Statistics in 2023

744.8
Amount of Rainfall (mm) in

Beijing via Remnants of TY Doksuri;
Heaviest Total Since 1883

2
Weeks Between New Zealand's
Two Costliest Weather Disasters

On Record

Economic Loss Insured Loss

2000 2005 2010 2015 2020

$100B

$200B

$300B

$400B

$500B

$600B

U
SD

 b
ill

io
n

2000 2005 2010 2015 2020

$500B

$1,000B

$1,500B

$2,000B

$2,500B

U
SD

 b
ill

io
n

$2,102B

$243B