PwC 17Semiconductor and beyond 2026

Faster, bigger, smarter data centers

It is cliché, but true, that we are living in the world of data and 
connectivity now. More and more devices are interconnected than 
ever before, including cars, home appliances, smartphones, and PCs. 
In addition to the growth of number of devices connected, consumers 
are demanding higher-quality entertainment such as AR/VR/XR 
gaming and seamless video streaming. Moreover, the introduction of 
‘ChatGPT’ in November 2022 became a motivator for both companies 
and individuals to actively utilize AI services in various applications 
they can possibly imagine.

These applications generate and require astronomical amount of data, 
and we’ve witnessed just the start of it. With high demand for gaming 
and video streaming, and most importantly, with the rising demand 
of AI, global data centers are expected to more than double their 
power consumption by 2030.

Data centers are a crucial resource for storing, processing, and 
managing data. They used to focus on providing services for 
enterprises, but with rising demand, they have achieved hyperscale 
status, providing internet as a service. Now with the demand of AI-
specific applications, Data centers are once again evolving into AI-
data centers, enhancing managers’ ability to provide lossless services 
to data center users. 

17

Global data center power consumption (Unit: GW)

’19 ’20 ’21 ’22 ’23 ’24 ’25F ’26F ’27F ’28F ’29F ’30F

AI-driven demand

Conventional demand

0

20

40

60

80

100

120

140

160

180

Rising AI data center power 
consumption signals growing AI 

compute demand and chipset needs

Source: IEA, PwC analysis