The BEAT | June 2025

With De-escalation in Focus, Markets Have Exhibited “Risk-On” Trends

TOP THEMES

Source: Bloomberg, MSIM. As of May 20, 2025. For illustrative purposes only. Not a recommendation to buy or sell any security. It is not possible to invest directly in an index. The views 
and opinions expressed are those of the portfolio management team at the time of writing/of this presentation and are subject to change at any time due to market, economic, or other 
conditions, and may not necessarily come to pass.  Forecasts/estimates are based on current market conditions, subject to change, and may not necessarily come to pass. Past 
performance is not indicative of future results.

Since the reciprocal tariffs delay announced on April 9th, equity market internals have signaled risk-on trends across several 

perspectives: On average, Cyclicals (ex energy) have outperformed Defensives, the high-volatility factor has outperformed 

low-volatility (sector neutral basis), and our tariff “exposed” basket of stocks has outperformed the tariff “resilient” basket.

The “Risk-On” Trade Has Returned Since Early April, with De-escalation in Trade Tensions a Key Catalyst

YTD cumulative performance for key pair trades

7

-35%

-30%

-25%

-20%

-15%

-10%

-5%

0%

5%

Jan 2025 Feb 2025 Mar 2025 Apr 2025 May 2025
S&P 500 Tariff Exposed vs. Tariff Resilient S&P 500 Cyclicals (ex Energy) vs. Defensives S&P 500 Sector Neutral High Vol vs. Low Vol Long-Short

De-escalation news flow has 
reversed most of the “risk-off” 
moves in equity factors and sectors