We forecast that global consumer video game revenue will reach 
$214B by 2029

 59

CONSUMER VIDEO GAME REVENUE BY REGION1, GLOBAL, 2019 VS. 2021 VS. 2025E VS. 2029E, BILLIONS USD

1. Excludes hardware and device sales, augmented/virtual reality content, and advertising. 
Sources: Activate analysis, Newzoo, Omdia, PricewaterhouseCoopers, Statista

2019 2021 2025E 2029E

$214B

$180B
$169B

$136B
$155B

$130B$121B

$101B

$59B$50B$48B$35B

10%

16%

2%

1%

2019-2021 
CAGR:

2021-2025E 
CAGR:

11%

2%

REST OF WORLD

U.S.

4%

4%

2025E-2029E 
CAGR:

4%

ACTIVATE 
FORECAST

VIDEO GAMING