Notes to the Financial Statements

102

www.kingsgate.com.au

28. Financial risk management and instruments continued

A change of 100 basis points (“bps”’) in interest rate at the reporting date would have increased / (decreased) equity and profit or loss by the amounts 
shown below. This analysis assumes that all other variables, in particular foreign exchange rates, remain constant. 

100 bps increase 100 bps decrease

Profit 
$’000

Equity 
$’000

Profit 
$’000

Equity 
$’000

Variable rate instrument – 2013 1,920 – (1,920) –

Variable rate instrument – 2012 481 – (481) –

(b) Credit risk
Credit risk arises from cash and cash equivalents, deposits with banks and financial institutions, as well as credit exposures to customers including, 
outstanding receivables and committed transactions.

The Group has no significant concentrations of credit risk. The sale of gold and other cash transactions are limited to counterparties with sound credit 
ratings.

The maximum exposure to credit risk is represented by the carrying value of the Group’s financial assets in the statement of financial position. The maximum 
exposure to credit risk at reporting date was:

2013 
$’000

2012 
$’000

Cash and cash equivalents 32,987 90,623

Receivables 9,431 12,226

Restricted cash 5,474 –

Other financial assets 7,808 4,670

Total exposure to credit risk at year end 55,700 107,519

(c) Liquidity risk
The Group’s liquidity requirements are based upon cash flow forecasts which are based upon forward production, operations, exploration and capital  
projections. Liquidity management, including debt / equity management, is carried out under policies approved by the Board and forecast material liquidity 
changes are discussed at Board meetings. The following table analyses the Company’s financial assets and liabilities into relevant maturity groupings based 
on the remaining period at the reporting date. The amounts disclosed are the contractual undiscounted cash flows.

Carrying 
amount 
 $’000

1 year  
or less 
 $’000

1–2 years 
 $’000

2–5 years 
 $’000

More than  
5 years 
 $’000

Total 
 $’000

2013
Payables 47,106 41,185 – 3,373 4,327 48,885

Borrowings 202,565 94,432 30,458 85,138 13,521 223,549

Derivatives held for trading 1,271  1,271 – – – 1,271

Total financial liabilities 2013 250,942 136,888 30,458 88,511 17,848 273,705

2012
Payables 49,278 42,597 4,637 2,044 – 49,278

Borrowings 157,544 45,474 75,260 66,359 – 187,093

Derivatives held for trading 2,685 2,685 – – – 2,685

Total financial liabilities 2012 209,507 90,756 79,897 68,403 – 239,056