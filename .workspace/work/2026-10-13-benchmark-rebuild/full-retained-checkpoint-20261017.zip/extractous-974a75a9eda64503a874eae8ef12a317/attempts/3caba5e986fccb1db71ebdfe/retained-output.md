$0

$20

$40

$60

$80

$100

$120

$140

$0

$5,000

$10,000

$15,000

$20,000

$25,000

$30,000

$35,000

$40,000

$45,000

1988 1993 1998 2003 2008 2013 2018 2023

G
lobal G

D
P

 ($T)

S
&

P
 5

0
0

 S&P 500 (11% annualized total return)

 Global GDP Growth (5% annualized growth)

The performance graph is not necessarily indicative of future investment performance.

S&P 500 and global GDP growth5

5. Figure 1.1. Source: FactSet, World Bank. Data as of December 31, 2023. S&P 500 return assumes reinvestment of all dividends. The 
performance graph is not necessarily indicative of future investment performance  

6. Our World in Data, Data compiled from multiple sources by World Bank (2025); Bold and van Zanden — Maddison Project Database 2023; 
Maddison Database 2010 

to the New York Stock Exchange, 
most financing has come from 
banks, corporations, and 
governments — not the  
capital markets. 

Why banks, corporations, and 
governments? Because that’s 
where people put their money. 
They parked their savings in bank 
accounts, drove corporate growth 
through consumption, and paid 
taxes that fund public spending.

But when my partners and I 
founded BlackRock in 1988, we 
believed the world was changing. 
The capital markets wouldn’t just 
supplement banks, corporations, 
and governments — they’d stand 
alongside them as a coequal 
source of capital. 

The logic was simple: Markets 
delivered better returns than the 
other three. Better returns would 
attract more investors. More 
investors would deepen markets. 
And deeper markets meant more 
capital. Plus, asset managers 
could accelerate this shift through 
innovation. For BlackRock, that 
meant first developing better 
technology to manage risk, then 
expanding choice and lowering 
fees through products like 
exchange-traded funds (ETFs).

We’ve been fortunate these past 
37 years. Our logic panned out. But 
what’s striking now is how early 

we still are in the story of market 
expansion. The real payoff is only 
just beginning.

As we enter our century’s second 
quarter, there’s a growing 
mismatch between the demand 
for investment and the capital 
available from traditional sources. 

Governments can’t fund 
infrastructure through deficits. 
The deficits can’t get much higher. 

Instead, they’ll turn to  
private investors. 

Meanwhile, companies won’t  
rely solely on banks for credit. 
Bank lending is constrained. 
Instead, businesses will go to  
the markets.

The money is already there. In fact, 
more capital is sitting idle today 
than at any point in my career. In 
the U.S. alone, roughly $25 trillion 
is parked in banks and money 
market funds.7

But we’re repeating a mistake 
from the earliest days of finance: 
Abundant capital. Deployed too 
narrowly. As one historian wrote, 
Amsterdam’s first stock exchange 
“could have made a much greater 
contribution to the economy” if 
investors had more companies to 
invest in. The same is true today.8 

Assets that will define the 
future — data centers, ports, power 

grids, the world’s fastest-growing 
private companies — aren’t 
available to most investors. They’re 
in private markets, locked behind 
high walls, with gates that open 
only for the wealthiest or largest 
market participants.

The reason for the exclusivity 
has always been risk. Illiquidity. 
Complexity. That’s why only 
certain investors are allowed in. 

But nothing in finance is 
immutable. Private markets 
don’t have to be as risky. Or 
opaque. Or out of reach. Not 
if the investment industry is 
willing to innovate — and that’s 
exactly what we’ve spent the 
past year doing at BlackRock.

BlackRock has always had a foot 
in private markets. But we’ve 
been — first and foremost — a 
traditional asset manager. That’s 
who we were at the start of 2024. 
But it’s not who we are anymore.

In the past 14 months, we’ve 
announced the acquisition of two 
of the top firms in the fastest-
growing areas of private markets: 
infrastructure and private credit. 
We bought another firm to get 
better data and analytics, so we 
can better measure risk, spot 
opportunities, and unlock access 
to private markets.

We’ve transformed our company. 
The next section details why we  
did it, how we did it, and why  
it matters.

The $68 trillion  
investment boom:  
Who will own it? 

Throughout history, infrastructure 
has driven a surprising amount 
of economic growth. Between 
1860 and 1890, just building 
railroads boosted U.S. GDP by 
roughly 25%.9 A century later, 
highways did something similar: 

These investors have benefited 
from the greatest period of wealth 
creation in human history. Over 
the past 40 years, global gross 
domestic product (GDP) has 
grown more than in the previous 
two thousand combined.6 This 
extraordinary growth — partly 
propelled, it must be noted, by 
historically low interest rates  
— has driven exceptional long-

term returns. But of course, not 
everyone has shared in this wealth.

This extraordinary era of market 
expansion has coincided with —  
and was largely fueled by —  
globalization. And while a flatter 
world lifted 1 billion people out 
of $1-a-day poverty, it also held 
back millions in wealthier nations 
striving for a better life. 

Today, many countries have 
twin, inverted economies: one 
where wealth builds on wealth; 
another where hardship builds on 
hardship. The divide has reshaped 
our politics, our policies, even 
our sense of what’s possible. 
Protectionism has returned with 
force. The unspoken assumption is 
that capitalism didn’t work and it’s 
time to try something new. 

But there’s another way to look 
at it: Capitalism did work — just 
for too few people. 

Markets, like everything humans 
build, aren’t perfect. They reflect 
us — unfinished, sometimes 
flawed, but always improvable. The 
solution isn’t to abandon markets; 
it’s to expand them, to finish the 
market democratization that 
began 400 years ago and let more 

people own a meaningful stake in 
the growth happening around them. 

In the pages (or pixels) ahead, I’ll 
offer some thoughts on how we 
can further democratize investing 
in two broad ways:

1. By helping current investors 
access parts of the market they’ve 
previously been restricted from.

2. By enabling more people  
to become investors in the  
first place.

I’ll begin with BlackRock’s work, 
but both of these efforts extend 
beyond asset management, 
touching broader issues like 
retirement policy, energy, and 
tokenization. 

More investment. More 
investors. That’s the answer. 

Given that BlackRock is a fiduciary 
and the largest asset manager 
in the world, some readers might 
contend I’m talking my own book. 
Fair enough. But it’s also the book 
we intentionally chose — long 
before it was a bestseller. From 
the start, we believed that when 
people can invest better, they 
can live better — and that’s exactly 
why we built BlackRock. 

Unlocking 
private markets
BlackRock’s past 14 
months — and the future

Economies run on capital. Whether 
you’re assembling 17th-century 
trading fleets or 21st-century data 
centers, the money has to come 
from somewhere. But historically, 
it hasn’t been investors. Despite 
400 years of financial innovation, 
from Amsterdam to Change Alley 

7. Source: ICI and The Federal Reserve. Cash in Money Market Funds and Commercial Bank Deposits, as of March 5, 2025 

8. Lodewijk Petram, The World’s First Stock Exchange, (Columbia University Press, 2014)

9. National Bureau of Economic Research, Railroads, Reallocation, and the Rise of American Manufacturing, (2019), pg. 2. Note: The study 
estimates that U.S. aggregate productivity would have been 25% lower in 1890 in the absence of railroads, with an associated annual loss of 
$3 billion or 25% of GDP

BlackRock has always had a foot 
in private markets. But we’ve 
been — first and foremost — a 
traditional asset manager. That’s 
who we were at the start of 2024. 
But it’s not who we are anymore.

We believed the world was 
changing. The capital markets 
wouldn’t just supplement banks, 
corporations, and governments 
— they’d stand alongside them as 
a coequal source of capital.

BlackRock 2024 Annual Report    1312     BlackRock 2024 Annual Report