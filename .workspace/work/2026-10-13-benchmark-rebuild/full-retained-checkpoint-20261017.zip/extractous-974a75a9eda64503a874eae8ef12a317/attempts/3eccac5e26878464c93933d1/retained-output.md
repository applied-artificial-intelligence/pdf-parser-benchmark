Global Outsourcing Survey 2024 | Multidimensional sourcing: Orchestrating the extended workforce ecosystem 

17

One pathway lies in transforming the traditional Vendor Management Office (VMO) into an  
Extended Workforce Management Office (EWMO). This evolution will allow organizations to:

However, building and maturing the EWMO is a long-term endeavor. Currently, less than 20% of 
executives report that their traditional VMO owns the extended workforce strategy, and nearly 70% of 
organizations acknowledge that their VMO function is not fully mature.

Enhance risk management and 
regulatory compliance across all 
workforce models.

Centralize ownership of extended 
workforce strategy and governance.

Develop and implement contractual 
provisions for use of AI and service 
integration across sourcing models. 

Integrate all sourcing models into the 
organization’s operating model.  

Redefine how to measure 
service performance.

Ensure visibility and control over 
external labor, including spend and 
performance management.

Extended Workforce Management and Governance Owner

13%Individual Functions / Business Units

16%Risk organization

32%Procurement / Sourcing organization

19%Vendor / Supplier Management Office

20%IT organization

Maturity of Vendor Management Office (VMO) and Processes

No change

Decrease moderately

Decrease significantly

Increase moderately
8%

25%

36%

31%