2 ©2014 Association for Financial Professionals, Inc. All Rights Reserved www.AFPonline.org

AFP GUIDE: Data Visualization: How to Tell Number Stories with Pictures

Introduction: The Trend
Survey shows more finance professionals are looking to data 
visualization to help solve problems, identify patterns and 
anomalies, and understand what’s driving their 
organizational performance. 

The trend toward greater use of visualization among 
FP&A professionals is still growing. “A lot of them are 
still focused on numbers,” said Craig Schiff, president 
and CEO of BPM Partners, a vendor-neutral advi-
sory services firm specializing in business performance 
management (BPM) and business intelligence solutions. 
However, the data from the 2014 BPM Pulse Survey 
of finance professionals shows the desire for change is 
strong. Asked if they require data visualization beyond 
typical charts or graphs offered in Excel, 40 percent of 
the finance professionals surveyed responded that they 
do. “That’s a large and growing number,” Schiff noted. 

More interactive features scored highest (71 percent) 
when asked what kind of data visualization capability 
respondents would like to have. “They really want to 
understand what’s going on behind the scenes. Graphics 
are great. The important thing is that not all the visu-
alization tools provide the ability to drill back into the 
detail to broaden your own understanding of the graph 
that brought the issue to your attention.” Fifty percent 
of respondents also wanted more chart types and tools 
in order to present the data with specialized graphics.

The last question the survey asked about data visu-
alization is from what source respondents would prefer 
to acquire these tools. The choices were: third-party 
providers, included in their performance management 
solution, or doesn’t matter. According to the results, 71 
percent preferred that the data visualization capabilities 
be integrated into the core product. “One of the chal-
lenges of the third-party tools is how to connect them to 
the source data,” Schiff said. That integration is already 
built into the budgeting tools. Those systems also speak 
the financial language and are designed for business 
end-user self-sufficiency. Many of the standalone tools 
require more IT knowledge to connect them to the data 
sources. “We believe that data visualization is a grow-
ing trend, and there is still a lot of opportunity for the 
vendors to add value.”

 

Source: BPM Partners 2014 BPM Pulse Survey

Do you require data visualization capabilities 
beyond standard charts and graphs?

 Yes

 No 

 Not sure

70.6%

56.5%

43.5%

21.2%

7.1%

More interactive

More chart types 
(heat chart, fractals, 

tree map, bubble 
chart, etc.)

Access to more 
data sources 

(external)

Not sure

Access to more 
data sources 

(internal)

 0% 20% 40% 60% 80%

What data visualization capabilities do you 
need that you are not getting today? (select 
all that apply)

Where would you prefer to get these data 
visualization capabilities from?

15.3%

72.9%

11.8%

Included in  
performance 
management 
solution

Doesn’t matter 

Third-party 
solution that 
may access my 
performance 
management 
data

24.0%

35.1%

40.9%