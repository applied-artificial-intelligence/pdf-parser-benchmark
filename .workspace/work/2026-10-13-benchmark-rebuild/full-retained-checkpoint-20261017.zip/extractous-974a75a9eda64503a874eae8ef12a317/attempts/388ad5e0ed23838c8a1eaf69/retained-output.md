230    

OECD EMPLOYMENT OUTLOOK 2024 © OECD 2024 
  

point to a globally weighted implicit price on all emissions of more than EUR 600 per tonne of CO2 (Network 

for Greening the Finanical System, 2023[10]), when using carbon prices as a proxy for all climate policies. 

Some studies warn that even carbon prices of this order of magnitude will not suffice to meet net-zero 

emission targets, without accompanying policies to markedly raise the responsiveness of emissions to 

carbon pricing, such as regulations concerning certain uses of fossil fuels or support for clean technology 

(D’Arcangelo et al., 2022[11]). Yet, in 72 OECD and non-OECD countries that together account for 80% of 

global greenhouse gas (GHG) emissions, less than half of all emissions were covered by some form of 

carbon pricing measure4 in 2021 (OECD, 2023[8]), and prevailing price levels are mostly much too low to 

incentivise deep emission cuts. In OECD countries, only a small share of emissions is priced at or above 

EUR 60 per tonne of CO2. Globally, sizeable fossil-fuel subsidies reduce effective carbon prices, 

sometimes turning them negative in countries with little or no carbon pricing measures in place (OECD, 

2022[12]). 

Figure 5.1. Support for climate policies hinges on perceived gains and losses 

Correlation between beliefs (as listed) and support for a carbon tax package with cash transfers 

 

Note: Results of regressions of support on standardised variables measuring respondents’ beliefs and perceptions. Dark green indicates 

variables measuring expected gains and losses. Country fixed effects, treatment indicators, and individual socio-economic characteristics are 

included but not displayed. The dependent variable is an indicator variable equal to 1 if the respondent (somewhat or strongly) supports each 

of the main climate policies. N=40 680, R2=0.378. CC: climate change. 

Source: Adapted from Dechezleprêtre, A. et al. (2022[7]), “Fighting climate change: International attitudes toward climate policies”, 

https://doi.org/10.1787/3406f29a-en. 

StatLink 2 https://stat.link/fknrvx 

∗∗∗

∗∗∗

∗∗∗

**

​

​

**

∗∗∗

∗∗∗

∗∗∗

∗∗∗

∗∗∗

∗∗∗

∗∗∗

∗∗∗

-15 -10 -5 0 5 10 15

Own household would lose

Low-income earners will lose

Understands impacts of CC

Net-zero is technically feasible

Worries about the consequences of CC

Understands emission across activities/regions

CC is real and caused by human

Will suffer from climate change

High-income earners will lose

Knows which gases cause CC

Policies entail positive economic effects

Policies would reduce pollution

Trusts the governement

Inequality is an important problem

Policies would reduce emissions

Correlation (%)

https://doi.org/10.1787/3406f29a-en
https://stat.link/fknrvx