Renewables 2025 Chapter 1. Renewable electricity 
Analysis and forecasts to 2030 
 

PAGE | 44  I E
A.

 C
C

 B
Y

 4
.0

. 

levels. Projections have been reduced 16% for utility-scale solar PV and 9% for 
wind, whereas distributed solar PV has been revised up 30%, offsetting the 
decline. 

Forecasts for utility-scale solar PV and wind reveal diverging trends across key 
Latin American markets. For Brazil, projections have been revised downwards 
because curtailment (particularly in the Northeast) and transmission bottlenecks 
are reducing project profitability, lengthening connection queues and extending 
project lead times. Curtailment also remains a key challenge in Chile, but the 
government is addressing it through grid expansion auctions and strong battery 
deployment, while a steady flow of permit requests indicates sustained interest in 
renewable power projects. Conversely, Mexico’s energy forecast has expanded 
since the country launched a USD 22-billion energy plan in early 2025, targeting 
29 GW of new capacity – 6.4 GW from variable renewables – along with grid 
upgrades, storage expansion and revived projects. 

For distributed PV, 30% more growth in the region is estimated in this year’s 
forecast than in last year’s. In Brazil, despite a 2023 policy change reducing 
remuneration under the net-metering scheme, distributed solar PV additions 
remain robust. Meanwhile, Mexico experienced record growth in distributed solar 
PV in 2024, adding 1 GW and reaching half a million users. This surge is largely 
the result of its attractive net metering programme, which is expected to enable an 
additional 13 GW of capacity by 2030, particularly benefiting commercial 
customers after the system-size threshold was increased from 0.5 MW to 0.7 MW. 

Net renewable capacity additions by country and technology in Latin America, 2025-
2030 

 
IEA. CC BY 4.0. 

 

Slow grid expansion continues to pose a significant challenge across Latin 
America. In Brazil, the increasing deployment of variable renewable energy has 

0

 2

 4

 6

 8

 10

 12

 14

 16

N
et

 a
dd

iti
on

s 
(G

W
)

Utility-scale PV

Brazil Mexico Chile Argentina Colombia Rest of the region Renewables 2024 forecast

0

 2

 4

 6

 8

 10

 12

Distributed PV

0

 1

 2

 3

 4

 5

 6

Wind