Chapter 3: The role of social investment 

95 

across countries widened (Chart 3.15). (214) In light of recent trends, many Europeans responding to a recent 
survey believe that addressing the high cost of living (48%) and the lack of social housing and homelessness 
(23%) should be a main priority in their country. Around 6 in 10 respondents think that their governments should 
increase their spending on housing, with variation across countries ranging from below 30% in Finland and 
Denmark to over 80% in Cyprus, Ireland and Greece. (215) 
 

Chart 3.16 

Housing allowances reduce the AROP rate 
Differences in AROP and AROP rates before housing allowances, 2022 

  

Note: AROP rate before housing allowances is calculated by excluding housing allowances from equivalised household disposable income and by calculating the share of people with an 
equivalised adjusted disposable income below 60% of the national median. AROP before housing allowances rate is missing for Romania, which does not collect data on housing 
allowances. 

Source: EU-SILC scientific use files, 2022. 

Click here to download chart. 

 
Social housing and housing allowances reduce the AROP rate in the short term, without accounting 
for the possible longer-term effects on housing prices and housing affordability. Comparing the 
adjusted AROP rate, which excludes social rent subsidies and/or housing allowances from equivalised household 
disposable income, (216) to the standard AROP rate provides a good measure of the impact of both policy 
instruments in reducing poverty. It does not however capture other relevant aspects of housing affordability such 
as supply and demand for affordable housing, underlying drivers or broader societal impacts. In 2022, housing 
allowances decreased the AROP rate by an estimated 1.4 pp (from 17.7% based on AROP rate before housing 
allowances to 16.3% of AROP rate) in the EU on average, with the biggest decreases in Finland (4.3 pp), Ireland 
(3.5 pp), France (3.1 pp) and Germany (3.0 pp) (Chart 3.16). (217) Similarly, in 2019, the provision of social housing 
proxied through social rent subsidies decreased the AROP rate in the EU by an estimated 0.4 pp on average (from 
18.1% in AROP rate before housing allowances and social rent subsidies to 17.7% in AROP rate before housing 
allowances).  (218) The highest decreases were observed in Ireland (3.7 pp) and Belgium (2.4 pp). The higher 
average impact of housing allowances could be due to relatively low public spending on social housing 
(Chart 3.15). While this analysis suggests that social housing and housing allowances reduce poverty, it does not 
account for the impact of other related policies or institutional setups and bottlenecks relevant for the 
functioning of rental and housing markets, thus likely reflecting the upper bound of the impact. For instance, the 
potential shift of (part of) housing allowances to landlords through higher rents might reduce the effectiveness 

 
(214) While countries with the lowest initial levels catch up relatively to those with the highest initial level of public spending on housing, 

changes in the public spending of other countries contributes to increased variance thus increasing overall dispersion.  
(215) 2024 Eurobarometer on Social Europe; 2022 Eurobarometer on Fairness, Inequality and Intergenerational Mobility. 
(216) Share of people with an equivalised adjusted disposable income below 60% of the national median, and further referred to as AROP 

before housing allowances and social rent subsidies, and AROP before housing allowances, respectively. 
(217) Romania is excluded from both averages, as it does not collect data on housing allowances (variable HY070G in EU-SILC). The reported 

results assume that no housing allowances are shifted towards landlords through higher rents. The rather small impact of housing 
allowances in reducing the AROP rate in some countries is largely due to low spending on these policies. However, part of the differences 
in impact on poverty reduction between countries might also be driven by the design of housing allowances, with some countries 
targeting households at risk of poverty more effectively. 

(218) Social rent subsidies (as a proxy for social housing) are estimated using the imputed rents variable (HY030G) for social tenants (those 
who indicated paying below-the-market rent) from EU-SILC. Since 2021, this variable is no longer part of the annual EU-SILC but will be 
provided on a three-yearly basis as part of the module “labour and housing conditions” (starting in 2023). Some countries (Denmark, 
Germany, Malta, the Netherlands, Slovakia, Sweden) did not collect data on imputed rents for social tenants for most years considered 
and are excluded from the analysis on social housing, in addition to Romania (where housing allowances do not exist). While data for 
social rent subsidies (imputed rents) are available until 2020, data for 2019 were used to avoid estimating the impact of temporary 
measures adopted during the COVID-19 pandemic. 

5%

10%

15%

20%

25%

AT BE BG CY CZ DE DK EE EL ES FI FR HR HU IE IT LT LU LV MT NL PL PT SE SI SK EU

2022

AROP AROP before housing allowances

https://ec.europa.eu/employment_social/empl_portal/publications/Esde2024/xls/Chap3/Chap3-Chart-3.16.xlsx