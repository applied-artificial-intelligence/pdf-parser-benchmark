X-raying the arXiv: A Large-Scale Analysis of arXiv
Submissions’ Source Files

Giovanni Apruzzese
University of Liechtenstein

Vaduz, Liechtenstein
Reykjavik University
Reykjavik, Iceland

giovanni.apruzzese@uni.li

Aurore Fass
Inria Centre at Université Côte d’Azur

Sophia Antipolis, France
CISPA Helmholtz Center for Information Security

Saarbrücken, Germany
aurore.fass@inria.fr

Abstract

arXiv is the largest open-access repository for scientific
literature. When submitting a paper, authors upload the man-
uscript’s source files, from which the final PDF is compiled.
These source files are also publicly downloadable, poten-
tially exposing data unrelated to the published paper—such
as figures, documents, or comments—that may unintention-
ally reveal confidential information or simply waste storage
space. We thus ask ourselves: “What can be found within the
source files of arXiv submissions?”
We present a longitudinal analysis of ≈600,000 submis-

sions appeared on arXiv between 2015–2025. For each sub-
mission, we examine the uploaded source files to quantify
and characterize data not required for producing the respec-
tive PDF. On average, 27% of the data in each submission are
unnecessary, totaling >580 GB of redundant content across
our dataset. Qualitative inspection reveals the presence of of-
fensive/inappropriate text (e.g., “WTF does this mean?”) and
experimental details that could disclose ongoing research.
We have contacted arXiv’s leadership team, as well as the au-
thors of affected papers to alert them of these issues. Finally,
we propose recommendations and an automated tool to de-
tect and analyze arXiv submissions residual data at scale,
aiming to improve data hygiene in the arXiv’s ecosystem.

1 Introduction

arXiv represents a cornerstone for modern research, en-
abling the fast and free exchange (upload and download)
of “preprints” used to disseminate the most recent scientific
discoveries [28]. As of August 2025, over 60M connections
are made daily to arXiv [19]. Its databases encompass over
2.8M submissions, whose overall number of downloads ex-
ceeds 3.3 billions [19]. Just in Q1 2025, over 65k papers have
been submitted to arXiv, spanning a variety of domains—of
which computer science detains the lion’s share [19, 45].

Uploading a preprint on arXiv is a simple process: an
author, potentially after having received an endorsement by
another arXiv user, can either (a) submit a paper as a PDF—
but such an option is rarely used (we found that only 10% of
submissions are made in this way) and is not encouraged by

Fig. 1: An arXiv submission. Clicking on “TEX Source” allows
anyone to download the source files of this paper.

arXiv [25]; or (b) submit the source TEX files of a paper, which
are then rendered as PDF by arXiv itself—this is the way
recommended by arXiv [27] and used by most submissions.
arXiv is rooted on the concept of openness [12]. For in-

stance, the web page of a submission provides a history that
lists all the previous “versions” of such a submission. All such
versions are freely retrievable (in PDF format); even submis-
sions that have been withdrawn still retain the full history
of previous versions (see, e.g., [10]). However, arXiv also
provides the possibility to retrieve the submissions’ source
TEX files. We show this in Figure 1. In other words, anyone
can download, and inspect, the files that a paper’s author has
uploaded to arXiv during the submission procedure. We argue
that this peculiarity deserves particular attention.
A TEX project can be complex [63]. For instance, besides

the content shown in the PDF produced after the compila-
tion, the source code of a TEX project can include custom
macros or even textual comments that are not part of the
actual PDF. Moreover, focusing the attention on research
papers, it is well-known that “a scientific paper consists of a
constellation of artifacts that extend beyond the document
itself” [2]. Therefore, it is sensible to assume that the TEX
source files of a research paper contain a variety of data (be-
yond textual comments) that are not necessary to produce
the paper, such as unused images, old sections of the paper,
or even files that are completely unrelated to the PDF (e.g.,
experimental source code, research spreadsheets, or different

1

ar
X

iv
:2

60
1.

11
38

5v
1 

 [
cs

.N
I]

  1
6 

Ja
n 

20
26

https://orcid.org/0000-0002-6890-9611
https://orcid.org/0000-0001-6611-4447
https://arxiv.org/abs/2601.11385v1