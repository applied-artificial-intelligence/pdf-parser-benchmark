86    

OECD EMPLOYMENT OUTLOOK 2024 © OECD 2024 
  

which employ, on average, more high skilled and high educated workers, pay better wages and have 

higher job quality (see Sections 2.2.2 and 2.3) are, in fact, concentrated in urban areas. Without an 

effective policy strategy to mitigate the disadvantage of those regions most specialised in GHG-intensive 

activities and least specialised in green-driven occupations (see Box 2.6), there is a significant risk that the 

net-zero transition exacerbates regional disparities and endangers social cohesion. 

Figure 2.6. Both green-driven and GHG-intensive occupations are more widespread in rural than in 
urban areas 

Share of green-driven and GHG-intensive occupations by rural/urban area, average 2015-19 

 

Note: Countries are ranked by decreasing gap of the share in rural areas compared to total. For European countries, the degree of urbanisation 

is defined on the share of local population living in urban clusters and in urban centres. It classifies areas into three types: thinly populated area 

(rural area); intermediate density area (towns and suburbs/small urban area), and densely populated area (cities/large urban area). In the 

United States, rural and urban areas are defined as non-metropolitan and metropolitan areas, respectively. 

Source: Secretariat’s estimates based on version 24.1 of the O*NET database and the following country-specific sources: United States: Current 

Population Survey; All other countries: EU Labour Force Survey. 

StatLink 2 https://stat.link/1g08k9 

14

16

18

20

22

24

26

28

30

% A. Green-driven occupations

0

2

4

6

8

10

12

14

16

18

20

% B. GHG-intensive occupations

Rural Urban Suburban Total

https://stat.link/1g08k9