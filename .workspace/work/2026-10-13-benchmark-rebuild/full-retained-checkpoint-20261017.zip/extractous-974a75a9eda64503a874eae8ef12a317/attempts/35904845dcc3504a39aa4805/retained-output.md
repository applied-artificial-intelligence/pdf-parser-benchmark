Meeting Notice and Voting Roadmap

How to Attend
Stockholders may attend the virtual annual meeting by
visiting the meeting website:
www.virtualshareholdermeeting.com/Intel25

DATE: Tuesday, May 6, 2025

TIME: 9:00 A.M. Pacific Time

For additional details on how to access the meeting, see
page 94.

How to Vote
Stockholders as of the close of business on the record
date, March 10, 2025, are entitled to vote at the
meeting.

ONLINE at www.proxyvote.com.

You may also vote online during the annual meeting
and/or submit questions at the meeting website
(see above).

BY PHONE by calling the applicable number below:

For stockholders of record:
(800) 690-6903

For beneficial stockholders:
(800) 454-8683

BY MAIL if you have received a printed version of these
proxy materials.

For more information, including for beneficial holders,
see “Additional Information” on page 94.

Proposal 1

Election of 11 Directors

Through regular refreshment, we have built a Board that is highly qualified, engaged and independent. We
believe our Board possesses the necessary skills, experiences, and mix of backgrounds and perspectives
to effectively oversee our business and strategic initiatives and represent the long-term interests of our
stockholders.
Upon the recommendation of the Governance Committee, the Board has nominated the following 11 current
directors for election to serve as directors until our 2026 Annual Meeting. See page 12

The Board recommends that you vote “FOR” each director nominee.

Our Director Nominees
James J. Goetz
Partner at Sequoia Capital

Gregory D. Smith
Former CFO and EVP, Enterprise
Operations of Boeing

Andrea J. Goldsmith
Dean of Engineering and Applied
Science and Professor of
Engineering at Princeton University

Stacy J. Smith
Executive Chairman at Kioxia

Alyssa H. Henry
Former Square CEO at Block

Lip-Bu Tan
CEO, Intel

Eric Meurice
Former President and CEO of ASML

Dion J. Weisler
Former President and CEO of HP

Barbara G. Novick
Co-Founder, Former Vice Chairman,
and Senior Advisor at BlackRock

Frank D. Yeary
Chair
Principal at Darwin Capital Advisors

 

SCAN this code to your phone to
receive all of the meeting details.

This 2025 Proxy Statement and Notice of Annual
Meeting and the 2024 Annual Report on Form 10-K are
available at www.intc.com.

Steve Sanghi
Interim CEO and former CEO of
Microchip Technology

4