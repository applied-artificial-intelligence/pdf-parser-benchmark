Employment and Social Developments in Europe 2024 

32 

GDHI observed in most quarters of 2021 and 2022. In the first two quarters of 2023, these net social benefits 
started to positively contribute to growth again, but stagnated in the second two quarters (see Section 3.6.). 
 

Chart 1.16 

Real GDP growth, real GDHI growth and its main components 
Real GDHI and real GDP (% change on previous year), and contribution of GDHI components (pp), 2012-2023, EU 

           

Note: Nominal GDHI converted into real GDHI by deflating it with the price index of household final consumption expenditure [prc_hicp_aind]. 

Source: DG EMPL calculations based on Eurostat data, national accounts [nasq_10_nf_tr] and [namq_10_gdp], data non-seasonally adjusted. 

Click here to download chart. 

 
The price of some necessities continued to increase in 2023, affecting the purchasing power of 
lower-income households, while energy prices remained high. Despite easing inflationary pressure, some 
essential items for households, such as food and beverages (12.6%), clothing and footwear (4.4%) and rents 
(3.0%), continued to increase in 2023. This negatively impacted households, especially those with lower incomes, 
which spend a large share of their income on essential consumption items. However, prices grew less 
substantially for electricity, gas and other fuels (1.4%), which likely eased the financial pressure stemming from 
energy consumption for lower-income and some middle-income households. In this context, the increase in 
energy poverty in 2023 was less pronounced compared to 2022 (Chart 1.17). 
 

Chart 1.17 

Prices of items continued to increase in 2023 compared to 2022 and 2021 
Price index of household final consumption expenditure (year-on-year change), by COICOP, HICP annual data, EU 

           

Note: Consumption items selected from the classification of individual consumption by purpose (COICOP); HICP gives comparable measures of inflation for the countries and country 
groups for which it is produced. 

Source: Eurostat data [prc_hicp_aind]. 

Click here to download chart. 

 
In the context of easing inflation, the proportion of people reporting financial distress experienced a 
decline. After stagnating at high levels, around 17.1%, from May to December 2023, financial distress slightly 
declined in the first two quarters of 2024, reaching 16.2% in July (-1.0 pp compared to one year before). In the 
same month, the share of the population declaring that they needed to draw on savings reached 12.0% (-0.8 pp 
compared to the same month in 2023), while 4.2% stated that they were running into debt (-0.2 pp) (Chart 1.18). 

 

-16

-12

-8

-4

0

4

8

12

16

Q1 Q3 Q1 Q3 Q1 Q3 Q1 Q3 Q1 Q3 Q1 Q3 Q1 Q3 Q1 Q3 Q1 Q3 Q1 Q3 Q1 Q3 Q1 Q3

2012 2013 2014 2015 2016 2017 2018 2019 2020 2021 2022 2023

%
 c

ha
ng

e 
on

 p
re

vi
ou

s 
ye

ar

Compensation of
employees

Compensation of
self-employed

Net property
income

Net other current
transfers

Net social
benefits

Taxes on income,
wealth (negative)

Real GDHI

Real GDP

-10

0

10

20

30

40

50

Al
l-

ite
m

s 
H

IC
P

Fo
od

 a
nd

 n
on

-a
lc

oh
ol

ic
 b

ev
er

ag
es

Cl
ot

hi
ng

 a
nd

 f
oo

tw
ea

r

Ac
tu

al
 r

en
ta

ls
 p

ai
d 

by
 t

en
an

ts

W
at

er
 s

up
pl

y

El
ec

tr
ic

ity
, g

as
 a

nd
 o

th
er

 f
ue

ls

H
ou

se
ho

ld
 f

ur
ni

tu
re

H
ou

se
ho

ld
 a

pp
lia

nc
es

H
ea

lth

Pa
ss

en
ge

r 
tr

an
sp

or
t b

y 
un

de
rg

ro
un

d
an

d 
tr

am

M
ot

or
 c

ar
s

Fu
el

s 
an

d 
lu

br
ic

an
ts

 f
or

 p
er

so
na

l
tr

an
sp

or
t 

eq
ui

pm
en

t

Te
le

ph
on

e 
an

d 
te

le
fa

x 
se

rv
ic

es

Re
cr

ea
tio

n 
an

d 
cu

ltu
re

Ed
uc

at
io

n

Ch
ild

 c
ar

e 
se

rv
ic

es

Re
tir

em
en

t 
ho

m
es

 f
or

 e
ld

er
ly

pe
rs

on
s 

an
d 

re
si

de
nc

es
 f

or
 d

is
ab

le
d

pe
rs

on
s

In
su

ra
nc

e
2021 2022 2023

https://ec.europa.eu/employment_social/empl_portal/publications/Esde2024/xls/Chap1/Chap1-Chart-1.16.xlsx
https://ec.europa.eu/employment_social/empl_portal/publications/Esde2024/xls/Chap1/Chap1-Chart-1.17.xlsx