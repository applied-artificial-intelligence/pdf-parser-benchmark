WORLD TRADE REPORT 2024

- 32 -

1.  Globalization has led to 
income convergence,  
but some economies have 
been left behind

The world has become more equal over the 
past three decades. Until the 1990s, there was 
little evidence of poorer economies catching up with 
richer ones, a phenomenon known as unconditional 
convergence. However, since the mid-1990s, economic 
growth has been unambiguously characterized by 
unconditional convergence (Patel, Sandefur and 
Subramanian, 2021; Kremer, Willis and You, 2022). 
This has been due mainly to faster catch-up growth in 
poorer economies, although the simultaneous slowing 
of growth in richer economies has also contributed. 
Consequently, income inequality among economies 
has been decreasing for the last quarter-century. Only 
the shock of the COVID-19 pandemic ended this era 
of unconditional income convergence.

Richer economies have a lower poverty rate, 
higher levels of education and longer life 
expectancies. Although income per capita is an 
imperfect measure of development, it is correlated with 
several dimensions of human development. Thus, the era 
of global income convergence has been accompanied 
by a stark reduction in the global poverty rate1 and has 
contributed to United Nations Sustainable Development 

Goals, such as those associated with education 
and health. According to data from the World Bank, 
the global share of people living in extreme poverty 
declined from 32.7 per cent in 1995 to 9 per cent  
in 2022, even though the global population rose by  
38.7 per cent during the same period.

The period of unprecedented income convergence  
has been accompanied by a steep increase in 
trade participation (see Figure B.1). While part 
of this correlation may be related to the fact that 
economic growth leads to more trade and that other 
common factors can cause an increase in both income 
per capita and trade, a compelling set of empirical 
research suggests that more trade also leads to 
higher incomes (see Figure B.1) (Feyrer, 2019, 2021; 
Cerdeiro and Komaromi, 2021).2 Comprehensive trade 
liberalization in developing economies has been shown 
to increase income growth by an average of 1.0 to  
1.5 percentage points, resulting in incomes higher by 10 
to 20 per cent after a decade (Irwin, 2024). Trade has 
been an essential component of high-growth episodes 
that typically involved a shift of capital and labour to the 
tradeable manufacturing sector and intensified imports 
of capital goods (World Bank, 2024a).

Low- and middle-income economies have become 
dominant in global merchandise trade. The 
increased trade participation of low- and middle-income  
economies has transformed the global trade 

Figure B.1: Positive correlation between low- and middle-income economies’ convergence speed  
and trade participation, 1996-2021

-1

0

1

2

3

4

5

6

7

8

40

60

80

100

120

140

160

19
96

19
98

20
00

20
02

20
04

20
06

20
08

20
10

20
12

20
14

20
16

20
18

20
20

19
97

19
99

20
01

20
03

20
05

20
07

20
09

20
11

20
15

20
13

20
17

20
19

20
21

Speed of income convergence

S
pe

ed
 o

f i
nc

om
e 

co
nv

er
ge

nc
e 

(p
er

ce
nt

ag
e 

po
in

ts
)

Tr
ad

e 
pa

rt
ic

ip
at

io
n 

(1
00

=
19

96
)

Trade participation

Source: Authors’ calculations, based on World Bank data on nominal GDP and real GDP per capita and WTO data on trade in goods and 
commercial services.
Note: The figure displays the evolution over time of the population-weighted averages of trade participation and income convergence speed 
between 1996 and 2021. The trade participation index is the share of goods and commercial services trade in GDP, adjusted for country size. 
Speed of income convergence is expressed as the difference between the average real GDP per capita growth rate of low- and middle-income 
economies and the average growth rate in high-income economies. The light blue fill indicates a contribution of negative growth in high-income 
economies. The income groups are based on the 1995 World Bank classification.