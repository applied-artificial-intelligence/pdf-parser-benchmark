The hourly rate companies invoice their clients is a 
poor indicator of how profitable their businesses are. 

Internal tasks, fixed price projects exceeding budgets, 
discounts and lack of clarity as to how many hours 
should be billed always lower the realised hourly rate. 

Looking at the discrepancy between the billed and the 
realised hourly rate gives you crucial insights into your 
ability to budget and execute your projects.

Realised hourly rate at €92 
What is your time worth?projects

2017 2018 2020 20212019

Realised hourly rate the past 5 years*: 

Not achieving your desired realised hourly rate?  
 Do you remember to always round hours  
 to nearest quarter or half an hour on your  
 invoices? 

 Do you remember to include all internal   
 project management costs in fixed price  
 projects when giving potential clients a   
 quote? 

Initiated Piloted Deployed Institutionalised Optimised

Realised hourly rate across maturity levels 
Mature companies see higher revenue on their  
consultants’ working hours 

€37.5 €67.0 €92.9 €113.0 €123.2

€87.1

€92.4 €90.6 €92€92

* Calculated on a yearly work time of 2,000 hours
18