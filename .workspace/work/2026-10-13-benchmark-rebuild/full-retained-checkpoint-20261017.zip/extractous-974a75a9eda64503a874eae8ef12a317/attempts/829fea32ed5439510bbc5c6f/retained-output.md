46%

43%

42%

44%

47%

43%

46%

47%

46%

46%

SALE SFORCE 21S TATE OF DATA & ANALY T IC S, 2N D EDI T ION

Bad Data:  
The Hidden Reason 
AI Projects Fail
A whopping majority of data and analytics 
leaders believe their data strategies — 
how they collect, manage, store, and 
make available their organizations' data 
—  aren’t up to the task of bridging their AI 
initiatives with business needs.

84% of data and analytics 
leaders believe their data 
strategies need overhauls  
for successful AI.

The general dissatisfaction with AI 
outputs can be traced in large part to 
shortcomings in the data that underpin 
them. Unfortunately, most respondents 
continue to lack full confidence in 
various aspects of their data — ranging 
from integration and harmonization to 
governance and management practices 
and overall quality — and progress has 
been incremental at best since our  
2023 survey.

2023

2025

03 Data Foundations Are Barely Improving in the Agentic Era

Quality

Integration

Harmonization

Infrastructure

Management

Security/compliance

Governance

Timeliness*

Bridge data strategy, culture, and execution to build an agentic 
enterprise. Get the guide

Salesforce Perspective

Data and Analytics Leaders Who Rate the Following Data Aspects as Fully 
Prepared for AI

45%

44%

47%

46%

49%

* Not included as a variable in 2023.

https://www.tableau.com/learn/blueprint/download