208    

OECD EMPLOYMENT OUTLOOK 2024 © OECD 2024 
  

Figure 4.8. Workers in green-driven and GHG-intensive occupations train less than average 

Point estimate of the percentage difference between workers that participate in training and those that do not 

participate, 2018 

 

Note: Panel A and B report the point estimate (and 95% confidence intervals) of the percentage difference in the average incidence of each type 

of worker between those workers that undertake training and those that do not. Estimates are obtained from a linear regression with the inverse 

hyperbolic sine of the share of each type of occupation as a dependent variable and including a training dummy (formal training in Panel A and 

informal training in Panel B), educational attainment (3 classes), gender, age (3 classes) and country dummies as explanatory variables and 

standard errors clustered on the dimensions of variability of the dependent variable. The reported point estimates and confidence intervals refer 

to the estimated coefficient of the training dummy and are expressed in percentage of the untransformed dependent variable. 

Reading: Controlling for demographic characteristics, the percentage share of green-driven occupations is, on average, 50% lower among 

employees who undertake formal training and 18% lower among employees who undertake informal training, than among those that do not. 

The share of workers in GHG-intensive occupations participating is 31% lower for formal training and 12% lower for non-formal training. 

Source: OECD estimates based on version 24.1 of the O*NET database and the following country-specific sources: Australia: Table Builder of 

the Australian Bureau of Statistics (Labour Force: Characteristics of Employment); United States: Current Population Survey; All other countries: 

EU Structure of Earnings Surveys. 

Training for the green transition is becoming a priority for many governments. In 2022 the European 

Council adopted recommendations to stimulate learning for sustainable development, which highlights the 

need to provide learning in formal, non-formal and informal settings (European Council, 2022[29]). The 

United Nations Environment Programme has recently produced a framework for education on green jobs 

– guidelines aimed at the higher education community on how to prepare students for the green economy 

(United Nations Environment Programme, 2021[30]). The importance of the challenge is not lost on 

OECD countries, with 13 out of 26 of them reporting they are funding new training and apprenticeship 

programmes for the green transition (OECD, 2023[31]).18 

In Canada, the Energy to Digital Growth Education and Upskilling Project (EDGE UP) was developed by 

Calgary Economic Development in partnership with the Information and Communication Technology 

Council (ICTC) with the goal of reskilling displaced mid-career oil and gas professionals and supporting 

them in starting a career in the technology sector in Calgary. The EDGE UP programme created reskilling 

pathways based on a skills mapping research study that highlighted the transferrable skills of workers in 

high-emission occupations and their skills gaps when compared with the needs of the most in-demand 

-60

-50

-40

-30

-20

-10

0

10

20

New green-driven
occupations

Established green-
driven occupations

GHG-intensive
occupations

%

A. Formal

-60

-50

-40

-30

-20

-10

0

10

20

New green-driven
occupations

Established green-
driven occupations

GHG-intensive
occupations

%

B. Not formal