Long-term debt-to-equity ratio for select energy companies and U.S. manufacturing companies

percentage

Petroleum and Liquid Fuels Markets Team | Financial Review 2024                                               

May 2025

The long-term debt-to-equity ratio was relatively flat for the energy 

companies and U.S. manufacturing companies, at 42% and 56%

Data source: Evaluate Energy and U.S. Census Bureau

Note: Select energy companies includes 158 global oil and natural gas companies. The Appendix contains the full list of companies.

0%

10%

20%

30%

40%

50%

60%

70%

80%

2015 2016 2017 2018 2019 2020 2021 2022 2023 2024

energy companies

all U.S. manufacturing

28