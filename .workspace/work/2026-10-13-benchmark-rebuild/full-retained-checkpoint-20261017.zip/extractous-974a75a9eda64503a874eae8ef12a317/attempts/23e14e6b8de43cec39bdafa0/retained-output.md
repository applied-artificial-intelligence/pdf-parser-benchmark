Chapter 7. Global Taxation of Multi-Millionaires
Figure 7.2. The super-rich pay proportionately less than others

99% of the population are located 

in the shaded area. 

0%

5%

10%

15%

20%

25%

P0−
10

P10
−2

0

P20
−3

0

P30
−4

0

P40
−5

0

P50
−6

0

P60
−7

0

P70
−8

0

P80
−9

0

P90
−9

5

P95
−9

9

P99
−9

9.
9

P99
.9

−9
9.

99

P99
.9

9−
P99

.9
99

P99
.9

99
−P

99
.9

99
9

Billi
on

air
esE

ffe
ct

iv
e 

in
co

m
e 

ta
x 

ra
te

s 
by

 
in

co
m

e 
gr

ou
ps

  a
nd

 fo
r 

 
bi

lli
on

ai
re

s 
(%

 o
f p

re
−

ta
x 

in
co

m
e)

Brazil France Netherlands Spain United States

Interpretation. This figure shows effective income tax rates by pre−tax income group and for U.S. dollar
billionaires in Brazil, France, the Netherlands, Spain, and the United States. Income tax rates include only
individual income taxes and equivalent levies. All values are expressed as a share of pre−tax income, defined as
all national income before taxes and transfers, after pensions. P0−10 denotes the bottom 10% of the income
distribution, P10−20 the next decile, etc. Sources and series: Artola et al. (2022), Bozio et al. (2024), Bozio et
al. (2020), Bruil et al. (2024), Palomo et al. (2025), Saez and Zucman (2019), and Zucman (2024).

Effective income tax rates by income groups

Safeguarding progressivity at the top
If today’s tax systems collapse intoregressivity at the very top, the crucialquestion to ask is: how do we restorefairness? Figure 7.4 provides a straightforwardanswer: introduce a minimum wealth taxon centi-millionaires and billionaires (seeZucman (2024)). The figure simulates whatwould happen if governments in high-incomecountries implemented a tax of 1%, 2%, or3% of wealth annually.

The results are striking. With no reform,billionaires face effective tax rates around20%, well below the burden of householdswith lower incomes. A 1% wealth tax wouldmodestly increase their contribution, butregressivity would remain. At 2%, the declineis essentially neutralized; centi-millionairesand billionaires would be brought back upto roughly the same tax burden as othertaxpayers. At 3%, the system becomesmodestly progressive again, with the veryrichest paying more than the rest.
A 2% tax rate is the minimum benchmarkfor safeguarding non-regressivity. Thisproposal builds on work by the EU TaxObservatory and the report titled “A

Blueprint for a Coordinated Minimum Effective
Taxation Standard for Ultra-High-Net-Worth
Individuals”, prepared by Gabriel Zucmanand commissioned by the Brazilian G20presidency in 2024. The report showsthat such a measure is technically feasible,administratively manageable, and politicallytransformative. A 2% minimum tax on globalbillionaires could raise between $200 and$250 billion annually from about 3,000individuals worldwide, funds equivalentto the entire health budgets of manylow-income countries combined.

Momentum for this idea has acceleratedin several countries. Some examples areBrazil, South Africa, Spain, and France. Brazilplaced the billionaire tax on the G20 agendaduring its 2024 presidency. Spain hasalso taken a leadership role internationally,co-launching with Brazil and South Africa in2025 a platform at the UN to build supportfor a global billionaire tax. France debateda 2% tax on fortunes above €100 millionearlier in 2025: the National Assemblyapproved it, but the Senate rejected the bill.The issue in France is at the center of thepolitical debate. In the United States, SenatorElizabeth Warren and others continue to
132