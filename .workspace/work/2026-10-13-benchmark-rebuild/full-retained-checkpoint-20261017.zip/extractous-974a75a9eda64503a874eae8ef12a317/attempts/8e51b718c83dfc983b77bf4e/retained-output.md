OUE BAYFRONT ONE RAFFLES PLACE OUE DOWNTOWN OFFICE LIPPO PLAZA MANDARIN GALLERY
HILTON SINGAPORE 
ORCHARD

CROWNE PLAZA CHANGI 
AIRPORT

Property Description Located at Collyer Quay in 
Singapore’s central business 
district (“CBD”), OUE Bayfront 
is a premium Grade A office 
building which occupies a 
vantage position between the 
Marina Bay downtown and 
established financial hub of 
Raffles Place.

One of the tallest buildings  
in the Singapore CBD, One 
Raffles Place is an iconic 
commercial development 
comprising two Grade A office 
towers and a retail mall, 
strategically located in  
the heart of main financial
district Raffles Place.

OUE Downtown Office is part  
of the OUE Downtown mixed-
use development, a refurbished 
landmark property comprising 
Grade A offices, a retail  
podium as well as serviced 
residences, strategically 
located in Shenton Way.

Lippo Plaza is a Grade A 
commercial building located  
on Huaihai Zhong Road, within 
the Huangpu business district, 
one of Shanghai’s established 
core CBD locations in the Puxi 
area of downtown Shanghai, 
China.

Mandarin Gallery is a high-
end retail mall situated along 
Orchard Road, in the heart 
of Singapore’s shopping 
precinct. The mall boasts a 
wide 152-metre frontage, 
according it a high degree of 
prominence, and serves as a 
preferred flagship location for 
international brands.

Hilton Singapore Orchard 
(formerly known as Mandarin 
Orchard Singapore) is Hilton's 
flagship hotel and its largest 
in Asia Pacific. With 1,080 
rooms, the hotel is also the 
largest in the heart of Orchard 
Road, Singapore's shopping 
and entertainment district, 
providing top accommodation 
choices for both leisure and 
business travellers globally.

Crowne Plaza Changi Airport, 
managed by InterContinental 
Hotels Group, is a 575-room 
hotel situated within the  
vicinity of the passenger 
terminals of Changi Airport.  
The hotel is connected directly 
to Changi Airport Terminal 3  
and enjoys seamless 
connectivity to Jewel Changi 
Airport via a pedestrian bridge 
from Terminal 3.

Ownership Interest 50% 83.33% interest in  
OUB Centre Limited, which  
owns 81.54% beneficial  
interest in One Raffles Place

100% of the office 
components  
of OUE Downtown

91.2% share of  
strata ownership

100% 100% 100%

Leasehold Tenure OUE Bayfront and 
OUE Tower:
99-year lease from  
12 November 2007
OUE Link:
15-year lease from  
26 March 2010 
Underpass:
99-year lease from  
7 January 2002

One Raffles Place Tower 1:   
841-year lease from  
1 November 1985
One Raffles Place Tower 2:  
99-year lease from  
26 May 1983 
One Raffles Place  
Shopping Mall:
•  approximately 75% of the  

NLA of the retail podium is  
on a 99-year lease from  
1 November 1985

•  the balance 25% of the NLA  
is on a 841-year lease from  
1 November 1985

99-year lease from  
19 July 1967

50-year land use  
right commencing  
from 2 July 1994

99-year lease from  
1 July 1957

99-year lease from  
1 July 1957

66-year lease from  
9 June 2017

Property Valuation S$1,340.0 million2 S$1,909.0 million3 S$930.0 million RMB 2,400.0 million
(S$449.0 million)

S$453.5 million S$1,346.0 million S$519.0 million 

FY 2023 Revenue S$31.6 million2 S$71.4 million3 S$48.8 million S$23.3 million S$30.1 million S$74.8 million S$22.5 million

Committed Occupancy/ 
RevPAR4

Overall: 97.6%
Office: 97.9%
Retail: 92.3%

Overall: 96.3%
Office: 95.8%
Retail: 99.2%

92.6% Overall: 84.9%
Office: 83.3%
Retail: 94.5%

97.6% FY 2023 RevPAR: S$274 FY2023 RevPAR: S$205

Net Lettable Area  
(“NLA”)

37,125.1 sq m 65,464.0 sq m 49,235.3 sq m 39,188.1 sq m 11,733.1 sq m Gross Floor Area:
91,999.8 sq m

Gross Floor Area:
40,913.5 sq m

C O M M E R C I A L1

PROPERTIES  
AT A GLANCE
As of 31 December 2023

OUE REIT04