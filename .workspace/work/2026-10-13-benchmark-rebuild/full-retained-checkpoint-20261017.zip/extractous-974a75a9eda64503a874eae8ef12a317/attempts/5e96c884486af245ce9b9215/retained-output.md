X-raying the arXiv: A Large-Scale Analysis of arXiv Submissions’ Source Files

categories, such as Cryptography & Security, or Artificial
Intelligence (see [21] for the complete categories).

arXiv’s vision is to facilitate dissemination of “established
and emerging research” [12]. The submission of a paper is
not bound to a peer-review process. Some submissions may
present errors (and can be withdrawn [33]) or can be just
short drafts / critiques (e.g. [30]); while others can become
seminal works (e.g., the adversarial example paper by Good-
fellow et al. [41]). Some authors may upload on arXiv an
early-version of a paper undergoing peer-review to share
their discoveries as soon as possible [28], while others may
use arXiv to provide a free version of a (peer-reviewed) article
published in some journal or conference proceedings [47].

To make a submission, it is necessary to upload its source
files. As of November 2025, arXiv accepts two main classes
of source files: a (zipped) file containing a TEX project, which
will be compiled on arXiv’s infrastructure and used to pro-
duce the PDF hosted on arXiv; or a single PDF, representing
the actual paper.While the latter may seem themost intuitive
way, arXiv discourages such a practice, and explicitly forbids
uploading PDF files generated via LATEX [24]. Nonetheless,
as we wrote, arXiv enables anyone to download the source
files of any given submission (see Figure 1).
A submission’s PDF remains on arXiv perpetually [26].

Authors can update the submission by uploading different
source files. Doing so will create a new “version” of a sub-
mission, resulting in a new PDF: downstream users can re-
trieve the PDF of any previous version of a submission. How-
ever, such versioning system does not apply for a submis-
sion’s source files: whenever a submission is updated, its new
source files overwrite the previous ones. Hence, users cannot
retrieve the source files of past versions of a submission.

2.2 Retrieval of Papers (Data Collection)

To comprehensively investigate what lies within the source
files of arXiv submissions, we need to download thousands of
submissions’ source files. Doing so manually is unthinkable.

The best option we found1, which is also endorsed by arXiv
itself [14], was by accessing the copy of arXiv’s database
hosted on Amazon S3 [15]. Such a database contains the
source files of all arXiv’s submissions, updated monthly,
which we could download (at a cost [11]) from Amazon
S3—without burdening arXiv’s servers. Hence, after setting
up an AWS account, we began (in May 2025) downloading
the data used in our assessment. However, at this point in
time, we did not know how much data we needed to down-
load, nor how expensive such operations would be. Indeed,
1We first considered scraping. However, even by considering the “scrape-
friendly” endpoint of arXiv (i.e., [1]), scraping approaches are not viable.
According to arXiv’s terms [14] “a reasonable rate are bursts of 4 requests
per second with a 1 second sleep”; moreover, the robots page of arXiv
explicitly prohibits programmatic source-file download [20].

Table 1: Data downloaded from AWS S3. Number of “chunks” and
overall size (in GB) retrieved from S3 and containing the data we analyzed

Year January February March April Total

Chnks Size Chnks Size Chnks Size Chnks Size Chnks Size
2025 154 76.6 180 89.4 232 115.3 186 92.4 752 373.8
2024 134 67.3 149 74.9 176 88.0 161 81.0 620 311.3
2023 98 49.0 110 54.8 146 73.8 115 58.5 469 236.2
2022 84 42.5 90 45.0 122 61.7 98 49.1 394 198.4
2021 69 35.3 76 38.7 109 56.0 93 47.5 347 177.6
2020 40 21.1 42 23.1 50 27.3 51 27.8 183 99.4
2019 33 16.8 33 16.7 38 18.9 42 21.4 146 73.9
2018 27 13.2 28 14.1 32 16.1 32 15.8 119 59.3
2017 21 10.1 20 10.0 26 13.2 23 11.1 90 44.5
2016 17 8.5 19 9.3 21 10.6 21 10.2 78 38.7
2015 15 7.4 16 7.8 18 8.8 17 8.2 66 32.1
(sum) 692 347.8 763 383.8 970 489.7 839 423.0 3,264 1,645.2

the only information provided in [15] was “The source files
[are grouped in] tar files of ≈500MB each and the complete
set of source files is about 2.9 TB (March 2023)”. We did not
know how many “chunks” of 500MB were included in each
month, so it was impossible to make any estimate.
Hence, we initially downloaded just the data for the first

four months of 2025 (i.e., all months preceding the current
one). This required 373GB (and around 40USD).We estimated
that the size for the previous years would be inferior (see,
e.g., the growth of submissions on arXiv [19]). To enable a
fair analysis which could reflect yearly trends, and given that
we had already downloaded the data for January–April 2025,
we decided to focus only on the first four months of each
year. According to our budget (around 150USD), we were
able to afford downloads back to 2015. At the end of this
process (which we finalized in July 2025), we downloaded a
total of ≈1.6TB of data, distributed across 3,264 tar files of
≈500MB each. The detailed breakdown is in Table 1.

2.3 Structure of Submissions’ Source Files

After downloading our dataset, we inspected its contents to
get a preliminary understanding of how to plan our analyses.

We extracted the 154 chunks of January 2025. We obtained
a total of 19,407 files in the form “YYMM.XXXXX.EXT”,
where: YY and MM represent the year and month; XXXXX is
a five-digit integer which progressively increases; and EXT
is the extension of the file. Notably, the extension included
only two types: PDF or GZ. We provide a snippet in Figure 2.
We hypothesized that all PDF files were submissions up-

loaded directly as a PDF: we confirmed such an hypothesis by
visiting the web pages of such submissions (e.g., 2501.00008
in Figure 2) and noticing that they lacked the “Source Files”
button. We then turned our attention to the GZ files, i.e.,
compressed archives. Some were very small (e.g., 2501.00002
in Figure 2) and contained a single extensionless file typi-
cally named “withdrawn”: we hypothesized that such files
were those referring to papers withdrawn from arXiv (we
verified this—explaining why 2501.00002 has a more recent
“Last Modified” date than the other submissions in Figure 2).

However, the vast majority of GZ files contained TEX-
related data, which could come in two different formats.

3