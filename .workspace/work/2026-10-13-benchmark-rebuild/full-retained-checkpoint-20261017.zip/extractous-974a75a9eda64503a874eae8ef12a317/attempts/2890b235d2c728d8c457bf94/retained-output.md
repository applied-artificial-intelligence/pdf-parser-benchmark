Note: Numbers may not sum to 100%, because of rounding.

Source: Heidrick & Struggles US professional services partner compensation survey, 2024, n=144

Yes 49
27

No 19
40

It varied too 
much to say 8

12

Don’t know/prefer 
not to answer 23

21

In your most recent fiscal year, did your firm pay a premium to attract or retain 
diverse consultants at any level?

2024 2022

Diverse talent (%) Attracting diverse talent
Meanwhile, significantly fewer 
respondents said they’re paying 
a premium to attract or retain 
diverse consultants at any level.

We found the results of this year’s 
survey disappointing, if not surprising. 
As firms face more uncertain market 
conditions, we are seeing the focus on 
diversity and inclusion wane slightly 
across industries as firms retreat to 
more traditional hiring practices. More 
forward-looking firms, however, will find 
themselves best positioned for future 
success by both continuing to prioritize 
competition for a diverse group of 
partners and cultivating a diverse 
leadership pipeline of more junior talent.

Respondents at strategy consulting firms 
more often said that they did not pay a 
premium for diverse talent at any level.

Overall 27 12 2140

Other 31 19 1931

Management/advisory 
consulting 29 12 1941

Strategy consulting 18 7 2055

Technology/IT consulting 36 16 2820

Yes No It varied too much to say Don’t know/prefer not to say

By firm type

Note: Numbers may not sum to 100%, because of rounding.

Source: Heidrick & Struggles US professional services partner compensation survey, 2024, n=144

In your most recent fiscal year, did your firm pay a premium 
to attract or retain diverse consultants at any level?

Diverse region, inclusive workforces: Diversity and inclusion policy and practice in Asia PacificHEIDRICK & STRUGGLES

15