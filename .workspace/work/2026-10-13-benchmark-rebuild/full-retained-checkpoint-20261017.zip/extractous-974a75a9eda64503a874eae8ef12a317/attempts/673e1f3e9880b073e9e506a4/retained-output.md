By firm size, we saw a correlation 
between personal revenue targets 
and firm size (the smaller the firm size, 
the smaller the revenue target), with 
the exception of the largest firms; for 
respondents at firms with more than $20 
billion in revenue, there was more of an 
even distribution of revenue targets.

46

27

13

19

22

14

26

9

16

24

10

18

29

11

10

16

22

9

21

28

20

10

20

21

14

13

7

7

10

7

7

7

7

7

13

14

14 8

8

8

17

14

28

20

10

7

Less than 
$1.00bn

Less than 
3 years

$5.01bn–
$20.00bn

6–10 years

More than 
$20.00bn

More than 
10 years

$1.01bn–
$5.00bn

3–5 years

Personal revenue targets, by firm size

Personal revenue targets, by tenure at firm

Less than $1.00m

$1.00m–$3.00m

$3.01m–$6.00m

$6.01m–$10.00m

$10.01m–$15.00m

$15.01m–$20.00m 

$20.01m–$25.00m 

$25.01m–$30.00m

More than $30.00m

Prefer not to answer

Less than $1.00m

$1.00m–$3.00m

$3.01m–$6.00m

$6.01m–$10.00m

$10.01m–$15.00m

$15.01m–$20.00m 

$20.01m–$25.00m 

$25.01m–$30.00m

More than $30.00m

Prefer not to answer

Note: Numbers may not sum to 100%, because of rounding.

Source: Heidrick & Struggles US professional services partner compensation survey, 2024, n=155

Note: Numbers may not sum to 100%, because of rounding.  
Source: Heidrick & Struggles US professional services partner compensation survey, 2024, n=155

0

0

0 0

0

0

0

0

00

5

5

5

5

5

5

5

5

5 5

3

3

3

3

2

2

2

2

2

2

3

3

4

4

We also saw a positive correlation 
between personal revenue targets 
and tenure at current firm, with 
those who have been at their 
firm longer having higher targets 
than their less-tenured peers.

Personal revenue targets (%)

Diverse region, inclusive workforces: Diversity and inclusion policy and practice in Asia PacificHEIDRICK & STRUGGLES

7