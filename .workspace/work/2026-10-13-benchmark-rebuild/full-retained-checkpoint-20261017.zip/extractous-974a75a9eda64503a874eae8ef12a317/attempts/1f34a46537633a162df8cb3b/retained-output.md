64

SHARE OF GAMERS1 USING EACH PLATFORM FOR GAMING IN THE LAST 12 MONTHS, U.S., 2025, % GAMERS1 BY SEGMENT

24%

70%

89%

34%

56%

82%
87%89%93%

MOBILE

CONSOLE

PC

SUPER GAMERS2 AVID GAMERS3 CASUAL GAMERS4

1. “Gamers” are defined as adults aged 18+ who play video games.  2. “Super Gamers” are defined as gamers who view gaming as their 
primary source of entertainment and follow gaming content online.  3. “Avid Gamers” are defined as gamers who view gaming as one of 
a few equivalent options for entertainment, or gamers who view gaming as their primary source of entertainment but do not follow 
gaming content online.  4. “Casual Gamers” are defined as gamers who only view gaming as an entertainment option when other 
options are not available, or gamers who view gaming as one of a few equivalent options for entertainment but do not follow gaming 
content online. 
Sources: Activate analysis, Activate 2025 Consumer Technology & Media Research Study (n = 4,026)

VIDEO GAMING

Super Gamers play video games across all platforms, while Avid 
and Casual Gamers primarily use mobile