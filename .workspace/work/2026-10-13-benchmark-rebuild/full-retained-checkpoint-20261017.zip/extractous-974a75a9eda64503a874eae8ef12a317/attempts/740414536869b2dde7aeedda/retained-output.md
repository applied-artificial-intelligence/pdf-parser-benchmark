SDG INDICATORS

Below we provide select examples of how our sustainability and social impact programs support the SDGs, a collection of 
17 global goals intended to provide a shared blueprint to achieve a better future for all.

UN SDG 3: Good Health & Well-Being

Governance
Supply Chain: Management of chemicals is part 
of our supplemental health and safety guide
Product Safety: Management of chemicals in 
consumer products
People
Comprehensive Total Rewards
Employee Health & Well-Being: Mental Health: 
Our Employee Assistance Program (EAP) 
supports emotional well-being

UN SDG 4: Quality Education

Governance
Digital Wellness & Responsible Content: Digital 
wellness education grants
People
Employee Engagement & Inclusion
Talent Development

UN SDG 5:Gender Equality

Governance
Corporate Governance
Human Rights: Our Human Rights policy 
specifies that we do not tolerate gender 
discrimination
People
Comprehensive Total Rewards: Equitable Pay 
Commitment: Our 2024 adjusted pay ratio 
analysis includes gender
Environment
Nature: Contribution to Jane Goodall's Roots & 
Shoots youth-led action program and funding 
awards that recognize trailblazing women in 
conservation globally

UN SDG 6: Clean Water & Sanitation

Environment
Water:

– Watershed Stewardship
– Water Conservation

Sustainable Design

UN SDG 7: Affordable & Clean Energy

Environment
Emissions
Sustainable Design:

– Disney Lookout Cay
– Disney's Fort Wilderness Resort

UN SDG 8: Decent Work & 
Economic Growth

Governance
Ethics: Global Anti-Bribery and 
Anti-Corruption Policy
Human Rights: Our Human Rights Policy is 
informed by leading global principles on 
fundamental human rights and international 
labor rights
Supply Chain: International Labor Standards and 
Supply Chain Investment Program
Workplace Safety
People
Comprehensive Total Rewards:

– Equitable Pay Commitment
– Wages For Hourly Employees

Employee Engagement & Inclusion
Talent Development

UN SDG 10: Reduced Inequalities

Governance
Human Rights: Human Rights Policy
People
Comprehensive Total Rewards: Equitable Pay 
Commitment: Our 2024 adjusted pay ratio 
analysis includes gender, race, and ethnicity
Employee Engagement & Inclusion
Talent Development

UN SDG 11: Sustainable 
Cities & Communities

Environment
Emissions
Sustainable Design:

– New York City building
– Disney Lookout Cay

UN SDG 12: Responsible 
Consumption & Production

Governance
Product Safety: Management of chemicals is part 
of our supplemental health and safety guide
Environment
Water: Water Conservation
Waste
Materials
Sustainable Design:

– Disney Lookout Cay
– Disney's Fort Wilderness Resort

Nature: ourHOME campaign 

UN SDG 13: Climate Action

Environment
Emissions:

– Pathway to Net Zero Emissions for Direct 
Operations (Scope 1 & 2)

– Reducing Scope 3 Emissions and Engaging 
Suppliers and Licensees

Sustainable Design: Disney Lookout Cay 
includes on-site solar panels equipped with 
battery storage

UN SDG 14: Life Below Water

Environment
Water
Sustainable Design: Disney Lookout Cay 
includes an innovative open-trestle pier that 
extends to deep water
Nature: ourHOME campaign

UN SDG 15: Life on Land

Environment
Emissions
Sustainable Design: Disney Lookout Cay
Nature

UN SDG 16: Peace, 
Justice & Strong Institutions

Governance 
Corporate Governance
Ethics:

– Our Standards of Business Conduct
– Anti-Corruption

Human Rights: Human Rights Policy
Supply Chain: International Labor Standards

UN SDG 17: Partnerships for the Goals

Approach
Stakeholder Engagement & Participation
Environment
Nature

Table of 
Contents

Introduction & 
Our Approach

Governance

People

Environment

Data & 
Frameworks

Fiscal 2024 
Data Table

SASB Index

TCFD Index

SDG Indicators

40