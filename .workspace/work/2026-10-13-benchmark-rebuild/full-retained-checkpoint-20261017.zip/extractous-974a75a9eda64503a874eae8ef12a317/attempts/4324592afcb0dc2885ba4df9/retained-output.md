FoX: Formation-aware exploration in multi-agent reinforcement learning

Yonghyeon Jo, Sunwoo Lee, Junghyuk Yum, Seungyul Han*

Artificial Intelligence Graduate School, UNIST, Ulsan, South Korea
{whdydgus9, c176111, yumjunghyuk, syhan}@unist.ac.kr

Abstract

Recently, deep multi-agent reinforcement learning (MARL)
has gained significant popularity due to its success in vari-
ous cooperative multi-agent tasks. However, exploration still
remains a challenging problem in MARL due to the partial
observability of the agents and the exploration space that
can grow exponentially as the number of agents increases.
Firstly, in order to address the scalability issue of the explo-
ration space, we define a formation-based equivalence rela-
tion on the exploration space and aim to reduce the search
space by exploring only meaningful states in different forma-
tions. Then, we propose a novel formation-aware exploration
(FoX) framework that encourages partially observable agents
to visit the states in diverse formations by guiding them to
be well aware of their current formation solely based on their
own observations. Numerical results show that the proposed
FoX framework significantly outperforms the state-of-the-art
MARL algorithms on Google Research Football (GRF) and
sparse Starcraft II multi-agent challenge (SMAC) tasks.

1 Introduction
In recent years, multi-agent reinforcement learning (MARL)
has successfully solved various real-world application chal-
lenges such as traffic control (Chu et al. 2019; Wang et al.
2019b), games (Vinyals et al. 2019), and robotic controls
(Kalashnikov et al. 2018). With its increasing popularity,
many multi-agent learning algorithms have been introduced
(Tan 1993; Lowe et al. 2017; Rashid et al. 2018). The
MARL algorithms can be broadly classified into three cat-
egories. First, the fully decentralized methods (Tan 1993;
Zhang et al. 2018a) train agents independently. Second, the
fully centralized methods (Gupta, Egorov, and Kochender-
fer 2017) share information among agents for more efficient
training. Finally, The CTDE methods (Foerster et al. 2018;
Sunehag et al. 2017; Rashid et al. 2018) provide global infor-
mation during training to alleviate the nonstationarity while
maintaining scalability. As a result, MARL algorithms have
achieved significant success in various applications.

However, MARL algorithms still face challenges from
partial observability (Sukhbaatar, Szlam, and Fergus 2016).

*Corresponding author
Copyright © 2024, Association for the Advancement of Artificial
Intelligence (www.aaai.org). All rights reserved.

Exploration Space 

Equivalent States

Formation
Agent
Exploration

(a)

Exploration w/o 
Formation-awareness

Formation

Sight
Agent

Formation-aware 
Exploration (ours) 

(b)

Figure 1: (a) Illustration of formation-based state equiv-
alence. Defining state equivalence under formations can
reduce the search space efficiently. (b) Illustration of
formation-awareness. Our method encourages agents to be
fully aware of the formation.

Even in the traditional RL, exploration is critical to pre-
vent the agent from converging to sub-optimal policies (Os-
trovski et al. 2017). To address exploration in traditional
RL, exploration methods based on curiosity (Ostrovski et al.
2017; Pathak et al. 2017; Burda et al. 2019a) have been pro-
posed. Among the curiosity explorations, count-based ex-
ploration has demonstrated simple yet efficient exploration
in single-agent RL problems (Burda et al. 2019a; Tang
et al. 2016). Unfortunately, the single-agent approaches may
struggle in the context of MARL as partial observability
makes efficient exploration even more challenging. As con-
sideration for agent relationships exponentially increases the
search space, (Wang et al. 2019a) techniques such as uti-
lizing the influence between agents (Wang et al. 2019a) or
social influence (Jaques et al. 2018) have been introduced,
but despite these efforts, efficient exploration in MARL still
remains a challenge (Zheng et al. 2021).

In realistic scenarios, soccer for example, it is often im-
practical to consider the entire information of the field upon
formulating a strategy. Rather, coaches formulate strategies
based on a formation, which contains the distance infor-
mation between the players in soccer games. Thus, in this
soccer game, formation information is critical to winning

ar
X

iv
:2

30
8.

11
27

2v
1 

 [
cs

.L
G

] 
 2

2 
A

ug
 2

02
3