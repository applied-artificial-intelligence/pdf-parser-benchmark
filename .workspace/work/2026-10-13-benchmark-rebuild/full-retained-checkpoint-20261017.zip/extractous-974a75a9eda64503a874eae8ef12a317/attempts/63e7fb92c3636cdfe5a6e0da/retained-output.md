2023 SENIOR VICE PRESIDENTS & ABOVE2

RACIAL/ETHNIC DIVERSITY

ASIAN (US)

BLACK/AFRICAN AMERICAN (US)

HISPANIC/LATINX (US)

2023 US WORKFORCE DIVERSITY2

RACIAL/ETHNIC DIVERSITY

ASIAN

BLACK/AFRICAN AMERICAN

HISPANIC/LATINX 

OTHER4

WHITE

GENDER DIVERSITY

MEN  

WOMEN

BOARD OF DIRECTORS DEMOGRAPHICS5

RACIAL/ETHNIC DIVERSITY

WHITE (8)

BLACK/AFRICAN AMERICAN (4)

GENDER DIVERSITY

MEN (8)

WOMEN (4)

Global workforce diversity
We work to create a culture built on supportive relationships and an 
inclusive workplace, as reflected by our Blue Box Values. We regularly 
disclose representation data on our global workforce to provide 
transparency, including our EEO-1 data and other information featured 
in this report and our annual proxy statement.

Hiring, promotions, and retention
Our focus is on fostering an inclusive and equitable culture for all colleagues. 
As part of our commitment to ongoing transparency, we provide detailed 
disclosures on hiring, promotion, and talent retention rates, including across 
genders globally and disaggregated data by race and ethnicity in the US. 

 

INTRODUCTION OUR APPROACH TO CORPORATE SUSTAINABILITY FINANCIAL CONFIDENCE CLIMATE SOLUTIONS DIVERSITY, EQUITY, & INCLUSION GOVERNANCE & OPERATING RESPONSIBLY SUPPORTING DATA 46

16.9%

7.4%

6.6% 2023 HIRING, PROMOTIONS, AND RETENTION RATES

W
O

M
E

N
 G

LO
B

A
LL

Y

M
E

N
 G

LO
B

A
LL

Y

U
S

 A
S

IA
N

2

U
S

 B
LA

C
K

/A
FR

IC
A

N
 

A
M

E
R

IC
A

N
2

U
S

 H
IS

P
A

N
IC

 O
R

 
LA

T
IN

X
2

U
S

 O
T

H
E

R
2,

 4

U
S

 W
H

IT
E

2

NEW COLLEAGUE 
HIRES 51% 49% 28% 17% 18% 4% 33%

COLLEAGUE 
PROMOTIONS 49% 51% 25% 11% 13% 3% 48%

COLLEAGUE 
RETENTION 90% 92% 96% 85% 91% 89% 94%

66.7%

33.3%

66.7%

33.3%

Since 2016, American Express has been included in the Bloomberg 
Gender-Equality Index (GEI), The GEI highlights public companies 
committed to disclosing their efforts to support gender equality through 
policy development, representation, and transparency.

44.1%

55.9%

2 Based on self-identified characteristics. 
3 Based on data for the 2023 US EEO-1 submission for Black/African American, Hispanic/Latino, Asian, Native American or Alaskan Native, Native Hawaiian or Pacific Islander, and two or more races (based on self-identified characteristics).
4 Other includes colleagues that self-identify as Native American or Alaskan Native, Native Hawaiian or Pacific Islander, or two or more races.
5 Based on self-identified characteristics. Data is following our May 6, 2024 annual meeting.

20.6%

15.6%

14.3%

3.6%

45.9%

For our full US Workforce Employer Information Report (EEO-1) 
data, refer to the Supporting Data section of this report.

2023 GLOBAL WORKFORCE HIGHLIGHTS

53% 50%
of our total 

global workforce
are women

of our Executive Committee 
are women or from 

diverse races and ethnic 
backgrounds2

54%
of our US workforce are 
from diverse races and 
ethnic backgrounds3