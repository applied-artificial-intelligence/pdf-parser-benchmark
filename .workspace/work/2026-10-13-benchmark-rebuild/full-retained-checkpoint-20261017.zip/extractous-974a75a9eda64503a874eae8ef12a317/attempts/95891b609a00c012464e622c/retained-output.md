THIS  

IS SKF

BACK TO  

START

PRESIDENT’S  

LET TER

VALUE CRE ATION 

AND STR ATEGY

THE BE ARING  

MARKET

RISKS AND 

THE SHARE

SUSTAINABILIT Y  

REPORT

CORPOR ATE 

GOVERNANCE

REMUNER ATION

REPORT

GROUP  

DATA

FINANCIAL  

STATEMENTS

Our offering

• Supplying more than 40 industries globally with products and 

services, both directly and indirectly through a network of more 

than 7,000 distributors.

• Broad product range of bearings, seals and lubrication systems.

• Rotating shaft services and solutions for machine health 

assessment, reliability  engineering and remanufacturing.

Our position

A leading position in industries such as railway, heavy industries 

and industrial distribution market, and a prominent position in 

other industries.

The Industrial business

1) Adjusted for items affecting comparability.   2) Total value of accessible bearings market.

The Automotive business

Our offering

• Customized bearings, seals and related products for e-powertrain, 

driveline, engine, wheel-end, suspension and steering applications 

to manufacturers of electrical vehicles and commercial vehicles.

• Supplying the vehicle aftermarket with spare parts, both directly 

and indirectly through a  network of more than 10,000 distributors.

Our position

One of the leaders in highly innovative bearing products to drive the 

shift to automotive electrification and ensure the highest efficiency 

in commercial vehicles. A strong global position in the aftermarket 

with an extensive product assortment and distribution network.

150–170
Bearings market value2), SEK bn

+8–10%
Bearings market  development 2023

29%
Share of net sales

12%
Share of operating profit1)

305–325
Bearings market value2), SEK bn

+0–2%
Bearings market  development 2023

71%
Share of net sales

88%
Share of operating profit1)

6SKF ANNUAL REPORT 2023