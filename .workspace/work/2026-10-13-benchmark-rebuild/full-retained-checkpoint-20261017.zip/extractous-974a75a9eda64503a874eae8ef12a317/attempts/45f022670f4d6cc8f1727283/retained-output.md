What Next for the Global Car Industry? Chapter 1: The global car industry 
An Energy Technology Perspectives Special Report in context 
 

36 

I E
A.

 C
C

 B
Y 

4.
0.

 

Figure 1.10 Revenues and profits for global original equipment manufacturers, 2016-
2024 

 
IEA. CC BY 4.0. 

Notes: OEM = original equipment manufacturer. Data taken from a sample of the 26 largest automakers with revenues 
accounting for nearly three-quarters of global sales. China: BYD, Changan, Dongfeng, GAC, Geely, Great Wall, 
Leapmotor, Li Auto, SAIC, Seres Group. North America: GM, Ford. Europe: BMW Group, Mercedes-Benz, Renault-Nissan 
Alliance, Stellantis, VW Group. Japan: Honda, Mazda, Mitsubishi, Subaru, Suzuki, Toyota. Other: Tata Group (India), 
Hyundai (Korea). Chery and FAW (China) are excluded since these are state-owned and there is no financial data reported 
after 2020. The sales from these companies account for around 80% of the global car market. Numbers are adjusted for 
inflation to 2024. 
Source: IEA analysis based on Bloomberg Terminal. 
 

Automotive suppliers tend to have profit margins that are lower than those 
experienced by OEMs in advanced economies, partly as a result of strong 
competition. Chinese automotive suppliers are nearly all related to battery 
manufacturing and have been leaders in terms of net profit margins, with several 
companies reaching margins of over 20% in the past 10 years.5 The average 
profitability of Chinese suppliers has been lower, at around 6-7% for most years 
since 2016, although this trend has been broken in the past 2 years to reach more 
than 10% in 2024. In addition, while North American and European suppliers have 
not recovered their pre-pandemic profitability, the average profitability of Chinese 
suppliers has grown, led by CATL, the world’s largest battery manufacturer. CATL 
has experienced unprecedented growth since it first started generating revenues 
in 2015, becoming a market leader in 2024. The year 2024 was the first in which 
CATL experienced a decline in total revenues – driven by declining battery prices 
– after experiencing sixfold growth between 2020 and 2022. CATL’s net profit 
margin has been around or above 10% ever since 2015. This is very high 
compared to other automotive component suppliers: since 2020, the average 
profitability of the five largest diversified suppliers by revenue has been around 
2.5%. In contrast, among specialised companies (such as those supplying 

 
 

5 CATL in 2016-2017, Gotion High-tech in 2014-2016 and Eve Energy in 2019-2020. 

0

 500

1 000

1 500

2 000

2 500

3 000

2016 2018 2020 2022 2024

Bi
llio

n 
U

SD
 (2

02
4,

 M
ER

)

Global OEMs' revenues per region

Europe North America Japan China Other Total (nominal)

0

 50

 100

 150

 200

 250

 300

2016 2018 2020 2022 2024

Global OEMs' profits per region