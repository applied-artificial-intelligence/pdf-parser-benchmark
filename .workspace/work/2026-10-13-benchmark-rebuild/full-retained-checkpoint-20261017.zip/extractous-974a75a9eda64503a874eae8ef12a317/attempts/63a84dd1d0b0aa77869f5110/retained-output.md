Transaction Rationale (cont’d)

Source: Company Information
Notes: (1) As at 30 June 2024. (2) Financial year ended 31 March. (3) Information as of 31 December 2023. (4) 5 assets under ESR Japan’s balance sheet and 34 assets under funds managed by ESR Japan (5) As 
at 1 July 2024. (6) Unitholders should note that the data and information provided by Wood Mackenzie should not be interpreted as advice and Unitholders should not rely on it for any purpose. No person may copy or 
use this data and information except as expressly permitted by Wood Mackenzie in writing. To the fullest extent permitted by law, Wood Mackenzie accepts no responsibility for the use of this data and information by 
any person. (7) Chinese production is typically for the domestic market.

74.4%

16.7%

8.9%

75.0%

21.3%

3.7%

1H2024
(by AUM)

After the Acquisitions
(by AUM)

Australia

Singapore

Japan

Increase E-LOG’s exposure to Nagoya logistics market1

Map of Japan

Tokyo

Osaka

Nagoya

2 Nagoya is a key hub with great access to domestic and 
international markets

 Strategically located in central Japan 
connecting Greater Tokyo and Greater Osaka, 
allowing it to access both domestic and 
international markets

 Renowned for its automotive sector which 
accounts for about 30% of the national 
manufacturing shipment value

 The New Japan Property is located in the 
Bay Area of Greater Nagoya, where the Port 
of Nagoya is located

Income Stability from High-Specs Space Leased to REC Solar…

7,389
6,296

9,506 9,613 8,815

3,888 4,318 4,624 4,641 4,541

FY20 FY21 FY22 FY23 FY24
EBITDA Net Profit

(JPYm)

EBITDA FY20-24A CAGR: +4.51%

Net Profit FY20-24A CAGR: +3.96%

c. 40% Anchored by significant logistics player Meiko Trans3 4 E-LOG can tap on ESR Japan’s on the ground expertise

Meiko Trans is a Japanese Logistics Company with a Market Cap 
of c. JPY44,732m(1)

Financial Highlights(1)(2)

1) Extensive Port Operations

2) Largest Warehouse Capacity

3) Operates in Growing 3PL Sector

4) Financial Stability

ESR Japan will be the 
Asset Manager and 
Property Manager 
for the New Japan 
Property

ESR Japan in Numbers

ESR Japan Expertise
1) One stop solution executed by >80 

local experts
2) Proprietary Japan Logistics Market 

Database
3) Strong presence & track record

JPY 1,206bn(3)

AUM (Logistics only)

4.5m sqm
Developed assets GFA

39(4)

Logistics Assets

18
Years in Japan

Long-term lease provides long term rent stability and 
sustained organic growth through rent escalations1 2 Strong tenant covenant as a 100% subsidiary of a Fortune 

500 company

High specifications manufacturing facility is
100% leased to REC Solar

Duration of lease
from 10 January 2019

to 21 June 2038

c. 19 years

Option for lease
renewal

20 years
Average

1.15% p.a.
Rent escalations from

1 December 2024

88th
On Fortune Global 500

list of the world’s biggest
corporations as of 2023

US$253bn 
market cap(5)

Largest publicly traded
company in India by
market capitalisation

Exposure to growing PV industry3 4 Commitment to properties shown from significant 
investments

 Ranks within top 20 module 
producers and capacity 
availability

 Ranked globally as the second 
largest producer, excluding 
Chinese production(7)

Global solar PV installations(6)

Responsible for all 
property outgoing 

expenses

Expected to 
increase its 

investment over 
the rest of 2024

Significant 
investments in its 

plant and machinery 
equipment since 2009

2022 2032

10Y CAGR 

+4.0%

REC Solar:

… as Anchor Tenant on Long Term Lease with In-Built Rental Escalations

Acquisitions will significantly improve E-LOG’s key portfolio 
metrics:
Scale up Japan presence with sizable freehold asset while tapping on ESR 
Japan’s on the ground expertise for economies of scale

5.3

Acquisitions will significantly improve E-LOG’s key portfolio 
metrics:
New Singapore Property with occupancy of 99.7% provides income stability 
and in-built rental escalations

5.4

05