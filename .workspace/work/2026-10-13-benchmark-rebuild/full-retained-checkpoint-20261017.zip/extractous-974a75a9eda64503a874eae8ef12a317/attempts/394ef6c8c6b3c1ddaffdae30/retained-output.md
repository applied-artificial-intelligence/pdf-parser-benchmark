29 

However, our primary data source does not contain balance sheet information 
that would allow us to replicate this analysis. 

2.49 We have therefore conducted supplementary analysis using Bureau van Dijk’s 
FAME dataset and the methodology that we used in the CMA’s previous State 
of Competition report (2022). 

2.50 While our baseline methodological approach is more robust, Figure E.1 in the 
appendix shows that overall markup trends using this alternative data source 
and methodology are similar to our preferred baseline. Figure 13 below also 
shows that the relationship between markups and the labour share (which we 
can also calculate using FAME data) is comparable to what we find in our 
baseline data. 

Figure 13: Markups are consistently positively related to profits, overall debt, 
and the labour share, and negatively related to short-term liquidity 

Regression coefficients of markups on Berry ratio, debt ratio, liquidity ratio and 
labour share under different model specifications. Controls include year fixed effects, 
firm fixed effects, and observations weighted by turnover. Data from Bureau van 
Dijk’s FAME 2013-2023. UK   

 
 

https://www.gov.uk/government/publications/state-of-uk-competition-report-2022
https://www.gov.uk/government/publications/state-of-uk-competition-report-2022