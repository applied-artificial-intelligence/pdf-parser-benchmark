 185 

 

DO ADULTS HAVE THE SKILLS THEY NEED TO THRIVE IN A CHANGING WORLD? © OECD 2024 
  

Figure 4.20. Relationship between over-qualification and life satisfaction 

Change in likelihood of over-qualified workers reporting high life satisfaction 

 

Note: Employed adults aged 25-65 who are not self-employed; does not include adults who were only administered the doorstep interview due 

to a language barrier (see Box 1.1 in Chapter 1 and Box 4.1). Over-qualification is defined in Table 4.2 and Box 4.3. Life satisfaction is defined 

in Box 4.2. Estimates account for age, gender, immigrant background, whether one lives with a partner or has children and (log) wages. Darker 

colours denote differences that are statistically significant at the 5% level. *Caution is required in interpreting results due to the high share of 

respondents with unusual response patterns. See the  ote for Poland in the Reader’s Guide. 

Countries and economies are ranked in descending order of the effect of over-qualification on life satisfaction. 

Source: Table A.4.17 of Annex A.  

  

 

2

0

 2

  

  

 8

 10

 12

 1 

S
lo
 a

k 
R
ep

ub
lic

 
ew

  
ea

la
nd

It
a
ly

 
at
 i
a

 i
th
ua

n
ia

S
in
g
a
po

re

F
in
la
nd

 
or
w
ay

C
 e

ch
ia

 
et
he

rl
a
nd

s

C
an

ad
a

E
st
o
ni
a

S
w
e
de

n

E
ng

la
nd

 (
U
 
 

C
ro
at
ia

 
e
nm

ar
k

S
p
ai
n

Is
ra
e
l

 
E
C
 
 a
ve

ra
g
e

F
ra
n
ce

P
or
tu
ga

l

G
er
m
a
ny

P
o
la
nd

 

A
us

tr
ia

C
hi
le

 a
p
an

H
un

g
a
ry

 
or
ea

S
w
it 

e
rl
a
nd

F
le
m
is
h 
R
e
gi
o
n 
( 

E
 

Ir
el
a
nd

U
ni
te
d 
S
ta
te
s

Percentage points