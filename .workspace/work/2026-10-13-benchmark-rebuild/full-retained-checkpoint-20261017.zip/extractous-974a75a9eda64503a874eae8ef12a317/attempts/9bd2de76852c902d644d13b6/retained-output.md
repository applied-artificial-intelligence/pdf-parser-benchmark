How much news do people see on each platform? 

Facebook tells us that about 4% of the content of the average person’s 
feed comes from news outlets, though for some that proportion will 
be much higher.9 Twitter does not provide equivalent data, but our 
survey shows that across markets it has a high proportion (56%)  
who use it for news weekly. By contrast, only around four in ten 
(39%) Instagram users access news via the platform weekly and just 
a third of TikTok users do the same (33%). But do people think they 
are seeing too much or too little news in these networks?10 

More than a fifth of UK respondents (21%) feel that they see too 
much news on Facebook and only 3% would like to see more. 
Facebook has been trying to reduce the amount of news on the 
platform partly for reputational reasons but also because, as 
previous research shows, people are mainly there to connect with 
friends and family rather than consume news. On the other hand, 
Twitter is seen as having more of a reputation for news so it is 
somewhat surprising to find one in ten (11%) saying they see too 
much. There is a clear link with news avoidance: those who often 
avoid the news are twice as likely to say they see too much news on 
both Facebook and Twitter when compared with the average user.

These data suggest the ambivalent relationship many people have 
with news on social media. It drives much of the conversation 
and engagement but can also interrupt other activities and 
create arguments. This dilemma may be one of the factors 
behind Facebook’s recent decision to create a separate tab in five 
countries (Facebook News) with content from a selection of partner 
publishers, in parallel with an ongoing string of decisions in recent 
years to reduce the amount of news in the main ‘Feed’ (recently 
renamed from ‘News Feed’). Platforms like Twitter might also need 
to think about why even some people who love the news want to see 
less of it, given the network’s reputation for often abusive debate. 
TikTok and Instagram will also be aware, as they grow, of the careful 
balance they need to strike if they are not to put people off.

9 https://www.cnbc.com/2018/01/19/facebooks-news-feed-survey-users-to-find-high-quality-news.html
10 We did ask respondents directly to estimate how much news they saw in each of their social media feeds, partly to prime them for this subsequent question about too much/too little. 

We have preferred to use data on the proportion who say they use each network for any purpose/for news as they show similar trends and are data we collect every year.

REUTERS INSTITUTE FOR THE STUDY OF JOURNALISM / EXECUTIVE SUMMARY GRAPHS

Graph 35

PROPORTION WHO THINK THEY SEE TOO MUCH NEWS  
ON EACH NETWORK – UK

Q12_Social_rightsize ... Do you think that the amount of content you see from news outlets on 
<social network>. is too much, about right, or not enough? Base: All that use each social network: 
Facebook = 1501, Twitter = 685, Instagram = 859, TikTok = 270.

8%

20%

66%

6%

9%

20%

65%

6%

Facebook Twitter Instagram TikTok

21%

20%

55%

3%

11%

13%

73%

3%

Too much About right Not enough Don’t know

Twitter

India 23%

Australia 23%

South Africa 19%

South Korea 15%

Belgium 14%

Facebook

Portugal 26%

USA 22%

Hungary 21%

UK 21%

Australia 20%

Canada 20%

Top markets  
saying too much

REUTERS INSTITUTE FOR THE STUDY OF JOURNALISM / EXECUTIVE SUMMARY GRAPHS

Graph 36

PROPORTION WHO SAW FALSE OR MISLEADING 
INFORMATION ABOUT EACH TOPIC IN THE LAST WEEK – 
SELECTED REGIONS

Q. FAKE_NEWS 2021a. Have you seen false or misleading information about any of the 
following topics, in the last week? Base: Total sample in each region: Europe = 48,836, North 
America = 4048, Asia = 20,349, Latin America = 12,104, Africa = 6057. Note: Africa average is Kenya, 
South Africa, and Nigeria only (English speakers in South Africa and Nigeria). 

COVID-19 47%
53%

45%
54%

47%

Politics 34%
43%

42%
51%

49%

Celebrities 20%
22%

29%
33%

48%

Climate  
change

19%
32%

15%
21%

19%

Immigration 20%
27%

9%
18%

16%

Products  
(e.g. scams)

16%
19%

22%
26%

29%

Europe North America Asia Latin America Africa

MISINFORMATION 

In this year’s survey we find a link between online misinformation fears 
and the widespread use of social media. Across markets, just over half 
(54%) say they worry about identifying the difference between what is 
real and fake on the internet when it comes to news, but people who 
say they mainly use social media as a source of news are more worried 
(61%) than people who don’t use it at all (48%). Additionally, regions 
with the highest levels of concern – Africa and Latin America – 
correspond closely with high levels of social media news use. This is 
not to say that social media use causes misinformation, but that 
usage may generate awareness of and potential exposure to false 
information, including giving voice to extreme perspectives that 
previously would not have been widely heard.

When looking at the types of misinformation that people claim to 
see, we find that dubious health claims around COVID-19, including 
from anti-vaccination groups, are, as in 2021, still most widespread 
across most regions, ahead of politics. Notable exceptions are in 
Kenya – where political misinformation is more widely seen – as well 
as Colombia and the Philippines, both countries where elections 
were held this year. 

Reuters Institute for the Study of Journalism   |   Digital News Report 202226