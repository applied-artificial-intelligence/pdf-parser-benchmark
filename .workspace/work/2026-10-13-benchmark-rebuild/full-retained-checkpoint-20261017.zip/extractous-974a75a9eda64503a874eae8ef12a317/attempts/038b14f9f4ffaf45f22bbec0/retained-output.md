Mandiant M-Trends 2025 Report 21

Most Frequently Seen Malware Families
For the fifth consecutive year, BEACON was identified as the most frequently observed malware 
family in Mandiant investigations globally and was identified in 5.4% of all intrusions. BEACON usage 
has decreased dramatically since 2021, when it was observed in 28% of Mandiant investigations. 

30

20

10

0
2020 2021 2022 2023 2024

24%
28%

15%

10%

5%

BEACON Usage, 2020-2024

Most Frequently Seen Malware Families, 2024
6

4

2

0
BEACON GOOTLOADER WIREFIRE SYSTEMBC REDBIKE

(Akira)
RANSOMHUB LOCKBIT BASTA

5.4%

2.5% 2.5%

1.8% 1.8% 1.8% 1.6% 1.6%

Most Frequently Seen Malware Families, 2024

Of note, in July of 2024, Europol12 provided an update on Operation MORPHEUS, a global action 
against the illicit use of the unlicensed versions of the Cobalt Strike red teaming tool. This  
operation, conducted with law enforcement and private sector partners, successfully disrupted 
infrastructure linked to cyber criminal activities. The initiative, which began in 2021, involved  
flagging 690 IP addresses, 593 of which were taken down by online service providers. Fortra,13 
the maintainers of the Cobalt Strike framework, also announced the number of unauthorized 
copies of Cobalt Strike observed in the wild has decreased by 80% over the past two years as a 
result of their participation in Operation MORPHEUS. Observed declines in percentages of inves-
tigations where Mandiant identified BEACON since 2021 may reflect the success of this effort.