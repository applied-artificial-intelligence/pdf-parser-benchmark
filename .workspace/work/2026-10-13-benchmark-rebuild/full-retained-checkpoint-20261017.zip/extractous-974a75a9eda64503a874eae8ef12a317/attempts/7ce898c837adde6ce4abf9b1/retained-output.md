At A Glance

Bangalore

• International Tech Park Bangalore 
(ITPB)

• CapitaLand Data Centre ITPB

HEBBAL

KOTHNUR

KRISHNARAJAPURAM

BANASHANKARI

KORAMANGALA

ULLAL

YESWANTHPUR PERAMBUR
VILLIVAKKAM

CHROMEPET

GERUGAMBAKKAM

THORAIPAKKAM

THIRUVANMIYUR

Chennai

• International Tech Park Chennai 
(ITPC)

• CyberVale (CV)
• CapitaLand Data Centre Chennai
• Industrial Facility 1, Mahindra 

World City (IF1, MWC)
• Industrial Facility 2 and 3, Mahindra 

World City (IF2 and IF3, MWC)

MIYAPUR

SECUNDERABAD

DAMMAIGUDA

MADHAPUR

VANASTHALIPURAM

Hyderabad

• International Tech Park 
Hyderabad (ITPH)

• CyberPearl
• aVance Hyderabad
• CapitaLand Data Centre ITPH

NAVI MUMBAI

MULUND WEST
ANDHERI WEST

THANE

DOMBIVLI

WASHI

PALASPA

PANVEL

DADAR

Mumbai

• Building Q1, Aurum Q Parc
• Building Q2, Aurum Q Parc1 

CapitaLand Data Centre Navi 
Mumbai

• Logistics Park

KOTHRUD

WAGHOLI

KHARADI

DEHU ROAD

BIBWEWADI

Pune

• International Tech Park Pune 
Hinjawadi (ITPP-H)

• aVance I, Pune
• aVance II, Pune2

1 Building Q2, Aurum Q Parc was acquired in July 2024.
2      aVance II, Pune was acquired in March 2024.For more details on our portfolio, go to pages 38 to 41.

S$3.7 billion 21.9 million sq ft
Assets under management

10
IT Parks

18
Diversified World 
Class Assets

4
Industrial and 
Logistic Facilities

4
Data Centre 
Developments

Completed floor area

5
Top Tier Cities

2 CapitaLand India Trust