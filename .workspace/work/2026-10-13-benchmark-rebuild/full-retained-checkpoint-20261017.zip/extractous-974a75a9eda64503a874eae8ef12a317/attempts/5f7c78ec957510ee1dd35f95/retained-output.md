21 
 

 

Figure 5.  

Comparison of yields at issuance of SURE bond issuances with equivalent ESM benchmark yields 
 

 

Source: ESM, European Commission 
 

Having considered the differing uptake between the PCS and SURE instrument, a follow-up 

workstream could be initiated to address the stigma concern related to the ESM role. Important 

elements of this work would include possible refinements of the ESM precautionary toolkit and 

processes, which are analysed in the following section. 

 

2.1.5 Possible refinements of the ESM precautionary instruments  

The emerging challenges for the euro area as well as lessons learned from the design of PCS provide 

a starting point for considering refinements to precautionary instruments. Vulnerabilities that could 

manifest from risks such as climate change, geopolitics, and geoeconomic fragmentation pose a 

particularly uncertain outlook for the euro area. At the same time, the stigma associated with ESM 

support hampers access to its instruments by its Members even in case of severe crises. Against this 

backdrop, the ability of the ESM toolkit to tailor responses to a multitude of contexts remains a vital 

safeguard. To ensure these instruments remain effective, their design could be refined in two areas: 

• By making good use of the confidential consultation procedure, including as a platform for 

group requests. 

• By analysing the merits of designing a new precautionary instrument. 

 

Use of confidential consultations to improve the effectiveness of the ESM precautionary instruments 

The process through which precautionary assistance is requested and granted is of crucial 

importance for its effectiveness. It ensures that the formal requirements of the ESM Treaty are 

respected. It can also provide prospective beneficiary ESM Members with more concrete information 

on potential ESM assistance before submitting an official request. The procedure to request the 

precautionary instruments under the revised Treaty can be summarised in Figure 6. 

 

0.0 %

0.5 %

1.0 %

1.5 %

2.0 %

-1.0%

-0.5%

0.0%

0.5%

1.0%

1.5%

2.0%

10yr 20yr 5yr 30yr 15yr 7yr 30yr 15yr 5yr 25yr 8yr 25.6yr 15yr

European Commission: SURE ESM Benchmark Yield of Equivalent Maturity

SURE #1 
20/10/20

SURE #2 
10/11/20

SURE #3 
24/11/20

SURE #4 
26/01/21

SURE #5 
09/03/21

SURE #6 
23/03/21

SURE #7 
18/05/21

SURE #8 
29/03/22