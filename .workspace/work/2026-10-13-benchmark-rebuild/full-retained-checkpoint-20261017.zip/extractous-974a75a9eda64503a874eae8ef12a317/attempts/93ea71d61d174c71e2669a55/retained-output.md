 13 

OECD ECONOMIC OUTLOOK, INTERIM REPORT MARCH 2025 © OECD 2025 
  

Figure 6. Household inflation expectations have recently risen in some countries 

 

Source: European Central Bank; Bank of Korea; Office for National Statistics; University of Michigan; and OECD calculations. 

Global financial conditions have tightened slightly and volatility has risen recently 

10. Global financial conditions have tightened slightly since late 2024, with market volatility increasing 

recently. 10-year government bond yields have risen in Europe, particularly after the recent announcement 

of substantial planned additional expenditures on defence and infrastructure in Germany and at the 

EU level. However, nominal bond yields in the United States have fallen since mid-January, unwinding the 

rise observed through the final months of 2024. Indicators suggest that the recent movement reflects a fall 

in real yields as economic growth slows, rather than lower inflation expectations. The US dollar has also 

fluctuated, with a depreciation against most currencies this year after a sustained rise through the final 

quarter of 2024 that contributed to tighter financial conditions in emerging market economies.  

11. Financial market stress has so far remained contained. Bank credit growth has gradually 

recovered from low levels in advanced economies, as the impact of easier monetary policy has transmitted 

to lending interest rates. Despite already-stretched valuations in some sectors and some recent price 

corrections, equity prices are still higher than in November 2024, particularly in Germany, Spain and Italy. 

Robust growth in corporate bond and leveraged loan issuance has signalled investor confidence and 

increased risk appetite, with the equity risk premium having fallen in the United States, the United Kingdom 

and in Europe. 

Projections 

Global growth is expected to soften and inflation to ease further 

12. Global GDP growth is projected to slow from 3.2% in 2024, to 3.1% in 2025 and 3.0% in 2026. 

New data and recent developments result in a downward growth revision from the December 2024 OECD 

Economic Outlook (Figure 7, Panel A). In quarterly terms, growth is expected to soften from the first quarter 

of 2025 and to remain subdued thereafter. The imposition of new bilateral tariff rates and the associated 

increase in policy and geopolitical uncertainty will act as a drag, particularly on business investment and 

trade. In addition, increased trade costs are expected to feed through gradually to final goods prices, 

putting additional upward pressure on inflation in many countries and requiring monetary policy to remain 

restrictive for longer than previously expected.