Chapter 3. Renewable heat Renewables 2025 
Analysis and forecasts to 2030 

PAGE | 213  I E
A.

 C
C

 B
Y

 4
.0

. 

The global solar heat for industrial processes (SHIP) market rebounded strongly 
in 2024, reaching a five-year high with a 30% increase in new installed capacity. 
A total of 106 new systems added 120 MWth, led by China with an 80-MWth 
parabolic trough project for a leisure park. Other highlights are Latin America’s first 
linear Fresnel plant in Mexico (111 kWth of capacity), producing 180°C steam; 
Germany’s demonstration plant, which began producing renewable fuels in 
September 2024 and has since secured several offtake agreements with airports 
and the shipping industry; Kenya’s 180-kW solar thermal system with 1 MWh of 
storage for a tea plantation; and a 4.1-MWth brewery in Spain that uses linear 
Fresnel collectors.  

In Croatia, construction began in 2024 on a winning Innovation Fund solar thermal 
project (combined with thermal storage, a waste heat recovery system and two 
heat pumps). However, despite the overall rise in SHIP capacity, the total number 
of new projects dropped slightly, mainly due to a 30% subsidy cut in the 
Netherlands that led to several project cancellations.  

At the end of 2024, the global SHIP market totalled 1 315 systems with a combined 
capacity of 1 071 MWth and 1.5 million m2 of collector area. The technology mix 
has also changed, with concentrating collectors making up 69% of new capacity, 
heavily influenced by the aforementioned large-scale project in China. The market 
is also trending towards larger systems, with average system size growing more 
than 40% in the past year alone.  

Annual industrial solar thermal capacity increases and number of commissioned SHIP 
projects, 2018-2024 (left), and regional shares of total industrial solar thermal capacity, 
2024 (right) 

IEA. CC BY 4.0. 

Note: SHIP = solar heat for industrial processes.  
Source: IEA Technology Collaboration Programme (2023), Solar Industrial Heat Outlook 2023-2026. 
 

0

20

40

60

80

100

120

0

 50

 100

 150

 200

 250

 300

2018 2019 2020 2021 2022 2023 2024

N
um

be
r o

f S
H

IP
 s

ys
te

m
s

M
W

Annual capacity increases and commissioned SHIP systems

Newly installed SHIP capacity Number of commissioned SHIP systems

0

 200

 400

 600

 800

1 000

1 200

M
W

Regional shares of total 
capacity, 2024

Rest of world

Central and
South
America
South Africa

China

https://synhelion.com/news/synhelion-inaugurates-dawn
https://www.absolicon.com/commissioned-solar-heat-from-absolicon-to-combat-drought-and-emissions-in-kenya/
https://newheat.com/en/projects/malthouse-in-croatia-group-boortmalt/
https://business.gov.nl/subsidy/sustainable-energy-investment-subsidy-isde/
https://solarthermalworld.org/news/global-ship-market-reaches-five-year-high-despite-national-fluctuations/
https://solarthermalworld.org/news/promising-solar-industrial-heat-outlook-2023-2026/