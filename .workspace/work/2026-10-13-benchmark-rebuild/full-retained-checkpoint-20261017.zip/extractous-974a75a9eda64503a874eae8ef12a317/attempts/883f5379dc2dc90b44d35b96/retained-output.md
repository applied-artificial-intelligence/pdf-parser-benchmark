Renewables 2025 Chapter 1. Renewable electricity 
Analysis and forecasts to 2030 
 

PAGE | 75  I E
A.

 C
C

 B
Y

 4
.0

. 

Governments are reluctant to accept EACs in emissions-based 
trade rules 
While internationally recognised GHG accounting frameworks increasingly 
accommodate EAC use, national governments remain hesitant about accepting 
foreign certificates, particularly in regulatory and trade-related contexts. 

The GHG Protocol, widely used by industry for corporate emissions reporting, 
defines two distinct approaches: location-based and market-based. The location-
based method relies on the average emissions factor of the local electricity grid, 
while the market-based approach allows companies to report lower emissions by 
procuring EACs regardless of the grid’s underlying emissions intensity. 

Corporate initiatives and industry platforms, including RE100, have largely allowed 
the market-based approach. RE100 permits the use of most recognised EAC 
systems globally, enabling multinational companies to claim 100% renewable 
electricity sourcing. However, conditions may apply to avoid double counting or 
ensure environmental integrity. For example, since May 2025, companies in China 
have been required to purchase both green electricity certificates and carbon-
offset certificates to meet RE100 requirements to avoid potential double counting. 

Illustrative example of the impact of EACs on the carbon footprint of CAN fertilisers 

 
IEA. CC BY 4.0. 

Notes: EAC = energy attribute certificate. CBAM = Carbon Border Adjustment Mechanism. We assumed a grid emissions 
factor of 561 g CO2-e/kWh, a price of EUR 70/t CO2-e for a CBAM certificate and EUR 0.3/MWh for an EAC. 
 

In contrast, national governments have shown greater reluctance to incorporate 
foreign-issued EACs into official GHG accounting methodologies, especially in 
sectors tied to trade-related regulations. This is particularly relevant in the context 
of emerging emissions-based trade rules and product-specific emissions 
standards, such as those under discussion in the EU Carbon Border Adjustment 
Mechanism (CBAM) or in the new Batteries Regulation.  

0

20

40

60

80

100

120

0.0

0.2

0.4

0.6

0.8

1.0

1.2

1.4

1.6

Without EACs With EACs
Fossil (coal-based) Grid-based

EU
R

/t

t C
O

2-
e/

t

Carbon
footprint

CBAM
costs

EAC costs