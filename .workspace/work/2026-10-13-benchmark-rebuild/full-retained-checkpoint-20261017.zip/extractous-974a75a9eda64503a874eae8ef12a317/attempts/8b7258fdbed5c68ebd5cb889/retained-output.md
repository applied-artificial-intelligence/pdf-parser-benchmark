Trendline

CDU/CSU
Germany

The Republicans
France

SDP Germany

Die
Grünen

Germany

Les Verts
France

Die Linke
Germany

Alternative
for Germany

Podemos
Spain

Ciudadanos
Spain

National
Rally

France

Brexit
Party‡
Britain

Conservatives
Britain

Labour
Britain

Lib Dems
Britain

Fidesz†
Hungary

Northern
League
Italy

Five Star Movement
Italy

Law & Justice
Poland

En Marche* France

Unsubmissive France

Parties in grey do not
belong to a group

Democratic Party Italy
Socialist Party
France

Italy’s Five Star 
Movement is a 
distinctive centrist, 
anti-EU outlier ↓

Anti-EU
↓

Far right → ← Far left Political ideology

Po
sit

io
n 

on
 th

e 
EU

↑
Pro-EU

Conservatives 
and Reformists

Europe of Freedom
& Direct Democracy

European
People’s
Party

Socialists and
Democrats

United Left/
Nordic Green Left

Greens/
European
Free Alliance

Alliance of Liberals
and Democrats/
Renaissance

Europe of Nations
and Freedom

*Includes MoDem and UDI     †Currently suspended from the EPP group   ‡Ideology and difference based on UKIP 2014 Sources: Chapel Hill Expert Survey (2014/2017); ECFR; European Parliament    

Parliamentary grouping 2019 election, provisional results, seats 10 20

Anti-EU parties cluster at ideological extremes, whereas pro-EU ones are centrist

European Parliament political parties and groupings
By ideology and position on the EU 

Party name

Change in seats from 2014 to 2019 elections
Selected parties, by position on the EU 

-10-15 -5 50 10 15 2520

-10-15 -5 50 10 15 2520

SDP 
Democratic Party Italy

Socialist Party

Les Verts

Alternative for Germany

National Rally

En Marche*

gained →  ← lost

Lib Dems

Fidesz

Unsubmissive France

 Five Star
Movement

Law & Justice

↑
Pro-EU

CDU/CSU

Podemos

The Republicans France

Die Linke

Labour

Conservatives

Northern League

Brexit Party‡

Die Grünen
Ciudadanos

Anti-EU
↓

Position on the EU

Strongly pro- and 
anti-EU parties 
won seats from 
the traditional 
centre-left and 

centre-right

nil

The Economist June 1st 2019 81

Eurosceptics hoped that populist par-
ties would sweep last week’s European

Parliament elections. But voters delivered
a murky verdict. Eurosceptics did make
progress: parties in the top 15% of hostility
towards the eu, as measured by a survey of
political scientists run by the University of
North Carolina at Chapel Hill, gained 30
seats. Yet parties in the most pro-eu 15%
won 32 extra seats. The losers were the
main centre-left and centre-right parties.

For the first time in the parliament’s
history, its two main blocs, the European
People’s Party and the Socialists and Demo-
crats, failed to achieve a majority between
them. In theory, that could turn the Euro-
sceptics into kingmakers. In practice, the
older parties back the eu and want nothing
to do with the populists. That will force

them to depend on the liberals instead.
Moreover, the pro-eu parties are likely to
form a more cohesive group than their ad-
versaries will.

Almost every possible mix of policy po-
sitions is present among the parliament’s
177 different parties. However, the Chapel
Hill survey shows that some combinations
tend to go together. Its authors assess par-
ties’ views on dozens of issues, and aggre-
gate them into ideological scores. The
study was last run in 2017, so its ratings do
not count recent political shifts. Nonethe-
less, its scores track well with other sur-
veys, and with parties’ own manifestos.

One pattern is the boomerang-shaped
relationship between views on the eu on
one hand, and older divides over economic
redistribution and cultural openness on
the other. Before the global financial crisis,
Euroscepticism won few votes. But the eu’s
bailouts of bankrupt member states and
struggles to absorb refugees linked opposi-
tion to European integration with hostility
towards bankers and foreigners. Sensing a
chance to broaden their scope, far-right
and far-left parties sharpened their criti-
cism of the eu, and Eurosceptic parties be-

came more radical on other issues.
As a result, today’s anti-eu parties

mostly land on either the far left (such as
Unsubmissive France) or far right (like the
Alternative for Germany). These two wings
will struggle to find common cause over
economic policy. The biggest exception, It-
aly’s Five Star Movement, sits in the centre
only because it combines policies from
both left and right extremes.

In contrast, the surging pro-eu parties,
including France’s En Marche and Britain’s
Liberal Democrats, have much in common.
They combine cultural liberalism with a
centrist economic agenda emphasising
equitable growth. These parties also tend
to back efforts to fight climate change,
making them natural allies of the Green
parties that gained seats across Europe.

European Parliament elections are
sometimes dismissed as a mere opinion
poll, since the body has much less power
than domestic legislatures do. In terms of
votes cast, pro- and anti-eu forces battled
to a draw. But the parliament also has real
duties, including approving the eu’s bud-
get and laws. By this measure, liberals may
have won the upper hand. 7

Centrist liberals, not populists, gained
the most power in the eu Parliament

An equal and
opposite reaction

Europe’s electionsGraphic detail

Issue Date: 01-06-2019 Zone: UKPB Desk: GraphicDetail Output on: 29-05-2019----18:36 Page: GD1 Revision: 0