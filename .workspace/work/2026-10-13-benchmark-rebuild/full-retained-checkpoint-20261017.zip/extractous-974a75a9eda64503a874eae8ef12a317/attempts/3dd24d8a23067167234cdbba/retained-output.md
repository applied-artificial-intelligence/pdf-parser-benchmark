The following graph illustrates the average occupancy rates in the Singapore CBD for the

period from 2010 to the third quarter of 2013.

Average Occupancy Rates in the Singapore CBD (%)

65%

70%

75%

80%

85%

90%

95%

100%

Shenton Way/Robinson Rd/Cecil StreetRaffles PlaceMarina Bay

Q3 2013Q2 2013Q1 2013201220112010

96.8%

94.4%

90.4%

70.3%

83.6%

90.9%

84.1%(1)

95.3%

97.7%

94.8%
94.3%

95.2%

91.6%

93.3%
93.6%

88.5%

91.2%

93.7%

Note:

(1) Due to the completion of Asia Square Tower 2 in the third quarter of 2013.

Source: Independent Market Research Report.

Average monthly passing rent for office space in the Singapore CBD had eased in 2011 due

to uncertain global economic conditions, but began to recover in the third quarter of 2013,

with rates at Marina Bay and Raffles Place growing 4.8% and 1.3% quarter-on-quarter to

S$11.0 per sq ft per month and S$9.4 per sq ft per month, respectively.

The following graph illustrates the average rental rates in the Singapore CBD for the period

from 2010 to the third quarter of 2013.

Average Rental Rates in the Singapore CBD (S$ per sq ft per month)

0

2

4

6

8

10

12

14

Shenton Way/ Robinson Rd/ Cecil StreetRaffles PlaceMarina Bay

Q3 2013Q2 2013Q1 2013201220112010

12.0

10.5 10.510.5
11.0

9.4

7.5

9.3

7.3
7.3

9.39.3

7.3

9.8

7.8
9.0

6.5

S$

Source: Independent Market Research Report.

13