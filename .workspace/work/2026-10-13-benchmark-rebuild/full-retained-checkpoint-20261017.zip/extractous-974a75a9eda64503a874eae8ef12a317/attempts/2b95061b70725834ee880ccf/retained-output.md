69European Innovation Scoreboard 2025

Figure 27: Convergence in innovation performance

Note: Lines show the coefficient of variation of the summary innovation index. defined as the ratio of the 

standard deviation to the mean, indexed to 2018.

3.5 How do EU27 Member States perform compared to neighbouring countries? 
The innovation performance of the 12 neighbouring (non-EU) European countries (Albania, 
Bosnia and Herzegovina, Iceland, Moldova, Montenegro, North Macedonia, Norway, Serbia, 
Switzerland, Türkiye, Ukraine and the United Kingdom) compared with that of the EU27 
Member States is examined in this section. The performance progress concerns only the 
indicators for which data is available as data availability varies across countries. The 
neighbouring countries are strategic partners for the EU, with a mix of highly advanced 
economies and economies in transition, some of which are on the path to EU accession. 

Four of the neighbouring countries score above the EU average in 2025, namely Switzerland, 
the UK, Norway, and Iceland. Switzerland ranks first in the enlarged ranking outperforming 
all EU27 Member States in 2025. However, its innovation performance has seen a slight 
decline, the country recording a 1.6%-point decrease compared to 2024 and an overall 
1.7%-point decrease in performance since 2018. The United Kingdom outperforms 24 
EU27 Member States with an improvement of 1.2%-point in 2025 marking a breakthrough 
into the Innovation Leaders group. The UK’s performance reflects a long-standing positive 
trend with a 12.2%-point increase in performance since 201831. Norway ranks third among 
Strong Innovators group but registers a 0.9%-point decrease compared to 2024. Performing 
at 121.6% of the EU average in 2025, it builds on a positive trend since 2018, with a strong 
13%-point increase over the period. Finally, Iceland ranks sixth in the Strong Innovators 

31 For the United Kingdom, data from 2020 is used, based on an earlier edition of the Community Innovation Survey (CIS). 

0.0

0.2

0.4

0.6

0.8

1.0

1.2

1.4

1.6

1.8

2018 2019 2020 2021 2022 2023 2024 2025

C
oe

ffi
ci

en
t o

f v
ar

ia
tio

n

All EU Member States

Emerging innovators

Moderate innovators

Strong innovators

Innovation leaders