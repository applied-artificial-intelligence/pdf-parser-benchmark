Aligning with the United Nations 
Sustainable Development Goals (SDGs)

We believe our actions can 
contribute positively to achieving 
the UN’s 2030 Agenda for 
Sustainable Development. 03 Good Health and Well-Being

04 Quality Education

05 Gender Equality

07 Affordable and Clean Energy

08 Decent Work and Economic Growth

09 Industry, Innovation and Infrastructure

10 Reduced Inequalities

11 Sustainable Cities and Communities

12 Responsible Consumption and Production

13 Climate Action

17 Partnerships for the Goals

INTRODUCTION OUR APPROACH TO CORPORATE SUSTAINABILITY FINANCIAL CONFIDENCE CLIMATE SOLUTIONS DIVERSITY, EQUITY, & INCLUSION GOVERNANCE & OPERATING RESPONSIBLY SUPPORTING DATA 65

We map our corporate and sustainability initiatives and programs to the 17 United Nations Sustainable 
Development Goals (SDGs) and believe our work contributes most to the following 11 SDGs: