32    

OECD EMPLOYMENT OUTLOOK 2024 © OECD 2024 
  

Despite the recent pick-up in their year-on-year growth, real wages remain below their pre-COVID-19 

levels in most countries, even though the average change across all 35 countries with available data is 

positive (Figure 1.9, Panel B).9 By Q1 2024, real wages had recovered at least some of the lost ground in 

23 of the 27 countries in which they fell in the aftermath of the COVID-19 crisis – rising above pre-pandemic 

levels in 11 of them. However, real wages remained well below their pre-pandemic levels in virtually all 

countries where they fell the most. Overall, in Q1 2024, real wages were still below their Q4 2019 level in 

16 of the 35 countries with available data. 

Box 1.2. Data for selected countries point to continued improvement in real wage growth in 
recent months generally driven by declining inflation 

For a limited number of countries, it is possible to gain insights on very recent wage developments using 

monthly data. This analysis is subject to the caveat that the underlying measures differ between 

countries (and from those used in the main analysis in Figure 1.10) and are generally not seasonally 

adjusted. 

Figure 1.10. Monthly data point to continued improvement in real wage growth 

Year-on-year percentage change 

 

Note: Up to Q4 2023 refers to the average of the monthly observations of the six months ending to December 2023. Latest refer to the 

average of all monthly observations available after December 2023. The last available data point is April 2024 for Finland, Hungary, Japan, 

Norway and the United Kingdom; and May 2024 for Iceland and the United States. For Norway, earnings observed in April 2024 corresponds 

to the preliminary value. Real wage growth is “increasing” (“decreasing”) where the year-on-year percentage change in the average real 

wage over January to April 2024 is higher (lower) than the year-on-year percentage change in the average real wage over July to 

December 2023. 

Source: OECD calculations based on the Wage and salary indices by industry (Statistics Finland) for Finland; the Main earnings data 

(Central Statistics Office) for Hungary; the Wage indices by sector and month (Statistics Iceland) for Iceland; the Monthly Labour Survey 

(Ministry of Health, Labour and Welfare) for Japan; the Number of employment and earnings (Statistics Norway) for Norway;; the Monthly 

Wages and Salaries Survey (Office for National Statistics) for the United Kingdom; and the Current Employment Statistics (Bureau of Labor 

Statistics, retrieved from FRED) for the United States; OECD (2024), “Prices: Consumer prices”, Main Economic Indicators (database), 

https://doi.org/10.1787/0f2e8000-en (accessed on 26 June 2024). 

StatLink 2 https://stat.link/1kthew 

0

2

4

6

8

10

12

14

16

HUN NOR GBR JPN ISL USA FIN

Increasing real wage growth Decreasing real wage growth

%

Nominal wage growth Inflation

Up to Q4 2023 Latest Up to Q4 2023 Latest

https://doi.org/10.1787/0f2e8000-en
https://stat.link/1kthew