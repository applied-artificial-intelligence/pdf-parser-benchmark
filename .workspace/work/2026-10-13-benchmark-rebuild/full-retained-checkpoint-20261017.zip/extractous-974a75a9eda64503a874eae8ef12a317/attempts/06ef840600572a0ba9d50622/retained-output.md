PLANETPEOPLE PROSPERITYGOVERNANCEINTRO ABOUT THIS REPORT APPENDICES

U.S.Canada Chile Latin AmericaAlgeria Gulf of Mexico Oman UAE

*  Oxy applies operational control as our primary organizational boundary for climate and sustainability reporting. Algeria, Al Hosn and Dolphin are joint ventures in which Oxy is a participant but is not the 
operator. We include them here as their operations generate significant value for Oxy and our partners. See About this Report for further information on our reporting boundaries.

Oxy’s Integrated Portfolio

•  Emerging low-carbon businesses commercializing 
CCUS and DAC solutions

•  Developing competitive-returns businesses with 
cash flow stability

Oxy Low Carbon Ventures

•  A leading position in the Denver-Julesburg Basin 
0.7 MM net acres including vast  
minerals position

•  Among the largest producers in Colorado with 
significant free cash flow generation

•   Emerging Powder River Basin 
0.3 MM net acres

Rockies

• 9 active operated platforms

• Significant free cash flow generation

•  Sizeable inventory of remaining  
tie-back opportunities

Gulf of Mexico

•  Premier unconventional positions in the Delaware 
and Midland Basins 
 
2.8 MM net acres 
- 1.4 MM for unconventional 
- 1.4 MM for conventional

•  Significant scale, technical capability and  
low-decline conventional production

•  Strategic infrastructure and logistics hub in place

•  EOR advancements and CCUS potential for 
economic growth and carbon reduction strategy

Permian

•  Deepwater exploration opportunities

Latin America

•  23 owned or operated facilities in the U.S., Canada 
and Chile

•  Integrated assets capture benefits of favorable 
market conditions

•  Top-tier global producer in every  
product produced

OxyChem

•   High-return opportunities in Oman 
6 MM gross acres, 17 identified horizons

•   Exploring Blocks ON-3 and ON-5 in UAE 
2.5 MM gross acres

•   World-class reservoirs in Algeria  
0.5 MM gross acres in the Berkine Basin

•   Al Hosn and Dolphin provide steady cash flow  
with low sustaining capex

Middle East / North Africa*

as of year-end 2023

5