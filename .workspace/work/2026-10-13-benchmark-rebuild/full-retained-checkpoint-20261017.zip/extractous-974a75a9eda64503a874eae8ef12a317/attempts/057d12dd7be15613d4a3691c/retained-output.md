Contents 27

Private debt

The terms “private debt” and “private credit” 

are used interchangeably and refer to non-

bank lending or bonds outside traditional 

markets used to fund private businesses.44

The global private credit market has surpassed 

$3 trillion in assets under management 

(AUM).45 This asset class consists of higher-

risk loans with higher-interest rates than 

conventional debt. Unlike public debt, private 

debt is issued by non-bank entities or 

individuals to raise funds or form capital.

Private debt can attract investors, offering 

higher returns and risk. Private-sector leaders 

believe private debt will be the first asset class 

to be tokenized and routinely traded.46 About 

70% of private-debt investors are institutional 

investors or entities investing on behalf of an 

individual, typically a private credit fund.47

Most private loans on-chain are direct loans to 

institutional crypto investors. These loans 

mostly appeal to high-net-worth individuals 

and accredited investors as yields range from 

9% to 20%. However, they carry risks in that 

the collateral posted is limited in diversity.48

Because crypto-assets such as Ethereum 

back most loans, significant market 

corrections of these assets could affect the 

lending positions of the holders.

Examples of the benefits of tokenization for 

private debt include:

1. Enhances information symmetry

Transaction flow would be in real time, 

providing data on underlying assets 

at all times.49

2. Facilitates operational efficiency

Smart contracts reduce and mitigate back-

office costs and lower transaction costs 

and management fees.

3. Expands accessibility

Easing the process of buying into private 

credit funds and of trading shares can 

increase the range of investors. For 

example, in 2022, KKR collaborated with 

Securitize to tokenize a segment of its $4 

billion healthcare fund on Avalanche, 

reducing investment minimums and 

onboarding accredited investors, 

increasing reach.50

On-chain activity for private debt/credit is 

increasing but is largely limited to crypto-

assets and select corporate bond issuances. 

Protocols such as Maple, Goldfinch and 

Centrifuge have driven more than $13 billion in 

on-chain loans in public networks, including 

Ethereum and Solana.51

Tokenized assets

F I G U R E  1 0

Tokenized private credit by issuer

Figure represents almost 80% of the value of outstanding tokenized private loans

Source: RWA.xyz (2025)

Figure Tradable Maple PACT MB | Mercado Bitcoin Others

$14M

$12M

$10M

$8M

$6M

$4M

$2M

$0M

Jan
 23

Ma
r 23

Ma
y 2

3
Jul

 23
Sep

 23
No

v 2
3

Jan
 24

Ma
r 24

Ma
y 2

4
Jul

 24
Sep

 24
No

v 2
4

Jan
 25

Ma
r 25

https://rwa.xyz