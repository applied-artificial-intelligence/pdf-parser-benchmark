126    

OECD EMPLOYMENT OUTLOOK 2024 © OECD 2024 
  

Annex Figure 2.C.10. The wage gap in GHG-intensive occupations is less negative for women 

Percentage difference between the share of green-driven and GHG-intensive occupations among high and low-

wage workers, 2018 

 

Note: The figure reports the cross-country unweighted average difference in the percentage of green-driven and GHG-intensive occupations in 

wage and salary employment between high and low wage workers, by gender. High (resp. low) wage is defined as hourly wage above one-and-

a-half times (resp. below two-thirds of) the median wage. Included countries are Australia, Belgium, Canada, Czechia, Denmark, Estonia, 

Finland, France, Germany, Greece, Hungary, Iceland, Italy, Latvia, Lithuania, Luxembourg, the Netherlands, Norway, Poland, Portugal, the 

Slovak Republic, Slovenia, Spain, Sweden, the United Kingdom, the United States. Agriculture is excluded except in Australia, Canada and the 

United States. Data for Belgium, Denmark, France, Greece, Iceland, Italy, Luxembourg, Portugal, Sweden and the United Kingdom do not 

include firms with less than 10 employees. Data for Canada and the United States refer to 2019. GHG: greenhouse gases. Countries are ranked 

by the difference in the incidence of GHG-intensive occupations between high and low wage workers. 

Reading: On average, the share of green-driven occupation is 1.6% higher among high-wage men than among low-wage men. A larger incidence 

of a given type of occupation among high-wage workers than among middle or low-wage workers is indicative of a positive wage gap between 

that occupation and the others. 

Source: Secretariat’s estimates based on version 24.1 of the O*NET database and the following country-specific sources: Australia: 

Table Builder of the Australian Bureau of Statistics (Labour Force: Characteristics of Employment); Canadian Labour Force Survey; 

United States: Current Population Survey; All other countries: EU Structure of Earnings Surveys. 

StatLink 2 https://stat.link/nrm1j0 

-5

-4

-3

-2

-1

0

1

2

Green-driven occupations GHG-intensive occupations

%

Men Women

https://stat.link/nrm1j0