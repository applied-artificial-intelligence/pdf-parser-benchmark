Global Natural Catastrophe Overview

16

2003 2004 2005 2006 2007 2008 2009 2010 2011 2012 2013 2014 2015 2016 2017 2018 2019 2020 2021 2022 2023

25

50

75

100

125

150

175

200

U
SD

 b
ill

io
n

Weather / Climate Other Natural Perils

By Peril % Covered by Private Insurers Billion-Dollar Events

SCS

FL

TC

DR

EQ

WF

EU WS

WW

Other

$13B

$71B

$0B

$11B

$4B

$9B

$5B

$3B

$7B

SCS

FL

EQ

TC

DR

WF

EU
WS

WW

Other

58%

11%

0%

4%

6%

9%

3%

3%

7%

Private Public

90%
2023

90%
2000-2023

United States 24

Weather / Climate Other Natural Perils

Europe

Oceania

Asia

Latin America

Africa

Middle East

Rest of N. America

6

2

1

1

0

0

0

34
All Natural Perils

33
Weather / Climate

A 20-year view of global insured losses resulting from natural catastrophes is seen below in Figure 7. There has been an increasingly obvious upward 

trend in insured losses during this time (+4.3% annualized rate of growth). It is unsurprising that the annual rate of insured losses has grown at a faster 

pace than the overall economic total. As insurance penetration continues to expand into parts of the world with traditionally limited policy take-up, in 

addition to the growth of public-private partnerships to introduce parametric or cat bond solutions to guarantee financial recovery in the aftermath of 

an event, it is expected that more damage costs will be covered. We also see a greater portion of losses covered by government-sponsored insurance 

entities. Examples include the National Flood Insurance Program, or the USDA’s Risk Management Agency’s crop insurance program in the US, or 

the Turkish Catastrophe Insurance Pool (TCIP). While the progress of insurance protection is promising, there remain considerable gaps in coverage 

that leave many parts of the developing world highly vulnerable to catastrophe risk. The need for more guaranteed climate or natural catastrophe 

financing to mitigate or adapt to a more complex world of natural hazards becomes more critical by the day.

Figure 7: Last 20 years of annual global insured losses; historical losses adjusted using US CPI and a construction + cost of labor factor  |  Data and Graphic: Gallagher Re

Figure 8: 2023 global insured loss statistics  |  Data and Graphic: Gallagher Re

EQ: Earthquake

DR: Drought

SCS: Severe Convective Storm

EU WS: European Windstorm

TC: Tropical Cyclone

WF: Wildfire

WW: Winter Weather

FL: Flooding