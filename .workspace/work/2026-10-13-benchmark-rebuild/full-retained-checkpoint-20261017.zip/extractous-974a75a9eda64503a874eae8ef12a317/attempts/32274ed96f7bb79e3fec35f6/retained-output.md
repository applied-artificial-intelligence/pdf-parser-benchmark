Energy Technology Perspectives 2024 Chapter 1: The state of manufacturing and trade 
  

PAGE | 52 I E
A.

 C
C

 B
Y 

4.
0.

 

Clean energy technologies made up just 0.2% of total mass traded in 2023, but 
approximately 1% of total traded value. Other manufactured goods made up just 
7% of traded mass, but nearly half of traded value (Figure 1.15).  

 Shares of physical goods in global trade, 2023 

 
IEA. CC BY 4.0. 

Notes: Clean energy technology includes batteries, electric vehicles, electrolysers, heat pumps, solar PV and wind. 
Aluminium includes mineral inputs, intermediates (such as alumina and scrap), ingots and semi- and finished products. Iron 
and steel include mineral inputs, intermediates (such as scrap, pig iron and direct reduced iron) and semi- and finished 
products. Other energy includes bioenergy, hydrogen, and nuclear fuel. Other manufactured goods include arms and 
ammunitions, clothing, electronics, machinery, and pharmaceuticals, among others. Other materials and chemicals include 
cement, chemicals, ethanol, metals, methanol, paper, plastics and rubber and wood. Other transport includes non-electric 
vehicles including hybrids, aircrafts, ships and other transport equipment. 
Source: IEA analysis based on CEPII, (2024); Oxford Economics Limited (2024b); and IEA (2024e). 

Fossil fuels account for 40% of international trade by mass, but only 10% in value. 

Rising energy demand, in particular, has historically led to increasing trade of fossil 
fuels. Between 1973 and 2023, global exports of oil and oil products increased by 
60%, reaching more than 24 billion barrels in 2023. For coal, exports increased 
more than sixfold, reaching 1.2 Gt of coal equivalent (Gtce), while natural gas 
exports expanded more than fifteen-fold to 1.3 trillion cubic metres (tcm). In 
aggregate, fossil fuel exports in mass terms increased by 160% over 1973-23, 
reaching 5.8 Gt. Today, exports make up around 20% of global coal supply, 30% 
of that of natural gas and 75% of that of oil products (Figure 1.16). 

0% 20% 40% 60% 80% 100%

Value

Mass

Share of global exports in 2023

Fossil fuels Iron and steel Aluminium
Food Other materials and chemicals Other manufactured goods
Ammonia and fertilisers Critical minerals Clean energy technologies
Other transport Other energy