The BEAT | June 2025

Overweight European High Yield Credit

TOP IDEAS

The reduction in global growth risks from the recent positive trade negotiation outcomes should reduce default risks, making 

lower-quality credit more attractive. European HY credit appears attractive especially for USD-based investors, given an 

additional 2.4% pick up from hedging euro exposure back to USD. 

12

European HY Credit Offers the Highest Yield on USD-Hedged Basis

Yield decomposition across major credit asset classes

Source: Bloomberg, MSIM. As of May 22, 2025. For illustrative purposes only. Not a recommendation to buy or sell any security. It is not possible to invest directly in an index. The views 
and opinions expressed are those of the portfolio management team at the time of writing/of this presentation and are subject to change at any time due to market, economic, or other 
conditions, and may not necessarily come to pass.  Forecasts/estimates are based on current market conditions, subject to change, and may not necessarily come to pass. Past 
performance is not indicative of future results.

8.1%
7.9%

7.6%

5.6%
5.4%

0%

1%

2%

3%

4%

5%

6%

7%

8%

9%

EUR High Yield EM Hard Currency USD High Yield EUR IG Corp USD IG Corp

Base Rate Option-Adjusted Spread (OAS) EURUSD 3m Hedging Income