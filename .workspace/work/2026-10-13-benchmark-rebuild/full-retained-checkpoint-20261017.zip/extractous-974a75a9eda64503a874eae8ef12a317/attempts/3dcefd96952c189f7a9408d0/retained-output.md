44    

 

HEALTH AT A GLANCE: EUROPE 2024 © OECD OECD/EUROPEAN UNION 2024 
  

1.6.3. Improving the remuneration of some categories of health workers can increase attractiveness 
and retention 

An important aspect of job quality relates to earnings, as explicitly recognised under the OECD Job Quality Framework. Based on 

standard economic theory, wage adjustments should address any imbalance in the supply and demand for different categories of 

health workers: if there are shortages of some categories of workers, wages should go up to increase supply (either in terms of 

the number of health workers and/or their working hours) while the demand should decrease, thereby reducing the shortage. 

However, this supposes that wages are free to adjust to labour market conditions and that the supply of health workers is fairly 

responsive (or “elastic”) to wage changes. In practice, both of these conditions often do not apply in the health sector.5 

The remuneration of health workers varies widely by categories of workers depending on qualification levels, years of experience 

(seniority), working time (or activity rates) and negotiating power. In general across EU countries, the remuneration of doctors is 

several times higher than the average wage of workers in all occupations reflecting their higher qualifications and longer working 

hours. GPs earn two to four times more than the average wage, while specialists earn two to five times more (see indicator on 

“Remuneration of doctors” in Chapter 7). The remuneration of nurses is substantially lower than that of doctors. On average 

across EU countries, it is about 20% higher than the average wage of workers in all occupations, although in some countries 

nurses do not earn more than the average wage (see indicator on “Remuneration of nurses” in Chapter 7). The remuneration of 

personal care workers is about 30% lower than the economy-wide average wage on average across EU countries (OECD, 

2023[36]). 

Based on data collected through the Eurofound’s EWCTS survey in 2021, over 40% of personal care workers on average across 

EU countries reported having financial difficulties (almost the same proportion as cleaners and cooks and waiters). Over 20% of 

nurses also reported having difficulties in making ends meet, slightly lower than the average across all occupations considered to 

be in shortage, but nonetheless a significant proportion. Only about 5% of doctors reported facing such financial difficulties on 

average across EU countries (Figure 1.19). 

Workers in certain health occupations also believe that they were not fairly rewarded. This is notably the case for nurses: only 

40% of nurses felt in 2021 that they were paid fairly in relation to their efforts and achievements on average across EU countries 

(19 percentage points less than the average across all occupations). 

Figure 1.19. Almost a quarter of nurses and half of personal care workers report financial difficulties across 
EU countries 

 
Source: European Commission  (2023[18]), Employment and social developments in Europe 2023, https://data.europa.eu/doi/10.2767/089698. 

StatLink 2 https://stat.link/jf50p8 

43

22

5

0

5

10

15

20

25

30

35

40

45

50

Cleaners Cooks and
waiters

Personal care
workers

Salespeople Building
workers

Truck and bus
drivers

Metal workers EU average Electronic
workers

Nurses Software
developers

Doctors

% of workers in shortage occupations reporting difficulty in making ends meet 

https://data.europa.eu/doi/10.2767/089698
https://stat.link/jf50p8