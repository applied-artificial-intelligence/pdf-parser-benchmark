Appendix: facts and figures sigma No 1/2025 Swiss Re Institute 27

Global insured losses

Hurricane Helene and Milton, the second highest severe convective storms (SCS) and 
large-scale urban floods were the main events driving global insured losses from natural 
disasters of USD 137 billion in 2024. Man-made disasters triggered an additional 
USD 9 billion losses.

Primary and secondary perils

Hurricane Helene and Milton brought the share of insured losses from so-called primary 
perils to roughly 41% in 2024, more than double the share in 2023 (19%).

Figure 18 
Insured catastrophe losses, 1970 – 2024 (USD bn, 2024 prices)

Source: Swiss Re Institute

0

50

100

150

200

250

2024202120182015201220092006200320001997199419911988198519821979197619731970

Earthquake/tsunami Weather-related catastrophes Man-made disasters

Hurricane
Andrew

Winter Storm
Lothar WTC

Hurricanes
Ike, Gustav

Hurricanes Ivan, 
Charley, Frances

Hurricanes
Katrina, Rita, Wilma

Japan, 
NZ earthquakes, 

Thailand flood

Hurricanes Harvey,
Irma, Maria

Hurricane Ian

Hurricanes Helene,
Milton

Hurricane
Sandy

Figure 19 
Global insured losses from primary and secondary perils, 1970 – 2024, in USD billion at 2024 prices

Source: Swiss Re Institute

0

25

50

75

100

125

150

175

200

2024202120182015201220092006200320001997199419911988198519821979197619731970

Insured losses (USD bn) 

Exponential trend (total natcat losses)Primary perils (incl secondary effects)Secondary perils