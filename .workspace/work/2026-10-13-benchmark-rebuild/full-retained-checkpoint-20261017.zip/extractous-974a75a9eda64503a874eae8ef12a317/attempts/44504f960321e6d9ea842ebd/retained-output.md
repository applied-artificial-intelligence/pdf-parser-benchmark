Leveraging these value streams ... enables the realisation  
of our strategy ...

Monitoring and reporting on our ambitious SDG-related 2025 goals aligns with our Thrive strategy of 
being a trusted partner to all our stakeholders. See our 2023 Sappi Group Sustainability Report for 
more information www.sappi.com/2023GSDR 

Grow our  
business

Sustain our 
financial  
health

Drive 
operational 
excellence

Enhance 
trust

and generates  
certain outputs

Products:
• 4,988,309 tons of saleable 

production.

Waste:
• 1,432,165 tons of waste generated, 

of which 1,064,482 tons (74.3%) 
diverted from disposal.

Emissions:
• 3.5 million tCO2e absolute direct 

(Scope 1) GHG, in specific terms:  
0.70 tCO2e/adt.

Timber
• Our Forest Stewardship Council™ (FSC™ N003159) and 

Programme for the Endorsement of Forest Certification 
(PEFC/01-44-43) certified tree plantations in South 
Africa provide a high-quality woodfibre base and 
enhance our competitive advantage. Our leading-edge 
tree improvement programmes ensure this advantage is 
maintained and leveraged.

Manufacturing excellence
• We focus on enhancing machine efficiencies, digitising 

our processes to make the smart factory a reality, 
reducing variable costs through new logistics and 
procurement practices and implementing go-to-market 
strategies which lower the cost of serving our customers 
and increase customer satisfaction.

Biomaterials
• We are unlocking the chemistry of trees and aligning 

with the circular economy by establishing a strong 
position in adjacent businesses, including nanocellulose, 
furfural, lignosulphonates and bioenergy. Extracting 
more value from each tree is at the core of our business 
model.

Pulp
• Our dissolving pulp (DP) brand, Verve, creates renewable 

alternatives for raw material feedstock to textiles, 
pharmaceuticals, foodstuffs and more – products that 
meet the needs of people around the globe every day.

Speciality papers 
• Our customers use our speciality papers to add value to 

niche markets and enable product differentiation. Our 
focus on innovation helps our customers to meet and 
anticipate the challenges of changing market dynamics.

Packaging papers  
• Our packaging solutions offer environmentally 

conscious consumers an alternative to fossil-fuel-based 
packaging.

Graphic papers  
• Our market-leading range of coated and uncoated 

graphic paper products is used in magazines, corporate 
reports and accounts, direct mail, high-quality 
brochures, catalogues, calendars and books.

Sappi Annual Integrated Report     2023        25