Financials Price-to-Book Valuation Spreads

Financials’ performance may be durable this time  
Investors considering financials may be concerned about a repeat of 2016, when the sector underperformed despite low 
valuations and improving earnings. This time it looks different. The sector’s valuation spreads are near recessionary levels 
(left), suggesting the market is priced for bad news. Interest rates and credit spreads have declined—a good combination for 
the sector, historically (right).   

12

Financials have benefited from falling rates and credit spreads Valuation spreads are wide   
NTM Average Relative Performance when Credit Spreads (HYOAS) or Rates 
(1-Yr Yield) Are Rising or Falling, 1980–Present

Past performance is no guarantee of future results. Sources: Haver Analytics, FactSet, Fidelity Investments, as of 11/30/24. LEFT: Valuation spread: 
The difference between the average price-to-book ratio of the most-expensive and least-expensive quartiles. Analysis based on Russell 3000. Data analyzed monthly 
from December 1990 to October 2024. RIGHT: NTM: Next 12 months. HYOAS: ICE BofA US High Yield Index Option-Adjusted Spread. Data analyzed monthly from 
January 1980 to October 2024.

0

50

100

150

200

250

19
90

19
92

19
94

19
95

19
97

19
98

20
00

20
02

20
03

20
05

20
06

20
08

20
09

20
11

20
13

20
14

20
16

20
17

20
19

20
21

20
22

20
24

-3%

-2%

-1%

0%

1%

2%

3%

4%

5%

Rates Rising/
Spreads Rising

Rates Rising/
Spreads Falling

Rates Falling/
Spreads Falling

Rates Falling/
Spreads Rising

4%

Pr
ice

-to
-b

oo
k 

va
lu

at
io

n 
sp

re
ad

s