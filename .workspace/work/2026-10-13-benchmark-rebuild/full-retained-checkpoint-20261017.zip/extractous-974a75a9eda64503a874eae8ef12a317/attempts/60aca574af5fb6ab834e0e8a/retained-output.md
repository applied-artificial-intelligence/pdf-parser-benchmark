Fundamentals — Sustainability at Ford — Products and Services — Environment — Social — Governance — Data — Appendices 

 

 

 

46

Overview — Climate Change — Circular Economy and End of Life — Air, Water, and Soil Pollution — Water Resources — Biodiversity and Ecosystems

European Carbon Neutral 2035 Strategy 

In Europe, we have an accelerated strategy with 
the goal of being carbon neutral no later than 2035. 
This means: 

• Ford is shifting our entire line-up of passenger 
and commercial vehicles to 100% electric by 2035. 

• Ford is targeting carbon neutral 

– EV and EV component manufacturing facilities 

– Tier 1 suppliers (Scope 1 and 2) 

– Logistics operations that transport parts to EU 
production sites and vehicles to dealers 

Our strategy is powered by an exciting lineup of EVs, 
including an electric version of the popular Ford 
Puma, the E-Transit, and the electric Explorer. 

Not only is the European market seen as ready for an 
accelerated Ford carbon neutrality strategy, but we 
also view it as a potential blueprint for other regions. 

Our Scope 3 use of sold products (vehicles) target is 
consistent with a well-below 2°C path; vehicle sector 
pathways for a 1.5°C target setting have not yet been 
finalized by the SBTi. Our Scope 3 target goes beyond 
tailpipe emissions and includes vehicle emissions 
from an energy-cycle (fuel and electricity) perspective 
(well-to-wheels). This includes energy production and 
consumption during vehicle use. 

These interim GHG reduction targets do not include 
the use of offsets. 

Key Supporting Commitments 
In 2020 Ford committed to the UN’s Business Ambition 
Pledge for 1.5°C, which calls on companies to set 
science-based targets aligned either with limiting global 
temperature rise to 1.5°C above pre-industrial level or 
a 2050 net zero target date. This is reflected in our 
2050 aspiration and our Scope 1 and 2 target. We have 
evaluated SBTi’s proposed interim automotive sector 
1.5°C pathway for vehicle use and are awaiting the final 
version’s publication. 

Ford is also committed to the New Deal for Europe 
initiative to devise a comprehensive Sustainable Europe 
2030 Strategy. 

Vehicles 
In 2021, Ford joined RouteZero, a global coalition, to sign 
the ZEV Declaration, pledging to work towards making 
sales of all new cars and vans zero-emissions by 2040 
globally and no later than 2035 in leading markets. 
RouteZero ran in the lead up to COP26 from 2020-2021, 
and the work is now being continued under Accelerating 
to Zero (A2Z) Coalition. SBTi’s proposed automotive OEM 
interim 1.5°C pathway also includes a reference to A2Z. 

We support the authority of California and other U.S. 
states to protect people’s health and avoid the worst 
impact of climate change by establishing and enforcing 
air pollution standards and zero-emission vehicle 
requirements for new vehicles within their states. 

Operations 
We’ve joined the U.S. Department of Energy’s (DOE) 
Better Climate Challenge to reduce GHG emissions from 
our U.S. manufacturing facilities 50% by 2030, relative 
to a 2017 baseline. We have also joined the U.S. DOE’s 
Better Plants Challenge to reduce energy intensity from 
our U.S. manufacturing facilities by 10% by 2030, relative 
to a 2020 baseline. Through these programs, DOE 
provides technical assistance and opportunities to learn 

about and share actionable best practices for carbon 
reduction. We are proud to join this effort to meet the 
urgent call to mitigate the impacts of climate change. 

Supply Chain 
We are members of the First Movers Coalition to 
accelerate the transition to low-carbon aluminum and 
near-zero steel, addressing two key high-carbon 
materials in the supply chain. 

Alignment with Business and Financial Planning 
Decarbonizing our business and providing sustainable 
mobility solutions is essential to realizing Ford’s overall 
vision of building a better world. It is reflected in our 
overall strategy to transform our product and services 
portfolio and in major investments to realize the 
transformation. Nothing will be more influential than 
our electrification strategy. Our overall decarbonization 
approach is summarized below. 

Read More 

In Electric Vehicles, Batteries, and Charging infrastructure on p.34

Decarbonization Levers, Actions, and Investments 
Emissions avoidance and reductions are Ford’s top 
climate change priority. Understanding the potential 
environmental and cost impacts of our vehicles and 
services over their life cycle — from the acquisition of raw 
materials, through vehicle production, distribution, and 
use, to end-of-life disposal or recycling — aids this effort, 
allowing the company to focus on key GHG sources. 

The graphic, Decarbonization Levers and Actions 
Overview, on page 48 shows an overview of the key 
decarbonization levers along with example actions for 
our largest contributors — currently vehicle use and 
supply chain emissions — and our operations. 

It is important to note that the backbone of the 
transformation to a carbon neutral business is carbon-
free energy. This includes wind, solar, nuclear, 

geothermal, hydro, and bio energy sources. We are 
actively investing, partnering, and collaborating in 
carbon-free energy throughout our value chain. 
Examples include renewable electricity for not only 
our operations but also for public and home charging 
infrastructure, supporting our supply base via 
Manufacture 2030 and advocating for the transformation 
of the electric grid. 

Read More 

In Climate Change — Achieving Carbon Neutrality on p.59

The Carbon Neutrality Scenario graph shows what 
the decarbonization path might look like as a result 
of actions taken, including those discussed here. 
The path will not be linear, and the relative share 
of GHG emissions for each scope will shift over time. 
As we sell more EVs and fewer internal combustion 
engine vehicles, the total GHGs from vehicle use should 
decrease significantly. However, in the near term, the 
GHGs from energy production will likely increase due 
to more electricity use for EV battery production. 

Climate Change — Carbon Neutrality Overview
— continued

... 
N 
0 
N ... 
0 
c. 
a, 
a: 

Carbon Neutrality Scenario 

2019 2035 

SBTi 
Targets 

Met 

2050 

Carbon 
Neutrality 
Globally 

• Scope 1 and 2 
Operations 

• Scope 3 Misc 

• Scope 3 Supply 
Chain 

• Scope 3 Vehicle 
Energy Production 

• Scope 3 Vehicle 
Tailpipe 

• Carbon Removals