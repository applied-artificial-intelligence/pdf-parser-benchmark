 179 

 

DO ADULTS HAVE THE SKILLS THEY NEED TO THRIVE IN A CHANGING WORLD? © OECD 2024 
  

Figure 4.17. Likelihood of over-qualification, by socio-demographic characteristics [1/2] 

Change in likelihood of over-qualification (relative to reference category)  

 

F
in
la
n
d

 
ew

  
ea

la
n
d

S
pa

in

 
o
rw

ay

G
e
rm

an
y

 i
th
ua

n
ia

 
a
t 
ia

 
en

m
a
rk

P
o
rt
ug

al

It
al
y

P
ol
an

d 

 
e
th
e
rl
an

ds

S
w
e
de

n

C
h
ile

H
u
ng

ar
y

S
lo
 a

k 
R
ep

u
b
lic

 
E
C
 
 a
ve

ra
g
e

U
ni
te
d 
S
ta
te
s

 a
pa

n

C
ro
at
ia

C
 e

ch
ia

S
in
g
ap

or
e

F
ra
n
ce

F
le
m
is
h 
R
eg

io
n 
( 

E
 

E
st
on

ia

Ir
el
an

d

A
us

tr
ia

 
or
e
a

Is
ra
el

S
w
it 

er
la
n
d

C
an

ad
a

E
ng

la
n
d 
(U

 
 

 

0

  

 8

Percentage points  .  umeracy

It
a
ly

P
or
tu
g
a
l

C
hi
le

C
 e

ch
ia

H
un

g
ar
y

E
st
o
ni
a

S
lo
 a

k 
R
ep

ub
lic

 
or
e
a

Ir
el
an

d

 
et
he

rl
a
nd

s

F
ra
n
ce

S
w
it 

e
rl
an

d

 a
p
an

S
p
ai
n

F
le
m
is
h 
R
e
gi
o
n 
( 

E
 

 
E
C
 
 a
ve

ra
g
e

A
us

tr
ia

S
w
e
de

n

P
o
la
nd

 

 
at
 i
a

G
er
m
a
ny

C
ro
at
ia

 
e
nm

ar
k

 
or
w
ay

U
ni
te
d 
S
ta
te
s

C
an

ad
a

 
ew

  
ea

la
n
d

 i
th
ua

n
ia

S
in
g
a
po

re

F
in
la
n
d

E
ng

la
nd

 (
U
 
 

Is
ra
e
l

20

1 

12

8

 

0

Percentage points B.  ears of education

 i
th
ua

n
ia

 
e
nm

ar
k

 
at
 i
a

 
or
e
a

G
er
m
a
ny

 a
pa

n

C
ro
at
ia

 
et
he

rl
a
nd

s

U
ni
te
d 
S
ta
te
s

It
a
ly

F
le
m
is
h 
R
e
gi
o
n 
( 

E
 

S
in
g
a
po

re

P
ol
a
nd

 

E
st
o
ni
a

 
ew

  
ea

la
n
d

S
lo
 a

k 
R
ep

ub
lic

F
in
la
n
d

H
un

g
ar
y

 
E
C
 
 a
ve

ra
g
e

 
or
w
ay

C
an

ad
a

S
p
ai
n

C
hi
le

Ir
el
an

d

F
ra
n
ce

S
w
it 

e
rl
an

d

P
or
tu
g
a
l

A
us

tr
ia

E
ng

la
nd

 (
U
 
 

S
w
e
de

n

C
 e

ch
ia

Is
ra
e
l

8

 

0

  

 8

Percentage points C.  lder  or ers  Ref:  ounger  or ers