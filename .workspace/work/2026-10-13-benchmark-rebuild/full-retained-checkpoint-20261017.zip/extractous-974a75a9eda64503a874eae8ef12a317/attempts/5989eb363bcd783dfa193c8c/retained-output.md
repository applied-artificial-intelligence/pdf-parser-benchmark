Mandiant M-Trends 2025 Report 41

Most Frequently Seen Initial Infection Vectors by Region-EMEA Map

Targeted Attacks

Initial Infection Vector
The most frequently identified initial infection vectors in Mandiant incident response investi-
gations in EMEA in 2024 were exploits (39%), followed by email phishing (15%) and brute-force 
attacks (10%). In EMEA, email phishing and brute-force attacks represented larger proportions 
of observed initial infection vectors than Mandiant encountered in global investigations.

 
Detection by Source
The intrusions that Mandiant investigated in EMEA in 2024 were first discovered internally 41% of 
the time, while in 59% of cases, an external organization first notified organizations of a  
compromise. These figures are similar to the global numbers (43% internal and 57% external).

The metrics reported in this section are based on Mandiant Consulting investigations 
affecting organizations in Europe, the Middle East, and Africa (EMEA).

EMEA
In

te
rn

al
 D

et
ec

tio
n 

(P
er

ce
nt

) External D
etection (Percent)

EMEA Detection by Source, 2017-2024
100

80

60

0

40

20

100

80

60

0

40

20

2017 2018 2019 2020 2021 2022 2023 2024

Internal
Average Trend 

EMEA Detection by Source, 2017-2024

EMEA 
 
Exploit

39%
 Email Phishing

15%
Brute Force

10%