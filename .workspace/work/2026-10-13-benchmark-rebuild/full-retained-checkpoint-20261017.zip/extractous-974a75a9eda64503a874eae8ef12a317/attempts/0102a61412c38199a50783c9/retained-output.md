Clean Energy Market Monitor – March 2024  

PAGE | 9  

Overview 

IE
A.

 C
C

 B
Y 

4.
0.

 

Without this clean energy deployment, the development of energy markets would have looked 
very different 

 
IEA 2024. CC BY 4.0. 

-800 -600 -400 -200 0  200  400

C
oa

l
(M

tc
e)

Avoided annual demand due to 
2019-23 clean tech. deployment

Actual 2019-23
change  in demand

2023 coal demand
in G7 countries

-200 -150 -100 -50 0  50  100

N
at

ur
al

 g
as

(b
cm

)

Avoided annual demand due to 
2019-23 clean tech. deployment

Actual 2019-23
change  in demand

Pre-invasion natural gas 
exports from Russia to 
the European Union

-1.00 -0.75 -0.50 -0.25 0.00 0.25 0.50

O
il

(m
bo

e/
d)

Avoided annual demand due to 
2019-23 clean tech. deployment

Actual 2019-23
change  in demand

2023 United Kingdom
oil demand