Chapter 6. Climate, a Capital Problem
Figure 6.1. Triple climate inequality: the poorest lose the most,contribute the least, and lack the means to act

74%

10%
2%

22%

43%

24%

3%

47%

74%

0%

10%

20%

30%

40%

50%

60%

70%

80%

Bottom 50% Middle 40% Top 10%

S
ha

re
 in

 g
lo

ba
l t

ot
al

s

Relative losses Emissions (consumption−based) Capacity to finance (wealth)

Global climate inequality: relative losses, emissions, and capacity to finance

Interpretation. The figure illustrates three dimensions of global climate inequality. Projected relative income losses
from climate change are taken from Bothe et al. (2025). They represent percentage reductions in income compared
with a business−as−usual scenario. The global bottom 50% concentrates 74% of these percentage reductions. The
distribution of emissions is based on Bruckner et al. (2022). The distribution of wealth shares comes from WID
(2025). Groups are defined by income for losses, by emitters for emissions, and by wealth for the wealth distribution,
but all three distributions are highly correlated. For another paper on emissions inequalities by income groups, see
Kartha et al. (2020), who find similar concentration levels. Sources and series: Bothe et al. (2025), Bruckner et al.
(2022), and WID (2025).

concentration. In France, Germany, andthe United States, the carbon footprint ofthe wealthiest 10% is three to five timeshigher when private ownership–basedemissions are included. In the UnitedStates, the top 10% accounts for 24% ofconsumption-based emissions but 72% ofownership-based emissions. The share of thetop 1% rises from 6% (consumption-based)to nearly 43% (ownership-based).
At the global scale, the contrast is evensharper. The top 1% accounts for 41%of all greenhouse gas emissions underownership-based accounting, comparedwith 15% under the consumption approach.Conversely, the contribution of the bottom50% drops from 10% to 3% (Figure 6.2). Inother words, the average individual in thetop 1% emits more than twenty-five times asmuch carbon as the global average citizen.Their share of emissions even exceeds theirshare of global wealth—estimated at 36% in2022 (Chancel and Rehm (2025a)).
The extreme concentration of privateownership–based emissions stems fromboth the amount of wealth owned

and the investment choices made.Wealthy individuals not only hold largerasset portfolios but also allocate themdisproportionately toward high-carbonsectors.
As shown in Figure 6.3, every $1 millioninvested in business assets in the UnitedStates corresponds to roughly 143 tonnesof carbon emissions, compared with 75tonnes for equities (Chancel and Rehm(2025a)). Similar patterns emerge in Franceand Germany.
The global top 10% allocates about halfof their wealth to such carbon-intensiveholdings, often seeking higher-risk,higher-return investments that coincide withhigher emissions. Hsu, Li, and Tsou (2023)find that high-emission companies yield,on average, 4.4 percentage points more inannual excess returns than low-emissionpeers—an implicit “pollution premium”that further incentivizes carbon-heavyinvestments.
From this ownership perspective, thenature of emissions changes acrossthe wealth distribution. For low- and

118