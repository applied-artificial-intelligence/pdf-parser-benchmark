Chapter 1. Global Economic Inequality
Figure 1.8. Extreme wealth inequality is persistent andincreasing

The top 0.001% (about 56,000 adults) have 3 times 
more wealth than half of the entire world population 
combined. 

0%

1%

2%

3%

4%

5%

6%

7%

1995 2000 2005 2010 2015 2020 2025

S
ha

re
 o

f g
lo

ba
l p

er
so

na
l w

ea
lth

 (
%

)

Bottom 50% Top 0.001%

Extreme wealth inequality, 1995−2025

Interpretation. The share of personal wealth held by the richest 0.001% of adults rose from around 3.8% of total
wealth in 1995 to nearly 6.1% in 2025. After a very slight increase, the share of wealth owned by the poorest half
of the population has stagnated since the early 2000s at around 2%. Net personal wealth is equal to the sum of
financial assets (e.g. equity or bonds) and non−financial assets (e.g. housing or land) owned by individuals, net of
their debts. Sources and series: Arias−Osorio et al. (2025) and wir2026.wid.world/methodology.

it is shaped not only by economics, butalso by deep-rooted historical, political, andcultural legacies. It also highlights anotherkey dimension: inequality does not justseparate rich and poor individuals in thesame context; it also entrenches dividesbetween entire parts of the world. Regionalcomparisons allow us to see both howfar apart regions stand from each other(Figure 1.12) and how unequal they areinternally (Figure 1.13). The specific countrygroupings are detailed in Box 1.1.1.Figure 1.12 contrasts average incomeand wealth per adult across world regionsin 2025, relative to the world average. Thepatterns are striking. Wealthier regions arealso typically higher-income regions, thoughthere are exceptions. East Asia, for instance,has a higher average wealth level than Russia& Central Asia but a lower average income.At the top of the scale, North America &Oceania and Europe stand well above theglobal mean. In these regions, and in EastAsia, wealth levels exceed income levelsrelative to the world average. In the restof the world, however, income levels arerelatively higher than wealth levels.

At the bottom of the scale, Sub-SaharanAfrica, South & Southeast Asia, and LatinAmerica remain far below the global averageon both counts, though Latin America’saverage income is somewhat closer to theworld mean. The Middle East & NorthAfrica and Russia & Central Asia occupy anintermediate position: their average incomesare closer to East Asia’s and not far fromLatin America’s, but their average wealthremains much lower. The contrast is sharp:for instance, in 2025, average wealth inNorth America & Oceania is 338% of theworld average, while in Sub-Saharan Africa itis just 20%. Put differently, the average adultin North America & Oceania owns morethan sixteen times the wealth of the averageadult in Sub-Saharan Africa.
Turning to Figure 1.13, the focusshifts from differences between regionsto disparities within them, using the top10%/bottom 50% (T10/B50) ratio. Thissimple but powerful metric asks: on average,how many times more does the top 10%earn (or own) compared to the pooresthalf? The results reveal enormous divides.5First, wealth gaps everywhere are far larger

43