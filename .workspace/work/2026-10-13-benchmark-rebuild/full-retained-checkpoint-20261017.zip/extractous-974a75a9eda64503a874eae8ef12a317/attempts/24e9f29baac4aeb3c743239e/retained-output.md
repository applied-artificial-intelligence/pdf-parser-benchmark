Chapter 1: Main employment and social developments 

31 

the positive effect of these measures. (38) As a share of GDP, social protection benefit expenditure decreased to 
27.2% in 2022, 3 pp lower than in 2020 and 1.5 pp lower than in 2021. Old age and survivors’ benefits 
represented the highest proportion of social benefit expenditure (46.3%), followed by sickness and healthcare 
(30.0%), family and children (8.6%), disability (7.0%), unemployment (4.3%), social exclusion (2.6%) and housing 
(1.3%). At national level, estimated total expenditure on social protection benefits ranged between 11.3% of GDP 
in Ireland and 32.2% of GDP in France in 2022. (39) The significance of social protection benefits is also affected 
by the large shares of people entitled to such benefits but not claiming them. For instance, national case studies 
estimated that in Spain, 58% of households entitled to minimum income benefits in 2022 did not request them 
in Italy, the non-take-up rate of minimum income by eligible households in 2021 was 38.5%, and almost half 
(46.6%) of potentially eligible households in Belgium remained uncovered in recent years. (40) 
 

Chart 1.15 

Old age, unemployment and health-related benefits contributed to the decline in social protection benefit expenditure 
in 2022 
Growth in social protection expenditure (% change on previous year, in real terms) and contribution, by function, to the yearly increase (purchasing power standards, PPS), both on the 
left axis, EU 

  

Note: Nominal expenditure converted into real expenditure by deflating with HICP. 

Source: Eurostat, ESSPROS [spr_exp_sum] and ESSPROS early estimates (2022), and prices statistics [prc_hicp_aind]; DG EMPL calculations. 

Click here to download chart. 

 

4. LIVING CONDITIONS, POVERTY, AND INCOME DEVELOPMENTS 
This section presents recent trends in income and living conditions of EU households since the start 
of the cost-of-living crisis. It documents income trends for the overall population and for different income 
groups, the role of social transfers in mitigating income inequality, and the multifaceted nature of poverty and 
social exclusion.(41) As the official indicators on inequality and risk of poverty are computed with survey data on 
income (latest available are 2023 data based on 2022 incomes), these figures are complemented with Eurostat 
flash estimates on income inequality and poverty (2023 incomes). 

4.1. Income and consumptions trends 

Following declines in the last three quarters of 2022, real gross disposable household income (GDHI) 
began to rise again in 2023, especially in the last quarter. The impact of high inflation on real wages 
prompted real GDHI to decline by 0.3% in the fourth quarter of 2022 compared to the previous year. However, as 
inflationary pressures eased and nominal wage growth gained pace in 2023, real GDHI saw improvements and 
was 1.8% higher in the fourth quarter of 2023 compared to the same quarter of 2022 (0.7% in the first, 1.2% in 
the second, 0.6% in the third quarter in year-on-year comparisons). The positive growth of real GDHI in the first 
two quarters of 2023 was primarily due to the lower negative impact of taxes on income and wealth. In the 
context of easing inflation, real compensation of employees contributed positively to GDHI in the second half of 
2023 (Chart 1.16). The phase-out of the extraordinary measures after the COVID-19 pandemic and the 
accompanying energy crisis can explain the negative contribution of net social benefits on the growth of real 

 
(38) (European Commission, 2024c). 
(39) 2022 figures are preliminary results based on Eurostat early estimates for expenditure on social protection. 
(40) Based on latest available administrative data, which extends up to 2022. Spain: (Autoridad Independente Responsabilidad Fiscal, 2023); 

Belgium and Italy: (Almeida, De Poli and Hernández, 2022); for EU-level developments: (Heylen, 2024), (European Commission, 2022f). 
(41) Note that the social transfers analysed here do not include in-kind transfers such as healthcare coverage. Those are nevertheless known 

to have strong impact on reducing poverty (see the State of Health Synthesis Report 2023 p.17, and ESTAT on theSTIK - Impact of 
health social transfers in kind on income distribution and inequality - Statistics Explained (europa.eu)). 

-8

-6

-4

-2

0

2

4

6

8

10

2012 2013 2014 2015 2016 2017 2018 2019 2020 2021 2022

Family and children Housing and social exclusion n.e.c. Old age and survivors

Sickness, healthcare and disability Unemployment Social protection benefits

https://ec.europa.eu/employment_social/empl_portal/publications/Esde2024/xls/Chap1/Chap1-Chart-1.15.xlsx
https://ec.europa.eu/eurostat/web/social-protection/database/early-estimates