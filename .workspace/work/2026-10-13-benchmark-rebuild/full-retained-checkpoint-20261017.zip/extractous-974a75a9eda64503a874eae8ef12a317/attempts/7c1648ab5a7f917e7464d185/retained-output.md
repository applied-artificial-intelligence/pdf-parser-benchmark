What Next for the Global Car Industry? Chapter 1: The global car industry 
An Energy Technology Perspectives Special Report in context 
 

31 

I E
A.

 C
C

 B
Y 

4.
0.

 

domestically. An important reason for this is that Japanese automakers were 
technologically superior: they had developed “lean manufacturing” techniques 
which guaranteed lower costs and higher quality compared to the older 
manufacturing systems employed by US carmakers at the time.  

The affordability and superior energy efficiency led to a surge in imports of cars 
from Japan. US carmakers were slow to adapt their vehicle offering and technology 
to cater for the higher oil price environment, leading to losses of over USD 6 billion 
across the Big Three by 1980. In 1980, more than one in five cars sold in the 
United States was imported from Japan, and Japan accounted for nearly two-thirds 
of imported cars. In response, the US government negotiated a “voluntary export 
restriction” with the Japanese government, effectively setting a quota of cars that 
could be imported to the United States. This measure remained in place until 1994, 
and coincided with a real term increase in the price of new cars in the 
United States.  

Japanese carmakers have built manufacturing capacity in the United States since 
the 1980s. The first Honda factory began operations in 1982, and, in 1984, the 
landmark NUMMI plant – a joint venture between GM and Toyota – was set up. 
The investments of Japanese OEMs led to technology transfer, as US carmakers 
started to adopt some of the new manufacturing techniques pioneered by 
Japanese carmakers, and improved their productivity and quality over the following 
decade. The fuel economy of domestically made cars also improved by over 10% 
from 1980 to 1990, closing the gap with imported cars. To this day, Japanese 
OEMs account for around one-third of cars produced in the United States.  

Japanese car imports in the United States, oil price and political milestones, 
1964-1984 

 
Notes: JV = joint venture. WTI = West Texas Intermediate. Real oil prices are derived using the Consumer Price Index 
(CPI). 
Sources: IEA analysis based on USITC (1985), FRED (2025). 

0

20

40

60

80

100

120

140

160

0%

5%

10%

15%

20%

25%

1964 1966 1968 1970 1972 1974 1976 1978 1980 1982 1984

U
SD

 (2
02

4)
/b

bl

Japanese imports as share of demand WTI price

10% Emergency Import 
Surcharge

Voluntary Export 
Restrictions

Honda Factory

Toyota-GM JV

https://babel.hathitrust.org/cgi/pt?id=mdp.49015002864719&seq=161
https://www.aeaweb.org/articles?id=10.1257/aer.89.3.400
https://www.bts.gov/archive/publications/national_transportation_statistics/2001/table_04_23