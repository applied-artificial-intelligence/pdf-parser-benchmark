Chapter 1. Global Economic Inequality
Figure 1.3. Income and wealth shares are distributed veryunequally

8%

38%

53%

2%

23%

75%

0%

10%

20%

30%

40%

50%

60%

70%

80%

90%

100%

Income Wealth

S
ha

re
 o

f g
lo

ba
l i

nc
om

e 
or

 w
ea

lth

Bottom 50% Middle 40% Top 10%

By broad groups

8%

38%

33%

20%

2%

23%

38%

37%

0%

10%

20%

30%

40%

50%

60%

70%

80%

90%

100%

Income Wealth
S

ha
re

 o
f g

lo
ba

l i
nc

om
e 

or
 w

ea
lth

Next 9% Top 1%

More detail on the top 10%

Interpretation. The global bottom 50% capture 8% of total income and own 2% of global wealth (2025 PPP).
The top 10% capture 53% of income and own 75% of wealth, while the P90–99 capture 33% of income and own
38% of wealth. Moreover, the top 1% capture 20% of income and hold 37% of wealth. Income is measured after
pensions and unemployment benefits are received by individuals and before taxes and transfers. Sources and
series: Arias−Osorio et al. (2025) and wir2026.wid.world/methodology.

Global income and wealth inequality, 2025

curve. It shows that while the bottomhalf of the world has enjoyed relativelyrobust growth since 1980, the middle 40%experienced stagnation, with some groupsgrowing at less than 1% per year. Meanwhile,growth accelerated again at the very top,with the richest 1% and especially the top0.1% capturing the fastest gains. The resultis a polarized pattern: the poor and the richhave seen their incomes rise, while the globalmiddle class has benefited the least over thepast four decades. These uneven growthdynamics explain why today’s distributionof income is so skewed: the gains of thepast decades have consolidated mainlyat the very top. Such polarization alsocarries political implications: the relativeexclusion of large middle-income groups,the stagnation of many poorer groups inrich countries, and the growing influenceof the global plutocracy all raise pressingquestions for democratic stability and globalgovernance; we will return to this point inChapter 8.

Wealth inequality is larger, more extreme, andrising faster
So far, we have seen that, when examiningincomes, inequality is very large. But incomeinequality only tells part of the story, sinceit largely reflects labor earnings. Capitalincome, which is even more concentratedand closely tied to wealth ownership, addsanother layer of inequality.Figure 1.3 makes this clear: the global top10% owns three-quarters of all wealth, whilethe bottom 50% holds just 2%. Zoomingfurther in, the concentration becomesstaggering. The top 1% alone, roughly theadult population of the United Kingdom,controls 37% of global wealth. This is morethan eighteen times the wealth of the entirebottom half of the world population, a groupas large as the combined adult populationsof China, India, the United States, Indonesia,Nigeria, Brazil, and Russia.Figure 1.6 sheds light on just how extremeinequality becomes at the very top. The topone-in-a-million (about 5,600 adults, enoughto fill a concert arena) collectively hold 3% of

38