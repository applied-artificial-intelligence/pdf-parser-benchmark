 19 

 

A DECADE OF OECD COMPETITION TRENDS, DATA AND INSIGHTS © OECD 2025 
  

Figure 2.4. Average merger intervention rate, 2015-2024 

 

Note: The intervention rate is the share of mergers approved with remedies, prohibited or challenged over total merger decisions. A three-year 

average is used to smooth out volatility caused by random fluctuations. Data based on the 54 jurisdictions in the OECD CompStats database 

that provided data for merger remedies and merger prohibitions or challenges for the period 2015-2024. 

Source: OECD CompStats database 

Notably, the number of mergers prohibited or challenged increased as a proportion of total decisions, 

particularly in OECD jurisdictions, where most prohibition decisions are concentrated (see Figure 2.5). 

2024 was the year with the most prohibited or challenged mergers as a proportion of total merger decisions. 

As observed in the 2024 version of the Competition Trends report, an analysis of 216 prohibition or 

challenge decisions between 2015 and 2022 revealed that theories of harm based on unilateral, horizontal 

effects make up the majority of these decisions (OECD, 2024[19]). Prohibition decisions in non-OECD 

jurisdictions are relatively rare, representing less than 0.1% of merger decisions in 2024.  

Figure 2.5. Proportion of mergers challenged or prohibited over total merger decisions for OECD 
and Non-OECD jurisdictions, 2015-2024 

 

Note: A three-year average is used to smooth out volatility caused by random fluctuations. Data based on the 58 jurisdictions in the OECD 

CompStats database that provided data for merger prohibitions or challenges for the period 2015-2024. 

Source: OECD CompStats database 

0%

1%

2%

3%

4%

5%

6%

7%

Average merger intervention rate Trendline

Percentage of decisions

0.0%

0.1%

0.1%

0.2%

0.2%

0.3%

0.3%

0.4%

0.4%

0.5%

Percentage

All OECD Non-OECD