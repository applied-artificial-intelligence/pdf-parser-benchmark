6 Source data: Table 1

Receipts Outlays Deficit(-)/Surplus

2024 2025

O
ct

N
ov

D
ec Ja
n

Fe
b

M
ar

A
pr

M
ay

Ju
n

Ju
l

A
ug S
ep O
ct

N
ov

D
ec Ja
n

Fe
b

M
ar

A
pr

M
ay

Ju
n

Ju
l

A
ug S
ep

($1,000B)

($600B)

($200B)

$200B

$600B

$1,000B

($600B)

($400B)

($200B)

$0B

$200B

2024 2025

O
ct

N
ov

D
ec Ja
n

Fe
b

M
ar

A
pr

M
ay

Ju
n

Ju
l

A
ug S
ep O
ct

N
ov

D
ec Ja
n

Fe
b

M
ar

A
pr

M
ay

Ju
n

Ju
l

A
ug S
ep

$1,000B
$2,000B
$3,000B
$4,000B
$5,000B

($7,000B)
($5,000B)

($3,000B)

($1,000B)

($2,000B)

($1,000B)

$0B

Figure 4. Monthly Receipts, Outlays, and Budget Deficit/Surplus of the U.S. Government, Cumulative,
Fiscal Years 2024 and 2025

Receipts Outlays Deficit(-)/Surplus

Figure 3. Monthly Receipts, Outlays, and Budget Deficit/Surplus of the U.S. Government, Fiscal Years
2024 and 2025

$0B

blee
Line