Executive Summary

Figure 17. Without redistribution, political inequality willincrease

0%

10%

20%

30%

40%

50%

60%

P0−
P10

P10
−P

20

P20
−P

30

P30
−P

40

P40
−P

50

P50
−P

60

P60
−P

70

P70
−P

80

P80
−P

90

P90
−P

10
0

P
er

ce
nt

ag
e 

of
 to

ta
l p

ol
iti

ca
l 

 d
on

at
io

ns
 b

y 
in

co
m

e 
de

ci
le

France South Korea

Political donations by income decile, % of total

Interpretation. Average shares of total political donations by income decile in France and South Korea
(2013–2021). Donations are highly concentrated at the top, with the richest decile contributing the largest share.
Sources and series: Cagé (2024).

25