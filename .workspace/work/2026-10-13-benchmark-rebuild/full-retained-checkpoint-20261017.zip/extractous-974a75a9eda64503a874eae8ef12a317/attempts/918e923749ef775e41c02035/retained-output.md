Investing in Education 2025 
14   Part 1: Early signs of a moderate rebound in investment in education  

 
 
 
 
 
 

 
 

Figure 6. Evolution of nominal and real public expenditure on education in the EU-27 (index 
2007=100) 

 

Notes:  Real values are expressed at 2015 constant prices by using the price deflator for collective consumption 
expenditure of general government.  

Source:  European Commission services’ calculations based on Eurostat COFOG data and AMECO data 

 

Figure 7. Public expenditure by function (2019-2023) 

 
Source:  Eurostat COFOG data. Online data code: [gov_10a_exp]. 

 
Overall, early signs of a moderate rebound in investment in education are emerging against the 
backdrop of increased competition for public funding. 2023 data shows that investment in education 
started to bounce back from its post-pandemic low, especially as a share of total public expenditure. However, 
education faces a stronger competition from other public functions, and consequently continues to get a lower 
share of total public expenditure than in the 2010s. Although part of the measures taken in 2020-2021 to 
respond to the Covid-19 pandemic in the areas of economic affairs and health were discontinued over 
2022-2023, new measures were introduced to face the energy crisis and support Ukraine after Russia’s 
invasion. A clearer picture of whether a new composition of public expenditure in the EU has emerged out of 
the recent crises and the new economic and geopolitical priorities will likely appear only over the next few years. 

2019 2020 2021 2022 2023 2019-2023
% of total % of total % of total % of total % of total percentage point change

Economic affairs 10.1 12.3 12.7 12.1 11.8 1.7
Housing and community amenities 1.2 1.2 1.7 2.0 2.4 1.2
Defence 2.6 2.5 2.4 2.5 2.7 0.1
Environmental protection 1.7 1.6 1.5 1.6 1.7 0.0
Health 14.9 15.0 15.7 15.4 14.8 -0.1
Public order and safety 3.6 3.4 3.3 3.4 3.5 -0.1
Recreation, culture and religion 2.5 2.3 2.3 2.3 2.4 -0.1
General public services 12.3 11.4 11.4 11.9 12.0 -0.3
Education 10.0 9.3 9.3 9.4 9.6 -0.4
Social protection 41.2 41.1 39.6 39.3 39.3 -1.9

https://ec.europa.eu/eurostat/databrowser/view/gov_10a_exp__custom_16381775/default/table?lang=en
https://dashboard.tech.ec.europa.eu/qs_digit_dashboard_mt/public/sense/app/667e9fba-eea7-4d17-abf0-ef20f6994336/sheet/f38b3b42-402c-44a8-9264-9d422233add2/state/analysis/
https://ec.europa.eu/eurostat/databrowser/view/gov_10a_exp__custom_15908675/default/table?lang=en