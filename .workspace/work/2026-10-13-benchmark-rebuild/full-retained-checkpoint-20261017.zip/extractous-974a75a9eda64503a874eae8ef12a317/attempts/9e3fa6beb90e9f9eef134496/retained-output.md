Board of Directors

• SF REIT Asset Management Limited 
(the Manager of SF Real Estate 
Investment Trust) (listed on  
The Stock Exchange of Hong Kong 
Limited)

• Xihe Capital (Pte.) Ltd. (in liquidation 
pursuant to a members’ voluntary 
winding up since 22 October 2020 
and in liquidation pursuant to a 
creditors’ voluntary winding up since 
19 November 2021)

• Xihe Holdings (Pte) Ltd (under 
judicial management since  
13 November 2020 and in liquidation 
pursuant to a compulsory  
winding up since 24 March 2022)

• Zheneng Jinjiang Environment 
Holding Company Limited

Others:
• Partner, KPMG LLP (from September 

1994 to September 2015)

MR ONG KIAN MIN
INDEPENDENT DIRECTOR 

Date of first appointment as a Director:
17 September 2019

Length of service as a Director  
(as at 31 December 2024)
5 years 3 months

Board Committee(s) served on:
• Nominating and Remuneration 

Committee (Chairman)
• Audit and Risk Committee (Member)

Academic & Professional Qualification(s):
• Bachelor of Laws (Honours), 

University of London, England
• Bachelor of Science (Honours), 

Imperial College of Science & 
Technology, England

• Advocate and Solicitor, Singapore

Present directorships  
(as at 1 January 2025):
Listed companies
• Food Empire Holdings Limited
• Silverlake Axis Ltd (delisted from 

the Singapore Exchange Securities 
Trading Limited on 3 January 2025)

• YHI International Limited

Other principal directorships
• JEKKA-MOLLE Pte. Ltd.
• Kanesaka Sushi Private Limited
• QEnergy Pte Ltd
• Artista Associates Pte. Ltd.
• Artista Technologies Pte. Ltd.

Major Appointments  
(other than directorships):
• Board Member, Alpha Singapore 

Past Principal Directorships held over the 
preceding 5 years 
(from 1 January 2020 to 31 December 2024):
• BreadTalk Group Limited
• Penguin International Limited
• GPTW Institute (Singapore) Pte Ltd
• One Eternity Foundation Company 

Limited

Others:
• Former Member of Parliament of 

Singapore (1997 – 2011)
• President’s Scholarship and the 

Singapore Police Force Scholarship 
(1979)

MS USHA RANEE CHANDRADAS
INDEPENDENT DIRECTOR 

 
Date of first appointment as a Director:
8 November 2017

Length of service as a Director  
(as at 31 December 2024)
7 years 2 months

Board Committee(s) served on:
• Audit and Risk Committee (Member)
• Nominating and Remuneration 

Committee (Member) 
Academic & Professional Qualification(s):
• Bachelor of Laws (Honours),  

King’s College, University of London
• Graduate Diploma in Singapore Law, 

National University of Singapore
• Master of Professional Accounting 

degree, Singapore Management 
University 

• Master’s degree in Asian Art 
Histories, Goldsmith’s College, 
University of London, awarded 
by LASALLE College of the Arts 
Singapore

• Advocate and Solicitor, Singapore
• Accredited Tax Specialist –  

Income Tax, Singapore Chartered  
Tax Professionals

• Chartered Accountant of Singapore 

Present directorships  
(as at 1 January 2025)
Listed companies
• OUE Healthcare Limited

Other principal directorships
• NUR Investment and Trading Pte Ltd

Major Appointments  
(other than directorships):
• Nominated Member of Parliament of 

Singapore 
• (Plu)ral Art LLP (Founder and 

Partner)
• Adjunct Associate Professor at the 

Nanyang Technological University’s 
Nanyang Business School  
(Centre of Excellence International 
Trading) 

• Member of the International 
Monetary Fund’s Panel of Experts 
(Tax-Legal) 

• Singapore Red Cross Council 
Member

• Pro Bono Services Office – Law 
Society of Singapore, Finance 
Committee (Member), Project 
Law Help (Vice Chair), Content 
Management Committee (Chair)

• Intellectual Property Office of 
Singapore (Member of the Board)

Past Principal Directorships held over the 
preceding 5 years  
(from 1 January 2020 to 31 December 2024):
• Nil

Others:
• Council member of the Law Society 

of Singapore (from 2014 to 2015)

OUE REIT26