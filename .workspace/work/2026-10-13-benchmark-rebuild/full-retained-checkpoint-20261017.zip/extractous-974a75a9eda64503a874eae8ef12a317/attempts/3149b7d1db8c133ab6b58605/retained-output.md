Japan and China Properties

Strategically located in the prime area of Ebisu (Shibuya 
Ward), Ebisu Fort is a seven-storey building (with two 
basement levels), featuring convenience retail, golf 
school and services. As at 30 June 2024, the property 
is fully occupied. 

The property appeals to young and stylish urbanites 
and is approximately a seven-minute walk from the 
Ebisu station of the JR line.

Having weighed the cost and benefits of earthquake 
insurance for the property, no specific earthquake 
insurance has been taken up, which is consistent with 
industry practice in Japan.

The China Property is located in the vibrant city of 
Chengdu, the capital city of Sichuan province. Chengdu 
is the third city in China with two airports, after Beijing 
and Shanghai. 

Situated along the Second Ring Road, the China Property  
is in close proximity to prime residential estates and 
 offices. The Nijiaqiao MRT station is located in front of  
the property and is easily accessible by major roads 
and public transport. Comprising four levels of retail 
space with a mezzanine floor, the China Property is 
tenanted to a sole tenant, Markor, which is one of the 
largest furniture retailers in China. The parent company 
of Markor is listed on the Shanghai Stock Exchange, with 
a market capitalisation of RMB3.1 billion (approximately 
S$0.6 billion(3)) as at 30 June 2024. The tenancy 
agreement incorporates a fixed rent with a periodic  
rent step-up.

Ebisu Fort

China 
Property

Starhill Global REIT’s Japan and China portfolio 
comprises one contemporary commercial 
building in prime Tokyo area and one single 
tenanted mall in Chengdu. 

Address:
1-24-2 Ebisu-Minami, Shibuya-ku, Tokyo, Japan 
Visit:
www.starhillglobalreit.com/ebisu-fort.html

Address:
19, 4th Section, Renminnan Road, Chengdu,  
Sichuan, China
Visit:
www.starhillglobalreit.com/china-property.html

Tenure 

Freehold
Number Of Tenants
(As at 30 June 2024)

6
Purchase Price

S$71.3M

Tenure 

Leasehold
expiring on  
27 December 2035
(Remaining tenure of 11 years)

Tenant(2)

(As at 30 June 2024)

Markor
Lease expiring in  
FY 2026/27

Purchase Price

S$70.6M

Market Valuation
(As at 30 June 2024)

S$33.2M

Market Valuation
(As at 30 June 2024)

S$24.7M

Total Net Lettable Area
(As at 30 June 2024)

18,816 SQ FT

Total Gross Floor Area
(As at 30 June 2024)

100,854 SQ FT

Retail
100.0%

Retail
100.0%

Occupancy Rate(1)(2)

(As at 30 June 2024)

(As at 30 June 2023)

Notes:
(1) Based on committed leases as at the reporting date. 
(2) Under single tenancy agreement with Markor. Excludes tenant’s option to 

pre-terminate. 
(3) Based on exchange rate of RMB5.35:S$1.00 as at 30 June 2024.

Retail
100.0%

Retail
100.0%

Occupancy Rate(1)

(As at  
30 June 2023)

(As at  
30 June 2024)

Retail Trade Mix
By Gross Rental Contribution 
(As at 30 June 2024)

 Others
 General Trade
 Services
 Health & 
Beauty 

31.2%
29.1%
25.3%
14.4%

48 STARHILL GLOBAL REIT