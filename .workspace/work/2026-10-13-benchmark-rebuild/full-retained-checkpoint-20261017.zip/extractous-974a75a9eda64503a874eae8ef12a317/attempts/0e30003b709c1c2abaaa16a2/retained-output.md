26    

OECD ECONOMIC OUTLOOK, VOLUME 2025 ISSUE 2 © OECD 2025 
  

Figure 1.14. Underlying inflation and short-term inflation expectations have risen in some 
economies 

 
Note: In Panel A, the latest data are for October 2025, except for the United States (August 2025). Trimmed mean inflation is the recomputed 

overall inflation rate after removing 10% of the consumer basket at the top and at the bottom of the distribution of inflation rates so that the most 

extreme price changes are excluded. In Panel B, the most recent monthly data are for November for Korea, New Zealand, the United Kingdom 

and the United States, October 2025 for Mexico, and September 2025 for other countries, except Australia and Canada (third quarter of 2025). 

Source: Banco de Mexico; Bank of Canada; Bank of Japan; Bank of Korea; Bureau of Economic Analysis; European Central Bank; Eurostat; 

Federal Reserve Bank of Atlanta; Korean Statistical Information Service; Ministry of Statistics and Program Implementation; Office of National 

Statistics; Reserve Bank of Australia; Statistics of Japan; Turkish Statistical Institute; University of Michigan; YouGov/Citigroup; and 

OECD calculations.  

StatLink 2 https://stat.link/0bjrsm 

Financial market conditions have improved 

Financial conditions have eased considerably since April in both advanced and emerging-market 

economies, with financial market volatility and stress indicators generally remaining low, strong equity 

returns, compressed credit spreads and the depreciation of the US dollar against most currencies this year. 

However, sovereign yield curves have steepened considerably at the long end, suggesting growing 

concerns about fiscal risks. Soaring gold prices and large-scale hedging of US dollar-denominated 

exposures also point to continued uncertainty. 

Equity markets have risen strongly, particularly in the United States, where price-earnings valuations are 

approaching levels last seen in the late 1990s at the peak of the dot-com bubble (Figure 1.15, Panel A). 

Equity risk premia have also continued to decline, reaching levels last observed in 2005–06 prior to the 

global financial crisis, highlighting strong risk appetite. Despite some sell-offs in recent weeks, technology 

stocks remain the main driver of the surge in equity prices, reflecting investor enthusiasm for the potential 

gains from AI and stronger expected earnings growth than in other sectors and jurisdictions (Figure 1.15, 

Panel B). After soaring for most of this year, the market value of crypto-assets has declined sharply, by 

around 30% from the peak reached in early October. In the United States domestically focused 

US companies, often reliant on imported inputs, face higher costs and have continued to see more limited 

gains than other companies (Roulet and Tatomir, 2025). Japanese equities have also performed strongly, 

supported by robust earnings prospects, but equity prices have risen more slowly in Europe, reflecting 

softer expected earnings growth. Equity performance has remained weaker for firms heavily exposed to 

US tariffs in these jurisdictions.  

https://stat.link/0bjrsm