Utilisation is consistently the most measured KPI in 
professional services companies. It is also an indicator 
of the balance between workload and opportunity. 

This year the industry surpassed the past 15 years of 
billable utilisation levels with a record-breaking 73.2%. 

One of the main drivers for a high billable utilisation 
is the adoption of PSA solutions, as companies using 
PSA display 75.3% billable utilisation. In contrast, 
companies that have not yet adopted a PSA solution 
could only muster 68.1% in 2021.

Billable utilisation 
Consultants’ time was highly billable in 2021

2017 2018 2020 20212019

5 years of billable utilisation:

Do your consultants not spend enough time on 
billable work? 
 Do you and your employees have access to  
 real time dashboards that let you   
 keep track of your billable utilisation? 

 Have you identified the non-billable   
 activities your employees spend most time  
 on? 

Initiated Piloted Deployed Institutionalised Optimised

73.2%

71.5%

69.7%

71.7% 71.4%

Billable utilisation across maturity levels
Mature companies outperform industry average utilisation 
by 13%

57.3% 68.2% 77.2% 77.5% 82.5%

20