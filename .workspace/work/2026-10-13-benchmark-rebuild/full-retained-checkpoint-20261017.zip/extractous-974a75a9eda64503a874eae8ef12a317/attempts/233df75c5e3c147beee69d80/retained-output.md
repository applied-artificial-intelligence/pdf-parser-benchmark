26 27

Stakeholder Engagem
ent

Financial Capital:
Natural Capital

Hum
an Capital

Social Capital
Intellectual Capital

Ab
ou

t t
he

 R
ep

or
t

FY 2024-25Sustainability Report FY 2024-25 Sustainability Report
Le

ad
er

sh
ip

 In
si

g
h

ts
R

es
p

on
si

b
le

 B
an

ki
n

g
Ap

pr
oa

ch
 to

 g
ov

er
na

nc
e

St
ra

te
gy

Ab
ou

t t
he

 B
an

k

Aligning profit with purpose 
As country’s leading bank, SBI recognizes that its role extends far beyond its operations. The 
Bank is cognisant of its responsibility to drive positive environmental impact through its product 
offerings across value chain. SBI recognises the importance of integrating responsible banking 
principles into financial decision making and investment strategies, which plays a crucial role in 
transition to more sustainable and resilient economy.

Green energy investments
As India’s oldest and largest commercial bank, 
SBI is committed to playing a leading role in 
India’s transition towards a green economy 
by stepping up transition finance to clean 
energy such as solar, wind, hydro, biomass, 
and new age technologies. The Bank has set 
an ambitious target to achieve green portfolio 
of at least 7.5% of its domestic gross advances 
by 2030, underscoring its commitment to 
sustainable financing. To realize this goal, 
the Bank has developed a comprehensive 
roadmap with year wise annual targets and 
has developed tools to measure and monitor 
the growth of its green portfolio.

The Bank also supports industries in their 
decarbonization efforts through transition 
finance, including financing for low-
carbon technologies and energy efficiency 
improvements thereby facilitating our clients 
to achieve their sustainability goals.

The Bank has taken proactive steps in capacity 
building for emerging sectors, including 
green hydrogen, battery storage and electrical 

Responsible banking is at the core of the SBI’s operations, aligning with the vision 
of Viksit Bharat- a developed and self-reliant India. The Bank remains committed 
to supporting India’s growth journey, with a focus on sustainability, inclusivity, and 
resilience.  SBI continues to finance projects that contribute towards greener economy 
and promote financial inclusion towards resilient India.

SBI’s initiatives on responsible banking

Responsible 
Banking

BRSR Principle

Material Topic Impacted 

Key Performance Highlights 

SDGs Impacted

Principle 7: Business, when 
engaging in influencing public 
and regulatory policy, should do 
so in a manner that is responsible 
and transparent 

 Economic performance

 ₹76,736 Crore  
Financed for RE Initiatives 

 ₹20,558 Crore  
Sanctioned for Sustainability 
Linked Projects 

₹128.31 
Crore   

Green Rupee 
Term Deposits

₹76,736  
Crore 

Financed for 
RE initiatives

Approx USD 
3.07 bn  

Borrowings 
through Lines 

of Credit

₹20,588 Crore 
Sanctioned for 
Sustainability 

Linked Projects

>38 GW 
Capacity of 

RE Financed 
Portfolio

Sustainability Report FY 2024-25

mobility. The Bank is also in the process of 
setting up a “Centre of Excellence” dedicated to 
New Age Sectors, reinforcing SBI’s leadership 
in project finance, sustainability finance and 
supporting India’s commitment to achieve 
Net Zero by 2070.

Green/ESG borrowings Lines 
of Credit  
Leveraging global partnership, the Bank 
avails Lines of Credit (LoCs) from various 
Development Financial Institutions (DFIs) and 
Multilateral Development Banks (MDBs) to 
supplement sustainable financing activities. 

State Bank of India and the Asian 
Development Bank (ADB) signed a 

USD 90.50 million loan agreement on 
December 20, 2024, to fund residential 

solar rooftop projects.