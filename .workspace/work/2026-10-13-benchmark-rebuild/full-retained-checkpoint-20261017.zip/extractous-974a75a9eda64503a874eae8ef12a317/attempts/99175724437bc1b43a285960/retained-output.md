KENNETHWOODS
PORTFOLIO MANAGEMENT PROGRAM

6

Business overview and drivers

Exhibit 1 GS revenue driver dashboard

F1: IB: DCM revenues F2: IB: ECM revenues

F3: IB: Financial advisory revenues F4: IB: Overall investment banking revenues

F5: ICS: FICC revenues F6: ICS: Equities revenues

25

75

125

175

225

Performance indexed to 100

Global M&A deal count Global M&A deal volume
GS Financial advisory revenue

--

100

200

300

400

Performance indexed to 100

Global IPO deal count Global IPO value

GS equity underwriting revenue

50
70

90

110

130

150

170
Performance indexed to 100

US corporate profits GS investment banking revenues

40

90

140

190

240

FY2010 FY2011 FY2012 FY2013 FY2014 FY2015

Performance indexed to 100

S&P 500 volume Vix index GS ICS equity revenues

--

50

100

150

200

FY2010 FY2011 FY2012 FY2013 FY2014 FY2015

Performance indexed to 100

Interest rate (US 10yr) High yield spread (inverted)
GS FICC revenues

--

50

100

150

200

FY2012 FY2013 FY2014 FY2015

Performance indexed to 100

DCM deal value Deal count GS debt underwriting revenues