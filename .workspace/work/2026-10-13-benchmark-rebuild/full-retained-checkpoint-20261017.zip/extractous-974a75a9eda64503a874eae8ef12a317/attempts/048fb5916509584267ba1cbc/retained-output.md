2024 UN E-GovErNmENt SUrvEy

146

C
h

ap
ter 4

The 2024 analysis related to public procurement reveals that 59 per cent of the city portals assessed 
share procurement announcements – a notable increase from 53 per cent in 2022. There has been 
a more modest rise, from 40 to 42 per cent, in the publication of procurement results. The adoption 
of e-procurement platforms has seen significant growth, rising from 36 per cent in 2022 to 42 per 
cent in 2024. Those cities that utilize national portals are awarded a point here as long as they link to 
a procurement portal with clear guidelines. For example, the Dublin city portal, in its Doing Business 
with the council section,13 clearly explains public procurement guidelines and provides a link to the 
national portal (etenders.gov.ie). conversely, the Tokyo e-procurement portal14 serves as a centralized 
platform for managing procurement processes electronically, facilitating transparent and efficient 
procurement activities for the city’s government agencies and vendors. 

Services provision

Although services provision continues to have the lowest level of compliance among the six criteria 
assessed (see figure 4.5), the data reveal a notable increase in the availability of online services since 
2022, with several indicators showing improvement (see figure 4.10). Among the most frequently 
met indicators are those relating to waste and recycling information and public transportation 
services, followed by online payment options for fines, utility bills and services. 

It is encouraging to see the increased presence of waste and recycling information on city portals, as 
this signals a growing commitment to environmental sustainability and the involvement of residents in 
waste management efforts. cities recognize the importance of offering people access to resources on 
waste reduction, recycling and reuse to encourage environmentally friendly behaviours and promote 
widespread engagement in tackling environmental challenges. These trends are promising and have 
the potential to contribute meaningfully to environmental sustainability. The Berlin city portal15 offers 
comprehensive guidance on waste management and disposal in the city, providing information on 
bulky waste disposal, clothing donations, e-waste recycling, and household waste segregation. 
Through its portal, the city government emphasizes the importance of environmental responsibility, 
offering information on recycling centres, donation organizations, and pollutant collection points to 
facilitate proper disposal practices and promote sustainability within the community.

Figure 4.9 Procurement information on city portals

59%

42%

42%

53%

40%

36%

0% 10% 20% 30% 40% 50% 60% 70%

Procurement announcements

Procurement results

Procurement platform

2022 2024