D I R E C TO R S ’ R E P O R T

3 3

The table immediately below sets out the total

remuneration of the three (3) highest remunerated executive officers of Mermaid during the

Financial Year. These three (3) are the only executive officers who meet the disclosure criteria.

Name Office Salary Other Total Employee

(i) Options

$ $ $ (number)

A Roberts Group Development Manager 149,195 10,806 160,001 Nil

L Churchill Technical Support Manager 111,918 12,644 124,562 Nil

R Graham-Measor Quality Control & Safety  75,064 15,643 90,707 Nil

Manager

(i) ‘Other’ includes superannuation, provision of motor vehicles and related fringe benefits tax.

Signed in accordance with a resolution of directors made pursuant to S.298(2) of the

Corporations Law.

On behalf of the Directors

Alan Birchmore

Chairman

Fremantle , 29 September 2000

E X E C U T I V E  O F F I C E R S ’  R E M U N E R AT I O N