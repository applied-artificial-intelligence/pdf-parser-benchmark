Australia Properties

Plaza Arcade is located in the heart 
of the city next to the David Jones 
Building. It sits on a freehold site 
of approximately 27,523 sq ft. 
The property is one of two main 
thoroughfares with entrances at 
both Hay and Murray Street Malls 
and comprises a three-storey 
heritage-listed retail building with 
17 tenancies. The property was 
91.9%(1) occupied as at 30 June 
2024, an improvement of over 10 
percentage points y-o-y, largely 
due to new tenants, Nespresso and 
Mazzucchelli's.

Plaza Arcade is anchored by UNIQLO’s 
first Perth store, which occupies a 
prominent frontage along Murray 
Street. The tenant mix of the asset is 
diversified, comprising fashion, food 
& beverage and services. Most leases 
at the property provide for rental 
upside from an annual upward-only 
rent review. Plaza Arcade's tenant mix 

Plaza 
Arcade
A three-storey heritage-listed retail building located 
next to the David Jones Building.

Tenure 

Freehold
Number Of Tenants
(As at 30 June 2024)

17
(including an anchor tenant)

Purchase Price

S$61.0M

Market Valuation
(As at 30 June 2024)

S$38.5M

Total Gross Lettable Area
(As at 30 June 2024)

36,933 SQ FT

91.9%

81.7%

Occupancy Rate(1)

(As at 30 June 2024)

(As at 30 June 2023)

Notes:
(1) Based on committed leases as at the reporting date.
(2) Based on gross rent as at 30 June 2024 and excludes gross turnover rent.
(3) Includes the UNIQLO lease.

Top 5 Tenants based on gross rent(2)

1. Uniqlo Australia Pty Ltd

2. The Jewellery Group Pty Ltd 

3. Nestle Australia Ltd 

4. Ghost Star Pty Ltd 

5. Conti Deli Pty Ltd 

complements Perth city centre’s 
transformative developments 
including the new ECU City 
Campus located at Perth City Link, 
Elizabeth Quay, the new emerging 
luxury precinct and the growth of 
student accommodation.

Retail Trade Mix
By Gross Rental Contribution 
(As at 30 June 2024)

 UNIQLO  
(Anchor Tenant)

 Jewellery
 General Trade
 Services
 Fashion
 Food & Beverage
 Storage

69.1%

8.3%
7.0%
6.1%
4.8%
4.0%
0.7%

11.4 73.1(3) 5.4 0.0 10.1

FY
24/25

FY
25/26

FY
26/27

FY
27/28

Beyond
FY 27/28

0

20

40

60

80

100

Lease Expiry Profile by gross rent(1)

(%)

43ANNUAL REPORT FY 2023/24