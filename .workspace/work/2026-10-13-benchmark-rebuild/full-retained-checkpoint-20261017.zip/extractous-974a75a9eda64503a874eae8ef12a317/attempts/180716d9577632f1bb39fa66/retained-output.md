 9 

OECD ECONOMIC OUTLOOK, INTERIM REPORT MARCH 2025 © OECD 2025 
  

4. Trade policy uncertainty has increased markedly in recent months, with the introduction of new 

trade barriers by a number of countries. This has translated into a substantial increase in newspaper-based 

measures of economic policy uncertainty (Figure 2, Panel C). Across the economies with available data, 

the biggest rise in policy uncertainty has been in Canada and Mexico (Figure 2, Panel D), both countries 

that are subject to increased tariff rates on bilateral exports to the United States. Greater policy uncertainty 

can be expected to hold back spending decisions by companies and households, particularly on 

longer-term items such as fixed capital investment and durable goods.  

Figure 2. Consumer confidence remains weak and economic policy uncertainty has spiked in 
advanced economies 

 

Note: Panel B shows a PPP-based weighted mean and is based on G20 economies except Argentina and Saudi Arabia. In Panel C, ‘Advanced 

economies’ includes Australia, Canada, Chile, France, Germany, Ireland, Italy, Japan, Korea, the Netherlands, Spain, Sweden and the United 
Kingdom, and ‘Emerging-market economies’ includes Brazil, India and Russia. 
Source: policyuncertainty.com; OECD, Main Economic Indicators database; and OECD calculations.