Renewables 2025 Chapter 1. Renewable electricity 
Analysis and forecasts to 2030 
 

PAGE | 42  I E
A.

 C
C

 B
Y

 4
.0

. 

pressures due to anti-dumping and countervailing duties (AD/CVD) on modules 
imported from countries such as Cambodia, Malaysia and Viet Nam, along with 
increased tariffs on Chinese solar cells.  

These tariffs could drive up costs just when federal subsidy support is ending. 
Plus, tariffs on non-energy-specific technologies and components may create 
additional financial pressure as the administration applies them to enabling 
infrastructure and construction materials, such as steel for transmission and 
distribution wires. 

Despite these headwinds, the accelerated-growth scenario anticipates nearly 24% 
higher capacity additions than in the main forecast. This optimistic outlook 
assumes the effective mitigation of current challenges through expanded 
corporate renewable energy procurement and stronger state-level renewable 
portfolio standards. 

Latin America and the Caribbean 

Solar PV is set to tie hydropower for largest installed capacity 
in 2030 
The Latin America and Caribbean region is expected to add almost 160 GW of 
renewable energy capacity by 2030, with solar PV making up most of this growth. 
In fact, solar PV is projected to match hydropower in total installed capacity by 
2030.  

Total installed renewable capacity by technology in Latin America and the Caribbean, 
2010-2030 

 
IEA. CC BY 4.0. 

 

While both utility-scale and distributed solar PV are expanding rapidly and their 
capacities were roughly equal between 2023 and 2025, utility-scale installations 

0

 50

 100

 150

 200

 250

2010 2012 2014 2016 2018 2020 2022 2024 2026 2028 2030

In
st

al
le

d 
ca

pa
ci

ty
 (G

W
)

Hydropower

Wind

Solar PV

Utility-scale PV

Distributed PV

Other renewables