2024 UN E-GovErNmENt SUrvEy

68

C
h

ap
ter 2

The number of countries that allow individuals and businesses to access or modify their data on 
government portals has increased by an average of 6 per cent since 2022. Globally, more countries 
allow users to access their data (71 per cent for businesses and 68 per cent for individuals) than to 
modify their data (64 per cent for businesses and 56 per cent for individuals). 

In 118 countries (a 3 per cent increase from 2022), it is possible for users to save specific service 
transactions initiated on the portal and access them later. The proportion of countries that allow 
users to access a list of their previous transactions or rely on AI-enabled chatbot functionality is nearly 
the same in 2024 as in 2022. 

For the 2024 Survey, a new “affordability” indicator was added to the TII and the use of “the fixed 
(wired) broadband subscriptions” indicator was discontinued (see the technical appendix for details 
on the methodology used). While the technology subindex of the OSI does not include TII component 
data, it is important to highlight the changes in TII indicators as part of the evolving landscape of 
technological advancement. Table 2.8 summarizes the global and regional findings for indicators 
relating to mobile service pricing, broadband and cellular subscriptions, and Internet use for 2022 
and 2024. Figure 2.28 highlights the changes in the latter three indicators between 2022 and 2024.

Internet use and subscriptions for mobile broadband and cellular services are on the rise. The sharpest 
increases in Internet use have been in Oceania (49 per cent) and Africa (31 per cent). The active 
mobile broadband subscription rate has increased by 27 per cent in Africa, 10 per cent in Asia and 
the Americas, and 8 per cent in Europe, but has declined by almost 2 per cent in Oceania (see figure 
2.28). Europe remains the leader in active mobile broadband use, with 105 subscriptions per 100 
inhabitants, followed by Asia (89) and the Americas (73).

Figure 2.27 Number of Member States with portals incorporating the assessed technology features,  
 2022 and 2024

Sources: 2022 and 2024 United Nations E-Government Surveys.

193 UN Member States

Americas

Africa

Asia

Europe

Oceania

Very high EGDI
High EGDI
Middle EGDI
Low EGDI

26%

56%

58%

50%

64%

59%

65%

58%

71%

83%

88%

97%

98%

98%

27%

58%

61%

56%

68%

64%

71%

56%

74%

89%

91%

97%

97%

98%

0% 10% 20% 30% 40% 50% 60% 70% 80% 90% 100%

Portal offers AI-enabled chatbot functionality

Users can access a list of their previous
interactions or transactions in the portal

Speci�c service transactions initiated through
the portal can be saved and accessed later

Individuals can  modify their own data online

Individuals can access their own data online

Businesses can modify their own data online

Businesses can access their own data online

There is an "advanced search" option

There is a sitemap (or index)

Portal has been updated in the last month

Portal is developed using responsive web design

Portal utilizes HTTPS

There is a "contact us" feature

Portal can be found on search engine

2024
2022