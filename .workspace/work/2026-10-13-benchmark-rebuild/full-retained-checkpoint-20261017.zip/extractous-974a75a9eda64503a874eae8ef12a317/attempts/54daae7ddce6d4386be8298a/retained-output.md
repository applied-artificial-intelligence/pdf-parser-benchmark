18 
 

The water purifier product market in India has steadily transitioned towards branded play, with branded players 

commanding a substantial 83% market share as of FY2024. Within this branded market, the top 5-7 leading 

players hold close to 90% market share. The shift towards branded play over unbranded play is influenced by 

factors on both the demand and supply sides. On the demand side, increasing health awareness among consumers 

and increase in availability and access to piped water are key drivers of this shift. On the supply side, technological 

interventions, brand-building initiatives by major players, the implementation of GST, and robust distribution 

network servicing extensive retail footprints contribute to the transformation towards branded play. As of FY2024, 

branded play accounted for nearly 83% (~INR 4,035 crore) of the water purifier product market in India. This 

marks a significant increase from the market share of around 78% (~ INR 2,960 crore) recorded in FY2019, 

showcasing a notable growth trajectory for the branded market. The branded play is estimated to capture ~88% 

(~INR 6,890 crore) market share by FY2029.  

 

Exhibit 3.5: Share of Branded Play in Indian Water Purifier (Product) Market- By Value (in %) (FY) 

   
Source: Technopak Analysis 
 

Key Sub-categories of Water Purifiers 
 

By Need for Electricity 

The Indian water purifier market can be segmented based on the need for electricity into Electric and Non-Electric 

categories. Electric water purifiers require electricity to operate and utilize RO, UV, or a combination of both 

RO+UV technology to provide pure and clean drinking water. RO water purifiers reduce Total Dissolved Solids 

(TDS) and enhance taste, making them suitable for areas with medium to high TDS levels in the fresh water 

supply. On the other hand, UV water purifiers remove sediments, microbials, and improve the water odor, making 

them applicable in areas with a low level of TDS in the fresh water supply. Filters of electric water purifiers 

typically need replacement once a year.  

 

Non-electric water purifiers operate without electricity and employ gravity-based mechanisms to purify water. 

They use a variety of filters like sediment filters, carbon filters etc., UF (Ultra Filtration) and/or chemical 

technology to remove impurities and bacteria, ensuring water purification. Non-electric water purifiers are 

particularly preferred in situations where inline water supply and electricity are not available. While these water 

purifiers do not enhance the taste and color of the water, they are suitable for use when the TDS level is low, i.e., 

within consumable limits. Filters of non-electric water purifiers typically require replacement every 3-6 months.  

 

Electric water purifiers exhibit superior water purification efficiency compared to non-electric water purifiers. As 

of FY2024, electric and non-electric water purifiers accounted for ~97% (INR 4,715 crore) and ~3% (INR 145 

crore) respectively, of the overall Indian water purifier product market by value. It is projected that by FY2029, 

electric and non-electric water purifiers will constitute ~99% (INR 7,750 crore) and ~1% (INR 80 crore) 

respectively, of the overall Indian water purifier product market by value. In terms of volume, the market size of 

electric and non-electric water purifiers was ~3.6 and ~0.6 million units as of FY2024. By FY2029, the market 

size of electric and non-electric water purifiers is projected to be ~5.1 and ~0.2 million units, respectively. 

 

 

 

 

 

 

 

78%

22%

2019

83%

17%

2024

Branded Play Unbranded Play

88%

12%

2029P