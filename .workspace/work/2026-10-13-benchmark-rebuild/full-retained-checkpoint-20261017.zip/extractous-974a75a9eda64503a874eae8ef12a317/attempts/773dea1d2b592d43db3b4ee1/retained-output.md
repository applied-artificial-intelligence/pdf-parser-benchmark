2025 Professional Services Maturity™ Benchmark  Talent Pillar 
  

 

 

© 2025 Service Performance Insight, LLC www.workday.com/professionalservices 143 

TALENT PILLAR 

The Talent Pillar is the central element in Service Performance Insight’s Professional 
Services Maturity™ Model. It encompasses all Professional Services Organization 
(PSO) workforce strategy aspects. This pillar focuses on the people, processes, and 
systems needed to recruit, attract, train, motivate, and retain a high-quality 
consulting workforce. Given the changing dynamics of the workforce, it requires more 
attention than ever.  

Talent remains a key challenge and a primary area for improvement in professional 
services. In 2024, factors such as rising inflation, high interest rates, global conflicts, 
and uncertainties surrounding the US election have impacted the global economy. 
Additionally, the skills required due to the emergence of AI in both professional and personal environments 
have transformed the workplace. A significant portion of the consulting workforce operates virtually, with 
68% of consulting hours delivered off-site, up from 58% in 2023. Today’s consulting work relies on a 
multilingual, multigenerational, multicultural, technically skilled, and project-based workforce. The 
demand for horizontal applications and technical skills remains high while emphasis is shifting toward 
business processes and vertical expertise due to technological advancements. 

The key takeaway from the Talent Pillar is that implementing best practices—such as providing clear roles 
and job descriptions, timely performance reviews, fair compensation, career planning, and skill 
development—results in significant benefits for employee satisfaction, billable utilization, and on-time 
project completion. A well-executed talent strategy can lead to lasting advantages, so creating a focused 
list for any maturity improvement plans is essential. 

Figure 26:  Talent Trends of Note 

Source: SPI Research, February 2025 

Figure 26 highlights some of the trends associated with talent. At the same time, the numbers aren't 
significantly different from 2023. They do show a lengthened recruiting cycle and increased cost per 
consultant. These two KPIs are correlated, and PS executives must plan for the additional time and 
expense as talent becomes scarce. This change is especially true considering artificial intelligence, and 
PSOs will need the best consultants available to drive revenue. SPI Research was also concerned with the