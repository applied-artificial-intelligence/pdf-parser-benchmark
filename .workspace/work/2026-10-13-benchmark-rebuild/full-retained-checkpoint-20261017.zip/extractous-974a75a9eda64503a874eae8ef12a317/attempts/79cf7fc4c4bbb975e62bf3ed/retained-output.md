HKR For Handwritten Kazakh & Russian Database 5

Fig. 6 Examples of segmented words.

5 Further Characteristics of the Database

The database consists of more than 1400 filled forms writ-
ten by 200 writers. There are approximately 63000 sentences,
more than 715699 symbols shown in Fig. 7. And also There
are approximately 106718 words. total images in the dataset
after pre-processing and segmentation the forms are 64943
images.

6 Conclusion and Future Work

We have built the handwritten Kazakh, Russian database.
The database can serve as a basis for research in handwrit-
ing recognition. This contains Russian Words (Areas, Cities,
Village, Settlements, Areas, Streets) by a hundred different
writers. It also incorporates the most popular words in the Re-
public of Kazakhstan.A few pre-processing and segmentation
procedures have been developed together with the database.
Finally, it contains free handwriting forms in any area of the
writer interest. This database is meant to provide a training
and testing set for Kazakh, Russian Words recognition re-
search.In future, as further work on gathering Handwriting
samples of keywords and envelope shots will continue.At the
same time, envelopes are annotated and various metrics are
checked to evaluate the recognition error.In order for the arti-
facts to not interfere, we need to collect as much tagged data
as possible.

Fig. 7 Histogram of Characters in the dataset

Acknowledgements This work was funded by the Min-
istry of Education and Science of the Republic of Kazakhstan
(Grant No AP05135175)

References

1. U. Marti and H. Bunke, A full English sentence database
for off-line handwriting recognition, In Proc. of the 5th Int.
Conf. on Document Analysis and Recognition, pages 705 -
708, (1999).

2. H. Liu and X. Ding, Handwritten Character Recognition
using Gradient Feature and Quadratic Classifier with Mul-
tiple Discrimination Schemes, Proc. 8th Int. Conf. on Doc-
ument Analysis and Recognition, pp. 19-25, (2005).

3. Fischer, Andreas, Ching Y. Suen, Volkmar Frinken, Kas-
par Riesen, and Horst Bunke, A fast matching algorithm for
graph-based handwriting recognition.In Graph-Based Rep-
resentations in Pattern Recognition, pp. 194-203. Springer
Berlin Heidelberg, (2013).

4. Zamora-Martnez, Francisco, Volkmar Frinken, Salvador
Espaa-Boquera, Maria Jose Castro-Bleda, Andreas Fischer,
and Horst Bunke, Neural network language models for off-
line handwriting recognition, Pattern Recognition 47, no. 4
(2014): 1642-1652.

5. Tao, Dapeng, Lingyu Liang, Lianwen Jin, and Yan Gao,
Similar handwritten Chinese character recognition by ker-
nel discriminative locality alignment, Pattern Recognition
Letters 35 (2014): 186-194.

6. Das, Soumendu, and Sreeparna Banerjee, An Algorithm
for Japanese Character Recognition, International Journal
of Image, Graphics and Signal Processing (IJIGSP) 7, no.
1 (2014): 9.

7. U. Bhattacharya, M. Shridhar, S. K. Parui, P. K, Sen
and B. B. Chaudhuri, Offline recognition of ine recognition
of handwritten Bangla characters: an efficient two-stage
approach, Pattern Analysis and Applications, vo1.l5(4),
pp.445-458, (2012).

8. John, Jomy, and Kannan Balakrishnan, A system for of-
fline recognition of handwritten characters in Malayalam
script, International Journal of Image, Graphics and Signal
Processing (IJIGSP) 5, no. 4 (2013):53.

9. Parvez, Mohammad Tanvir, and Sabri A. Mahmoud, Ara-
bic handwriting recognition using structural and syntactic
pattern attributes, Pattern Recognition 46, no. 1 (2013):
141-154.

10. UV Marti, H Bunke, The iam-database: An english sen-
tence database for offline handwriting recognition, Int. J.
Doc. Anal. Recognit. 5(1), 3946 (2002).

11. S Wshah, G Kumar, V Govindaraju, in Proceedings of In-
ternational Conference on Frontiers in Handwriting Recog-
nition, Script independent word spotting in offline hand-
written documents based on hidden markov models, pp.
1419, (2012).

12. S Wshah, G Kumar, V Govindaraju, in Proceedings
of 21st International Conference on Pattern Recognition,
Multilingual word spotting in offline handwritten docu-
ments,pp. 310313,(2012).

13. A Fischer, A Keller, V Frinken, H Bunke, Lexicon-free
handwritten word spotting using character hmms, Pattern
Recognit, Lett.33(7), 934942 (2012).

14. V Frinken, A Fischer, R Manmatha, H Bunke, A novel
word spotting method based on recurrent neural networks,
IEEE Trans. Pattern Anal. Mach. Intell.34(2), 211224
(2012).