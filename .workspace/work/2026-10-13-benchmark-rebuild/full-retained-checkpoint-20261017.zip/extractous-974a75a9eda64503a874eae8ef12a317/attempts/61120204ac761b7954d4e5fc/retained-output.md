 123 

OECD EMPLOYMENT OUTLOOK 2024 © OECD 2024 
  

Source: Source Secretariat’s estimates based on version 24.1 of the O*NET database and the following country-specific sources: United States: 

Current Population Survey; All other countries: EU Labour Force Survey. 

StatLink 2 https://stat.link/ai0tc1 

Annex Figure 2.C.7. GHG-intensive occupations are more likely low educated while green-driven 
occupations are more heterogeneous 

Percentages, average 2015-19 

 

Note: Countries are ranked by decreasing gap of the share for high education compared to the total. Data refer to the average for 2015-19. Low 

education refers to less than upper secondary, medium education to upper secondary, high education to more than upper secondary. OECD: 

Unweighted average of countries shown. GHG: greenhouse gases. 

Source: Secretariat’s estimates based on version 24.1 of the O*NET database and the following country-specific sources: United States: Current 

Population Survey; All other countries: EU Labour Force Survey. 

StatLink 2 https://stat.link/6nria2 

0

5

10

15

20

25

30

35

40

45

50

% A. Green-driven occupations

0

5

10

15

20

25

% B. GHG-intensive occupations

High Medium Low Total

https://stat.link/ai0tc1
https://stat.link/6nria2