Oxy Sustainability Report 2024

PLANETPEOPLE PROSPERITYGOVERNANCEINTRO ABOUT THIS REPORT APPENDICES

PLANET

The Environmental Partnership (TEP)

Methane Guiding Principles (MGP)

Oil & Gas Climate Initiative (OGCI) – 
12-member, CEO-led non-profit organization

Oil and Gas Methane Partnership (OGMP) 2.0 –
1st U.S.-based operator in the Permian to join

World Bank’s Zero Routine Flaring (ZRF) 
by 2030 Initiative – 1st U.S. oil and gas 
company to endorse

Aiming for Zero Methane Emissions 
Initiative – founding member

of OGCI’s initiative

Oil & Gas Decarbonization Charter (OGDC) -
original signatory at COP28

World Bank’s Global Flaring and Methane Reduction 
Partnership - committed $25MM in funding at COP28

Since 2017, Oxy has joined and actively participates in emissions reduction programs through multiple associations, including the climate-focused organizations listed below.

2017

2021

2018

2021

2023

2020

2022

2023

Greenhouse Gas Emissions, Methane and Flaring

80

Environmental Stewardship 

Accelerating Carbon Innovation

Greenhouse Gas Emissions, 
Methane and Flaring

Other Air Emissions

Energy Utilization and Efficiency

Water Stewardship

Waste Management 

Spill Prevention

Biodiversity, Land Use 
and Remediation