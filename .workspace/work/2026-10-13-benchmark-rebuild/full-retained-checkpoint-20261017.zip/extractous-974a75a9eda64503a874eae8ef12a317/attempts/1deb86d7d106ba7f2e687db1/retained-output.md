Our ESG Strategy 
and Goals

Our strategy is composed of 
three core pillars: Financial 
Confidence; Climate Solutions; 
and Diversity, Equity, and 
Inclusion.

In 2020, we completed our first ESG priority 
assessment to identify ESG issues of importance to our 
company and our stakeholders, which served as the 
foundation for our current ESG strategy and goals 
announced in 2021. We achieved a majority of our 
goals and continue to make progress on many others. 

As 2024 will be the final year of our current strategy, and 
we intend to sunset the current goals in 2025, we have 
now commenced a “double materiality” assessment to 
assess environmental, social, and governance topics 
based on both American Express’ impacts to society 
and the environment and the potential impacts to 
American Express. This assessment is being conducted 
at the enterprise level and includes perspectives from 
several jurisdictions where we operate. The outcomes of 
this assessment are expected to inform our refreshed 
Corporate Sustainability strategy and determine 
future reporting pursuant to the European Union’s 
Corporate Sustainability Reporting Directive (CSRD). 
The standards applied for this assessment considers 
views of materiality that differ from the definition of 
materiality applied for purposes of US securities laws or 
other legal requirements. See the About This Report 
section of this report for more information.

INTRODUCTION OUR APPROACH TO CORPORATE SUSTAINABILITY FINANCIAL CONFIDENCE CLIMATE SOLUTIONS DIVERSITY, EQUITY, & INCLUSION GOVERNANCE & OPERATING RESPONSIBLY SUPPORTING DATA 8

FINANCIAL 
CONFIDENCE

Empower individuals to build and maintain 
their financial well-being through products, 
services, tools, and education, while providing 
robust account security

Strengthen the financial security and money 
management capacity of small businesses through 
products, services, campaigns, and initiatives 

Help build resilient communities through 
grants, programs, and initiatives that 
support economic empowerment and equity

• Provide access to credit to at least 4 million 
individuals from underrepresented populations 
from 2021 through 2025

• Provide at least 5 million individuals with tools, 
resources, and educational content to improve 
financial well-being from 2021 through 2025

• Support small businesses, including by reaching 
$100 billion in spending by consumers at small, 
independently owned retailers or restaurants on 
Small Business Saturday and during other Shop 
Small campaigns from 2021 through 20251

• Invest $500 million to build more resilient 
and equitable communities from 2021 
through 2025

CLIMATE
SOLUTIONS

Minimize our climate impact and manage 
our climate-related risks and opportunities 

Enable our customers and partners to transition 
to a low-carbon economy through the development 
of new capabilities

Support community programs and initiatives 
to help build more climate-resilient and 
equitable communities

• Commit to net-zero emissions in alignment with 
the Science Based Targets initiative (SBTi) 

• Enhance the management of climate-related 
risks and opportunities across the business

• Pilot low-carbon product innovations, including 
carbon tracking and offset solutions

• Provide at least $10 million to support 
initiatives, partnerships, and programs 
that address the adverse effects of climate 
change and pollution on communities from 
2021 through 2025

• Engage our colleagues in sustainability 
initiatives through the Green2Gether program

DIVERSITY, 
EQUITY, AND 
INCLUSION

Enhance diverse representation, 
equal opportunity, and an inclusive culture 
at all levels of the company 

Meet the needs of underrepresented businesses 
and consumers and develop more inclusive 
marketing initiatives 

Advance racial equality and social justice 
in our communities

• Maintain 100% pay equity across genders 
globally and across races and ethnicities in 
the US

• Double annual spend with underrepresented-
owned suppliers in the US from a 2019 baseline 
to $750 million in a year by the end of 2024, 
including increasing spend with Black-owned 
suppliers to at least $100 million annually

• Provide $50 million in grants from late 2020 
through 2024 to nonprofits focused on 
addressing inequality and promoting social 
justice, including those led by members 
of underrepresented groups

• Provide access to capital and financial education 
to at least 250,000 underrepresented-owned small- 
and medium-sized businesses in the US from late 
2020 through 2024

• Develop more inclusive marketing initiatives, as well 
as design and build product experiences and programs 
that better meet the needs of underrepresented 
consumer and business customers

1 Based on spend as reported by consumers in surveys commissioned by American Express (not actual receipts or sales).