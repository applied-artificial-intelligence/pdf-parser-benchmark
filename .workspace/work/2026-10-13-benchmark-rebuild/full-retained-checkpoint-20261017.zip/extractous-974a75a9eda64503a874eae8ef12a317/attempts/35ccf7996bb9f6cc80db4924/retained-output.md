60 European Innovation Scoreboard 2025

Figure 23: Performance Innovation Leaders

Note: Performance is relative to that of the EU in 2018. The graph on the left shows the average performance of 

the Innovation Leaders calculated as the unweighted average of the respective Member States. All vertical 

scales in Figure 23-Figure 26 span a range of 70.0%-points to allow an easy comparison of the results between 

the four performance groups.

Strong Innovators 

For the Strong Innovators, Ireland (138.6% of the EU average in 2018) now leads the 
group, while Belgium (138.1%) dropped to second in 2025, closely followed by Luxembourg 
(128.9%) and Austria (128.3%). Germany (125.1%) and France (122.3%) also remained 
among the Strong Innovators, maintaining stable high-level performance. Estonia (118.0%) 
stands out for its upward trajectory, significantly narrowing the gap with leading countries 
through sustained innovation gains since 2018. 

Strong Innovators have seen notable progress in digital and collaborative 
domains, though performance in Intellectual assets has lagged, particularly in 
design-related outputs. 

Since the 2018 baseline, Strong Innovators have made steady progress in adopting digital 
technologies, with most countries recording notable improvements in Investments in 
information technologies. Estonia leads the group with a 103.6%-point increase, followed 
by Austria (+85.0%-points), Germany (+79.4%-points), and Luxembourg (+63.2%-points), 
Ireland (+62.7%-points) and Belgium (+55.7%-points) also posted solid gains, while France 
(+6.1%-points) showed only marginal improvement over the baseline. 

Under the Digitalisation dimension, nearly all Strong Innovators recorded substantial 
advances. Ireland stands out with the highest increase (+84.9%-points), followed by 
Austria (+66.1%-points), Germany (+60.6%-points), and France (+52.9%-points). Belgium 

100

110

120

130

140

150

160

170

'18 '19 '20 '21 '22 '23 '24 '25

S
um

m
ar

y 
in

no
va

tio
n 

in
de

x

Denmark

Finland
Netherlands

Sweden

100

110

120

130

140

150

160

170

'18 '19 '20 '21 '22 '23 '24 '25

S
um

m
ar

y 
in

no
va

tio
n 

in
de

x