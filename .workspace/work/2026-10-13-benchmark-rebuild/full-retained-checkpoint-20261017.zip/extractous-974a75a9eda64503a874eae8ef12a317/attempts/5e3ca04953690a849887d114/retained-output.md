F I G U R E  7 Short-run impact of financial fragmentation on gross domestic product 
across geopolitical blocs

-0.6%

-1.4%

0.0%

-0.6%

0%

-2%

-4%

-6%

-8%

-10%

-12%

Scenario 1
Low fragmentation

Marginal change in GDP growth (deviation from baseline in %)

Scenario 3
High fragmentation

Scenario 2
Moderate fragmentation

Scenario 4
Very high fragmentation

-1.8%

-3.9%
-3.5%

-10.5%

-5.5%

-3.2%
-2.8%

-2.3%

-2.8%

-4.6%-4.5%

-3.6%

Similar GDP decrease 
as the Great Recession’s 
impact on the US in 2009 

Over 2x larger GDP decrease 
than the global impact of the 
COVID-19 pandemic in 2020

NeutralsEast WorldWest

Source: NERA analysis based on the multi-country, multisector model of Baqaee & Farhi (2024).32 Data from 2013 World Input–Output Database and Asian 
Development Bank’s 2023 Input–Output Tables. Short-run impact is defined as the impact measured one year after the shocks and is based on applying the one-
year to 10-year trade elasticity ratio found in Boehm et al. (2023)33 to the elasticities in Baqaee & Farhi (2024), as in Bolhuis et al. (2023)34

assumes that three distinct economic blocs 
emerge based on today’s geopolitical environment: 
the “West” (the US, the EU, Australia, Canada, 
Japan, South Korea and the United Kingdom), the 

“East” (China and Russia) and “Neutrals” (Brazil, 
India, Indonesia, Mexico, Taiwan, Türkiye and a 
composite of additional remaining countries). 

Scenario 1 – Low fragmentation: In this scenario, 
countries restrict capital and trade flows only in 
certain sensitive areas and encourage unimpeded 
activity in all other parts of the economy. The model 
envisions a ban on trading sensitive technology 
between the Eastern and Western blocs similar to 
the “small yard and high fence” approach, which 
limits investment restrictions to sensitive industries 
or technologies without impeding capital flows to 
other parts of the economy.35 The overall impact on 
global output is notable, but moderate, at -0.6% 
after one year. Inflation increases by 0.6% globally.

Scenario 2 – Moderate fragmentation: This 
scenario introduces economic statecraft restrictions 
on all economic exchanges between the three 
blocs, with less severe measures between Neutrals 
and the other two blocs. Accordingly, the model 
shows that there are more significant tariff and 
financial productivity losses, driving a 2.3% decline 
in global economic growth in the short run. The 
effect on inflation is also more significant in this 
scenario, with a projected increase of 2.3%.

Navigating Global Financial System Fragmentation 18