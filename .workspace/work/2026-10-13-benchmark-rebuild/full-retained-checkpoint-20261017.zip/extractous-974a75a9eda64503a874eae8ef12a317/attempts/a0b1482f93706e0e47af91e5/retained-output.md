80    

 

DO ADULTS HAVE THE SKILLS THEY NEED TO THRIVE IN A CHANGING WORLD? © OECD 2024 
  

 

Figure 2.13. Gender differences in numeracy among STEM graduates 

Adjusted and unadjusted differences in average numeracy scores between tertiary-educated men and women who 

studied STEM fields (men minus women) 

 

Note: Adults aged 25-65. Does not include adults who were only administered the doorstep interview due to a language barrier, as information 

on field of study was not collected for those respondents (see Box 1.1 in Chapter 1). STEM stands for science, technology, engineering and 

mathematics. Educational attainment is based on the International Standard Classification of Education (ISCED) 2011, grouped into below upper 

secondary (ISCED 1, 2 and 3 short), upper secondary (ISCED 3 and 4) and tertiary (ISCED 5, 6, 7 and 8). Where possible, foreign qualifications 

are included as the closest corresponding level in the respective national education systems. Unadjusted differences are the differences between 

the two averages for each contrast category. Adjusted differences are based on a regression model that takes into account differences 

associated with age, immigrant background, language spoken at home and parents’ educational attainment. Darker colours denote differences 

that are statistically significant at the 5% level. *Caution is required in interpreting results due to the high share of respondents with unusual 

response patterns. See the  ote for Poland in the Reader’s Guide. 

Countries and economies are ranked in descending order of the unadjusted difference between men and women who studied STEM fields. 

Source: Table A.2.9 (N) in Annex A. 

Differences in proficiency between men and women 

On average across participating OECD countries and economies, women scored 3 points higher than men 

in literacy, while men outscored women by 10 points in numeracy and 2 points in adaptive problem solving 

(Figure 2.14). After accounting for relevant background characteristics, the adjusted gender gap shrinks to 

1 point in favour of women in literacy (which is not statistically significant), but widens to 12 points in 

numeracy and 4 points in adaptive problem solving in favour of men. One potential explanation for this 

increase in the size of the adjusted coefficients in numeracy and adaptive problem solving is gender 

differences in educational attainment. For example, on average, 48% of women are tertiary educated, but 

only 40% of men are (see Table B.3.3 in Annex B). As higher levels of education are normally associated 

with higher proficiency, adjusted differences control for the fact that women appear to underperform in the 

assessment, compared to what one would expect based on their level of education. 

In literacy, women in 13 countries (Croatia, Estonia, Finland, France, Germany, Hungary, Israel, Latvia, 

Lithuania, the Netherlands, New Zealand, Norway and Poland) scored significantly higher than men on 

2 

20

1 

10

 

0

  

 10

 1 

S
w
e
de

n

 
e
th
e
rl
a
nd

s

 a
p
an

P
ol
a
nd

 

U
ni
te
d 
S
ta
te
s

C
 e

ch
ia

F
le
m
is
h 
R
eg

io
n 
( 

E
 

E
st
o
ni
a

Ir
el
an

d

A
us

tr
ia

F
ra
n
ce

S
w
it 

er
la
n
d

 
e
w
  

ea
la
n
d

 
o
rw

ay

S
p
ai
n

 
E
C
 
 a
ve

ra
g
e

S
in
g
ap

or
e

 
at
 i
a

Is
ra
e
l

H
u
ng

ar
y

 
e
nm

ar
k

P
or
tu
g
a
l

G
e
rm

a
ny

F
in
la
n
d

It
a
ly

 i
th
ua

n
ia

E
ng

la
nd

 (
U
 
 

C
an

ad
a

C
hi
le

C
ro
at
ia

S
lo
 a

k 
R
ep

ub
lic

 
or
e
a

Score point diffe rence Unad u sted Ad usted

 en score higher  than women

Women score higher  than men