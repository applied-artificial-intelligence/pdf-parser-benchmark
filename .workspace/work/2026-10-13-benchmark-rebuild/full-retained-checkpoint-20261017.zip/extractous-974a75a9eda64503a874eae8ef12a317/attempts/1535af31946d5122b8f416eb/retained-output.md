Task 1 Strategic PV Analysis and Outreach – 2025 Snapshot of Global PV Markets    

 

9 

 

balanced by slow-downs in Spain and the Netherlands. Of particular note, the Turkish market 

grew over the past two years and is expected to remain strong as local manufacturing 

develops and electricity prices remain high following the Lira’s depreciation. Several GW were 

installed and commissioned over the end of 2023 and early 2024, impacting how data was 

recorded in previous reports.  

The 2024 Indian market benefited from both low-cost imports and a cut-off date for using them, 

as well as corporate green mandates. Not shown in Figure 2, Pakistan had very strong 

additions to new capacity. Data quality is uncertain when it comes to installed volumes, but 

large volumes of modules were imported in 2023 and 2024 (24 GW over 2 years according to 

the China Chamber of Commerce), and larger volumes were installed in 2024 with reported 

new capacity more than 13 times 2023 volumes at 17 GW. Policy changes have impacted 

deployment budgets in South Korea, whilst stabilised consumer electricity prices have 

contributed to the Spanish reduced market. 

These developments have not been significant enough to impact the regional distribution 

shares of new capacity in major markets as China continues to dominate (Figure 3). 

1.2 Impact of over-capacity in manufacturing  

In 2023, manufacturing capacity largely outstripped the market’s ability to absorb new module 

availability. Module stocks in China and Europe grew from already high 2022 values to reach 

an estimated 150 GW by the end of 2023. In 2024, stocks remained high as relatively stable 

markets in Europe and China failed to absorb these historical stocks.  

Manufacturers continued to deliver low-price modules to markets in an effort to secure cash 

flows, and so module prices continued to decrease across 2024. Concerted action by Chinese 

manufacturing led to module prices stabilising in Q1 2025 due to controlled production cuts 

and upwards movement in upstream costs. 

These low prices, combined with different local contexts stimulated markets in China and a 

selection of countries including India, Pakistan, Brazil and supported modest growth in some 

countries in Europe.  

However, the pressure on the industry remains tremendous and solutions are quite complex: 

with all segments of the PV value chain in significant overcapacity, the global development of 

0

100

200

300

400

500

600

2019 2020 2021 2022 2023 2024

GWp FIGURE 3:  GROWTH  OF NEW ANNUAL CAPACITY IN MAJOR MARKETS

Other Non IEA PVPS Countries India Other IEA PVPS Countries Japan European Union USA China

3Source: IEA PVPS