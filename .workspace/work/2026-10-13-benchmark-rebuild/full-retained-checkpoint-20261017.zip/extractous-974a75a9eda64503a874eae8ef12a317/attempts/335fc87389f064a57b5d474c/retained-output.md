9 
 

 

Figure 3. 

Euro area demographic dynamics 

 

Source: Eurostat 

Note: age dependency is measured as the ratio of population aged 0-14 and 65+ to population aged 15-64. 

 

Acute climate-related risks may impact many sectors, including notably the financial system. Both 

physical risks and uncertainty tied to transition pose the potential for enhanced volatility within the 

euro area financial infrastructure, with possible effects propagating via numerous channels.5 ESM staff 

are continuing to contribute to the collective understanding of how these risks are likely to manifest 

and pass through to financial stability.6 These are the main takeaways:  

• Output losses and reduced growth prospects: More frequent and extreme weather events could 

generate large economic losses and reduce production capacity by destroying human and 

physical capital and reducing productivity growth. 

• Worsening public sector balance sheets: Large expenditures could emerge from disaster relief, 

reconstruction, and recovery, as well as the materialisation of contingent liabilities. Beyond the 

climate mitigation expenditure burden, foregone tax revenue from activity disruptions and 

diminishing carbon-intensive sources could generate an additional strain on public finances.  

• Deteriorating corporate and financial sectors balance sheets: Both physical and transition risks 

could cause large and sudden re-evaluations of the assets of financial and non-financial firms. 

Notably, the insurance sector will be tested as claims rise, given the increased frequency and 

magnitude of natural catastrophes.7 

 
5 From Basel Committee on Banking Supervision (2021): Certain economic sectors will have greater sensitivities to acute 

climate related physical risks or to the transition to a low-carbon economy. These climate-related events and risks are 

uncertain and may be subject to non-linearities. Credit risks may manifest through both income (reduced ability to repay 

debts) and wealth effects (capital value erosion affecting recovery rates). Market risks could propagate through sharp 

reductions in financial asset values and liquidity risks through reduced market conditions, such as via credit line and deposit 

drawdowns from counterparties. Operational, and reputational risks from increased scrutiny, expectations and market 

sentiments associated with the transition may equally contribute to further volatility. 
6 See ESM 2023 for a discussion on how Regional Financial Arrangements contribute to fight climate change consequences.  
7 Swiss Re (2021) estimates that natural catastrophes caused USD 105 billion in global insured losses in 2021, the fourth 

highest since 1970.  

44%

46%

48%

50%

52%

54%

56%

58%

32

34

36

38

40

42

44

46

1984 1987 1990 1993 1996 1999 2002 2005 2008 2011 2014 2017 2020 2023

Median age of population (LHS) Age dependency ratio (RHS)

https://www.esm.europa.eu/publications/global-efforts-fight-consequences-climate-change-role-regional-financing-arrangements
https://www.swissre.com/media/press-release/nr-20211214-sigma-full-year-2021-preliminary-natcat-loss-estimates.html
https://www.swissre.com/media/press-release/nr-20211214-sigma-full-year-2021-preliminary-natcat-loss-estimates.html