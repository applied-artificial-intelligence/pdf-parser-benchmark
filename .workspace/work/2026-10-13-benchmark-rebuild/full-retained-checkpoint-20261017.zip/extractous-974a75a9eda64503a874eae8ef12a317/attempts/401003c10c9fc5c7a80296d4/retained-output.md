The BEAT | June 2025

Municipals: Higher Yields and a Steeper Curve

TOP THEMES

Source: Bloomberg, MSIM. As of May 21, 2025. For illustrative purposes only. Not a recommendation to buy or sell any security. It is not possible to invest directly in an index. The views 
and opinions expressed are those of the portfolio management team at the time of writing/of this presentation and are subject to change at any time due to market, economic, or other 
conditions, and may not necessarily come to pass.  Forecasts/estimates are based on current market conditions, subject to change, and may not necessarily come to pass. Past 
performance is not indicative of future results.

Longer-dated yields in the municipal market moved higher in May, a continuation of the YTD trend. In the face of heavy 

supply in recent months, the muni curve has (bear) steepened, to a greater degree than U.S. Treasuries (USTs), resulting in 

attractive Muni/UST ratios out on the curve.

Muni/UST Ratios Look Attractive Farther Out on the Curve

Muni/UST ratios across selected curves, 12/31/24 and present

11

60%

65%

70%

75%

80%

85%

90%

95%

2Y 5Y 10Y 30Y

12/31/2024 5/21/2025