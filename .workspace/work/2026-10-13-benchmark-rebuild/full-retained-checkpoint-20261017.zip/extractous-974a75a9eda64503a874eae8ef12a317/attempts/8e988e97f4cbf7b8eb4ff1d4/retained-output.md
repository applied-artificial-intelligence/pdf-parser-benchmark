Oxy Sustainability Report 2024

PLANETPEOPLE PROSPERITYGOVERNANCEINTRO ABOUT THIS REPORT APPENDICES

PEOPLE

Human Capital and Workforce
Development

Health and Safety 

Process Safety and
Asset Integrity

Emergency Preparedness
and Response 

Promoting Transportation
Safety

Product Stewardship

Benefits and Total Rewards

Health Financial Work/Life 

Medical, dental and vision coverage 401(k) Plan Flexible work schedules, including Balanced 
Workplace hybrid schedule*Health savings accounts Retirement Plan 

Free health support programs Life Insurance  

Competitive base pay

Paid Family Leave 

Mental health support 

Accidental Death &
Dismemberment Insurance

Short- and Long-Term Disability Insurance

Employee discounts on products and services

Paid vacation time

Paid Parental Leave

Educational assistance 

Community support 

Fitness subsidy program

Retiree medical 

We believe helping employees achieve work-life balance promotes both physical and mental well-being, increases job satisfaction, enhances productivity and 
helps Oxy retain top talent. That is why we work hard to help our employees around the world stay centered at the intersection of their personal and
professional lives.

*For eligible office-based employees.
43