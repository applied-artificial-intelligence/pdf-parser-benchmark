• Chassis Design & Development
 Our strategic partnership with Yorozu equips us to engineer 

chassis systems meeting global benchmarks for performance 
and safety.

• Tooling for High-Strength Components
 Our collaboration with Ogihara enhances our capacity to 

deliver precision tooling for 980 MPa BIW parts, supporting 
robust and scalable product launches.

• Proven Expertise in Sheet Metal Engineering
 Our extensive experience across BIW, chassis assemblies, 

engine mountings and crash-critical parts underlines JBML’s 
reliability and engineering depth.

• In-House Tool and Weld Line Capabilities
 Our localized infrastructure for press tools and weld lines 

accelerates product development and ensures cost-effective, 
high-quality delivery to Maruti Suzuki India Limited.

• Bench Testing and Prototyping
 Validating performance and durability, leveraging on JBM 

Group’s in-house capabilities to uphold stringent quality 
standards.

• Nationwide Engineering Footprint
 With operations across our various manufacturing facilities in 

Haryana and Gujarat, our engineering teams provide real-time 
support and accessibility to Maruti Suzuki India Limited.

• Advanced Joining & Forming
 Our adoption of state-of-the-art joining, laser cutting and 

tube forming technologies ensures the delivery of lightweight, 
durable components for the future of transportation.

Our capabilities reflect decades of expertise in automotive manufac-
turing, seamlessly blended with a vision for next-generation mobility.

Smart Systems and Modern Manufacturing 
Over the years JBML’s manufacturing plants have set benchmarks in 
efficiency and adaptability, with intelligent systems and digital controls 
driving superior outcomes.
E-Kanban Systems
Implementing real-time material 
management for maximum effi-
ciency and waste reduction. 

WICS (Weld Information Control 
System)
Advanced weld parameter mon-
itoring ensures traceability and 
quality assurance in our shops. 

Sequenced Manufacturing
Our new Kharkhoda facility ex-
emplifies just-in-time, sequenced 
production, enabling exceptional 
synchronization with Maruti Su-
zuki India Limited.

Digital  Process 
Intelligence
Modernization underpins our 
quality and operational agility:

1.  Automated Spot Accuracy  
Validation:

 Reduction in NCR defects 
from 46 to 25, down by a 
significant 45% through  
real-time inspection.

2.  Weld Nugget Digitization:
Process check time dramati-
cally reduced from  
2 hours to 7 minutes,  
bringing it down remarkably 
by 94%.

3.  Vision-Driven Inspection:
Deployment of smart vision 
cameras in BIW lines has 
eliminated defect outflow.

4.  Real-Time Defect  
Monitoring:

 Data analytics have driven 
internal PPM from 286 down 
to 75, a reduction by 73% 
enabling proactive process 
improvement.

Five Strategic Priorities for FY 2024–25

Strengthening Technical 
Capabilities through Strategic 
Collaboration
By reinvigorating core alliances and 
forging new technical partnerships, 
we are accelerating innovation and 
expanding our expertise to sharpen 
our competitive edge.

Advancing Lightweight Mobility 
with High-Tensile Steel

With proprietary capabilities in 
Advanced High-Strength Steel (AHSS) 
for BIW components and expertise in 
agile design and simulation, we are 
optimizing structures for enhanced 
performance and sustainability

Operational Excellence and  
Cost Efficiency
Through a blend of established 
process discipline and advanced 
manufacturing systems—including 
Industry 4.0 technologies and 
high-productivity tooling—we are 
improving throughput, increasing 
efficiency and reducing waste.

Integrated Engineering: 
Delivering Excellence at Scale

Accelerating Digital 
Transformation & Smart 
Manufacturing

From IoT-enabled real-time quality 
controls to intelligent customer 
interfaces, we are developing a highly 
connected ecosystem that enhances 
collaboration, performance and 
responsiveness. 

Empowering People with 
Future-Ready Skills

We are investing in cross-functional 
training, career development and the 
integration of automation, building 
a resilient and adaptable workforce 
equipped for the demands of the 
future. 

image changes
2024-25
ANNUAL REPORTJAY BHARAT MARUTI LIMITED

03-46
CORPORATE OVERVIEW

47-146
STATUTORY REPORTS

147-274
FINANCIAL STATEMENTS

13 14