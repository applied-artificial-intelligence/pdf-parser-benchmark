 141 

OECD EMPLOYMENT OUTLOOK 2024 © OECD 2024 
  

Figure 3.1. Classification of high- and low-emission industries 

GHG intensity within 2-digit NACE rev.2 sectors and frequency in top 2 deciles across 31 OECD countries, 

2009-20 average 

 

Note: GHG intensity is expressed as CO2- equivalent emissions in tonnes per million EUR of gross value added. 

Source: Eurostat – Air emissions accounts by NACE Rev. 2 activity. 

StatLink 2 https://stat.link/3xgc2z 

The list of sectors included in the definition encompass energy supply, as well as transport services (water, 

air and land), mining and manufacturing of energy-intensive products (basic metals, non-metallic mineral 

products, refined petroleum products, chemical- and paper products). The sewerage and waste-collection 

sector is omitted from the final list of high-emission industries as it is not expected to decline and indeed is 

a much needed industry for the net-zero transition (see Borgonovi et al. (2023[1])). The agricultural sector 

is entirely omitted from the list of industries studied in this chapter for two reasons. First, mass layoffs in 

agriculture are more likely to capture seasonal rather than structural adjustments in employment. Second, 

employment projections for many OECD countries do not suggest a decline in employment growth in the 

agricultural sector, in contrast to most other emission-intensive sectors, as current policy packages tend to 

shelter agricultural production from the climate mitigation effort (Borgonovi et al., 2023[1]). 

The classification of “high-emission industries” shows not only significant consistency across the 

countries considered, but also across different measures of emission intensity, such as carbon intensity 

or fossil fuel energy intensity (see Barreto et al. (forthcoming[11]) for details). A key limitation of the 

present approach is the classification of industries based 2-digit ISIC rev. 4 sectors. This does not allow 

disentangling subsectors which may be expected to expand because of the net-zero transition such as 

renewable energy power generation or electrified land transport from sectors that are expected to 

contract. However, cross-country emission data, whether in the form of GHG emissions, carbon intensity 

or energy use, are not available at a more disaggregate level. 

 0

1 000

2 000

3 000

4 000

5 000

6 000

7 000

8 000

9 000

0

5

10

15

20

25

30

35

C
ro

p 
an

d 
an

im
al

 p
ro

du
ct

io
n,

 h
un

tin
g

E
le

ct
ric

ity
, g

as
, a

ir 
co

nd
iti

on
in

g
S

ew
er

ag
e;

 w
as

te
; r

em
ed

ia
tio

n
O

th
. n

on
-m

et
al

lic
 m

in
er

al
 p

ro
du

ct
s

A
ir 

tr
an

sp
or

t
M

an
uf

. b
as

ic
 m

et
al

s
W

at
er

 tr
an

sp
or

t
C

ok
e 

an
d 

re
fin

ed
 p

et
ro

le
um

M
an

uf
. o

f c
he

m
ic

al
s

F
is

hi
ng

 a
nd

 a
qu

ac
ul

tu
re

M
in

in
g 

an
d 

qu
ar

ry
in

g
La

nd
 tr

an
sp

or
t; 

pi
pe

lin
es

P
ap

er
 a

nd
 p

ap
er

 p
ro

du
ct

s
F

or
es

tr
y 

an
d 

lo
gg

in
g

W
at

er
 c

ol
le

ct
io

n,
 tr

ea
tm

en
t a

nd
 s

up
pl

y
T

ex
til

es
, w

ea
rin

g 
ap

pa
re

l, 
le

at
he

r
F

oo
d 

pr
od

uc
ts

, b
ev

er
ag

es
 a

nd
 to

ba
cc

o
P

os
ta

l a
nd

 c
ou

rie
r 

ac
tiv

iti
es

M
et

al
 p

ro
du

ct
s,

 e
xc

. m
ac

hi
ne

ry
 a

nd
 e

qu
ip

.
A

cc
om

m
od

at
io

n 
an

d 
fo

od
 s

er
vi

ce
R

ub
be

r 
an

d 
pl

as
tic

 p
ro

du
ct

s
W

oo
d 

an
d 

co
rk

, e
xc

. f
ur

ni
tu

re
C

on
st

ru
ct

io
n

B
as

ic
 p

ha
rm

ac
eu

tic
al

 p
ro

du
ct

s
W

ho
le

sa
le

 a
nd

 r
et

ai
l t

ra
de

; r
ep

ai
r

M
ac

hi
ne

ry
 a

nd
 e

qu
ip

m
en

t n
.e

.c
.

W
ar

eh
ou

si
ng

 a
nd

 s
up

po
rt

 fo
r 

tr
an

sp
or

ta
tio

n
P

rin
tin

g 
an

d 
re

pr
od

uc
tio

n 
of

 r
ec

or
de

d 
m

ed
ia

W
ho

le
sa

le
 tr

ad
e,

 e
xc

. m
ot

or
 v

eh
ic

le
s

O
th

er
 s

er
vi

ce
 a

ct
iv

iti
es

E
le

ct
ric

al
 e

qu
ip

m
en

t
R

et
ai

l t
ra

de
, e

xc
. o

f m
ot

or
 v

eh
ic

le
s

C
om

pu
te

rs
, e

le
ct

ro
ni

c 
an

d 
op

tic
al

 p
ro

du
ct

s
O

th
er

 tr
an

sp
or

t e
qu

ip
m

en
t

F
ur

ni
tu

re
; o

th
er

 m
an

uf
ac

tu
rin

g
M

ot
or

 v
eh

ic
le

s,
 tr

ai
le

rs
 a

nd
 s

em
i-t

ra
ile

rs
R

ep
ai

r 
an

d 
in

st
al

la
tio

n 
of

 m
ac

hi
ne

ry
 a

nd
…

A
dm

in
is

tr
at

iv
e 

an
d 

su
pp

or
t s

er
vi

ce
 a

ct
iv

iti
es

A
rt

s,
 e

nt
er

ta
in

m
en

t a
nd

 r
ec

re
at

io
n

O
th

er
 p

ro
fe

ss
io

na
l, 

sc
ie

nt
ifi

c 
an

d 
te

ch
ni

ca
l…

P
ub

lic
 a

dm
in

., 
de

fe
nc

e;
 c

om
pu

ls
or

y 
so

ci
al

…
H

um
an

 h
ea

lth
 a

nd
 s

oc
ia

l w
or

k
A

rc
hi

te
ct

ur
al

 a
nd

 e
ng

in
ee

rin
g

M
ot

io
n 

pi
ct

ur
e,

 v
id

eo
, s

ou
nd

; b
ra

oa
dc

as
tin

g
A

dv
er

tis
in

g 
an

d 
m

ar
ke

t r
es

ea
rc

h
S

ci
en

tif
ic

 r
es

ea
rc

h 
an

d 
de

ve
lo

pm
en

t
Le

ga
l a

nd
 a

cc
ou

nt
in

g.
; m

an
ag

em
en

t…
E

du
ca

tio
n

P
ub

lis
hi

ng
 a

ct
iv

iti
es

A
ct

iv
iti

es
 a

ux
ili

ar
y 

to
 fi

na
nc

e 
an

d 
in

su
ra

nc
e

T
el

ec
om

m
un

ic
at

io
ns

In
su

ra
nc

e 
an

d 
pe

ns
io

n,
 e

xc
. c

om
pu

ls
or

y…
F

in
an

ce
 e

xc
. i

ns
ur

an
ce

 a
nd

 p
en

si
on

C
om

pu
te

r 
pr

og
ra

m
m

in
g;

 in
fo

rm
at

io
n 

se
rv

ic
es

R
ea

l e
st

at
e

GHG intensity
Frequency of countries in the 

top two deciles

Frequency: emission-intensive Rest of the economy GHG intensity: emission-intensive Rest of the economy

https://stat.link/3xgc2z