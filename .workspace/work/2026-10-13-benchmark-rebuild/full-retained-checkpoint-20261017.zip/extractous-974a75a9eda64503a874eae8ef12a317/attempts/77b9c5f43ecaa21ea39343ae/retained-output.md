Total cash compensation, by gender (%)

$400,000 or less

$401,000–$600,000

$601,000–$800,000

$801,000–$1.00m

$1.01m–$2.00m

$2.01m–$3.00m

More than $3.00m

Note: Numbers may not sum to 100%, because of rounding.

Source: Heidrick & Struggles US professional services partner compensation survey, 2024, n=155

Source: Heidrick & Struggles US professional services partner compensation survey, 2022, n=192

Women

20
11

13
37

7
5

40

7
0

13
42

0

0

5

Men

2
2

10
13

15
18

13
15

16
5

14
11

29
36

2024 2022

By gender, total cash compensation 
overall trended higher for women in 
2024 compared to 2022. We saw a sharp 
spike in total cash compensation for 
women in the $1 million to $2 million 
range, and a sharp decline for men 
in the $800,000 to $1 million range.

2024 US PROFESSIONAL SERVICES PARTNER COMPENSATION SURVEY

26