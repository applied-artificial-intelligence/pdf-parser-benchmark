A N D R I T Z  f i n a n c i a l  r e p o r t  2 0 2 4  

M a n a g e m e n t  r e p o r t  

 

14 

c) Financial result and taxes 

The financial result amounted to -15.4 MEUR in the reporting period (2023: 3.0 MEUR).  

 

The net interest result decreased compared to the previous year’s reference figure due to the decline in the 

interest rate environment and lower gross liquidity (1,434.4 MEUR versus 2023: 1,787.2 MEUR). The lower gross 

liquidity is attributable to an increase in net working capital as part of the scheduled processing of large orders and 

to the repayment of loans during the financial year. 

 

The significant decrease in the other financial result compared to the previous year is mainly attributable to a one-

time effect in the context of the deconsolidation of a company. The other financial result of 2024 includes a one-

time effect from the write-off of a loan granted to this company and the result from companies accounted for using 

the equity method includes a one-time effect from the measurement of the remaining shares at fair value.  

 

The tax rate decreased from 26.7% in the previous year to 23.2%. Above all, the capitalization of loss 

carryforwards through positive effects in the context of mergers, active management of tax groups and the 

consistent use of research and investment benefits have contributed to the reduction of the tax rate.  

 

 

d) Earnings and dividend per share 

The earnings per share decreased to 5.02 EUR (2023: 5.15 EUR). At the Annual General Meeting on  

March 27, 2025, the Executive Board will propose a dividend of 2.60 EUR per share (2023: 2.50 EUR) for the 

2024 financial year. This is equal to a payout ratio of 51.8% (2023: 48.5%).  

 

Dividend for 2024: Proposal to the Annual General Meeting.  

2,08

3,28

4,14

5,15
5,02

1,00

1,65

2,10

2,50
2,60

48,1%
50,3% 50,7%

48,5%
51,8%

0,00

1,00

2,00

3,00

4,00

5,00

6,00

2020 2021 2022 2023 2024

Earnings per share (EUR) Dividend per share (EUR) Payout ratio

— More informationin the notes to the consolidated financial statements chapter C) 16. Income taxes.