 29 

OECD ECONOMIC OUTLOOK, VOLUME 2025 ISSUE 2 © OECD 2025 
  

Figure 1.17. Global growth is projected to weaken before recovering gradually 

 
Note: In Panel A, ‘Advanced economies’ include the OECD member countries except Chile, Colombia, Costa Rica, Mexico, and Türkiye, plus 
Croatia. ‘Emerging-market economies’ comprises all other economies. In Panel B, Emerging Asia comprises China, Hong Kong (China), India, 
Indonesia, Malaysia, the Philippines, Singapore, Chinese Taipei, Thailand and Viet Nam. Latin America comprises Argentina, Brazil, Chile, 
Colombia, Costa Rica, Mexico and Peru. Contributions calculated using moving PPP shares of global GDP. 
Source: OECD Economic Outlook 118 database; OECD Economic Outlook 117 database; OECD Interim Economic Outlook 118 database; and 
OECD calculations.  

StatLink 2 https://stat.link/j3hlps 

The near-term growth projections are close to those in the September 2025 OECD Interim Economic 

Outlook but stronger than those in the June 2025 OECD Economic Outlook (Figure 1.17, Panel C). The 

change since June reflects several factors, including easier global financial conditions, evidence of 

stronger investment momentum in some OECD economies and more supportive macroeconomic policies 

than anticipated, with policy interest rates continuing to be lowered in many countries, and little fiscal 

tightening in the median OECD economy this year and next. Fiscal policies are also providing support for 

domestic demand in China, India (via the goods and services tax reform) and Indonesia. At the same time, 

inflation projections for G20 countries have been revised downwards to incorporate weaker-than-expected 

inflation outturns, most notably for the United States. Inflation in the G20 countries is anticipated to further 

moderate through 2026, with the inflationary impact from higher trade costs generally offset by softer 

growth (Figure 1.17, Panel D).  

  

https://stat.link/j3hlps