Findings by industry groups 3

Higher-technology
industries maintained

their strong progress,
outperforming other industries

The latest global trends of industrial sectors grouped by technolog-
ical intensity are shown in Figure 3.1. The data reveal that higher-
technology industries continued to exhibit strong dynamism, even
thriving amidst numerous challenges.

In recent periods, industries classified as medium-high and high-
technology (MHT) have generally outperformed other manufacturing
sectors. While they experienced a temporary slowdown in the first
quarter of 2024, they returned to growth in the next quarter, increasing
output by 1.5 per cent. This upward trend continued into the third
quarter of 2024 with a 1.0 per cent quarterly increase. Conversely,
lower-technology manufacturing sectors remained flat.

90

100

110

120

130

140

Q1 
2015

Q3 Q1 
2016

Q3 Q1 
2017

Q3 Q1 
2018

Q3 Q1 
2019

Q3 Q1 
2020

Q3 Q1 
2021

Q3 Q1 
2022

Q3 Q1 
2023

Q3 Q1 
2024

Q3

In
de

x 
(2

01
5 

= 
10

0)

Medium-high and high tech Other manufacturing industries

Figure 3.1 | Global index of manufacturing production, industries by technology level

Significant signs
of growth of

pharmaceuticals
in Q3 2024

As shown in Figure 3.2, the solid performance of higher-technology
manufacturing was mostly driven by the production of pharmaceu-
ticals (2.6 per cent), computers and electronics (2.1 per cent), and
electrical equipment (1.0 per cent). Machinery, on the other hand,
showed the worst performance in the current quarter among MHT
industries.