Chapter 1: Main employment and social developments 

23 

with severe potential costs for natural capital, infrastructure and economic activity. (18) Financing the digital 
infrastructure may also prove a challenge. 

3. LABOUR MARKET DEVELOPMENTS 
3.1. Employment trends 

Despite ongoing economic challenges, labour markets in the EU remain robust. Alongside modest GDP 
growth of 0.4% in 2023, employment increased by 1.2% in the EU and 1.4% in the euro area, with 216.5 million 
people employed in the EU and 168.7 million in the euro area. With the exception of Romania (-0.9% compared 
to 2022), all countries experienced an increase in employment. The countries with the highest percentage 
increase were Malta (+6.7 %), Ireland (+3.5%), Estonia (+3.2%), Spain (+3.2%) and Luxembourg (+2.2%). All other 
Member States recorded a percentage growth below 2.0%. Notwithstanding a rise of 1.0% in total hours worked 
in the EU (+1.3% in the euro area) in 2023 compared to 2022, there was a slight decrease in the number of 
hours worked per employed person (-0.2% in the EU and -0.1% in the euro area), still below the pre-COVID-19 
pandemic levels in 2019. This downward trend, which has been protracted for the last two decades, may reflect 
the introduction of more efficient and productive technologies, including the acceleration of digitalisation, as well 
as changes in work attitudes. After recovering in 2021 and 2022, labour productivity decreased again in 2023 
compared to the previous year (-0.8% per employed person and -0.6% per hour), reflecting a combination of 
higher labour supply and fewer hours worked per employed person, (19) as well as low total factor productivity 
growth. 

In 2023, the sectors that contributed most to employment growth were trade, transport, 
accommodation and public administration, defence, education, human health and social work 
activities. The numbers of people employed in these two sectors increased by 0.8 million and 0.7 million, 
respectively. In relative terms, employment grew most in information and communication (+4.2%), indicating the 
elevated need for specialised skills. It rose by 0.9% in construction and 0.2% in industry, and declined by 1.1% in 
agriculture, forestry and fishing. The number of self-employed people increased by 1.0% and employee numbers 
grew by 1.3%.  
 

Chart 1.4 

Number of hours worked per person employed stagnated in 2023 despite a resilient labour market 
Left chart: Number of people employed, and number of hours worked (2012=100); Right chart: Headcount employment (% change on previous year), 2012-2025 

   

Note: EA = euro area. European Commission (DG ECFIN) 2023 Spring Forecast in the shaded area. 

Source: Eurostat [nama_10_a10_e, nama_10_pe, naida_10_pe], DG ECFIN Forecast. 

Click here to download chart. 

 
According to the European Commission Spring 2024 Economic Forecast, employment should expand 
by 0.6% in the EU in 2024 and by 0.4% in 2025, driven by a positive carry-over effect of gains 
during 2023. Such expansion could be limited by the fact that employers are retaining their workers in a context 
of labour shortages (so-called labour hoarding). (20) In July 2024, the new indicator of labour hoarding developed 
by the Commission increased slightly compared to the previous month (+0.4 pp to 10.8%, three-month moving 

 
(18) (European Commission, 2024a) 
(19) (European Commission, 2024a)  
(20) ‘Labour hoarding can be defined as “that part of labour input which is not fully utilised by a company during its production process at any 

given point in time” (ECB, 2003). Typically, labour hoarding, implying under-utilisation of the workforce, occurs in periods of slack or 
downturn in economic activity. The rationale for companies not to lay off (redundant) employees in such periods is that (i) dismissing 
workers usually involves costs, e.g. severance payments, and (ii) recruiting workers once economic activity recovers also entails costs 
(screening the labour market for candidates, training them, etc.)’. When economic activity picks up again, companies may not hire new 
workers immediately, but rather rely on the underutilised labour already in the company. The European Commission developed an 
indicator of labour hoarding, which measures the percentage of managers expecting their firm’s output to decrease, but employment to 
remain stable or increase, based on the Joint Harmonised EU Programme of Business and Consumer Surveys (BCS) (European 
Commission, 2023c).   

90

95

100

105

110

115

2012 2013 2014 2015 2016 2017 2018 2019 2020 2021 2022 2023
EU - employment
EA - employment
EU - hours worked per person employed
EA - hours worked per person employed

-8

-6

-4

-2

0

2

4

6

2012 2013 2014 2015 2016 2017 2018 2019 2020 2021 2022 2023 2024 2025

EU EA UK US Japan

Forecast

https://ec.europa.eu/employment_social/empl_portal/publications/Esde2024/xls/Chap1/Chap1-Chart-1.4.xlsx