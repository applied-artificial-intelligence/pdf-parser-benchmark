 165 

 

DO ADULTS HAVE THE SKILLS THEY NEED TO THRIVE IN A CHANGING WORLD? © OECD 2024 
  

This positive relationship between life satisfaction, health and numeracy holds even after accounting for a 

number of personal characteristics. Figure 4.10 shows the percentage point difference in reporting high 

life satisfaction (Panel A) and positive health outcomes (Panel B) between adults with low and high 

numeracy skills. The regression model underlying these estimates controls for age, gender, years of 

education, immigrant background, parental educational attainment and whether an individual lives with a 

partner or has children. As the sample includes people who are not employed, no occupational controls 

are included. 

Figure 4.10. Relationship between numeracy and individual well-being 

Difference in likelihood of reporting positive outcomes (high proficiency minus low proficiency) 

 

 

Note: Adults aged 25-65; does not include adults who were only administered the doorstep interview due to a language barrier (see Box 1.1 in 

Chapter 1 and Box 4.1). Positive outcomes for life satisfaction and for self-reported health are defined in Box 4.2. High proficiency refers to 

numeracy proficiency at Level 4 and above and low proficiency to at or below Level 1. In addition to proficiency level, estimates account for 

years of education, age, gender, immigrant background, parental education and whether one lives with a partner or has children. Darker colours 

denote differences that are statistically significant at the 5% level. *Caution is required in interpreting results due to the high share of respondents 

with unusual response patterns. See the  ote for Poland in the Reader’s Guide. 

Countries and economies are ranked in descending order of the difference in the likelihood of reporting positive outcomes. 

Source: Table A.4.11 (N) in Annex A.  

On average, across OECD countries and economies, individuals with high numeracy skills are 

11 percentage points more likely to report positive health outcomes – and 10 percentage points more likely 

to report high life satisfaction – than individuals with low numeracy skills. Nevertheless, some cases stand 

out: in Croatia, for instance, individuals with high numeracy skills are 24 percentage points more likely to 

report high life satisfaction, a larger effect than in any other country, while the greatest gap in health occurs 

C
ro
at
ia

 a
pa

n

P
o
rt
ug

al

It
al
y

E
st
on

ia

G
e
rm

an
y

C
an

ad
a

 
or
e
a

S
lo
 a

k 
R
ep

u
bl
ic

C
 e

ch
ia

E
ng

la
n
d 
(U

 
 

F
ra
n
ce

P
o
la
n
d 

 
at
 i
a

 
o
rw

ay

S
w
e
de

n

 
E
C
 
 a
v
er
a
g
e

 i
th
ua

n
ia

S
w
it 

er
la
n
d

S
in
g
ap

or
e

F
le
m
is
h 
R
e
g
io
n 
( 

E
 

A
us

tr
ia

U
ni
te
d 
S
ta
te
s

Ir
el
an

d

C
h
ile

 
et
he

rl
an

ds

 
en

m
a
rk

F
in
la
n
d

 
e
w
  
ea

la
n
d

S
pa

in

H
un

g
ar
y

Is
ra
el

It
a
ly

C
ro
at
ia

C
an

ad
a

F
le
m
is
h 
R
e
gi
o
n 
( 

E
 

U
ni
te
d 
S
ta
te
s

E
ng

la
nd

 (
U
 
 

 
ew

  
ea

la
n
d

A
us

tr
ia

C
 e

ch
ia

G
er
m
a
ny

F
ra
n
ce

C
hi
le

 
e
nm

ar
k

 
or
w
ay

E
st
o
ni
a

 
et
he

rl
a
nd

s

S
in
g
a
po

re

S
w
it 

er
la
n
d

 
E
C
 
 a
ve

ra
g
e

S
lo
 a

k 
R
ep

ub
lic

S
w
e
de

n

H
un

g
ar
y

Ir
el
an

d

 a
p
an

 
at
 i
a

P
or
tu
g
a
l

Is
ra
e
l

 i
th
ua

n
ia

S
p
ai
n

F
in
la
n
d

P
ol
a
nd

 

 
or
e
a

30

2 

20

1 

10

 

0

  

Percentage points  .  ife satisfaction

30

2 

20

1 

10

 

0

Percentage points B.  ealt