 25 

 

A DECADE OF OECD COMPETITION TRENDS, DATA AND INSIGHTS © OECD 2025 
  

3.1. Market studies remain a valuable tool for competition authorities 

Market studies are a useful tool for competition authorities to assess whether competition in a market is 

working effectively and identify recommendations to address any issues if not. They are also key for the 

advocacy activities of the authorities, as they may include key messages and recommendations for 

relevant actors in the markets. A total of 1 561 market studies were conducted in the past decade, with the 

average number of market studies carried out per year remained relatively constant (three per year per 

jurisdiction). It is important to note that these numbers do not consider the different definitions that each 

authority may have of what constitutes a market study, as well as any changes in content, quality and 

depth of the studies through time.  

As it can be seen in Figure 3.1 there was a surge in the number of studies observed for OECD jurisdictions 

between 2020 and 2022 and despite the level of studies dropping off in the past two years, there remain 

more market studies per year in OECD jurisdictions than at the beginning of the decade. This shows their 

continued relevance for competition authorities, although there has been a fall in non-OECD jurisdictions. 

Reflecting their relevance, the decade has seen several pieces of OECD work related to market studies. 

Box 3.1 summarises this work. 

Figure 3.1. Total number of market studies conducted, 2015-2024 

 

Note: A three-year average is used to smooth out volatility caused by random fluctuations. Data based on the 60 jurisdictions in the OECD 

CompStats database that provided data for market studies for the period 2015-2024. 

Source: OECD CompStats database. 

0

20

40

60

80

100

120

140

160

180

200

All OECD Non-OECD