©2024 KPMG Corporate Finance LLC, a Delaware limited liability company. Member FINRA/SIPC. KPMG Corporate Finance LLC is a subsidiary of KPMG 

LLP, a Delaware limited liability partnership and a member firm of the KPMG global organization of independent member firms affiliated with KPMG 

International Limited, a private English company limited by guarantee. KPMG Corporate Finance LLC is not engaged in the pract ice of public accountancy. 

All rights reserved.

4

806 

1,090 

1,398 
1,528 

1,352 1,437 1,466 1,527 
1,329 1,342 1,286 

1,178 1,151 
999 940 

1,096 1,153 

Q2 Q3 Q4 Q1 Q2 Q3 Q4 Q1 Q2 Q3 Q4 Q1 Q2 Q3 Q4 Q1 Q2

2020 2021 2022 2023 2024

Professional Services M&A Market Commentary
• Announced year-over-year Q2 2024 global M&A transaction value increased to $56.8 bn from $31.5 bn in Q2 2023. Over the 

same period, announced transaction volume experienced a slight increase of 0.2%

• Announced Quarter-over-quarter, the global Q2 2024 transaction volume increased 5.2% compared to Q1 2024. Over the same 
period, announced transaction value increased from $28.1 bn in Q1 2024 to $56.8 bn in Q2 2024

• The spike in transaction value for Q2 2024 was driven the announcement of several large acquisitions, including International 
Business Machines Corporation’s $7.7bn acquisition of HashiCorp. and Permira Advisers $7.3bn acquisition of Squarespace.

RecentNotableU.S. Professional ServicesDeals

Professional ServicesAnnouncedDealVolume and Value(1)

Deal Volume (# of transactions); Deal Value ($ in bn)

June 2024
iQor / Mill Point Capital
Mill Point Capital, a private equity firm mainly targeting control 
investments in lower-middle market companies, has acquired iQor, 

a provider of business process outsourcing solutions. Transaction 
terms were undisclosed.

June 2024
Motion Recruitment Partners / Kelly Services (NasdaqGS:KELY.A)
Kelly Services, a staffing and workforce solutions firm, has acquired 
Motion Recruitment Partners for $485 mn. Motion Recruitment 

Partners operates as a recruitment and talent solutions firm focused 
on serving IT and technology companies.

July 2024
Amplify Consulting Partners / Sparq Holdings (Harvest Partners and 
Bain Capital)
Sparq, backed by Harvest Partners and Bain Capital, operates as an 

outsourced digital engineering services provider. Sparq has acquired 
Amplify Consulting, a consulting firm offering data engineering and 
visual analytics, for an undisclosed sum. 

June 2024
PrincetonOne / Hueman People Solutions (Shore Capital Partners)
Hueman People Solutions a recruitment process outsourcing (“RPO”) 
and talent acquisition firm, has acquired PrincetonOne for an 

undisclosed value. PrincetonOne operates as a recruitment process 
outsourcing services provider. Hueman People is backed by Shore 
Capital Partners. 

July 2024
Tandem HR / Vensure Employer Services (Stone Point Capital)
Vensure Employer Services (Vensure HR) has acquired Tandem HR. 
Tandem offers outsourced human resource and professional 

employer organization (“PEO”) solutions. Vensure HR is backed by 
Stone Point Capital and the acquisition of Tandem HR marks the 
company’s fourth acquisition over the past two months. 

(1) Market statistics sourced from Capital IQ, Merger Market, Pitchbook, Wall Street research, press releases. Notes: M&A analysis based on deals announced during respective periods. Deal value
represents aggregate deal value for disclosed transactions for time periods noted above

$65.0 $66.9 $69.6 $61.4 $70.0 $32.3$80.3$66.1$141.3$81.3$24.9 $27.3 $31.5 $49.3$51.2 $28.1

July 2024
Logic Information Systems / Accenture (NYSE:ACN)
Accenture, a professional services company that offers strategy and 
consulting, interactive, and technology and operations services, has 

announced the acquisition of Logic Information Systems, a strategy 
and consulting firm serving the retail industry. Transaction terms 
were undisclosed.

July 2024
Jamesbeck Global Partners / ZRG Partners (RFE Investment 
Partners)
ZRG Partners, backed by RFE Investment Partners, is a talent 

advisory firm providing executive search, interim solutions, and RPO 
services. ZRG has acquired Jamesbeck Global Partners for an 
undisclosed sum. Jamesbeck is an executive recruitment firm.

May 2024
AuditBoard / HgCapital 
HgCapital, an private equity firm focused on software and business 
services sectors, has announced the acquisition of AuditBoard for 

$3.0 bn and 15.00x LTM Revenue. AuditBoard provides a cloud-
based audit, risk, and compliance management platform.

$56.8