Petroleum and Liquid Fuels Markets Team | Financial Review 2024                                               

May 2025

Organic proved reserve additions and revisions for petroleum liquids 

and natural gas totaled 18 billion barrels in 2024

Data source: Evaluate Energy

Note: Select energy companies includes 158 global oil and natural gas companies. The Appendix contains the full list of companies.

Proved reserve additions for select energy companies

billion barrels of oil equivalent

-20

-15

-10

-5

0

5

10

15

20

25

30

35

2015 2016 2017 2018 2019 2020 2021 2022 2023 2024

total crude oil 

and natural gas 

reserve 

additions

extensions and 

discoveries

improved 

recovery

revisions

17

Organic proved reserve 

additions create new 

proved reserves from 

improved recovery, 

extensions, and 

discoveries.

Companies can also 

increase their proved 

reserves by purchasing 

them from other 

companies, but these 

additions do not create new 

proved reserves.