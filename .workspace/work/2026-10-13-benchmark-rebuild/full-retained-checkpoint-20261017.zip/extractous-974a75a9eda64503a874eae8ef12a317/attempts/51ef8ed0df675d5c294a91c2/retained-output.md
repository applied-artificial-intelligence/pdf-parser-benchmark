© 2024 IEEE. For personal use only. Published version under doi: 10.1109/AICCSA63423.2024.10912544.

after reviewing these datasets, we note that some of them

are of receipt type [12], [13], others consider a variety of

forms [14], [15], which differ slightly from a regular machine

written invoice. In [16], the authors propose a large dataset of

10000 synthetic invoices, specifically tailored for document

analysis and understanding. However, these documents do not

always reflect real-world scenarios where invoices are often

photographed with mobile phones, introducing significant dis-

tortions. We also notice that many of the datasets lack the

presence of stamp and signature components.

In order to fill this gap and to effectively apply DL tech-

niques, we propose a novel, fully annotated dataset composed

of real machine written invoice documents with various im-

perfections, such as blurriness, class imbalance, low-quality

phone-shot images, and varying formats. In our case study, we

consider a machine written invoice document to be valid only

if it contains a stamp, a signature, and certain selected fields.

After collecting and annotating the dataset, we select the most

relevant DL-based approaches for implementation and bench-

marking. We progressively evaluate and improve the results

until obtaining a robust pipeline that maximizes accuracy and

reliability, while maintaining reasonable performance.

The remainder of this paper is structured as follows. In

Section II, we present the material considered and the methods

proposed. The results are reported and discussed in Section III,

while Section IV concludes the paper and discusses the future

perspectives.

II. MATERIALS AND METHODS

In this section, we present the materials, detailing the data

collection and processing pipeline, and then describe the meth-

ods, including the selection of the most recent and relevant

models for implementation. Since invoice validation consists

of two main tasks, we divide our work into two independent

steps: keyword detection and object detection. The adopted

training pipeline is shown in Figure 1, which shows that

keyword detection is preceded by an OCR phase, which allows

for an OCR-augmented dataset. For object detection, we aim

to verify the presence of signatures and stamps to ensure the

authenticity of financial documents.

Fig. 1: Adopted training pipeline.

A. Materials

We outline the dataset used for our DL pipeline by first

describing the data annotation process, followed by data

augmentation and preparation.

1) Data annotation:

We collected 381 real financial documents, of which 84%

(320 documents) are invoices. Among these, 240 are machine-

written. We manually annotated the documents with bounding

boxes around the necessary elements to establish the validity

of the invoices, as shown in Table I. All classes are represented

as bounding boxes, except for a boolean attribute indicating

whether handwriting is present.

TABLE I: Annotated dataset description.

Class Description

Title Document type (e.g., invoice, receipt, etc.).

Client Client name.

Stamp Stamp for document authenticity.

Signature Signature for document authenticity.

Date Issue date, different formats.

Total Total label.

Total Value Total numeric value.

Handwritten True if handwritten (not machine-written).

An example of an annotated document is shown in Figure

2. For confidentiality reasons, some parts of the financial

documents have been blurred.

Fig. 2: Example of an annotated document.

Our dataset includes various real invoices; many are dis-

torted due to mobile phone capture as depicted in Figure 3, and

some are handwritten, potentially appearing skewed during

capture, as illustrated by Figure 4.

This work focuses on the processing of digital invoices,

since handwritten invoices are sparse in the current dataset, and

present additional challenges for augmentation and processing.

https://doi.org/10.1109/AICCSA63423.2024.10912544