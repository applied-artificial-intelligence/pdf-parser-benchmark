2004 2003 2002 2001 2000

Revenue $ 2,708.1 $ 2,517.8 $ 2,365.1 $ 2,257.5 $ 2,103.3
Operating income 452.3 412.7 459.5 283.5 434.0
Depreciation, amortization, depletion and accretion 273.1 251.8 199.6 215.4 197.4
Income before cumulative effect of changes
in accounting principles 237.9 215.4 239.6 125.5 221.0
Diluted earnings per share before cumulative effect
of changes in accounting principles 1.53 1.33 1.44 0.73 1.26
Cash flow provided by operating activities 666.3 600.5 569.7 459.2 461.8
Free cash flow* 388.2 336.4 325.7 218.6 266.4
Total assets 4,464.6 4,554.1 4,209.1 3,856.3 3,561.5
Total stockholders’ equity 1,872.5 1,904.5 1,881.1 1,755.9 1,674.9

dollar amounts in millions except per-share data

00 01 02 03 04
REVENUE

In Billions of Dollars

00 01 02 03 04
INCOME BEFORE CUMULATIVE EFFECT

OF CHANGES IN ACCOUNTING PRINCIPLES
In Millions of Dollars

00 01 02 03 04
FREE CASH FLOW

In Millions of Dollars

00 01 02 03 04
TOTAL ASSETS
In Billions of Dollars

00 01 02 03 04
STOCKHOLDERS’ EQUITY

In Billions of Dollars
DILUTED EARNINGS PER SHARE BEFORE

CUMULATIVE EFFECT OF CHANGES IN
ACCOUNTING PRINCIPLES

In Dollars

2.
1 2.

3 2.
4 2.
5 2.

7

21
5.

4 23
7.

9

22
1.

0

12
5.

5

23
9.

6

33
6.

4 38
8.

2

26
6.

4

21
8.

6

32
5.

7

3.
6 3.

9 4.
2 4.

6

4.
5

1.
7 1.

8 1.
9

1.
9

1.
9

1.
26

0.
73

1.
44

1.
33 1.

53

00 01 02 03 04

Corporate Office Stockholder Relations & Inquiries Independent Certified Common Stock Transfer &
Republic Services, Inc. Investor Relations Public Accountants Agent Registrar
110 SE 6th Street, Suite 2800 Republic Services, Inc. Ernst & Young LLP Wachovia Bank, NA
Fort Lauderdale, Florida 33301 110 SE 6th Street, Suite 2800 First Fort Lauderdale Place 1525 West W.T. Harris Boulevard
Phone: (954) 769-2400 Fort Lauderdale, Florida 33301 100 NE 3rd Avenue, Suite 700 Charlotte, North Carolina 28288-1153
www.republicservices.com Phone: (954) 769-3616 Fort Lauderdale, Florida 33301 Phone: (800) 829-8432

Notice of Annual Meeting
The Annual Meeting of Stockholders of Republic Services, Inc. will be held at 10:30 a.m., May 12, 2005,

at 110 SE 6th Street, 7th Floor Atrium, Fort Lauderdale, Florida 33301

*Free cash flow consists of cash provided by operating activities less purchases of property and equipment plus proceeds from the sale of property and equipment.

Financial Highlights

ANNUAL REPORT 2004
Corporate Headquarters

110 SE 6th Street, 28th Floor, Fort Lauderdale, Florida 33301
Phone: (954) 769-2400 • Fax: (954) 769-2664 • www.republicservices.com

©2005, RITM, LLC
Republic Services and Republic Services, Inc. names and logos are service marks of RITM, LLC

R
e

p
u

b
lic

 S
e

rvic
e

s, In
c

.  •  2
0

0
4

 A
n

n
u

a
l R

e
p

o
rt