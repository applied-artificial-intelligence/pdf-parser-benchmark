Net sales $22.1 billion, +2.9%, Net sales without fuel +5.5%, eCommerce +27%

• Continued strength in grocery and 
health & wellness; fourth consecutive 
quarter of positive general 
merchandise sales

• Comp sales driven by increases in 
transactions and unit volumes

◦ Transactions ex fuel: +4.8%
◦ Average ticket ex fuel: +1.7%

• eCommerce delivery growth of ~160%

• Share gains in grocery and general 
merchandise categories (per Circana)

• Member's Mark grew low double-digits, 
outpacing segment comp

eComm Cont. 
without fuel +180 bps +230 bps +290 bps +280 bps +350 bps

1 Comp sales for the 13-week period ended May 2, 2025 compared to the 13-week period ended May 3, 2024.

Sam’s Club U.S. revenues

3.5%

4.6%

3.7%

5.3%

4.0%
4.4%

5.2%

7.0% 6.8% 6.7%

With fuel Without fuel

Q1 FY25 Q2 FY25 Q3 FY25 Q4 FY25 Q1 FY26

19

Sam's Club U.S. comp sales1