246    

OECD EMPLOYMENT OUTLOOK 2024 © OECD 2024 
  

emissions echo those found in Chancel, Bothe and Voituriez (2023[112])’s recent study, even though the 

results presented here are less skewed. 

Figure 5.7. Carbon footprints are much bigger at high income levels, but in some countries low-
income households consume greater shares of high-emission goods 

Household expenditure and emissions shares of total, by (disposable) income decile 

 

Note: Average expenditure (resp. emissions) by income group (equivalised disposable household income) as a percentage of overall expenditure 

(resp. emissions). Estimates follow the “consumer responsibility” principle, accounting for all household consumption, including both domestically 

produced and imported goods. They therefore attribute emissions to the country where the final good is consumed, and this differs from the 

emissions per capita that are physically released in a given country. 

Reading: in Poland, expenditure from the lowest income decile accounts for about 6% of total national expenditure and expenditure from the 

highest income decile accounts for about 18%. About 5% of emissions accrued to the lowest income decile while 16.5% of emissions accrued 

to the highest income decile. 

Source: OECD calculations using IEA emissions factors for different fuels, World Input-Output Database (WIOD) as well as household budget 

surveys (2015 for EU countries, 2016 for Mexico, 2019 for Türkiye). 

StatLink 2 https://stat.link/2jcm09 

0

5

10

15

20

25

30

35

1 2 3 4 5 6 7 8 9 10
Income decile

France
%

0

5

10

15

20

25

30

35

1 2 3 4 5 6 7 8 9 10
Income decile

Germany
%

0

5

10

15

20

25

30

35

1 2 3 4 5 6 7 8 9 10
Income decile

Mexico
%

0

5

10

15

20

25

30

35

1 2 3 4 5 6 7 8 9 10
Income decile

Poland
%

Expenditure CO2 emissions

0

5

10

15

20

25

30

35

1 2 3 4 5 6 7 8 9 10
Income decile

Türkiye
%

0

5

10

15

20

25

30

35

1 2 3 4 5 6 7 8 9 10
Income decile

Five-country average
%

https://stat.link/2jcm09