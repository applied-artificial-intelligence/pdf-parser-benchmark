Natural gas front-month futures price (Henry Hub)

real 2024 dollars per million British thermal units

Data source: Bloomberg L.P.

10
Petroleum and Liquid Fuels Markets Team | Financial Review 2024                                               

May 2025

In 2024, U.S. natural gas prices were 12% lower in real terms than in 

2023

$0

$1

$2

$3

$4

$5

$6

$7

$8

2015 2016 2017 2018 2019 2020 2021 2022 2023 2024

Lower natural gas prices 

reduced cash from 

operations since 

companies earned less 

from selling natural gas.

Lower natural gas prices 

also led the energy 

companies to reduce their 

natural gas production.

Natural gas prices in 2024 

were at their lowest in real 

terms since at least 2000.