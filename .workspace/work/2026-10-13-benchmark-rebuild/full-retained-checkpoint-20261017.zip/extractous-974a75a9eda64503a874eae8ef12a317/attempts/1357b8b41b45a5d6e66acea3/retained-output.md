Global Outsourcing Survey 2024 | Multidimensional sourcing: Orchestrating the extended workforce ecosystem 

14

Success with outcome-based delivery models 
A key factor in the evolution of outsourcing toward core capabilities is the growing adoption of outcome-
based delivery models—for example, operate services.3 These models prioritize business outcomes and 
value creation rather than simply supplementing manpower.

Two years ago, we acknowledged that the traditional staff augmentation model is giving way to outcome-
based delivery models. According to recent data, this trend has gained further momentum.

High levels of satisfaction with managed and operate services are driving its continued adoption and 
increased investment across organizations.

Although the adoption of mature delivery models is expected to continue increasing, and the delivery 
models may evolve over time, it is evident that organizations are interested in buying capabilities and 
outcomes, and not hours.

67%
of executives reported adoption of 
managed or operate services (up from 
45% two years ago)

29%
of executives reported adoption of 
legacy staff-augmentation model

Report meets or exceeds satisfaction 
levels from outsourced services

Report a planned increase in 
investment in outsourced services

Organizations that adopt  
managed or operate services

88%

47%

Organizations that do not adopt 
managed or operate services

71%

35%