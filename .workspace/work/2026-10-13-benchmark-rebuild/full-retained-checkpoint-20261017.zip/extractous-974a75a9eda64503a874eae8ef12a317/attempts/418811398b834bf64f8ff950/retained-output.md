Sources: NASA GISTEMP; NOAA GHCND
*To March 23rd   †Data are lower resolution above 82°N

Land-surface air temperature and ocean-surface temperature
Average from December 2019 to February 2020, change from average during same months from 1951-80

Average daily low temperature, by month
Selected cities, °C  

The northern-hemisphere winter of 2019-20 was the warmest ever on land

EQUATOR

ARCTIC
C

IR
C

LE

Oslo

Tokyo

London

Boston Moscow

Novosibirsk

North Pole†

Anchorage

Max 7.9-1.1 0

Warmer →← Cooler

Moscow

-10

-20

0

10

20

London

5

0

10

15

Novosibirsk

-30

-15

0

15

Tokyo

0

10

-10 -5

20

30

Oslo

Coldest
months

Boston

Jan JunJul

Jan JunJul Jan JunJul

Jan JunJul

Jan JunJul

Jan JunJul

0

10

-10

20

0

10

-10

-20

20

2019-20* 1951-80
average

95% confidence
interval

The Economist March 28th 2020 85

The most commonly cited risks of cli-
mate change are natural disasters:

fiercer wildfires and hurricanes, bigger
floods and longer droughts. But one of the
most striking recent effects of global
warming has been unusually mild weather
in many parts of the world.

The northern-hemisphere winter that
ended on March 20th was the second-
warmest since records began, and the
warmest ever on land. The anomaly was
biggest in Europe and Asia, where average
temperatures from December to February
were 3.2°C (5.8°F) and 3.1°C above the aver-
age from 1951-80, and 0.8°C and 0.7°C above
those continents’ previous record highs.
After a normal autumn, temperatures
stayed close to their November levels for
months. In Boston, where daily lows in
January tend to hover around -6°C, the av-

erage minimum this January was 0°C; for
Tokyo the figures were 0°C and 5°C. By local
standards, the balmiest winter of all was in
Russia. Moscow’s average daily low in Jan-
uary was -2°C, far from the customary -13°C.

The winter-that-wasn’t of 2019-20 is not
yet a new normal. The main factor deter-
mining the severity of northern winters is
the “Arctic oscillation”: the relative pres-
sure of Arctic and sub-tropical air. When
pressure is higher in the Arctic, cold air
from the North Pole pushes south, bring-
ing harsh, dry winters to many places.
When pressure is higher towards the sub-
tropics, warm air pushes northwards, hem-
ming in cold air around the pole. These two

patterns flip back and forth irregularly.
For reasons that are not yet clear, pres-

sure in the sub-tropics this year was much
stronger than in the Arctic. And research-
ers have not yet determined how rising
temperatures affect the Arctic oscillation.
Until a few years ago, climate models tend-
ed to show pressure in the Arctic strength-
ening, reducing the amount of warming
during winter at temperate northern lati-
tudes. The latest models find the reverse.

However, climate change is still respon-
sible for anomalies like this one. At the av-
erage global temperature in 1950, a winter
this mild was all but impossible. In today’s
climate, such reprieves from the cold
should occur once every 11years. And if glo-
bal warming continues on its current tra-
jectory, winters like this year’s could be-
come standard within a few decades.

Mild winters offer benefits. Heating is
cheaper, flu seasons are shorter and fewer
people die overall. But problems mount as
well. Without hard frosts, pests can survive
and multiply to attack crops more harshly.
Warmer winters are usually wetter, chang-
ing snowfall patterns. This can shrink the
snowpack that supplies rivers, and cause
floods. Even people who bemoan frigid
winters may miss them if they vanish. 7

Northern-hemisphere temperatures
stayed flat from November to March

Winter is not
coming

Climate changeGraphic detail

Source: NASA GISTEMP

Northern-hemisphere land temperature in winter
Change from 1951-80 average, °C

3

2

1

0

-1

-2

↑ Warmer

↓ Cooler

Record

201020009080706050401930

Issue Date: 28-03-2020 Zone: UKPB Desk: GraphicDetail Output on: 25-03-2020----18:11 Page: GD1 Revision: 0