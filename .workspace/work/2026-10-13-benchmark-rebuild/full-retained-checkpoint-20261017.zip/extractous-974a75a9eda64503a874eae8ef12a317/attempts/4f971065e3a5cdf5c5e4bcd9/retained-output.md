Chapter 4. Gender Inequality
Figure 4.10. The high school enrollment gender gap hasdecreased in the last 25 years

Gender parity

80%

85%

90%

95%

100%

105%

2000 2005 2010 2015 2020 2025

F
em

al
e 

hi
gh

 s
ch

oo
l e

nr
ol

lm
en

t
(a

s 
%

 o
f m

al
e 

hi
gh

 s
ch

oo
l  

en
ro

llm
en

t)

High income Low & middle income World

Female high school enrollment as a share of male enrollment, 2000−2025

Interpretation. This figure shows the evolution of the gender gap in high school enrollment from 2000 to 2025
across country income groups. The indicator measures female enrollment as a share of male enrollment. At the
global level, this share increased from 88% in 2000 to 98% in 2025, indicating near gender parity. In high−income
countries, the ratio reached 101%, and in low− & middle−income countries, the ratio reached 98%, reflecting
considerable progress over two decades. Sources and series: wir2026.wid.world/methodology.

Figure 4.11. Education alone cannot fully close the gap

10.5%

8.3%

12.1%

10%
9.3%

6.5%

11%

8.7%

6.3%

4.2%

9%

6.6%

9.7%

7.8%

9.9%

7.6%

0%
1%
2%
3%
4%
5%
6%
7%
8%
9%

10%
11%
12%
13%
14%

MENA Other
Asia

China India World Sub−Sah.
Africa

Latin
America

Europe /
U.S.

R
et

ur
n 

to
 a

n 
ad

di
tio

na
l y

ea
r 

of
 s

ch
oo

lin
g 

(%
)

Men Women

Returns to schooling by gender, 2019

Interpretation. The figure plots returns to a year of schooling by gender and world region in 2019.
Estimates correspond to the effect of one additional year of schooling on the log of personal income,
estimated separately by gender using modified Mincerian equations that control for an experience
quartic. In all world regions, the return to a year of schooling is higher for women than for men. Sources
and series: Gethin (2024).

99