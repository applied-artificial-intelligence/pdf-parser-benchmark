a(ml +mres)

√ √ √ √

M
B
s
/M
B
l
·
ξ

APE:
√

mBs/mBd · ξ = 1.142(72), χ2/dof = 0.3

HYP:
√

mBs/mBd · ξ = 1.144(54), χ2/dof = 2.0

FIG. 6: Chiral extrapolation of
√

MBs/MBl
=
√

mBs/mBl

(
fBs

√
BBs/fBl

√
BBl

)
. The blue (tri-

angle) points denote the APE data, while the red (square) points denote the HYP-smeared data.

The color of the shaded (hatched) error band corresponds to those of the APE (HYP) data points.

The dashed vertical line denotes the physical average u-d quark mass and the black dot denotes the

physical strange quark mass, at which the SU(3)-breaking ratio must be one. The SU(2) HMχPT

coefficients obtained from the fit are RM = 1.18(8) and Dl = 2.6(1.1) in the case of APE smearing

and RM = 1.18(6) and Dl = 2.6(8) in the case of HYP smearing. Errors shown are statistical only.

TABLE VII: Results for ΦBs/ΦBd
and

√
mBs/mBd

· ξ at the physical point. Only statistical errors

are shown.

link smearing

APE HYP

ΦBs/ΦBd
1.165(88) 1.153(47)

√
mBs/mBd

· ξ 1.142(72) 1.144(54)

VI. ESTIMATION OF SYSTEMATIC ERRORS

In this section we estimate the systematic uncertainties in the SU(3)-breaking ratios

fBs
/fBd

and ξ. For clarity, we present each source of error in a separate subsection. The

30