Chapter 8. Political Cleavages
Figure 8.1. Working class representation has always been lowand has further deteriorated in recent decades

0%
2%
4%
6%
8%

10%
12%
14%
16%
18%
20%

19
00

19
05

19
10

19
15

19
20

19
25

19
30

19
35

19
40

19
45

19
50

19
55

19
60

19
65

19
70

19
75

19
80

19
85

19
90

19
95

20
00

20
05

20
10

20
15

20
20

20
25

S
ha

re
 o

f w
or

ki
ng

−
cl

as
s 

M
P

s 
(%

)

France United Kingdom United States

Working class representation in Western democracies, 1900−2025

Interpretation. The long−run decline in the share of working−class members of parliament (MPs): evidence from
France, the United Kingdom, and the United States. The figure plots the evolution of the share of working−class
MPs—measured as the number of MPs whose former occupation just before the elections was a “manual”
occupation (United Kingdom), a “blue−collar” occupation (United States), or an occupation as “employés et
ouvriers” (France)—over the total number of MPs in each country. The share of working−class occupations in the
total labor force is usually around 50%–60% or more. Sources and series: Cagé (2024).

with the bottom 90% has remained negative:top-income voters are consistently less likelyto support the left. This transition highlightsa shift from “class-based” to “multi-elite”party systems, which now feature opposingcamps comprising an educated “Brahmin left”and an affluent “merchant right” (see Gethin,Martínez-Toledano, and Piketty (2022);Gethin, Martínez-Toledano, and Piketty(2021); Gethin and Martínez-Toledano(2025)).
This structural transformation is closelyrelated to educational expansion andthe ensuing “complexification” of theoccupational structure. By way of illustration,many high-degree but relatively low-incomevoters (e.g., teachers or nurses) currentlyvote for the left, while many voters withlower degrees but relatively higher income(e.g., self-employed or truck drivers) tend tovote for the right.
Importantly, this transformation hasnot been restricted to a few countries. Ithas unfolded across almost all twenty-oneWestern democracies included in the

World Political Cleavages and Inequality

Database, despite wide differences in theirhistories, institutions, and party structures.This common transformation has beenclosely linked not only to the rise of a newsociocultural axis of political conflict, but alsoto the convergence of parties on economicpolicy, political fragmentation, economicdevelopment, and educational progress (seeGethin and Martínez-Toledano (2025)).Figure 8.3 documents the remarkablereversal of educational divides acrossdifferent Western democracies. In thepostwar decades, voters with low levels ofeducation were the backbone of left-wingparties, while the highly educated leanedright. Today, the opposite holds: highlyeducated voters now disproportionately votemore for the left, while the less educatedoften support conservative parties.
This reversal has transformed left-wingparties from representing the industrialworking class in the past into coalitionsanchored in the educated middle andupper-middle classes in the present. Theseleft parties increasingly attract highlyeducated “sociocultural professionals”, such

145