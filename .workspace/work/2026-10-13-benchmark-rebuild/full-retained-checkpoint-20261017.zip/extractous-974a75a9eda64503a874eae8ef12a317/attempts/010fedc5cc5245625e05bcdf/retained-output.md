© 2026 Dow Jones & Company. All Rights Reserved. THEWALL STREET JOURNAL. Monday, February 2, 2026 | B1

BY REBECCA FENG
AND JOEWALLACE

BY TIMOTHYW.MARTIN
AND JIYOUNG SOHN

Hyundai’s
CEO Leads
U.S. Push,
Sets Sights
On Robots

BY JON EMONT

LastWeek: S&P 6939.03 À 0.34% S&PFIN À 0.69% S&P IT g 0.36% DJTRANS À 0.55% WSJ$ IDX g 0.35% 2–YR. TREAS. yield 3.527% NIKKEI 53322.85 g 0.97% Seemore atWSJ.com/Markets

BUSINESS&FINANCE

BUSINESS NEWS
Labor shortage hits
broadband industry as
demand for fiber-optic

cable surges. B9

HEARD ON
THE STREET

Luxury business is
unlikely to rebound

in China. B10

Two CEOs waited by the el-
evators this summer in an of-
fice building in California farm
country where their compa-
nies made their headquarters,
on different floors. One ran a
multinational salad company,
the other a tiny bank with four
branches.
Their usual 8 a.m. small

talk took a turn when Taylor
Fresh Foods Chief Executive
Bruce Taylor offered Pacific
Valley Bancorp CEO Anker Fa-
noe an investment of between
$15 million and $20 million.
“Would that help you

guys?” Taylor asked.
Fanoe thought it had to be

a joke and moved on with his
day.
But truth be told, Fanoe

thought his bank could use it.
Pacific Valley had recently be-
come the last locally owned
and headquartered bank in
Monterey County after com-
petitors were eaten up by ac-
quisitions, he said.
Activist investors scouring

the country for new targets in
the industry had also rattled
his bank. Pacific Valley’s profit
had dropped double-digits af-
ter costs jumped and a busi-
ness loan went bad.
Taylor Fresh Foods, which

sells prepackaged salad prod-
ucts and rakes in billions of
dollars in revenue each year,
announced a roughly 16%
stake in Pacific Valley several
months later. That made it the
largest investor in the bank,
with a seat on its board. Tay-
lor was already one of its larg-

est depositors and the owner
of the five-story Taylor Build-
ing where the bank leases its
headquarters.
The unusual investment in

Pacific Valley by a salad com-
pany underscores the mount-
ing challenges that thousands
of community banks around
the country face. Pressures in-
clude the emergence of com-
petitors such as stablecoin and
fintech firms, in addition to a
steady rise in technology
costs.
“It’s hard to be a bank CEO

and not be worried,” Fanoe
said.
Based in Salinas, Calif., a

blue-collar city outside of
Monterey, the floors of Pacific
Valley are frequently covered
in dirt that farmers track in,
dressed in Wrangler jeans and

work boots. Its branches are
staffed with bilingual speak-
ers, with Salinas majority His-
panic.
When the rodeo comes to

town, the bank puts out bales

of hay and a saddle to cele-
brate.
Community banks like Pa-

cific Valley often serve as
stewards of local economies
that rely on them for plain-va-

nilla loans. These banks tend
to win deeply loyal customers
who keep deposits with them.
At Pacific Valley, local

knowledge and flexibility al-
PleaseturntopageB2

BY GINAHEEB

Border police stopped a car
last week crossing from Hong
Kong into the mainland Chi-
nese city of Shenzhen. The sus-
pected crime: silver smuggling.
Two men in their 40s hid

nearly 500 pounds of silver
bars in 10 cookie tins, six
milk-powder tins and nine
crispy egg-roll boxes. The esti-
mated market value was
roughly $782,000, according
to Hong Kong customs author-
ities, who arrested the men
and seized the bars.

The duo were likely headed
for one of the largest bullion
markets in China, the Shen-
zhen Shuibei Gold and Jewelry
Market, hoping to cash in on
the silver boom. The market,
where prices trade at a pre-
mium compared with other
countries, has become an epi-
center of a metals mania that
has captivated traders.
Silver prices shot up more

than 250% in the past year to
as high as $114 a troy ounce in
New York trading. At their
peak, they were up 63% in
January. In China, where the
metal is needed for solar-
panel production and coveted
by speculators, silver futures
rose to even higher levels,
above $140 on Thursday.
Silver’s surge crumbled on

Friday, when prices plunged
PleaseturntopageB9

Silver Market’s
Swings Rattle
Companies
Metal’s boom, slowed
by a plunge, caused
frenzy and pain for
refiners and users

2016 ’17 ’18 ’19 ’20 ’21 ’22 ’23 ’24 ’25

0

50

100

150

200

250million ounces
Photovoltaics Jewelry

Silver demand, by source

Jan. 2025 Jan. ’26

3.0

4.0

5.0

3.5

4.5

5.5 cents per wattSolar cells price*

*Prices for TOPCon M10 cells in China

Feb. 2024 ’25

Front-month contract

’26

0

20

40

60

80

100

$120 a troy ounce

Silver futures price

Sources: The Silver Institute (demand); OPIS (solar cells); Dow Jones Market Data (futures)

Friday

$78.29
▼31%

Generals Are Hot Commodity in Mining INSIDE

GOYANG, South Korea—If
the job of a car executive is to
sell cars, it is hard to argue
with the results of Hyundai
Motor’s José Muñoz. Last
year, Hyundai sold about a
million vehicles in the
U.S.—39% more than when he
joined the company in 2019—
and more than four million
worldwide.
Yet Muñoz, the first non-

Korean chief executive of the
South Korean carmaker, seems
to be worried that Hyundai is
moving too slowly in an era of
tariffs and technological
change. He wants to shake up
its hierarchical culture, expand
into robots and flying cars,
and build factories in the U.S.
faster.
“We’re focusing on acceler-

ating,” he said of the com-
pany’s roughly $26 billion plan
to invest in the U.S., in an in-
terview. “The sooner the bet-
ter, so we can enjoy our in-
vestments.”
So far the stock market

likes his gambles on high-tech
moonshots. When Hyundai
showed off its Atlas humanoid
robot in January, the stock
price skyrocketed. It is up 80%
in just the past month.
On Thursday, Hyundai re-

ported a 22% drop in net in-
come for 2025, stung by Presi-
dent Trump’s tariffs on
imported cars such as Korean-
made Hyundais, although
global revenue hit a record.
Trump stoked uncertainty
again last Monday by threat-
ening to restore 25% U.S. tar-
iffs on South Korea just three
months after the two coun-
tries had agreed to lower the
rate to 15%.
Muñoz, who has met Trump

several times, said he believed
the president understood
Hyundai’s commitment to the
U.S.
In the unpredictable Trump

age, the CEO wants his people
to be ready for anything—and
he reflects that in his manage-
ment style.
When he addressed roughly

1,000 local sales employees
early this year in this Seoul
suburb, aides had Korean
translations of his English-lan-
guage speech ready to display
on a large screen. But Muñoz
scrapped the canned speech.
He grabbed a microphone and
invited an interpreter to join
him on stage, where he told
the troops that 2026 couldn’t
be just another year of busi-
ness as usual.
Muñoz, a 60-year-old Span-

ish-U.S. dual national, didn’t
start out as an auto-industry
man. He earned a Ph.D. in nu-
clear engineering in his native
Spain during the 1980s and
worked in the country’s nu-
clear-energy sector. Back then,
he didn’t even own a car.

PleaseturntopageB2

Companies that mine criti-
cal minerals are looking more
like defense contractors these
days. One sign: Many are hir-
ing retired generals.
Western miners have added

at least a dozen former Ameri-
can generals, colonels and ad-
mirals to boards or to senior
leadership roles over the past
year, hoping to tap the billions
of dollars the Defense Depart-
ment is shelling out to rebuild
domestic supply chains after
China cut the U.S. off for much
of last year.
The retired generals guide

the geologists and finance ex-
ecutives who run mining com-
panies through the less-famil-
iar terrain of Washington. They
make introductions to defense
companies, scrutinize business
deals with foreign partners to
make sure they won’t raise

flags with the Pentagon and
give advice about whom to
meet on Capitol Hill.
Almonty Industries, a

North American company that
mines tungsten in Europe and
South Korea, picked up two re-

tired American generals last
year. Retired four-star Army
Gen. Gustave Perna, a logistics
expert, joined the company’s
board in March and retired
Army Brig. Gen. Steven Allen
enlisted as chief operations of-

ficer in December.
Board positions can earn

former generals tens of thou-
sands to hundreds of thou-
sands of dollars a year. Retired
Gen. Richard B. Myers, a board
member at rare-earth miner
MP Materials, brought in
$240,000 in 2024, based on
fees and stock awards.
United States Antimony,

whose namesake metal is used
to harden bullets, brought a re-
tired four-star Army general,
Jack Keane, onto its board in
August, after a search that
stretched for longer than a
year to find the right former
military official. Critical Met-
als, a British Virgin Islands-
based company developing a
rare-earth mine in Greenland,
last year appointed a retired
four-star general and a retired
rear admiral to an advisory
board.

PleaseturntopageB2

A Global Salad Chain Throws
A Lifeline to Tiny Local Bank

STREETWISE |By JamesMackintosh

Parsing Boom and Bust in Gold, Silver

What if—and
bear with me
here—the wild
gyrations in

gold and silver prices are
actually telling us some-
thing?
There are three plausible

messages from the rise in
gold prices. I’m not con-
vinced that any of them
provide a full explanation
for what’s going on.
But all of them have a

grain of truth, and tell us
something about how inves-
tors in stocks, bonds and
currencies are navigating a
very uncertain time in the
world

1) Investors want gold as a
dollar alternative

Countries that fear falling
afoul of Western sanctions
have been buying gold
rather than dollars for their
foreign-exchange reserves
for several years.
But last year, central

banks reduced their buying
as prices jumped, according
to the World Gold Council.
Instead, buying lately has

been dominated by private
investors, especially via ex-
change-traded funds. They
might simply be scooping
up gold expecting worried
central banks will intensify

their buying at
a still-higher
price, but at
best that’s a
hope.
If they’re

right, gold
should be ris-
ing as the dol-
lar falls
against other
currencies. In
fact, gold moved indepen-
dently of the dollar day to
day in the past year, al-
though overall the dollar is
down a lot while gold went
wild.
Treasury yields should

also rise relative to other

countries as
money leaves
America.
But U.S. 10-

year Treasury
yields have
fallen a little
since the start
of last year,
while those of
Japan, France,
Germany and

the U.K. are all up, in some
cases by a lot.

2) The ‘debasement trade’
An idea that appeals to a

lot of those scarred by the
last bout of inflation is that
another is on the way,

caused by hefty government
stimulus and a deliberate
policy of weakening the dol-
lar.
A weak dollar is mechani-

cally good for gold, since it
is priced in dollars, while
gold is often touted as a
safe asset to sit out infla-
tion.
The Swiss franc, the clos-

est thing to a haven cur-
rency, also has performed
well in the past couple of
weeks, along with the low-
debt oil-exposed Norwegian
krone.
Friday’s plunge in gold

and full-blown crash in sil-
PleaseturntopageB9

Friday’s plunge
indicates

investors were
worried about
debasement.

Retired four-star Army Gen. Gustave Perna, left, and retired
Army Brig. Gen. Steven Allen play roles at Almonty Industries.

YO
NH
AP
NE
W
S/
NE
W
SC
OM
/Z
UM
A
PR
ES
S

CEO Bruce Taylor of Taylor Fresh Foods, which sells prepackaged salad products.

CO
LB
Y
TA
RS
IT
AN
O
FO
R
W
SJ

PA
TR
IC
K
SE
M
AN
SK
Y/
AP

P2JW033000-0-B00100-1--------XA