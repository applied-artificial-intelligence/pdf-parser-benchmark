© 2025 Swiss Re. All rights reserved.

3  Swiss Re Institute  Unseasonal fires trigger above-trend first-half 2025 natural catastrophe insured losses   

Overall, losses from wildfires have been rising significantly in the 
past decade. Prior to 2015, on average wildfires across the world 
contributed around 1% of the total insured losses from all natural 
catastrophes. In the last 10 years, this has risen to 7%, the costliest 
periods being a two-year stretch of 2017‒18, and to a lesser extent 
2020. Eight of the 10 costliest wildfire insured loss events have all 
occurred in the last decade, after adjusting for inflation. Wildfires 
are an ever-present hazard in hot and dry regions with large areas 
of vegetation, such as there are in North America. The single 
biggest loss growth driver for this peril is increased exposure in 
such hazardous regions. Due to the combination of high hazard and 
high value asset concentration, most fire losses originate in the US 
and particularly in California, where expansion in said regions has 
been high. Since 1990, exposure growth in the high-risk wildland 
urban interface (WUI) zones has outpaced exposure growth in 
non-WUI zones by a factor of 1.8 in the US, and by a factor of 1.9 
in California.3 

Wildfires are typical for southern California after an extended period 
of low precipitation and in the presence of strong, dry winds. They 
are a natural phenomenon of the forest ecosystem, essential for 
restoring nutrients to the soil, clearing out decay and helping plants 
to reproduce. Occasionally forest fires turn into urban conflagration 
when they spread to urban areas, threatening human safety and 
property. Suburban sprawl with communities expanding into 
wildland increases the risk of such events. The close proximity of 
structures to dense vegetation allows for easier transfer of flames 
and embers to nearby buildings, increasing the vulnerability of the 
suburban environment risk. In addition, WUI development adds 
additional sources of ignition (sparks from machinery or trains, 
campfires, arcing from electrical utility lines, as well as arson).

Ongoing warming and drying trends, coupled with changing rainfall 
patterns, contribute to drier and more flammable fuels, creating 
conditions more conducive for ignition and spread. Rising 
temperatures are also extending the fire seasons, lengthening the 
overlap of the peak fuel dryness and the height of the Santa Ana 
winds season in California. The January fires in California were 
unusual in that they occurred in the winter season, typically the 
state’s wet season. Historically, the biggest wildfire loss events in 
California have occurred during the hot and dry late summer and 
autumn months, after which cooler temperatures and rains serve to 

dampen fire risk. Based on sigma records, 99% of the wildfire losses 
that originate in California occur in the second half of the year. 

The 2025 fires give the measure of the scale of devastation and 
loss potential when all ingredients for major conflagration come 
together: weather (drought and winds); dense urban or suburban 
environment; and fuel (flammable structures and dry grassland 
that connects the structures, providing a pathway of fire). There 
have been large wildfire-loss events outside of the US in recent 
years too, such as in Australia (as in 2019 and 2009), Canada (as 
in 2016), and also Europe (eg, Portugal in 2017), with all 
ingredients for urban conflagration present. Droughts are 
becoming more frequent in Europe also, extending the wildfire 
season and exacerbating water shortages, which hinder 
firefighting efforts. 

Wildfire is a complex peril to model. Human actions influence the 
occurrence and damage potential of wildfires to a much greater 
extent than other perils. To date traditional risk evaluation 
methods – such as predictive or probabilistic models – have not 
been fully captured the complex interactions between drivers of 
wildfire risk, changes in fire behaviour and inter-annual variability. 
Wildfire remains a volatile peril and in our view, more and rising 
associated insured losses can be expected.4 

Severe convective storm losses remain high though 
below trend

Between March and June, a number of severe thunderstorms with 
large hail and tornado outbreaks in the US led to global SCS-related 
insured losses of USD 31 billion in the first half of 2025 (see  
Figure 6 below). Though below the trend estimate of 
USD 35 billion and also the first-half loss tallies for this peril in 2023 
and 2024, those SCS losses are still the 4th costliest ever. Only a 
decade ago insured losses triggered by SCS were trending at 
around USD 20 billion. 

Entangled with high year-on-year volatility, SCS drive a substantial 
portion of global natural catastrophe insured losses. The main 
factors pushing losses higher are increased exposure values due to 
economic and population growth, urbanisation (expanding urban 
footprints in exposed regions) and inflation (mainly construction 

Figure 5: Global annual insured losses from wildfires (USD bn, 2025 prices)

Source: Swiss Re Institute

0

5

10

15

20

25

30

35

40

45

1H202520232021201920172015201320112009200720052003200119991997

Editable field 2023 - with outline

Editable field 2023 - without outline

Rest of the worldUS

Cedar &
Old, US

Fort McMurray
Canada

Tubbs, Atlas,
Thomas, US

Palisades,
Eaton, US

Camp,
Woolsey US

Glass, US