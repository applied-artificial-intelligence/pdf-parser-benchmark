7 
 

those consistent with a 2.0 percent target rate for total inflation, they are well down from the 
0.7 percent to 0.8 percent monthly rates seen in the latter half of 2022.  Over the year through 
April 2025, rent of housing inflation was 4.2 percent, the slowest pace since January 2022.  

 
Inflation for non-housing core services has been an integral driver of elevated core inflation.  
Significantly, inflation in this metric slowed to 0.2 percent during the first quarter of 2025, from 
an average 0.3 percent during the latter half of 2024.  The slowing pace of core non-housing 
services inflation largely reflected an easing of prices in several categories, including 
transportation services and hotel lodgings.  From 2017 to 2019, annual non-housing services 
inflation averaged 2.1 percent, versus 4.0 percent over the year ending in December 2024.  As of 
April 2025, core non-housing services inflation was 0.2 percent, and over the year through April, 
was 2.8 percent, the slowest twelve-month pace since March 2021.  
 
Inflation as measured by the PCE price index is the Federal Reserve’s preferred measure of 
inflation: the FOMC’s 2 percent inflation target is expressed in terms of headline PCE, and core 
PCE inflation is also taken into consideration.  There are notable differences in weights and 
methodologies between the CPI and the PCE measures.  Historically, twelve-month CPI inflation 
has exceeded PCE inflation by about 0.4 percentage points on average.  During 2024, however, 
the wedge widened, averaging 0.6 percentage points in the year’s first half.  As core services 
price growth slowed, the wedge narrowed noticeably, averaging 0.3 percentage points during the 
latter half.  Headline PCE inflation slowed during 2024 and was 2.1 percent over the twelve 
months through September—or 0.1 percentage point above the FOMC inflation target—while 
core PCE inflation was 2.7 percent over that same period.  By February 2025, headline PCE 
inflation had accelerated to 0.7 percentage points above the target.  Over the year through March 
2025 (latest data available), headline PCE was 2.3 percent—0.3 percentage points above the Fed 
target percent—and the core reading was 2.6 percent. 

 

Consumer Prices 

(Percent change from a year earlier)