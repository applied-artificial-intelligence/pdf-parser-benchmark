A R T H U R  D .  L I T T L E

This correlation between income and 
acceptance of autonomous driving holds in all 
regions, though the threshold for acceptance 
varies. In China, we see 34% net approval at 
average income and city size between 1 and 5 
million people, while in the US we need to move 
to cities with 5 million inhabitants and high 
incomes to see similar net approval levels.

European, Northeast Asian, and US respondents 
are the least willing to adopt autonomous 
vehicles, while those in India, China, and the 
Middle East demonstrate a much more favorable 
attitude (see Figure 10).

THE IMPORTANCE OF  
SAFETY TO ACCEPTANCE

Mirroring the examples cited above from 
California, the primary concern with 
autonomous driving across all incomes and 
regions is safety, encompassing both machine 
and human errors, as shown in Figure 11.

User concerns about safety mainly reflect the 
still-immature technology for L4/L5 autonomous 
driving and a resulting lack of positive experiences 
reported in the media. People are aware that 
current autonomous vehicles depend on backup 
human drivers who are ready to intervene, 
must go slower than a human driver, and only 

operate in dedicated environments with special 
infrastructure. The promised benefits of 
automation around convenience and ease of use 
have not materialized yet. On the contrary, recent 
incidents in the US, which led to pausing trials of 
the most advanced robo-taxis, coupled with high-
profile stories on crashes of private vehicles, have 
not helped to increase customers’ confidence in 
the maturity of the technology.

However, if these safety fears could be overcome 
by positive user experiences, it would lead to 
greater usage of personal autonomous vehicles. 
When asked whether a fully autonomous car 
would increase or decrease their car usage, 
all respondents globally gave an average 
weighted score of +4, rising to +26 for those 
who were positive about autonomous driving. 
Again, this was highest in India, with a score of 
+32 for all respondents and +42 for those open 
to autonomous driving. This increased usage 
would replace:

 - Existing personal non-autonomous vehicle (51%)

 - Public transport (44%)

 - Taxis (32%)

Overall, since 2015, the expectation of the 
percentage of public transport journeys 
potentially replaced with autonomous cars 
has grown, which would represent a switch 
from shared to personal mobility options.

Figure 10. Desire to use autonomous/semiautonomous cars

Source: Arthur D. Little

Source: Arthur D. Little

Figure 10. Desire to use autonomous/semiautonomous cars

Unfavorable 
attitude

Favorable 
attitude

16

29
23

48

28

-17 -17 -2

Do you, or would you, use cars that are fully or semiautonomous?
Weighted net favorability score (scale: -100 to 100)

16

Global China SEA India ME Europe US NEA

1 7