Super Users are present across all age cohorts, with higher density 
in younger generations

 24

SUPER USERS BY GENERATION, U.S., 2025, % ADULTS AGED 18+ / % ADULTS AGED 18+ BY GENERATION

Sources: Activate analysis, Activate 2025 Consumer Technology & Media Research Study (n = 4,026)

GEN Z 
(aged 18-28)

MILLENNIALS 
(aged 29-44)

GEN X 
(aged 45-60)

BABY 
BOOMERS 
(aged 61-79)

TOTAL ADULT 
POPULATION

ALL 
OTHER 
USERS

SUPER 
USERS

72%

28%
8%

66%

34%

53%

47%

73%

27%

92%

8%8%

SUPER USERS