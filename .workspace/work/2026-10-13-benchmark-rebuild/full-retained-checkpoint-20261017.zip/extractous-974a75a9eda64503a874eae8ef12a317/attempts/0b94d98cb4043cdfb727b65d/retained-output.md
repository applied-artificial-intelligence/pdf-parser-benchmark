34    

 

DO ADULTS HAVE THE SKILLS THEY NEED TO THRIVE IN A CHANGING WORLD? © OECD 2024 
  

Public policies can also create training and insurance policies to help workers at risk of losing their jobs 

(e.g. due to the introduction of regulations aimed at reducing emissions) in the transition to new 

occupations and encourage firms to invest in the training of all workers and improved working conditions 

to keep older workers in the workforce for longer. Public policies can also respond to ageing societies 

by reforming pension systems and promoting measures that boost birth rates. 

In democratic societies, the responses to these challenges will depend on citizens’ preferences, in 

particular those expressed in elections and through collective action. The context in which policy 

preferences are formed, and collective decisions taken, has significantly changed over the past decade, 

due in particular to the rise of digital media and the increasing socio-economic and cultural diversity of 

modern societies.  

The Internet has changed how people access news and information 

In the decade that separated the two cycles of the Survey of Adult Skills, OECD countries have achieved 

near-universal access to the Internet. On average, the share of adults using the Internet increased from 

76% in 2012 to 93% in 2023, with 87% of adults reporting using it daily (up from 61% in 2012; 

Figure 1.3). In 2022, 73% of adults reported accessing the Internet from a mobile device and 71% used 

it to read or download newspapers or news magazines (OECD, 2024[31]). 

Figure 1.3. Evolution of Internet usage, 2012-23 

Internet use in the past three months among 16-74 year-olds; OECD average; in per cent  

 
 

Note: Data on adults using the Internet in mobility are not available for 2023. 

Source: OECD (2024[31]), “ICT Access and Usage by Households and Individuals”, https://doi.org/10.1787/b9823565-en (accessed on 29 

May 2024). 

As a result, the role of traditional media (the printed press, radio and television) has declined, and adults 

increasingly use social media to get information and discuss and debate political opinions. In the 

European Union, 64% of adults reported using the Internet for reading online news sites or newspapers 

in 2023, and 18% used it for civic or political participation (Eurostat, 2024[32]). A recent survey by the 

Pew Research Center found that about half of adults in the United States got news from social media 

“sometimes” or “often” in 2022 (Pew Research Center, 2023[33]). 

The rapid diffusion and circulation of information is not without risks. There is a concern that the increase 

in the sheer amount of information available has been accompanied by a decrease in the quality 

(OECD, 2023[34]). Internet platforms and social media also make it easier to spread false and misleading 

information. Some actors may do so deliberately to distort public debates and fuel polarisation. At times 

this may form part of a hybrid warfare tactic, to erode the social fabric of open societies and weaken 

Adults using the Internet Adults using the Internet daily Adults using the Internet in mobility

2012 2013 201 201 201 201 2018 2019 2020 2021 2022 2023

100

90

80

 0

 0

 0

 0

30

20

10

0

 

https://doi.org/10.1787/b9823565-en