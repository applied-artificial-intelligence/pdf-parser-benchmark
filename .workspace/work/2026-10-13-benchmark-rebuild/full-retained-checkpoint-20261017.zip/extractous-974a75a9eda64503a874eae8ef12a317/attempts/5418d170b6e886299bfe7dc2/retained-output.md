10 Swiss Re sigma No 1/2021

Insuring subsidence: the French example
Subsidence risk has long been on the policy agenda in France, more so than in other 
markets. A national natural catastrophe insurance programme – CatNat – has 
covered property losses caused by subsidence since 1989. From 2016, inflation-
corrected insured losses from subsidence have exceeded EUR 550 million each year 
(see Figure 6), with the average annual loss standing at EUR 810 million.14 That 
corresponds to about 45% of the annual CatNat premiums collected, making 
subsidence the costliest natural hazard in France.15 Compared with an average 
annual loss of EUR 310 million in 2000–2015, the sudden and persistent yearly 
explosion in claims post-2016 is puzzling.

 

A Swiss Re study in 2011 suggested that climate change would lead to more 
droughts and increasing subsidence losses in France. Considering the dry years of 
2017–2019, it seems this prediction has been confirmed.16 That said, we would 
expect climate change influence to appear in a gradual upward trend of annual 
losses rather than a sudden, step-like increase. The loss pattern post-2016 suggests 
additional factors at play. 

One of the drivers may be the French insurance scheme itself, a key feature of which 
is that claimants are compensated for subsidence losses only if their municipality has 
been awarded a so-called CatNat declaration.17 The mayor of each municipality 
must first request such a declaration, the grant of which is dependent on whether 
the region has experienced what is determined to be a drought, and if specific 
geological prerequisites are met. In recent years, there has been an increase in the 
number of municipalities requesting the declaration. In 2018 and 2019, of all 
requests, 23% came from first-time applicants (see Figure 7). This cannot be 
explained by an increase in drought conditions alone.18 It may also be due to 
increasing awareness of the possibility to receive compensation for subsidence 
losses. 

We believe awareness of the opportunity to claim for subsidence losses will likely 
continue to rise. Of all municipalities, 62% have yet to request a CatNat declaration

14 Les catastrophes naturelles en France, Bilan 1982–2019, 2020, Caisse Centrale de Réassurance
15 In 2018, EUR 1 649 million of CatNat premiums were collected in France, most as cover for flood, 

subsidence, and earthquake risk. L’assurance des catastrophes naturelles en 2018, FFA, 2018.
16 The hidden risks of climate change: An increase in property damage from soil subsidence in Europe, 

Swiss Re, 2011.
17 Based on pre-defined criteria, the French administration provides CatNat declarations to municipalities 

that have been affected by a natural disaster.
18 “arrêtés de catastrophe naturelle”, CCR, 2020. 

France has had a nationwide 
insurance scheme for subsidence 
since 1989.

Figure 6  
Annual insured losses from  
subsidence in France, EUR million

 Source: Les catastrophes naturelles en France, Bilan 1982–2019, Caisse Centrale de Réassurance, 2020 

0

500

1 000

1 500

2 000

Errorbar

CCR

mean loss 2016 - 19

mean loss 2000 - 15

2019201720152013201120092007200520032001

CCR 2000–2015 2016–2019Mean loss:Error range

Climate change will likely exacerbate 
soil subsidence…

…but recent spikes in insured losses 
are likely due to growing awareness of 
the nationwide scheme.

If climate conditions remain dry, 
claims will likely continue to rise.

Exploring the secondary perils universe

https://catastrophes-naturelles.ccr.fr/les-arretes