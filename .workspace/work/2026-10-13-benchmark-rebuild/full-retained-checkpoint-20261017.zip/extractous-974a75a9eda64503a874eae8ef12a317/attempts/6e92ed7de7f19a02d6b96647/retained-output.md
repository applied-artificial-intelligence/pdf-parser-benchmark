Strategic report

41% 35% 24%

Wealth and Personal Banking Commercial Banking Global Banking and Markets

Customers Employees Investors Communities Regulators and 
governments

Suppliers

Our global 
businesses

Wealth and Personal  
Banking (’WPB’) 
We help millions of our customers 
look after their day-to-day 
finances and manage, protect and 
grow their wealth.

Revenue by  
global business1

Commercial Banking (‘CMB’) 
Our global reach and expertise 
help domestic and international 
businesses around the world 
unlock their potential. 

Global Banking and  
Markets (’GBM’) 
We provide a comprehensive 
range of financial services 
and products to corporates, 
governments and institutions. 

Building strong relationships with our stakeholders helps enable us to deliver 
our strategy in line with our long-term values, and operate the business  
in a sustainable way. 

Our stakeholders are the people 
who work for us, bank with us, 
own us, regulate us, and live 
in the societies we serve and 
the planet we all inhabit. These 
human connections are complex 
and overlap.

Many of our employees are 
customers and shareholders, 
while our business customers are 
often suppliers. We aim to serve, 
creating value for our customers 
and shareholders. 

Our size and global reach mean 
our actions can have a significant 
impact. We are committed to 
doing business responsibly, and 
thinking for the long term. This is 
key to delivering our strategy.

Our stakeholders

We serve our customers through three global businesses.

1  Calculation is based on revenue of our global businesses excluding Corporate Centre. Corporate Centre had negative 
revenue of $199m in 2023.

For further details of how we are engaging with our stakeholders, see page 15.

For further details, see page 30. For further details, see page 32. For further details, see page 34.

On pages 30 to 36 we provide 
an overview of our performance 
in 2023 for each of our global 
businesses, as well as our 
Corporate Centre.

In each of our global businesses, 
we focus on delivering growth  
in areas where we have  
distinctive capabilities and have 
significant opportunities.

Each of the chief executive 
officers of our global businesses 
reports to our Group Chief 
Executive, who in turn reports to 
the Board of HSBC Holdings plc.

HSBC Holdings plc Annual Report and Accounts 2023 5

Who we are