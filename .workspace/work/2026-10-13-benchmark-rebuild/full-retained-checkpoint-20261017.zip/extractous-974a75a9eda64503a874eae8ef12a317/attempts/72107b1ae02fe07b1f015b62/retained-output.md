112024 STATE OF THE U.S. SEMICONDUCTOR INDUSTRY

THE SEMICONDUCTOR 
WORKFORCE
Having a competitive domestic workforce and resilient 
manufacturing capabilities are critical to America’s 
lead in semiconductors. In addition, a strong domestic 
semiconductor industry is essential to the U.S. economy.

The semiconductor industry has a considerable economic footprint in the United 

States, with roughly 338,000 people working in the industry, including roles in 

chip design, electronic design automation (EDA), semiconductor manufacturing, 

and equipment manufacturing. Additionally, semiconductors enable over 300 

downstream economic sectors accounting for over 26 million U.S. workers.

SEMICONDUCTOR WORKFORCE BY FIELD, 2023

0 50,000 100,000 150,000 200,000

Machinery Manufacturing
29,000

Device Manufacturing
200,000

Design
100,000

EDA
9,000

338,000
Total Jobs

250,000 300,000 350,000

Employment

Source: CES, QCEW, Oxford Economics