2024 UN E-GovErNmENt SUrvEy

54

C
h

ap
ter 2

2.5.4 OSI content provision subindex 

In most countries (86 per cent), the Government provides information and services in multiple 
languages, which strengthens inclusiveness and facilitates access to information and online services 
in multilingual societies (see figure 2.12). However, fewer than half (47 per cent) proactively share 
web statistics on usage such as the number of new visits, total page views, or average time spent on 
site on their national portals.  

Figure 2.11 Percentage of countries with legislative frameworks relevant to e-government development,  
 2024

EDGI 2024  levels
Very high EGDI
High EGDI
Middle EGDI
Low EGDI

Very high EGDI
High EGDI
Middle EGDI
Low EGDI

Cloud, 44%

AI, 42%

E-participation, 51%

Misinformation, disinformation
or fake news, 47% 

Open government data, 63%
Digital ID, 78% E-government or digital government, 81%

Privacy statement on government website, 83%

Freedom of or access to information act, 76%

National data strategy or policy, 81%

Personal data protection, 83%

Cybersecurity, 82%

Availability of legislation, policy or strategy documents on: 
193 UN Member States

193 UN Member States

Americas

Africa

Asia

Europe

Oceania

15%

22%

26%

28%

48%

85%

78%

74%

72%

52%

Cloud

AI

E-participation

Misinformation,
disinformation or fake news

Open government data

Africa (54 countries)

24%

24%

33%

28%

35%

Americas (35 countries) 

48%

39%

57%

57%

59%

52%

61%

43%

43%

41%

Asia (47 countries) 

57%

59%

61%

52%

74%

43%

41%

39%

48%

26%

Europe (43 countries) 

11%

7%

6%

4%

7%

89%

93%

94%

96%

93%

Oceania (14 countries)

76%

76%

67%

72%

65%

15%

22%

26%

28%

48%

Cloud

AI

E-participation

Misinformation, disinformation or
fake news

Open government data

Africa (54 countries)

24%

24%

33%

28%

35%

Americas (35 
countries) 

48%

39%

57%

57%

59%

Asia (47 countries) 

57%

59%

61%

52%

74%

Europe (43 
countries) 

11%

7%

6%

4%

7%

Oceania (14 
countries)

Source: 2024 United Nations E-Government Survey.

Figure 2.12 Content provision on national portals, 2024      
(Percentage of countries, by region)

EDGI 2024  levels
Very high EGDI
High EGDI
Middle EGDI
Low EGDI

Very high EGDI
High EGDI
Middle EGDI
Low EGDI

193 UN Member States

Americas

Africa

Asia

Europe

Oceania

Very high EGDI
High EGDI
Middle EGDI
Low EGDI

86%

47%

89%

78%

Availability of content in more than
one of�cial language of the country

Availability of web statistics on usage

Announcements of forthcoming procurement or
bidding processes published on the portal

Information provided about the results of
government procurement or bidding online

193 UN Member States

100%

70%

94%

83%

Asia

83%

40%

89%

80%

Americas

100%

51%

95%

98%

Europe

50%

36%

93%

57%

Oceania

74%

30%

78%

61%

Availability of content in more than
one of�cial language of the country

Availability of web statistics on usage

Announcements of forthcoming procurement or
bidding processes published on the portal

Information provided about the results of
government procurement or bidding online

Africa

Source: 2024 United Nations E-Government Survey.