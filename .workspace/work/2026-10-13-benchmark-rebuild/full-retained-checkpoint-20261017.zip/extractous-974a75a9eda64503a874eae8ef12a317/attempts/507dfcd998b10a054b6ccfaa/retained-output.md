Certifications
JBML’s plants maintain internationally recognized certifi-
cations for quality, environment, health and safety:
• IATF 16949:2016 & ISO 9001:2015 – 

Quality Management Systems

• ISO 14001:2015 – 
Environmental Management Systems

• ISO 45001:2018 – 
Occupational Health & Safety Management Systems

2,290Cr
TURNOVER 7 

STATE-OF-THE-ART 
MANUFACTURING 

FACILITIES

4,319
WORKFORCE 

SHEET METAL  
COMPONENTS &  
ASSEMBLIES

WELDED 
ASSEMBLIES

TOOLS & 
DIES

EXHAUST 
SYSTEMS

FUEL 
FILLERS 

AXLES

CHASSIS & 
SUSPENSION SYSTEMS

TUBULAR 
COMPONENTS 

1180 MPA BIW 
ASSEMBLIES

ENGINE  
MOUNTING

CROSS-CAR
BEAM

Product Categories:

Strategic Collaborations
JBML’s partnerships with global leaders drive trans-
formative innovation and enable us to anticipate 
and  align with the evolving market trends and sen-
timents. Together, we are shaping a smarter, more 
efficient and more sustainable future for mobility.

At JBML, we are committed to setting new benchmarks in automotive engineering and manufacturing. Every 
innovation and advancement is a step towards a future where mobility is intelligent, sustainable and seam-
lessly integrated with the needs of SOCIETY.

2024-25
ANNUAL REPORTJAY BHARAT MARUTI LIMITED

03-46
CORPORATE OVERVIEW

47-146
STATUTORY REPORTS

147-274
FINANCIAL STATEMENTS

15 16