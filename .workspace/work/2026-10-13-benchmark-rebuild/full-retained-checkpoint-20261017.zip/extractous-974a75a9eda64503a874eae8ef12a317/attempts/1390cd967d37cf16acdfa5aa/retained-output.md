 157 

 

DO ADULTS HAVE THE SKILLS THEY NEED TO THRIVE IN A CHANGING WORLD? © OECD 2024 
  

Figure 4.4. Median wages, by numeracy proficiency level 

PPP-adjusted 2022 USD 

 

Note: Employed adults aged 25-65 not in formal education; does not include adults who were only administered the doorstep interview due to a 

language barrier (see Box 1.1 in Chapter 1 and Box 4.1). Includes bonuses and earnings by self-employed individuals. *Caution is required in 

interpreting results due to the high share of respondents with unusual response patterns. See the Note for Poland in the Reader’s Guide. 

Countries and economies are ranked in descending order of median gross hourly earnings for Level 4 and above. 

Source: Table A.4.7 (N) in Annex A. 

Numeracy skills and years of education continue to have statistically significant associations with wages 

independently of one another, and the magnitude of these effects varies considerably across participating 

countries and economies (Figure 4.5). The results presented here are adjusted for socio-demographic 

characteristics. On average, an increase of one standard deviation in an individual’s years of education is 

associated with a 16% increase in wages. This is broadly in line with existing international evidence (Clark 

and Abildgaard Nielsen, 2024[38]; Patrinos, 2023[39]). An increase of one standard deviation in numeracy 

proficiency is associated with a 9% increase in wages.6 

It is important to note that skills are associated with workers’ wages even after accounting for years of 

education. For 27 out of 31 participating countries and economies, the relationship between numeracy and 

wages is statistically significant, and in France the estimated effect for numeracy proficiency in fact exceeds 

that of years of education. The greatest differences between the effects of numeracy and years of 

education are found in Singapore (22 percentage points). Numeracy proficiency has the largest estimated 

relationship with wages in Chile, England (United Kingdom) and Germany (over 14%), and the smallest 

(statistically significant) relationship in the Flemish Region (Belgium), Italy and Poland (under 6%). For 

education, the largest estimated relationships are in Chile and Singapore (30% or more) and the smallest 

are in France and Japan (10% or less). 

 e el 1 and below  e el   and abo e Total

S
w
it 

er
la
n
d

 
en

m
a
rk

U
ni
te
d 
S
ta
te
s

 
o
rw

ay

G
e
rm

an
y

 
e
th
e
rl
an

ds

Ir
el
an

d

F
le
m
is
h 
R
eg

io
n 
( 

E
 

A
us

tr
ia

S
in
g
ap

or
e

C
an

ad
a

E
ng

la
n
d 
(U

 
 

F
in
la
n
d

 
e
w
  

ea
la
n
d

Is
ra
el

 
E
C
 
 a
ve

ra
g
e

S
w
e
de

n

F
ra
n
ce

It
a
ly

 
or
e
a

S
p
ai
n

 i
th
ua

n
ia

E
st
on

ia

 a
t 
ia

H
u
ng

ar
y

 a
pa

n

C
h
ile

P
o
rt
ug

al

C
 e

ch
ia

C
ro
at
ia

P
ol
a
nd

 

S
lo
 a

k 
R
ep

ub
lic

 0

 0

 0

30

20

10

0

Gross hourly earnings