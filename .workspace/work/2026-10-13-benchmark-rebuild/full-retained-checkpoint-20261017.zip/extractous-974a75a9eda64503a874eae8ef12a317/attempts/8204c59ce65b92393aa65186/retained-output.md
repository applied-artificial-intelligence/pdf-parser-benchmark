By Gross Revenue
(FY 2023/24)

S$118.7M

Ngee Ann City Property
Singapore

By Gross Revenue
(FY 2023/24)

S$40.6M

Myer Centre Adelaide
Adelaide

Our Geographical 
Reach

Singapore

Starhill Global 
REIT’s portfolio 
comprises nine 
mid- to high-end 
properties in six 
Asia-Pacific cities.

2.2M SQ FT
Retail and  
Office Space

9
Number of 
Properties

S$2,762.2M(1)

Investment Properties

SGREIT’s portfolio is characterised by its master and anchor 
leases which make up about 53.1% of gross rent(3).

Australia

619,880 SQ FT 921,912 SQ FT

By Asset Value
(As at 30 June 2024)

S$1,965.0M

Wisma Atria Property
Singapore

Retail

76.7%

Retail

79.3%

Office

23.3%

Office

20.7%

By Asset Value
(As at 30 June 2024)

S$346.4M

David Jones Building & Plaza Arcade
Perth

Retail

91.2%

Retail

100%

Office

8.8%

6
Asia-Pacific Cities

10 STARHILL GLOBAL REIT