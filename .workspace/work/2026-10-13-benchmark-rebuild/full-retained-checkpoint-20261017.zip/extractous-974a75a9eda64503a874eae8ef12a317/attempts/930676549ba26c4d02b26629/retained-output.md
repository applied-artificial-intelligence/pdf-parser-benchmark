 117 

 

HEALTH AT A GLANCE: EUROPE 2024 © OECD/EUROPEAN UNION 2024 
  

Figure 4.1. Tobacco smoking rates among 15-year-olds, 2014 and 2022 

 
Note: The EU average is unweighted. 1. Data for Belgium refer to the unweighted average of Flanders and Wallonia/Brussels. 
Source: HBSC Data Browser, https://data-browser.hbsc.org/. 

StatLink 2 https://stat.link/431xgk 

Figure 4.2. Cannabis smoking rates among 15-year-olds, 2014 and 2022 

 
Note: The EU average is unweighted. 1. Data for Belgium refer to the unweighted average of Flanders and Wallonia/Brussels. 
the unweighted average of Flanders and Wallonia/Brussels. 
Source: HBSC Data Browser, https://data-browser.hbsc.org/. 

StatLink 2 https://stat.link/yq9al0 

7
9

10
11

12 12 12 12 13 13
14 14

15 15
17 17 17

18 18 19 19 20

23 23

26 27

29

32

4

9

12

12
13

15

18

20

0

5

10

15

20

25

30

35

40

2014 2022

% of 15-year-olds who reported smoking a cigarette at least once in the last 30 days

3

4
4 4 4 4 5

5
5

6 6
6

7

7

7

7

7 8

8 8

8

9 9 9

10 12

12

13

2

3
4

5
5

10

0

2

4

6

8

10

12

14

16

2014 2022

% of 15-year-olds who reported using cannabis at least once in the last 30 days

https://data-browser.hbsc.org/
https://stat.link/431xgk
https://data-browser.hbsc.org/
https://stat.link/yq9al0