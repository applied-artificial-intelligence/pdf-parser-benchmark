The BEAT | June 2025

16.6

24.2
19.8

15.2 13.5
16.3

18.8 21.7 17.3 17.8

24.0

45.3

22.6

77.2

17.7 19.9

26.4
30.4

22.1 21.3

10.0

16.9 16.4

-263.8
*Not to scale

9.3
13.8 13.6 14.7

12.2
14.7

18.9

27.9

22.6

14.5
16.7 16.0

23.7 27.1

20.1
18.1

(30.0)

(10.0)

10.0

30.0

50.0

70.0

Valuation Analysis

EQUITIES

Source: FactSet as of 5/31/25. NTM P/E is market price per share divided by expected earnings per share over the next twelve months. The Real Estate sector is excluded from this 10-
year chart since the sector was created on August 31, 2016. Data provided is for informational use only. See end of report for important additional information. Forecasts/estimates are 
based on current market conditions, subject to change, and may not necessarily come to pass.

S&P 500 Sectors: Current NTM P/E vs. 10-Year High, Low, Average

35

High

Current
Average

Low

S&P 500

Current P/E 

Communication 

Services

Consumer 

Discretionary

Consumer 

Staples Energy Financials Health Care Industrials

Information 

Technology Materials Utilities

High Date 8/20 6/20 5/25 4/16 11/24 8/24 8/20 6/24 7/20 3/22

Low Date 5/18 2/16 4/18 7/20 3/20 3/20 12/18 12/18 9/15 6/15