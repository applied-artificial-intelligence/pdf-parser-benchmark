Insured losses on trend sigma No 1/2025 Swiss Re Institute 7

Adaptation measures like strengthening building codes or flood protection infrastructure 
help reduce exposures, but often such actions are insufficient to compensate for rising 
losses from value accumulation. A case in point is that even with major advancements in 
building codes, in 2022 Hurricane Ian still inflicted insured losses of USD 64 billion (in 
2024 prices).5 The main driver of these losses was the 620% growth in population in the 
landfall area since 1975.6  Losses can be even more severe when the establishment of 
loss reduction measures lags behind economic growth, as seen for instance in the case 
of insufficient drainage infrastructure in the UAE and also in southern Spain during last 
year’s floodings there. New technologies can also introduce adverse developments to 
vulnerability. For example, the growing number of solar power installations on roofs, 
often the most exposed parts of a building, has been one of the driving forces behind the 
steep rise in SCS losses in recent years.7

2024 in more detail

The biggest single loss events of 2024 were Hurricanes Helene and Milton in the US. 
Coming in quick succession in September and October, they triggered combined insured 
losses of USD 44 billion. Helene unleashed huge flooding in mountainous areas across 
Appalachia, inflicting much damage in areas where flood insurance is not mandatory. 
Combined economic losses from the two hurricanes were USD 113 billion, indicating 
economic losses of more than double the insured losses. Less than 2% of households in 
Georgia are currently covered by the National Flood Insurance Program (NFIP), and less 
than 1% in the hardest-hit areas like Buncombe County, North Carolina, including 
Asheville, the biggest city in the region. Coverage for North Carolina overall is around 
3%, and for South Carolina around 9%.8 Hurricane Milton, though a relatively small 
tropical cyclone (TC) loss event, coming soon after Helene is a reminder of the potential 
for large losses if two hurricanes strike a city like Tampa or Miami in quick succession.

Once again SCS were main drivers of last year’s losses, with the overall cost to the global 
insurance industry mounting to USD 53 billion (see Figure 3). It was the second year 
running that SCS-related losses were above USD 50 billion. It was also the second 
costliest year for this peril after 2023, when insured losses were USD 70 billion (in 2024 
prices). The US continues to see the largest SCS-related losses, but these are rising in 
other countries also. For instance, with insured losses of USD 2.3 billion, the hailstorm in 
Calgary last year was the costliest ever seen in Canada. SCS-triggered insured losses are 

5 Ian revisited: Disentangling the drivers of US hurricane losses, Swiss Re, 25 September 2023 bid.
6 sigma 1/2023: Natural catastrophes and inflation; a perfect storm, Swiss Re Institute. 
7 sigma 1/2024, Swiss Re Institute, op. cit.
8 See Flood Insurance Data and Analytics, FEMA.

Adaptation measures can help temper 
losses.

Hurricane Helene led to large-scale 
inundation and losses in areas where flood 
insurance is not mandatory.

Figure 3 
Global insured losses from natural catastrophes  
in 2024 and previous year averages  
(USD bn, 2024 prices)

 Source: Swiss Re Institute

0 10 20 30 40 50 60 70 80 90 100 110 120 130 140

2024

5-year average (2019-2023)

10-year average (2014-2023)

15-year average (2009-2023)

30-year average (1994-2023)

Earthquakes European winter storms Tropical cyclones Wildfires Severe convective storms

Floods Other secondary perils

SCS continued their recent trend of causing 
elevated losses.

https://www.swissre.com/risk-knowledge/mitigating-climate-risk/hurricane-ian-revisited.html
https://www.swissre.com/dam/jcr:1d793484-9b96-4e54-91c3-09f8fc841bde/2023-05-sigma-01-english.pdf
https://www.swissre.com/institute/research/sigma-research/sigma-2024-01.html
https://nfipservices.floodsmart.gov/reports-flood-insurance-data