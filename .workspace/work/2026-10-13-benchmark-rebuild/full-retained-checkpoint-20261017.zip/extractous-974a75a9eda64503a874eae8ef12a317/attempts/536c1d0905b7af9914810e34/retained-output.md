Notes:
(1) Based on committed leases as at the reporting date.
(2) Based on gross rent as at 30 June 2024 and excludes gross turnover rent.
(3) Includes the Toshin master lease.

Top 5 Tenants based on gross rent(2)

1. Toshin Development Singapore  
Pte. Ltd.

2. The Great Room NA Pte. Ltd.

3. Cortina Holdings Limited

4. Beauty One International

5. DBS Bank Ltd 

Retail
76.7%

Office
23.3%

Retail & Office Mix
By Gross Revenue 
(FY 2023/24)

 Retail 
 Real Estate & Property Services
 Banking & Financial Services
 Beauty/Health 
 Consultancy/Services
 Others 
 Petroleum Related 
 Medical 
 Information Technology 
 Trading

 Toshin (Master Tenant)
 Health & Beauty
 Services
 General Trade

35.9%
19.1%
14.5%

9.9%
7.1%
4.7%
3.4%
3.0%
1.7%
0.7%

86.5%
10.3%

2.7%
0.5%

Office Trade Mix
By Gross Rental Contribution 
(As at 30 June 2024)

Retail Trade Mix
By Gross Rental Contribution 
(As at 30 June 2024)

Tenure 

69 YRS
Leasehold estate,  
expiring on 31 March 2072
(Remaining tenure of 48 years)

Number Of Tenants
(As at 30 June 2024)

61
(including a master tenant)

Purchase Price

S$640.0M
Market Valuation
(As at 30 June 2024)

S$1,148.0M

Retail
255,021 sq ft

Office
139,558 sq ft

Total Net Lettable Area
(As at 30 June 2024)

394,579 SQ FT

Retail
100.0%

Retail
100.0%

Office
98.9%

Office
100.0%

Occupancy Rate(1)

(As at 30 June 2024)

(As at 30 June 2023)

Lease Expiry Profile by gross rent(1)

(%)

FY
24/25

2.5
30.5

86.8(3)1.1
21.2

6.4
25.1

3.2
4.6 18.6

FY
25/26

FY
26/27

FY
27/28

Beyond
FY 27/28

  Retail        Office

0

20

40

60

80

100

35ANNUAL REPORT FY 2023/24