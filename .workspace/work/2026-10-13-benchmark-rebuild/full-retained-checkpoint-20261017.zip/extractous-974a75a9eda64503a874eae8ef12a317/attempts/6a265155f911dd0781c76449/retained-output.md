57European Innovation Scoreboard 2025

(15%-points), and Intellectual assets (15%-points), still favour Moderate Innovators. The 
largest gaps are seen in Innovators (73%-points), and Sales and employment impacts 
(69%-points), again in favour of Moderate Innovators. 

Figure 22: Innovation performance of the innovation groups per dimension

Note: Average scores for each performance group are defined as the unweighted average of the relative-to-EU 

scores of the Member States within that group. As these unweighted averages do not consider differences in 

country size, results are not directly comparable. For this reason, average scores for the performance groups 

have been adjusted such that the unweighted average of the four groups for each dimension equals 100.

54

141

85
119

42

151

83
124

79

131

89
102

45

148

77
130

50

144

84
122

70

140

85
105

38

127

111
123

44

145

85
126

72

132

87
109

45

122

114
119

87

122

86
105

57

123

90
130Resource and labour productivity

Trade impacts

Sales and employment impacts

Intellectual assets

Linkages

Innovators

Investments in information technologies

Firm investments

Finance and support

Digitalisation

Attractive research systems

Human resources

0 20 40 60 80 100 120 140 160

Adjusted score per dimension in 2025

Emerging innovators Moderate innovators Strong innovators Innovation leaders