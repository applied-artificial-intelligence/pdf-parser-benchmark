250    

OECD EMPLOYMENT OUTLOOK 2024 © OECD 2024 
  

Overall, household burdens depend strongly on the specific patterns of carbon pricing across sectors. 

There is a huge spread of prices in practice, both in any given year, and when considering carbon price 

changes over time (OECD, 2023[8]). This chapter’s mapping from sectors to consumption goods captures 

this heterogeneity. By contrast, reform assessments based on simple “stylised” carbon pricing scenarios, 

such as a uniform rate applying to all emissions, are likely to miss key aspects of the distributional impacts 

of real-world policy trajectories. Moreover, as illustrated in some of the results, concurrent or sequential 

carbon pricing reforms in different policy areas can produce complex distributional effects, amplifying, or 

offsetting each other in terms of their impact on households. 

Figure 5.9. Carbon pricing measures during the past decade: Burdens for households 

Percentage of disposable income, 2012-21 

 

Note: Change in the cost of household-specific consumption baskets, as a share of disposable household incomes, taking consumption baskets 

(2015 in EU countries, 2016 in Mexico and 2019 in Türkiye) and the fuel mix and carbon intensity of consumption (using the 2016 vintage of the 

environmentally extended World Input-Output Database – WIOD) as fixed. The changes in carbon pricing burdens are thus only driven by 

changes in carbon pricing and neither by changes in consumption behaviour nor by changes in the fuel mix and carbon intensity of consumption 

(see Section 5.2 and Box 5.3 for more details on this assumption). Effective carbon rates for 2012 and 2021 are converted to real terms to match 

the corresponding household budget survey vintage. Averages by income decile (equivalised disposable household income). For the average 

household, burdens from carbon pricing reforms were as follows. France: +0.53% of total household income, Germany: +0.50%, Mexico: 

+1.03%, Poland: +2.34%, Türkiye: +0.09%. ETS: Emission Trading Systems. Changes are computed against the status quo, and do not account 

for the distributional impacts of inaction. 

Source: OECD calculations using OECD Effective Carbon Rates data, IEA emissions factors for different fuels, household budget surveys (2015 

for EU countries, 2016 for Mexico, 2019 for Türkiye) and World Input-Output Database (WIOD). 

StatLink 2 https://stat.link/cx409a 

The welfare impact of carbon price changes depends not only on the carbon price, but also on the growth of 

labour earnings, which may inform the rate of growth of individual and, hence, household labour income.27 

Indeed, if carbon prices increase at a faster (resp. lower) rate than earnings, then purchasing power 

(conditional on interactions with other policies such as taxation and benefits) is likely to fall (resp. increase). 

This can also help inform the impact of carbon prices on the real value of wages. While combining earnings 

changes and carbon price changes at the individual level is beyond the scope of the analysis conducted in 

this chapter, Box 5.4 presents some results when comparing the distribution of carbon price changes relative 

to the mean sectoral labour earnings growth (as proxied by labour cost growth) over the 2012 to 2021 period. 

-1

0

1

2

3

4

5

1 2 3 4 5 6 7 8 9 10 1 2 3 4 5 6 7 8 9 10 1 2 3 4 5 6 7 8 9 10 1 2 3 4 5 6 7 8 9 10 1 2 3 4 5 6 7 8 9 10

 France  Germany  Mexico  Poland  Türkiye

%

Income decile

ETS Carbon tax Fuel excise taxes Total

https://stat.link/cx409a