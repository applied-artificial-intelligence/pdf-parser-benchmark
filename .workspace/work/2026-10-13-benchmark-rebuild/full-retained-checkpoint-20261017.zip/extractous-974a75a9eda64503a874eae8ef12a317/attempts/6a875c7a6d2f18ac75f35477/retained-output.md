A R T H U R  D .  L I T T L E

In fact, the most often experienced new mobility 
service for urban respondents is ride hailing, 
tried by 50%-75% of people in every region or 
country except Europe and Northeast Asia. 
Globally, those in the 30-44 age range are the 
heaviest experimenters, with about 45% trying 
ride, car, or two-wheeler sharing, compared to 
only about 5% of people over 60 who have tried 
most service types (see Figure 6).

NEW MOBILITY SERVICES 
FOCUS ON RIDE HAILING

There are significant regional differences in 
the use of new mobility services, influenced 
by car ownership rates and access to reliable, 
comprehensive public transport. Urban dwellers 
in India, Southeast Asia, and the Middle East 
make an average of 14 to 17 journeys each 
month using new mobility services, compared 
to residents of Europe, the US, China, and 
Northeast Asia, who make dramatically fewer, 
between 11 and 12 (see Figure 7).

Figure 6. Types of new mobility services tried by urban dwellers, by age

Source: Arthur D. Little

Figure 7. Average monthly usage of new mobility services

Source: Arthur D. Little

Source: Arthur D. Little

Figure 6. Types of new mobility services tried by urban 
dwellers, by age

Sharing of 
a personal 

transportation 
device

Public 
transportation

Which types of new mobility services have you used?
Only urban respondents (in %)

0

10

20

30

40

50

<30 years 45-60 years30-44 years >60 years

Local underground/ 
metro, tram, bus service

Local train service

Ride hailing

2-wheeler sharing

Ride sharing

Car sharing

Source: Arthur D. Little

Figure 7. Average monthly usage of new mobility services

How many times do you use new mobility services in a normal month?
Only urban respondents

2.9

2.4

3.6
3.9

3.3
3.0

3.3

2.2

3.5
3.8

4.4 4.5

3.5
2.9

3.93.7
3.3

2.3

2.9
2.5

3.6
3.9

3.6

4.5
4.1

3.1

2.5

3.8

Global China SEA India ME Europe US NEA

2.7
2.3

3.6

2.3

Car sharing Ride hailing Ride sharing 2-wheeler sharing

1 3