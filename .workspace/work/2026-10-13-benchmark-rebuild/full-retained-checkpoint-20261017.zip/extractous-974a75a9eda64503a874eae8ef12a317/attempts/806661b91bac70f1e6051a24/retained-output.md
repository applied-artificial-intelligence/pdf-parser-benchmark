Executive Summary
Figure 9. Some countries face the double burden of low incomesand very high inequality

Top 10/bottom 50 
income gaps 
across the world, 2025

09 – 19
19 – 28
28 – 34
34 – 41
41 – 103

Top 10/bottom 50 income gaps across the world, 2025

Interpretation. This map shows the ratio between the average income of the top 10% and the average income of
the bottom 50% of the population in each country in 2025. Income is measured after pension and unemployment
benefits are received by individuals, but before other taxes they pay and transfers they receive. Sources and
series: wir2026.wid.world/methodology and Chancel and Piketty (2021).

Figure 10. Inequality can be reduced with progressive taxationand transfers

0

10

20

30

40

50

1980 1985 1990 1995 2000 2005 2010 2015 2020

R
ed

is
tr

ib
ut

io
n:

 r
ed

uc
tio

n 
in

 
 to

p 
10

%
 to

 b
ot

to
m

 5
0%

  i
nc

om
e 

ra
tio

 
th

ro
ug

h 
ta

xe
s 

an
d 

tr
an

sf
er

s 
(%

)

East Asia

Europe

Latin America

MENA

North America & Oceania

Russia & Central Asia

South & Southeast Asia

Sub−Saharan Africa

Intepretation. The figure shows the impact of taxes and transfers on inequality across regions, measured by the
reduction in the top 10% to bottom 50% income ratio (a positive value indicates inequality reduction). Tax and
transfer systems reduce inequality in all regions, but the extent of redistribution varies greatly. Sources and
series: wir2026.wid.world/methodology and Fisher−Post and Gethin (2025).

Redistribution, 1980−2025:  reduction in top 10/bottom 50 
income gaps through taxes and transfers

21