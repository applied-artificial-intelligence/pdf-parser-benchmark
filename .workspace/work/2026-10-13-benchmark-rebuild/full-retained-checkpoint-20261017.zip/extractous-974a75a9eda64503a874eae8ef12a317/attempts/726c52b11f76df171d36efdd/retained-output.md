84 European Innovation Scoreboard 2025

Figure 33: Innovation performance of the EU and its global competitors

Note: All performance scores are relative to that of the EU in 2018. Coloured bars show countries’ performance 

in 2025 while the vertical bars show performance in 2024. Due to limited data availability for global 

competitors, scores are calculated using a smaller set of indicators.

Compared to 2024, most global competitors have improved their innovation performance. 
Only Canada, the EU, and South Africa recorded a decline. South Korea shows the largest 
annual improvement (+6.3%-points), followed by China (+6.0%-points) and Australia 
(+3.8%-points). The gap between Australia and the United States is also narrowing. 

Over the longer term (Figure 34), all global competitors have improved their innovation 
performance between 2018 and 2025. Notably, the five countries that now outperform the 
EU have all recorded faster growth than the EU itself, thereby widening the performance 
gap. Among the six countries still lagging the EU, only Chile has increased its performance 
at a higher rate than the EU since 2018, with a gain of 15.5%-points.

I
I

I
I

I

I
I

I
I

I
I

IMexico

South Africa

Chile

India

Brazil

Japan

EU

Australia

United States

China

Canada

South Korea

0 20 40 60 80 100 120 140 160

Summary innovation index in 2025 (indexed to the EU in 2018)

Emerging innovators

Moderate innovators

Strong innovators

Innovation leaders

I Score in 2024