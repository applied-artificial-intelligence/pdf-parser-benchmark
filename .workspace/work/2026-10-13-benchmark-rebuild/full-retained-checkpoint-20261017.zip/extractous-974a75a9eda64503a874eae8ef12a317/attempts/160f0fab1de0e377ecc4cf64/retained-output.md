Employment and Social Developments in Europe 2024 

22 

and tightening monetary policy affected economic performance in 2023, with important consequences for 
households (see Section 4.1.). 
 

Chart 1.2 

Real GDP grew in most Member States in 2023 
Real GDP growth, EU, 2022 (dots) and 2023 (bars) (% change on previous year) 

    

Note: Ireland: modified domestic demand. 
2022: data provisional for Belgium, Cyprus, Germany, Greece, Spain, France, Croatia, Portugal and Romania. 
2023: data provisional for Belgium, Bulgaria, Cyprus, Germany, Greece, Spain, France, Croatia, Hungary, Luxembourg, the Netherlands, Portugal and Romania. 

Source: Eurostat [nama_10_gdp]. 

Click here to download chart. 

 
Inflation is projected to remain stable for the rest of 2024 and to decline further in 2025. Annual 
inflation in the EU is forecasted to average at 2.7% in 2024 and then to decline to 2.2% in 2025. Food and non-
energy industrial goods are the primary drivers behind this slowdown. (16). Yet, the expiration of policy measures 
introduced to address the energy crisis may continue to put pressure on the prices of consumer energy. Wage 
pressures remain elevated, with service prices having contributed little to disinflation. 
 

Chart 1.3 

Inflation decelerated in most Member States in 2023, but remained high despite decreasing prices of energy 
Left chart: All-items Harmonised Index of Consumer Prices (HICP), 2023; Right chart, Annual inflation rates for selected items, EU 

    

Source: Eurostat [prc_hicp_aind; prc_hicp_manr]. 

Click here to download chart. 

 
Almost all Member States’ economies are projected to grow in 2024, with an average growth at the 
EU-level of 1.0% (0.8% in the euro area). After recovering somewhat at the beginning of 2024 (+0.6% in Q1 
and +0.8% in Q2, compared to same quarter of the previous year), GDP growth is expected to reach 1.6% in 
2025 (1.4% in the euro area). The EU entered 2024 with a weaker economic outlook than initially expected. 
Nevertheless, the conditions remain in place for a gradual improvement in economic activity. Continued wage and 
employment growth are expected to sustain growth in households’ disposable income in 2024 and to continue in 
2025 (albeit slightly slower), which would also boost consumption. The contribution of investment to real GDP 
growth is expected to increase more gradually and the contribution of EU's net external demand is predicted to 
become neutral. (17) Overall, domestic risks related to growth and inflation are broadly balanced in the EU. 

Heightened geopolitical tensions and global policy uncertainty expose the EU economic outlook to 
several risks. Russia's ongoing war of aggression against Ukraine and the Middle East conflict could add to 
upward pressure on prices and stress on supply chains, jeopardising production and trade. Energy commodities 
are also vulnerable to these downward risks. Persistence of inflation in the US may delay its interest rate cuts, 
resulting in tighter global financial conditions. In addition, uncertainties linked to China and US economic activity 
developments could weigh on the EU economy. Finally, climate change risks continue to be of primary concern, 

 
(16) (European Commission, 2024a) 
(17) (European Commission, 2024a) 

-8

-6

-4

-2

0

2

4

6

8

10

IE EE FI LU H
U AT LV LT D
E SE CZ N
L PL EU EA FR IT BE SK SI BG EL RO PT D
K ES CY H
R

M
T

2023
Series2

0

2

4

6

8

10

12

14

16

18

H
U CZ SK PL RO EE LV LT BG H
R AT SI EU D
E SE IT FR M
T EA PT IE FI EL N
L CY ES D
K LU BE

%

Average 2023 Dec. 2023 Jul-24

-20

-10

0

10

20

30

40

50

20
20

-0
1

20
20

-0
4

20
20

-0
7

20
20

-1
0

20
21

-0
1

20
21

-0
4

20
21

-0
7

20
21

-1
0

20
22

-0
1

20
22

-0
4

20
22

-0
7

20
22

-1
0

20
23

-0
1

20
23

-0
4

20
23

-0
7

20
23

-1
0

20
24

-0
1

20
24

-0
4

20
24

-0
7

An
nu

al
 in

fla
tio

n 
ra

te
 (%

)

All-items HICP

Food, alcohol, and tobacco

Non-energy industrial goods

Energy

Services

https://ec.europa.eu/employment_social/empl_portal/publications/Esde2024/xls/Chap1/Chap1-Chart-1.2.xlsx
https://ec.europa.eu/employment_social/empl_portal/publications/Esde2024/xls/Chap1/Chap1-Chart-1.3.xlsx