3M | 2025 Global Impact Report 26Introduction Our workplace Innovation Circularity Climate Communities Governance Appendix

 

  
 

 
 

   

 

 
 

 

 
  

 

 

 

    
 

      
 

  

  

Scope 1 and 2 emissions 
In 2002 we calculated our first GHG inventories 
using IPCC TAR. Since then, our actions have included 
joining RE100 and the Department of Energy’s 
(DOE) Low Carbon Pilot and Better Plants programs, 
working with the Environmental Protection Agency 
(EPA) on methodology for calculating emissions, 
and co-authoring the IPCC National GHG Inventory 
Guidelines. 

Having achieved our first emissions reduction goal 
under EPA Climate Leaders, we’ve met, then reset, 
our goals as we gain momentum: 

2015 – We set a goal to have our scope 1 and 2 
GHG emissions be at least 50% below our 2002 
base year calculation by 2025. 

2021 – We updated our near-term commitment to  
a minimum 50% reduction in absolute scope 1 and 2  
GHG emissions by 2030 in alignment with the IPCC  
1.5 °C pathways.  

2024 – The Science Based  
Targets initiative (SBTi)  
validated our new near-term  
targets and classified our  
scope 1 and 2 target as in  
line with a 1.5 ºC trajectory. 

Target: Reduce absolute scope 1 and 2 GHG 
emissions 52.6% by 2030 from a 2019 base year

59.1% reduction in absolute 
scope 1 and 2 GHG 
emissions since 2019 

Target: Reduce absolute scope 3 GHG 
emissions 42% by 2030 from a 2021 base year

30.7% reduction in absolute 
scope 3 GHG emissions 
since 2021, aligning 
with SBTi 

Scopes defined 

Scope 1 –  Direct emissions  
generated from 3M’s  
activity. For example,  
making a product. 

Scope 2 –  Indirect 
emissions from our activity.  
For example, purchasing  
electricity to light a factory. 

Scope 3 – Indirect emissions  
from related activity up  
and down our value chain.  
For example, the emissions  
produced by a customer  
when using our products. 

3M Villach 
Our site in Villach, Austria, implemented an energy repurposing project in 2024 that captures 
waste heat from production processes to heat the site and supply Villach’s public teleheating grid. 

Recovers up to 

12 GWh 
of waste energy  
annually 

Reduces CO₂  
emissions by up to 

2,978 
metric tons  
annually 

Achieves significant cost  
reductions with more savings  
projected 

Up to 

30% 
of the total investment was  
covered by EU funding under  
the Green Deal 

Reduces reliance on external  
energy sources and enhances  
operational resilience