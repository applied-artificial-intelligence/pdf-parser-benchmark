 195 

 

HEALTH AT A GLANCE: EUROPE 2024 © OECD/EUROPEAN UNION 2024 
  

Figure 7.15. Practising nurses per 1 000 population, 2010 and 2022 (or nearest year) 

 
Note: The EU average is unweighted. The values shown are for 2022. Professional nurses refer to nurses with an education level meeting the EC Directive on the recognition 
of professional qualifications (minimum of 3 years of postsecondary education for general nurses and at least an equivalent level of education for specialist nurses). Associate 
professional nurses include other categories of nurses that are recognised in some countries. Some countries are not able to make a clear distinction between these two 
main categories. 1. The latest data refer to 2017. 2. The data for France and Poland starts in 2013, for the Netherlands in 2014 and for Hungary in 2017. 
Source: OECD Health Statistics 2024; Eurostat (hlth_rs_prs2); WHO National Health Workforce Accounts for Moldova and Ukraine. 

StatLink 2 https://stat.link/d7te05 

Figure 7.16. Ratio of nurses to doctors, 2022 (or nearest year) 

 
Note: The EU average is unweighted. 1. For countries that have not provided data for practising nurses and/or practising doctors, the numbers relate to “professionally 
active” nurses and doctors. 2. The ratio for Portugal is underestimated (professionally active nurses/all doctors licensed to practise). 3. For Greece, the data refer to 
nurses and doctors employed in hospitals. 4. The data for Luxembourg refers to 2017 only. 5. The data for Ireland refers to 2023 to avoid a break in the series for 
doctors in 2022. 
Source: OECD Health Statistics 2024; Eurostat (hlth_rs_prs2); WHO National Health Workforce Accounts for Moldova. 

StatLink 2 https://stat.link/7vnosp

14.1
13.3

12.0 11.7
11.5

11.010.9
10.4 10.4

9.0 8.8
8.4 8.2 7.9 7.7 7.5 7.5

6.6 6.5 6.2
5.7 5.5

5.3
4.3

4.2

3.9

18.4

15.6

14.9

8.7

6.6

5.0
4.5

2.9

11.6

5.7
5.9

0

2

4

6

8

10

12

14

16

18

20

Per 1 000 population

Professional nurses Associate professional nurses All nurses (no distinction) (2010) All nurses (no distinction)

3.9 3.9

3.6

3.2
3.1

2.9
2.8

2.6
2.5

2.3 2.2 2.2 2.1 2.0 1.9 1.9
1.7 1.7 1.6 1.6 1.6 1.5 1.5

1.4
1.3 1.2

1.0 1.0

4.1

3.4
3.2

2.7

2.1 2.1
1.9

1.5 1.5
1.3

0

1

2

3

4

5
Ratio

https://stat.link/d7te05
https://stat.link/7vnosp