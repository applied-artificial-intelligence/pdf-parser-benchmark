 159 

 

DO ADULTS HAVE THE SKILLS THEY NEED TO THRIVE IN A CHANGING WORLD? © OECD 2024 
  

France and Germany. In Korea and the Slovak Republic, conversely, skills account for less than 1% of 

overall wage variation. 

Figure 4.6. Contribution of observable characteristics to variation in wages 

Variation explained by each factor 

 

Note: Employed adults aged 25-65 not in formal education; does not include adults who were only administered the doorstep interview due to a 

language barrier (see Box 1.1 in Chapter 1 and Box 4.1). Decomposition calculates the percentage contribution to variation in log wages of the 

following factors: skills proficiency (numeracy and literacy), years of education, job tenure, field of study (nine categories) and individual 

characteristics (age, gender, immigrant background, and whether one lives with a partner or has children); wages are (log) gross hourly earnings 

for employed and self-employed individuals, including bonuses, in PPP-adjusted 2022 USD. See Fields (2003[43]) for further details on the 

decomposition method. *Caution is required in interpreting results due to the high share of respondents with unusual response patterns. See 

the  ote for Poland in the Reader’s Guide. 

Countries and economies are ranked in descending order of the percentage of variation in wages explained by skills proficiency.  

Source: Table A.4.9a (L, N) in Annex A. 

Observable individual characteristics do not typically account for a large proportion of variation in wages, 

at just 4% on average across participating OECD countries and economies. However, the share is 6% in 

Finland and is at least 8% in Estonia, Japan and Latvia. Japan is also an outlier in the explanatory power 

of years of job tenure, which accounts for 9% of its wage variation, compared to the OECD average of 2%. 

For 11 countries the share attributable to job tenure is less than 0.5% (Figure 4.6).  

The explanatory power of these observable characteristics differs by age. The total share of wage variation 

explained increases from 22% on average among 25-34 year-olds to 27% for 45-54 year-olds. This 

increase is driven in part by changes in the explanatory power of skills, which rises from 5% among 25-

34 year-olds to 7% among 45-54 year-olds. This suggests that numeracy and literacy proficiency matter 

more for the wages of older workers than for younger ones (see Table A.4.9b (L, N) in Annex A). This 

increase in the salience of skills proficiency is consistent with the concept of “employer learning”, noted 

above (OECD, 2014[32]). Even where workers change employers, as their careers progress their formal 

education recedes further into the past, whereas the concrete skills they develop and demonstrate 

regularly during their work will remain relevant. 

There are small differences in the patterns of explained wage variation by gender (Figure 4.7). On average, 

years of education explain a larger share of variation in wages for women than for men (Panel A), whereas 

numeracy and literacy proficiency accounts for a greater share of variation for men than for women 

(Panel B). This is consistent with research that finds that women’s wages are more closely linked to formal 

Proficiency Education Fiel d of study  ob tenure Indi idual characteristics

 0

3 

30

2 

20

1 

10

 

0

G
e
rm

an
y

F
ra
n
ce

E
ng

la
nd

 (
U
 
 

S
w
it 

er
la
n
d

 a
t 
ia

C
an

ad
a

C
 e

ch
ia

S
in
g
ap

or
e

E
st
o
ni
a

 
e
th
e
rl
an

d
s

C
hi
le

H
u
ng

ar
y

A
us

tr
ia

 a
pa

n

 
ew

  
ea

la
n
d

 
e
nm

ar
k

 
E
C
 
 a
ve

ra
g
e

 
o
rw

ay

S
w
e
de

n

P
or
tu
g
a
l

F
in
la
n
d

C
ro
at
ia

 i
th
ua

n
ia

F
le
m
is
h 
R
eg

io
n 
( 

E
 

U
ni
te
d 
S
ta
te
s

Ir
el
an

d

It
a
ly

S
p
ai
n

Is
ra
e
l

P
ol
a
nd

 

S
lo
 a

k 
R
ep

ub
lic

 
or
e
a