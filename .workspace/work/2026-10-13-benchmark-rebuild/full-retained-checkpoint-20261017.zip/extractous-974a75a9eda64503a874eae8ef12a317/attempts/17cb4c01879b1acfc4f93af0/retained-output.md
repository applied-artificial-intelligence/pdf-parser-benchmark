17 
 

Compared to other advanced economies, a much smaller share of EU private savings goes 
directly into investment in companies and riskier forms of investment. Productive 
investment is low and private saving is high94. The share of EU household savings going 
towards company bonds, listed shares, investment funds and similar is relatively low, 
corresponding to 43% of the levels of savings in traditional bank accounts (KPI 15)95. The 
corresponding level in the UK is 55% and in the US 72% (see Figure 4)96. High participation 
rates in financial markets help companies to diversify their funding. Strong capital markets are 
important to ease companies access to finance and unlock finance for scale-ups97. 

Significant amounts of EU savers’ money 
are either tied up in bank accounts or 
invested abroad. Although the volume of 
private savings in the EU was nearly 65% 
greater than in the US in 2022, EU 
households have considerably lower total 
wealth than their US peers98, largely because 
of the lower returns they generally receive 
from financial markets. While the net wealth 
of US households grew by around 150% over 
the past 15 years, the corresponding growth 
was only 55% in the Euro area99. This is 
largely due to a lack of capacity in the EU 
financial system to stimulate high-yielding 
investments, which can be explained by a 
combination of lack of fiscal incentives and 
cumbersome tax reporting requirements in 
many Member States, along with a public 
perception of the overall business climate not 
being sufficiently promising, lowering the 
confidence in the prospects of return on 

investment. Of the EU household savings invested in company bonds, listed shares and 
investment funds, a significant share, approximately EUR 300 billion annually, is invested not 
in the EU, but abroad100, and mainly in the US. EU foreign direct investment into the US 
simultaneously amounted to EUR 3.27 trillion in 2023101. 

New bank loans to SMEs have decreased since the COVID-19 pandemic, putting new 
investments at risk. Although a higher share of financing to companies channelled through 
corporate bonds, listed shares, venture capital and investment funds would be desirable, bank 
financing remains crucial to fostering growth and competitiveness of the bulk of European 
SMEs who use traditional bank loans to finance investments (counting for 57% of their total 
finance, see Figure 5). However, SME lending, which spiked following the on-set of the 

 
94  Productive investment is here defined as gross fixed capital formation minus residential investment.  
95  Note: Part of these savings will contribute to corporate investment activity via the portfolio allocation made by banks and 

other financial intermediaries. 
96  Note: The Commission’s set of indicators on the Capital Markets Union provide detailed indicators that help track capital 

markets’ developments. List of indicators to monitor progress towards the CMU objectives. 
97  European Investment Bank (EIB), The scale-up gap. 
98  Former Prime Minister Draghi, “The future of European competitiveness – A competitiveness strategy for Europe”, part 

B, page 1. 
99  ECB Distributional Wealth Accounts; US Federal Reserve Economic Data. 
100 Former Prime Minister Letta, “Much more than a Market”, page 11. 
101  Statista, Foreign direct investment from Europe into the United States from 2000 to 2023. 

Figure 4: Household savings invested in 
bonds, shares, investment funds and similar. 

 
Note: Volumes of household savings in company 
bonds; listed shares; and investment, insurance and 
pension funds, relative to the volumes of households’ 
cash holdings and bank deposits. 

Source: European Commission, DG FISMA 

https://finance.ec.europa.eu/publications/list-indicators-monitor-progress-towards-cmu-objectives_en
https://www.eib.org/attachments/lucalli/20240130_the_scale_up_gap_en.pdf
https://commission.europa.eu/topics/strengthening-european-competitiveness/eu-competitiveness-looking-ahead_en
https://www.consilium.europa.eu/media/ny3j24sm/much-more-than-a-market-report-by-enrico-letta.pdf
https://www.statista.com/statistics/188884/foreign-direct-investment-from-europe-in-the-us-since-1990/