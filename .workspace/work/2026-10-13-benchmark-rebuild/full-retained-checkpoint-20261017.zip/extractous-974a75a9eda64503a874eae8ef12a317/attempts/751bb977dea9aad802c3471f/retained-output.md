Chapter 8. Political Cleavages

Figure 8.3. The reversal of educational divides in Westerndemocracies

−40%
−35%
−30%
−25%
−20%
−15%
−10%

−5%
0%
5%

10%
15%
20%
25%
30%

1950−59 1960−69 1970−79 1980−89 1990−99 2000−09 2010−19 2020−25
Time periodD

iff
er

en
ce

 b
et

w
ee

n 
(%

 o
f t

op
 1

0%
 

 e
du

ca
te

d 
vo

tin
g 

le
ft)

 a
nd

 (
%

 o
f 

bo
tto

m
 9

0%
 e

du
ca

te
d 

vo
tin

g 
le

ft)

Australia Britain Canada Denmark Finland Iceland

Ireland New Zealand Norway Sweden United States Average

English−speaking and Northern European countries

−40%
−35%
−30%
−25%
−20%
−15%
−10%

−5%
0%
5%

10%
15%
20%
25%
30%

1950−59 1960−69 1970−79 1980−89 1990−99 2000−09 2010−19 2020−25
Time periodD
iff

er
en

ce
 b

et
w

ee
n 

(%
 o

f t
op

 1
0%

 
 e

du
ca

te
d 

vo
tin

g 
le

ft)
 a

nd
 (

%
 o

f 
bo

tto
m

 9
0%

 e
du

ca
te

d 
vo

tin
g 

le
ft)

Austria Belgium Germany Italy Luxembourg Netherlands

Portugal Spain Switzerland France Average

Continental and Southern European countries

Interpretation. In these countries, higher−educated voters used to be significantly more likely to vote for
conservative parties and have gradually become less likely to vote for these parties. Estimates control for
income, age, gender, religion, church attendance, rural / urban, region, race / ethnicity, employment status, and
marital status (in country−years for which these variables are available). Sources and series: Gethin et al.
(2021) and World Political Cleavages and Inequality Database (wpid.world).

Education divides in Western democracies, 1960−2025

150