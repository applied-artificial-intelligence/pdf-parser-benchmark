 103 

 

HEALTH AT A GLANCE: EUROPE 2024 © OECD/EUROPEAN UNION 2024 
  

Figure 3.9. Cancer mortality in EU countries by gender, 2021 (or nearest year) 

 
Note: The EU average is weighted. Data for the United Kingdom refer to 2020 and have been calculated by the OECD. 

Source: Eurostat (hlth_cd_asdr2). 

StatLink 2 https://stat.link/hufsd5 

Figure 3.10. Change in cancer mortality by cancer site in the EU, 2011-21 

 
Note: The red bubble signals an increase in mortality during 2011-21 while the green bubbles signal a decrease. The size of the bubbles is proportional to the mortality 

rate in 2021. “Lung” includes cancers of the lung, trachea, and bronchus. “Brain” refers to both brain cancers and central nervous system cancers. The data correspond 

to the EU27 weighted averages. 

Source: Eurostat (hlth_cd_asdr2). 

StatLink 2 https://stat.link/styxji

0

50

100

150

200

250

300

350

400

450

500

Age-standardised mortality rate per 100 000 population

Total Men Women

Bladder

Breast 

Cervix 
uteri 

ColorectumLeukaemia

Liver

Ovary 

Pancreas

Prostate 
Skin

Stomach

Brain

Lung

-40%

-30%

-20%

-10%

0%

10%

20%

0 10 20 30 40 50

Mortality in 2021 per 100 000 population

Percentage change in mortality rate 2011-21

https://stat.link/hufsd5
https://stat.link/styxji