65European Innovation Scoreboard 2025

(reaching 89.5) before rebounding. 

Cyprus recorded a sharp rise between 2020 and 2021 (from 80.3 to 104.6), peaking in 
2023 (109.9), before falling to 94.7 in 2025. 

Lithuania improved from 73.8 in 2018 to 94.7 in 2024, with a small decline to 91.2 
in 2025. 

Czechia increased from 74.4 in 2018 to 99.1 by 2023–2024, followed by a drop to 
90.8 in 2025. 

Greece experienced consistent growth between 2018 (70.0) and 2024 (88.2), with a 
slight dip to 85.3 in 2025. 

Croatia steadily improved its score from 61.2 in 2018 to a high of 81.6 in 2024, 
followed by a slight decline in 2025 (reaching 80.6).

Figure 25: Performance Moderate Innovators

Note: Performance is relative to that of the EU in 2018. The graph on the left shows the average performance of 

the Moderate Innovators calculated as the unweighted average of the respective Member States. All vertical 

scales in Figure 23-Figure 26 span a range of 70.0%-points to allow an easy comparison of the results between 

the four performance groups. 

Emerging Innovators 

In 2025, Hungary (at 78.3% of the EU average in 2018) was the highest-performing 
emerging innovator and only marginally below the threshold of the moderate innovators, 
reflecting strong recent momentum. Poland (74.2%) and Slovakia (70.5%) followed closely, 

50

60

70

80

90

100

110

120

'18 '19 '20 '21 '22 '23 '24 '25

S
um

m
ar

y 
in

no
va

tio
n 

in
de

x

Cyprus

Czechia
Greece

Spain

Croatia

Italy

Lithuania

Malta

Portugal

Slovenia

50

60

70

80

90

100

110

120

'18 '19 '20 '21 '22 '23 '24 '25

S
um

m
ar

y 
in

no
va

tio
n 

in
de

x