Energy Technology Perspectives 2023 Chapter 1. Energy supply chains in transition 

PAGE | 57  I E
A.

 C
C

 B
Y 

4.
0.

 

More investments are needed urgently to avoid bottlenecks 
Bridging the production gaps described above would require enormous additional 
investments in the coming years. The total cumulative investment in mining, critical 
material production and manufacturing of the clean energy technologies selected 
in this report required to bring the necessary capacity online by 2030 amounts to 
around USD 1.2 trillion,7 in 2021 dollars (Figure 1.11). Investments associated 
with projects already announced reach around60% of this, with large gaps in 
critical mineral mining and for some technology manufacturing.  

While mobilising such levels of investment is achievable, the timeline is extremely 
tight, especially given the long lead times to bring production to market. Most of 
the investment (including for projects already announced) needs to occur over 
2023-2025, implying an average of more than USD 270 billion per year over the 
period. To compare, this is about two-thirds of current annual capital spending of 
the oil and gas industry, and nearly seven times higher than the average annual 
investment seen in clean energy supply chains over 2016-2021.  

 Global investment in selected clean energy supply chains needed to bring 
online enough capacity in 2030 in the NZE Scenario, by supply chain step 

  
IEA. CC BY 4.0. 

Notes: CAPEX = capital expenditures. Only refers to the investments needed to bring online enough capacity in 2030 – not 
counting what would be needed to further scale up in subsequent years – for the subset of clean energy technologies 
selected in ETP-2023. Assuming construction times of five years for mining, three for processing plants and two for 
technology manufacturing. Investments are assumed uniform over the available period. Excludes site-tailored technology 
installation. 
Sources: IEA analysis based on company announcement; Bartholomeusz (2022); S&P Capital (2022). 

Most of the supply chain investments needed to meet NZE Scenario targets in 2030 are 
made over 2023-2025, at an annual average seven times higher than over 2016-2021. 

 
 

7 This refers only to the investments needed to bring enough capacity online in 2030 for the technologies selected in 
ETP-2023, excluding the investments that would also be needed by 2030 to further scale up deployment in subsequent years. 

0

 50

 100

 150

 200

2016-2021 2023-2030

Bi
llio

n 
U

SD

Copper mining Other Critical mineral mining Critical mineral processing Clean technology manufacuring

Average yearly CAPEX

0

 500

1 000

1 500

2023-2030

Bi
llio

n 
U

SD

Cumulative CAPEX

Final investment decision year
2023 2024 2025 2026 2027 2028 2029 2030

Time available for final investment decision