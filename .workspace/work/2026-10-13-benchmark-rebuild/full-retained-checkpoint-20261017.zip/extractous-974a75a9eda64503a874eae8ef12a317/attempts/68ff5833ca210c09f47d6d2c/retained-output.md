Global Outsourcing Survey 2024 | Multidimensional sourcing: Orchestrating the extended workforce ecosystem 

9

What is driving organizations’ adoption of insourcing? It’s not dissatisfaction with outsourced services. 

The leading drivers for insourcing include gaining better control over service quality and performance 
(beyond what outsourcing can provide) and growing strategic capabilities in-house, while eliminating 
vendor markup.

Organizations will likely continue balancing insourcing and outsourcing, making decisions about which 
functions to bring in-house and which to outsource. Both models will likely coexist as part of future 
sourcing strategies. This trend has potential implications on how organizations contract for outsourced 
services. Insourcing events can trigger changes to total cost of service, loss of knowledge, and change 
impacts to business stakeholders. Organizations should evaluate the commercial and business impact 
of insourcing based on current contract provisions. And by enhancing flexibility of contract provisions 
(e.g., changes to scope, service levels, term), organizations can be better prepared to leverage insourcing, 
when needed.  

Of the respondents who are exploring more insourcing opportunities

80%
are either maintining or 
increasing their investment 
in outsourced services

82%
reported ‘meets’ or ‘exceeds’ 
expectations from their 
outsourced services

Primary drivers for insourcing scope or services

12%For confidentiality / intellectual property (IP) reasons 

38%Better cultural alignment

38%For regulatory and compliance reasons

68%Better control over service quality and performance

46%For risk and security reasons

39%For improved transparency in service operations

39%Have a more balanced talent sourcing ecosystem (risk diversification)

56%Spend optimization

64%Invest in and grow strategic capabilities in-house