12 Stagility: Creating stability for workers for organizations to move at speed 

create value for workers and the organization.3 And 85% say that 
organizations need to create more agile ways of organizing work 
to swiftly adapt to market changes.4 

A disconnect between executives and workers is emerging, with 
leaders preparing for more agile ways of working and workers 
favoring stability (figure 1). The challenge is that the ability for 
organizations to evolve and adopt new models of work depends 
largely on the ability of the workforce to do the same. How can 
leaders find the right balance between the stability that workers 
crave and the agility that organizations need to create stagility? 

For many organizations there is a gap between knowledge and 
action. According to our 2025 Global Human Capital Trends survey 
(see “Methodology”), a significant majority of organizations (72%) 
recognize the importance of balancing agility and stability, yet only 
39% are doing something meaningful about it (figure 2). Whether 
organizations can strike this balance will likely depend on their 
ability to find ways to anchor the work, the organization, and the 
worker. These new anchors should provide a sense of identity, a 
clearly defined path of action, and a mental model for the way 
work works. They should also provide a sense of grounding and 
direction, binding worker to organization in a shared vision that 
benefits both parties. 

Traditional anchors that have long provided stability for both 
organizations and workers are being challenged. These anchors 
include static job descriptions, defined teams, and linear, internal 
career pathways and employment models. As these anchors become 
upended, workers may struggle to find the grounding they require to 
act with confidence and creativity and to have a dynamic capability 
to respond and evolve. 

Organizations and workers must find new sources of stability to 
reinforce the connection between worker and organization, putting 
both in a position to adapt and thrive. These new anchors will come 
in the form of reimagined organization structures, greater intention-
ality in the design and resourcing of work, a better understanding of 
workers as individuals, and stronger networks within and beyond 
the four walls of the organization. 

Sources of instability for work, organization, and worker 

For organizations and workers to establish new anchors, they should 
first assess the sources of instability they face. These fall under three 
broad categories: work, organization, and worker. 

Figure 1 

The changing nature of work no longer reflects workers’ ideal ways of working 
Percentage of workers answering the question, “Which of the following describes your ideal way of working,” and percentage 
of leaders answering the question, “Which of the following statements best describes the changing nature of work in your 
organization?” 

Source: Analysis of Deloitte’s 2025 Global Human Capital Trends survey data. 

0% 10% 20% 30% 40% 50% 60% 70%

Frequent changes in where and when 
work is done depending on the need 

Frequent changes in how work is 
done depending on the need 

Broadly defined jobs or positions, 
anchored to outcomes or challenges 
instead of specific tasks 

Shifting team(s) or workgroups 

Less stability 

Leaders Workers