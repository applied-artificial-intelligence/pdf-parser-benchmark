38 
 

 

Figure 9 
ESM maximum lending capacity expressed as share of selected euro area macroeconomic aggregates  
(2012 vs. 2023)

 

Source: ESM, European Commission, ECB 
Note: Euro area in rolling composition 
 

Against the metric of gross financing needs, both the ESM maximum and remaining lending capacity 

have declined in recent years. Debt sustainability is intrinsically linked to both stock and flow features 

of public debt, from which vulnerabilities can arise from term-to-maturity structures, roll-over risks, 

amortisation schedules and varying interest rates. As highlighted by ESM staff research (Gabriele et 

al., 2017), gross financing needs (GFNs) is a comprehensive flow metric for identifying such 

mismatches. Since the creation of the ESM in 2012, GFNs have declined within the prevailing low-

interest environment (Figure 10). Within this context, the ESM maximum and remaining lending 

capacity reached their peak as a share of euro area GFNs in 2019 at 29% and 24% respectively. Since 

2019 however, GFNs have increased considerably given the onset of the Covid pandemic and the 

subsequent energy crisis, reversing this trend. In 2023, only 20% of euro area GFNs could be covered 

by the ESM maximum lending capacity (16% for the remaining capacity), below the levels prevailing 

in 2012.  

Figure 10. 
ESM lending capacity as a share of euro area gross financing needs, 2012 - 2022  
(left hand scale: EA GFN in € billion, right hand scale: ESM lending capacity in % of GFN) 
 

 

Source: ESM, European Commission 
Note: Given their volatile nature, changes in methodology, and incomplete data-series, a full time-series of gross financing needs 
for the 2012-2023 period is not presented. 
 

  

0.0%

2.0%

4.0%

6.0%

8.0%

10.0%

12.0%

Revenue Debt GDP

2012 2023

0%

10%

20%

30%

40%

0

500

1000

1500

2000

2500

3000

2012 2016 2017 2018 2019 2020 2021 2022 2023

EA GFN ESM - Remaining ESM - Maximum