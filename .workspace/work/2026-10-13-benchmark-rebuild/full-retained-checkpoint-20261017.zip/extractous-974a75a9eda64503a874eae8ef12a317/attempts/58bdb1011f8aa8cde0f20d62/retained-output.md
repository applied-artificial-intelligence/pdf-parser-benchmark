23 © The Economist Intelligence Unit Limited 2024

Industry outlook 2025
Challenges, opportunities and trends to watch in six sectors

in March 2024 Dollar Tree, a US 
discount chain, announced plans 
to cut 1,000 stores in the US in 
2024-25, and in the second quarter 
McDonalds, a US fast-food chain, 
reported its first decline in global 
sales since 2020.  

The retail growth landscape will vary 
significantly according to region. 
Asian and the Gulf countries are 
expected to outpace other regions in 
retail volume growth, driven by large, 
young consumer bases with rising 
incomes, urbanisation and a surge in 
online shopping. 

−8

−6

−4

−2

0

2

4

USMCA Europe Asia-Pacific South America MEA

2024
2025

Source: EIU.

Asia will lead global retail 
sales growth, and South 
America will rebound in 2025

Retail sales volume growth rate, %

Copyright © The Economist 
Intelligence 
Unit 2024. All rights reserved.

While Chinese retail slows, India 
offers a silver lining

Real growth in retail sales in Asia 
will outpace that of other regions, 
but the star of the show will not be 
China. The world’s second-largest 
consumer market is expected to 
grow by nearly 4% year on year in 
real terms in 2025—the slowest 
rate since 2022, and markedly 
so compared with the historical 
trend (averaging 7% in 2015-19). 
Income shocks from the prolonged 
lockdowns, a property market 
downturn, job market weakness 
and an ageing population have all 
contributed to lasting pessimism in 
the market. 

Meanwhile, we expect growth to 
average about 5% year on year in 
India (down from 5.3% in 2015-19). 
For businesses, the opportunities 
will be twofold. At the lower end of 
the market, fast-moving consumer 
goods makers such as PepsiCo and 
P&G (US) are banking on increased 
spending by the country’s sizeable 
rural population (65% of the total) 
to offset some of the slowdown 
in China. Recent economic data 
suggest a strong propensity 
among this population to spend 
on packaged goods, cosmetics, 
toiletries and household goods.