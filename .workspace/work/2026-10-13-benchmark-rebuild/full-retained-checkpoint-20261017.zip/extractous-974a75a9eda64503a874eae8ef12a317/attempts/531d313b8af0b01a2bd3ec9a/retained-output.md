 117 

 

DO ADULTS HAVE THE SKILLS THEY NEED TO THRIVE IN A CHANGING WORLD? © OECD 2024 
  

Figure 3.7. Change in literacy proficiency between cycles, by educational attainment 

Adjusted and unadjusted difference in mean literacy scores between cycles (Cycle 2 minus Cycle 1); 25-65 year-

olds 

 

Note: Does not include adults who in Cycle 2 were only administered the doorstep interview due to a language barrier, to maximise the 

comparability across cycles (see Box 1.1 in Chapter 1 and Box 3.2). See Note 2 for an explanation of the classification of educational attainment. 

Unadjusted differences are the differences between the averages in each cycle. Adjusted differences are based on a method analogous to post-

stratification that reweights the samples in Cycle 2 so that education groups have the same demographic characteristics as in Cycle 1 (see Note 

1). Demographic characteristics considered are: age (in ten-year age brackets), gender and immigrant background. Darker colours denote 

differences that are statistically significant at the 5% level.  

In Chile and the United States, more than 20% of the subsample of adults with below upper secondary education only completed the assessment 

of reading and numeracy components in the second cycle. As the methodology for estimating the proficiency of adults who only took the 

components assessment has changed between the cycles, the change in proficiency for this group is not reported. *Caution is required in 

interpreting results due to the high share of respondents with unusual response patterns. See the Note for Poland in the Reader’s Guide. 

Countries and economies are ranked in descending order of the unadjusted change in literacy proficiency among adults with below upper 

secondary education. 

Source: OECD (2018[4]; 2015[5]; 2012[6]), Survey of Adult Skills (PIAAC) databases, http://www.oecd.org/skills/piaac/publicdataandanalysis/  

(accessed on 23 September 2024); Table A.3.11 (L) in Annex A.  

S
w
ed

e
n

F
in
la
nd

S
pa

in

 
en

m
a
rk

C
an

ad
a

F
le
m
is
h 
R
e
g
io
n 
( 

E
 

E
st
o
ni
a

It
al
y

 
et
he

rl
an

ds

G
e
rm

an
y

C
 e

ch
ia

S
lo
 a

k 
R
ep

u
bl
ic

Ir
el
a
nd

E
ng

la
n
d 
(U

 
 

 
o
rw

ay

P
o
la
n
d 

F
ra
n
ce

 a
p
an

 
or
ea

A
u
st
ri
a

U
ni
te
d 
S
ta
te
s

Is
ra
e
l

S
in
g
ap

or
e

 
e
w
  
ea

la
nd

 i
th
ua

n
ia

C
h
ile

H
un

g
a
ry

S
w
ed

e
n

F
in
la
n
d

S
p
ai
n

 
e
nm

a
rk

C
an

ad
a

F
le
m
is
h 
R
e
gi
o
n 
( 

E
 

E
st
o
ni
a

It
al
y

 
et
he

rl
a
nd

s

G
er
m
a
ny

C
 e

ch
ia

S
lo
 a

k 
R
ep

ub
lic

Ir
el
an

d

E
ng

la
n
d 
(U

 
 

 
o
rw

ay

P
o
la
nd

 

F
ra
n
ce

 a
pa

n

 
or
ea

A
us

tr
ia

U
ni
te
d 
S
ta
te
s

Is
ra
el

S
in
g
a
po

re

 
ew

  
ea

la
nd

 i
th
ua

n
ia

C
hi
le

H
un

g
a
ry

Ad ustedUnad u sted

20

10

0

 10

 20

 30

  0

  0

20

10

0

 10

 20

 30

  0

  0

20

10

0

 10

 20

 30

  0

  0

 ertiary

 pper 
secondary

Belo  
upper 
secondary

Round, Cycle 1:

Round, Cycle 1:

   

   

http://www.oecd.org/skills/piaac/publicdataandanalysis/