Sustainability Highlights
“CapitaLand Ascendas REIT (CLAR) places sustainability at the core of all initiatives across the properties 
globally and is aligned with CapitaLand’s sustainability objectives and goals. These efforts are also inclusive 
that extend to the tenants and the community at large.”

COMMITMENT TO THE ENVIRONMENT
RENEWABLE ENERGY
Solar Power
CLAR aims to accelerate solar panel installations 
across its portfolio. In 2022, solar panel installations 
were completed on 10 properties in Singapore. This 
brings the total number of active solar installations 
in Singapore to 17 properties, which is projected to 
generate about 18.4 GWh/year. 

Electric Vehicles (EV) 
There are a total of 273 EV (FY2022: +46) charging 
points installed across the CLAR portfolio. Plans for 
installation of more charging stations are being 
evaluated and there are ongoing discussions with 
tenants to encourage greater adoption. 

GREEN FINANCING
CLAR issued S$623 million of Green Bonds and 
Loans in FY2022, bringing total green financing to 
S$1.84 billion or approximately 28% of CLAR’s total 
borrowings.

PILOTING OF SUSTAINABILITY 
INNOVATIONS

CLAR continues to explore piloting and 
scaling of innovations that demonstrate 
potential commercial and technological 
feasibility. Following the launch of 
CapitaLand’s Sustainability-X Challenge 
(CSXC), CLAR has rolled out several initiatives.

Key Initiatives
Continewm 
Net

This is an initiative that involves using ceramic and 
polyethelene nets in air handling units (AHUs) to reduce 
AHU energy consumption. The initiative will be scaled up to 
involve all AHUs in LogisTech, Singapore in 2023.

Aeroseal An ongoing pilot project at 17 Changi Business Park Central, 
Singapore involving a duct sealing solution which improves 
heating, ventilation, and air conditioning (HVAC) efficiency 
and Indoor Air Quality.

INOVUES Ongoing CSXC INOVUES window retrofit project at Creekside 
5, Portland, US for better insulation and energy performance.

NOTABLE ESG ACHIEVEMENTS 
• "A" rating for GRESB2 Public Disclosure for three years running 
• 3-Star rating for GRESB Real Estate Assessment 2022
• Achieved a score of "B" for CDP Climate Change 2022
• Ranked 2nd on Singapore Governance and Transparency Index 2022 (REITs and Business Trust Category)

NURTURING COMMUNITY

CLAR engages with the community at large, 
which comprises the Manager’s employees, 
tenants and the local community. CLAR 
actively works towards creating inclusive 
spaces for these different stakeholders in 
order to contribute to uplifting the well-
being of various factions of society.

Key Initiatives
CapitaLand 
Ascendas REIT 
Study Awards

As a testament to its long-term commitment towards 
supporting the development of local communities 
that CLAR operates in, the Manager has pledged an 
additional S$1.3 million in donations towards educational 
causes in key markets including Singapore, Australia, the 
UK and the US. The total donations to date is S$2.5 million.

CLAR Sustainability 
Corner 
Competition

23 students across five tertiary institutions participated 
in the competition to develop innovative designs for a 
Sustainability Corner, a physical installation or space to 
raise awareness about climate change and sustainability 
issues among tenants and visitors to CLAR properties. 

CapitaLand 
Wellbeing 
Programme (Global)

This programme aims to improve employees’ quality of life 
in order to enhance their work performance. Attendees 
from CapitaLand Group across  13 countries globally have 
benefited from the programme and initiatives.

CapitaLand’s 
#LoveOurSeniors 
programme 
(Singapore)

This programme entailed the contributions of more 
than 600 staff and 148 tenants across CapitaLand 
Group to distribute bread and essential care packs to 
seniors, and assist some in moving to their new homes 
through emotional and financial support.

Blood Donation 
Drives (US)

Blood donation drives were held in Portland and Raleigh. 
This initiative involved at least 40 tenants that could 
potentially save more than 120 lives.

Group photo of the Manager's Management 
team with judges and winners of the CLAR 
Sustainability Corner Competition

• 58 Green 
Mark Certified 
Properties

• 4 5-Star NABERS Energy 
Rating Properties

• 1 3-Star NABERS Energy 
Rating Property

• 2 BREEAM Excellent 
Certified Properties• 5 LEED Platinum/

Gold Certified 
Properties

GREEN BUILDINGS
CLAR has 701 green-certified properties globally, and 
has the largest number of BCA Green Mark properties 
amongst S-REITs (581 including 19 newly certified 
properties and 27 re-certified properties). CLAR will 
continue to work towards more properties being certified, 
through initiatives such as systems and processes 
upgrading, implementation of green leases, and having 
a minimum green building target for new acquisitions 
and development, among others.

1 Includes non-managed properties
2 GRESB is an investor-led organisation providing standardised and validated ESG data

CapitaLand Ascendas REIT18