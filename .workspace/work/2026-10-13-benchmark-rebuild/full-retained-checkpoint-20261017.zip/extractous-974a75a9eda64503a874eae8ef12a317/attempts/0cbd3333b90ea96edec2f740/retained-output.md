1
3.0

Progressing towards Marico 3.0 

As we expedite our progress towards 

At Marico, we have defined robust competency frameworks. It enables us to engage in capability-
building investments that are aimed at reimagining the Marico of the future. To retain our 
competitive advantage, we believe in aligning our people with evolving industry demands through 
skill development and training opportunities. It is not only expected to fortify the foundation of a 
sustainable business but, empower us to explore new directions of growth

Marico 

The Marico Way’ - the foundation for building The Marico of Tomorrow

‘The Marico Way’ embodies the foundation of a journey towards building the Marico of tomorrow. With a refreshed 
set of values, we are charting a roadmap for the organisation’s future, focused on challenging the status quo, 
adapting to change and evolving in a dynamic business environment. At Marico, we took a conscious decision to 
build a Company grounded in ‘Values’ that resonate with our customers, partners and communities.

As we gear up for ‘Marico 3.0’, the next phase of our growth journey, we strive to remain closely aligned with the 
Company’s strategy, its business ecosystem and the industry as a whole. With our firm belief in the power of co-
creation, we took a comprehensive approach, including an exhaustive listening exercise (Surveys, FGDs, Workshops, 
Stakeholder Interviews etc) with our members and business partners/stakeholders across business units and 
geographies. ‘The Marico way’ lay the groundwork for a future-focused organisation that is ready to imbibe the next 
generation way of working. It serves as a gateway for understanding and aligning the company culture with the needs 
of a new-age workforce. Our revamped values will also encourage a culture of digital experimentation and adoption, 
designed to serve Marico in the long-run.

Our strong belief in ‘Values create Values’ have empowered us to evolve, innovate and excel. As we progress, we 
realise the importance of staying ahead of the curve with differentiated and innovative offerings. The ‘Marico Way’ is 
the result of a carefully crafted blend of our purpose, ethos and values that truly define our unique identity and carve 
the path for the ‘Marico of Tomorrow’.

Our values have been the guiding light, strengthening our ability to adapt and evolve. The revamped values were not 
only designed to drive Marico closer to its ambitious goals, but also to create an inclusive, socially responsible and 
forward-thinking company culture. Hence, as part of the design, we also looked through various lens encompassing 
a new generation workforce, rapid technology adoption and the aspirations of Marico 3.0. With ‘the Marico Way’, 
we are confident of building a courageous, bold, agile and consumer-centric Marico – committed to the purpose of 
making a difference.

we are striving to bring forth the right 
combination of capabilities, skills 
and talent to the forefront. We lay 
emphasis on building desired Leadership 
Capabilities and Future Skills, across 
functions and geographies, to define our 
way forward.

To make a difference to all the 
stakeholders. 

Make consumer delight a way of life

Enable win-win outcomes for external 
stakeholders

Deliver what we promise

Think big, start small, learn and scale fast

Nurture members to unleash their 
potential

Adapt to changing scenarios with speed 
& excellence

Emphasise the key elements of Owner’s 
Mindset, Frugality, Transparency, 
Mutual Trust, Integrity & Meritocracy.

Purpose

Consumer First

Responsible growth

Accountability for  
outcomes

Bold ambition

Grow with members

Execute with agilityEthos

The‘Marico Way’ will empower Marico members to align their actions, decisions and  
organisational direction with a clear sense of purpose.

Refreshed Values

In tegrated Annual Repor t  2023-24 • Corporate Overview • Statutory Reports • Financial Statements

M a r i c o  L i m i t e d
116 117