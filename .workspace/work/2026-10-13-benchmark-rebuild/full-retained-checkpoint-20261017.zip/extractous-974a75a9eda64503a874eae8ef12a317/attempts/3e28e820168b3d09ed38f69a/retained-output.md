P&C | 2025 Simplified Group Nat Cat Reinsurance Program1

Stable reinsurance program for 2025
In Euro

Insurance segment
(occurrence protection)

Alternative 
Capital &

Cat Bonds

Reinsurance 
segment

(illustrative)

43 Full Year 2024 Earnings 

3.9bn 1.2bn1.2bn

450m 400m 600m 600m600m

4.0bn 

2.1bn 2.1bn 1.2bn 

1.0bn

1.2bn 

EU 
Windstorm

Europe
Flood

Europe
Earthquake

Per other 
perils2

NA
Earthquake

NA
Hurricane

1. Excludes local reinsurance covers 2. Other perils include Türkiye earthquake, NA floods and wildfires, as well as a series of other secondary perils. Capacity varies by peril type.

400mRetention

Capacity