REUTERS INSTITUTE FOR THE STUDY OF JOURNALISM / FURTHER ANALYSIS GRAPHS

Graph 35

PROPORTION WHO PAY ATTENTION TO EACH SOURCE  
FOR CLIMATE CHANGE NEWS  – SELECTED MARKETS

C1_2022a. When it comes to climate change news, which of the following sources, if any, do you 
pay most attention to? Base: Total sample in each market (n ≈ 2,000).

Major news organisations Documentaries
Don’t pay attention to climate changeSmaller/alternative news sources

0% 25% 50% 75%

4

4

10

6

20

18

23

15

14

5

22

10

15

15

42

50

27

55

31

33

24

45

43

41

35

28

27

24

Don't pay attention to climate change

Smaller/alternative news sources

Documentaries

Major news organisations

USA

Australia

Norway

Greece

Japan

Portugal

Chile

When we drill down into the attention paid to major news 
organisations, we find that usage for climate change news is lower 
in markets where interest and attention are polarised, such as the 
US and Australia. In these markets, along with Norway, we see the 
largest proportions of people saying they don’t pay attention to 
climate change at all, with these high figures largely being driven by 
those on the political right. Half (49%) of those on the political right 
in the US say they don’t pay attention to climate change at all, and it 
is a third in Australia (34%) and Norway (31%). This compares to just 
5% of those on the political right in Portugal and Chile who say they 
don’t pay attention.

Indeed, the comparisons between the US, Australia, and other 
markets are stark, showing the role that polarised politics – and 
media coverage – can play in driving down interest in and attention to 
climate change as an issue. Attention to sources across the board is 
low in both the US and Australia despite the visible effects of climate 
change witnessed in both countries in recent years. In contrast, 
countries like Greece and Chile do not appear to suffer from the same 
levels of audience polarisation and see higher rates of attention. 

Finally, there are also interesting differences in attention to 
sources by age. Respondents under 35 in many markets are 
often two or three times more likely to say they pay attention 
to celebrities, social media personalities, or activists for climate 
change news than people over 35. So-called ‘green influencers’ 
have amassed large followings online, drawing attention to the 
linkages between climate change and social justice issues. They 
include Vanessa Nakate, a climate activist from Uganda with 
hundreds of thousands of followers across Twitter and Instagram; 
Jack Harries, an environmentalist YouTuber whose channel has 
3.7m subscribers; and Jerome Foster, a young climate activist who 
is a White House adviser with over 41,000 Instagram followers. 

Groups like the EcoTok collective on TikTok also seek to connect 
with the younger audience on the platform. Younger respondents 
are also somewhat more likely to say they get climate change 
news from smaller or alternative news sources, some of which 
have been started by young climate activists.

COVERAGE OF CLIMATE CHANGE

Audiences appear to be more interested in and pay more attention 
to climate change news in places where the negative effects are felt 
more acutely. But it is arguably too late if audiences only pay attention 
once disasters have already struck. A central challenge is how to cover 
the issue in a way that draws attention to the causes and decisions 
that lead to disasters, not ‘just’ the disasters themselves.

One approach to this is taking a clearer stance on the issue, 
as exemplified by the Guardian calling for more action on the 
‘climate crisis’ and many documentaries that take a clear activist 
stance on environmental issues. But how do audiences feel about 
news outlets adopting a position? 

We find that, in general, there are strong regional differences in 
views. These reflect similar patterns to those already identified in 
this chapter: audiences in Latin America, Southern Europe, and 
several markets in Asia-Pacific are more open to news outlets 
taking a stand in favour of climate change action. Large proportions 
of respondents in Chile (58%), Portugal (48%), and the Philippines 
(42%) say that journalists should advocate for change. On the other 
hand, pluralities in Northern European, Western European, and 
North American markets favour impartiality. Respondents in 
Germany (45%), Norway (44%), and the US (42%) say they would 
prefer news outlets to reflect a range of views and leave it up to 
them to decide what to think (see chart next page).

Examining these trends, it may be that audiences in markets such 
as Norway and Germany are predisposed to expect an impartial 
approach to reporting – particularly from public broadcasters. On 
the other hand, political polarisation may again be playing a role. 

In many markets, large majorities of those on the political right 
want journalists to remain impartial on climate change and their 
views drive some of the overall trends. The proportion of those on 
the right favouring impartiality is 60% in Norway and 69% in the 
US. Conversely, those on the political left tend to favour journalists 
advocating for climate change action. Views in Chile and Portugal 
are not as polarised on this question, with both those on the 
political left and right favouring climate action.

REUTERS INSTITUTE FOR THE STUDY OF JOURNALISM / FURTHER ANALYSIS GRAPHS

Graph 36

PROPORTION WHO PAY ATTENTION TO CELEBRITIES, 
SOCIAL MEDIA PERSONALITIES, OR ACTIVISTS FOR 
CLIMATE CHANGE NEWS – BY AGE – SELECTED MARKETS

C1_2022a. When it comes to climate change news, which of the following sources, if any, do you pay 
most attention to? Please select all that apply. Base: U35/35+: Greece = 468/1536, Portugal = 462/1549, 
USA = 668/1368, Norway = 496/1514, Australia = 561/1477, Japan = 406/1609. 

0%

25%

4

8

4 3
5

8

18
16

14
12 12 12

35+

U35

JapanAustraliaNorwayUSAPortugalGreece

0%

25%

4

8

4 3
5

8

18
16

14
12 12 12

35+

U35

JapanAustraliaNorwayUSAPortugalGreece

U35 35+

Reuters Institute for the Study of Journalism   |   Digital News Report 202256