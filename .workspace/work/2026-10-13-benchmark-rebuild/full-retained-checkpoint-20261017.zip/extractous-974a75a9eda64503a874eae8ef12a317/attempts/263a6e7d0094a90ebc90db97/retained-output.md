TRUST IN NEWS BRANDS: THE PARTICULAR CASE 
OF PUBLIC SERVICE MEDIA 

Underpinning news trust in many Northern and Western European 
countries, as well as Canada and Australia, we find a number of 
public service broadcasting organisations with a strong track record 
of independence. These generally appear at the top of our brand trust 
lists in each country and are often the first port of call for audiences 
when looking for reliable news around important stories such as 
COVID-19 and the Ukraine conflict. These institutions have a very 
different reputation to public and state broadcasters in Southern  
and Eastern Europe that often take a more partisan editorial line.

But independent public media are under increasing pressure in 
a number of countries, with attacks on funding, questions about 
impartiality, and challenges in reaching younger audiences who 
are increasingly turning to digital and social media. The BBC faces 
another round of cuts after a difficult licence settlement while DR, 
the Danish public broadcaster, recently cut three linear channels 
as part of a wider restructuring after a narrow parliamentary 
majority imposed a major cut in funding. Against this background, 
it is interesting to see how well trust is holding up, with some 
very notable exceptions. Nordic PSBs as well as those of other 
smaller countries like Ireland and Portugal have retained or even 
increased trust since 2018, but it has been a very different story in 
the UK, Australia, and Canada, with significant falls for the main 
public broadcasters.

The BBC, which remains the most widely used news source 
in the UK, reported record audiences in the first weeks of the 
Ukraine crisis,3 but it has also come under intense criticism for its 
reporting of a range of more divisive issues – notably Brexit but 
also immigration, race, gender identity, and attitudes to COVID-19 
vaccinations. In many cases, these criticisms of the BBC have been 
amplified on social media, with senior correspondents exposed to 
physical attacks along with personal abuse on social media.4 

Trust in BBC News has fallen 20 percentage points in the last five 
years, from 75% to 55%. Equally telling is the proportion who say 
they distrust the BBC, which has grown from 11% to 26% (see next 
chart). The majority of these are from the political right, echoing 
criticism from Boris Johnson’s government about an alleged anti-
Brexit and liberal bias, but we also find that low trust in the BBC 
also comes from those who are less interested in news altogether. 
It is important to note that other big brands in the UK (e.g. the 
Guardian and the Mail) have been affected by growing levels of 
distrust, though not as severely. Declining trust is a particular 
challenge for public media organisations, as they try to fulfil their 
mission to appeal to all audiences.

The continued audience success of some European public media 
makes them a particular target for those who want to influence 
the debates on politics and wider issues around culture. Our survey 
shows that journalists from these organisations are often first to 
be recognised by the public. The outgoing BBC political editor 
Laura Kuenssberg is by far the most well-known journalist in the 
UK, according to respondents to our survey, even when it comes 
to digital news. Broadcasters with a commitment to impartiality, 
including the BBC, make up 62% of all mentions. Journalists from 
public media also feature strongly in data from Finland, France, and 
Germany. But it is a very different story in the United States, where 
partisan cable TV hosts Tucker Carlson, Rachel Maddow, and Sean 
Hannity attract the most attention.

REUTERS INSTITUTE FOR THE STUDY OF JOURNALISM / EXECUTIVE SUMMARY GRAPHS

Graph 13

0% 25% 50% 75% 100%

84

81

80

74

66

59

55

76

75

67

66

62

57

53

86

83

82

80

78

76

75

71

71

69

68

66

57

55

2022

2018

France Télévisions

NHK (Japan)

ORF (Austria)

ZDF (Germany)

ARD (Germany)

SR (Sweden)

SVT (Sweden)

BBC (UK)

CBC (Canada)

ABC (Australia)

RTÉ (Ireland)

NRK (Norway)

DR (Denmark)

Yle (Finland)

PROPORTION THAT TRUSTS SELECTED PUBLIC SERVICE 
MEDIA BRANDS 2018 AND 2022 – SELECTED MARKETS

Q6_2018_trust. How trustworthy would you say news from the following brands is? Please use 
the scale below, where 0 is ‘not at all trustworthy’ and 10 is ‘completely trustworthy’. Base: All in 
2018 and 2022 that had heard of each brand (n ≈ 2000). Note: Showing scores  6–10 on 10-point scale. 

2018

2022

Biggest 
drops

Biggest 
drops

3 During the first week of the conflict, the BBC estimated 280 million people used its news output in the UK and around the world. https://www.independent.co.uk/news/uk/
bbc-ukraine-tim-davie-nadine-dorries-bbc-news-b2047209.html

4 https://www.theguardian.com/uk-news/2022/feb/17/bbcs-sarah-smith-relieved-to-escape-scottish-bile-and-hatred

REUTERS INSTITUTE FOR THE STUDY OF JOURNALISM / EXECUTIVE SUMMARY GRAPHS

Graph 14

PROPORTION THAT TRUSTS THE BBC (2018–22) – UK

Q6_2018_trust. How trustworthy would you say news from the following brands is? Please 
use the scale below, where 0 is ‘not at all trustworthy’ and 10 is ‘completely trustworthy’. 
Base: All in 2018–22 that had heard of the BBC (n ≈ 2000). Note: Trust = % scored  6–10 on 
10-point scale, Don’t trust = 0–4, Neither = 5. 

0%

25%

50%

75%

100% 11 16 17 21 26

75 73
64 62

55

Distrust

Neither trust nor distrust

Trust

20222021202020192018

Conservative
Lib Dem
Other

SNP
Labour

Trust Don’t trustNeither

Those that don’t trust the BBC are  
more likely to be men. Tend to be  
less interested in news and have  
lower levels of education.

More likely to only use social  
media as a source of news. 

Over half of this group voted 
Conservative at the last election 
(2019), two thirds voted for Brexit.

53%

Reuters Institute for the Study of Journalism   |   Digital News Report 2022 17