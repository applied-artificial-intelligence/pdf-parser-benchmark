By firm revenue

Delivery support
It is likely that larger firms were not 
investing as much in their most recent 
fiscal year. In terms of delivery support, 
40% of all respondents at firms with 
more than $20 billion in revenue said 
they had less support, and nearly as 
many at companies with $5.01 billion 
to $20.00 billion said the same.

Note: Numbers may not sum to 100%, because of rounding.

Source: Heidrick & Struggles US professional services partner compensation survey, 2024, n=144

Overall

$1.00bn–$5.00bn

$5.01bn–$20.00bn

More than $20.00bn

Less than $1.00bn

34 13 8 738

2222 17 435

38 12 838 4

40 16 7 533

30 9 6 352

In your most recent fiscal year, did the average delivery support ratio at your firm change? 

Yes, partners had 
less support

No Yes, partners had 
more support

It varied too 
much to say

Don’t know/prefer 
not to answer

Source: Heidrick & Struggles US professional services partner compensation survey, 2024, n=143

No 4
38

Yes, to attract them 8
6

Yes, to retain them 13
8

8
6

Don’t know/prefer 
not to answer

It varied too 
much to say

6
2

Yes, for both attraction 
and retention 67

34

In your most recent fiscal year, did your firm have to pay junior consultants notably more 
than in prior years?

2024 2022

Junior talent (%)Attracting junior talent
In 2024, we saw substantial changes in 
firms’ ability to attract junior consultants. 
Two years ago, when the market 
was significantly more competitive 
and with more work requiring more 
delivery support, 88% of respondents 
said that their firms had to pay junior 
consultants notably more than in 
prior years—for attraction, retention, 
or both—while only 4% said that 
they did not have to do so at all. 

In 2024, these shares have shifted 
dramatically, with nearly 40% saying 
that they did not have to pay junior 
consultants notably more.

Delivery support (%)

Diverse region, inclusive workforces: Diversity and inclusion policy and practice in Asia PacificHEIDRICK & STRUGGLES

13