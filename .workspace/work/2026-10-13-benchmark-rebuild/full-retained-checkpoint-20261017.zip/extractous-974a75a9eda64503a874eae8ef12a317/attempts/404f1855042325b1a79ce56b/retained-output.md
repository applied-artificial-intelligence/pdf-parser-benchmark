18 
 

COVID pandemic due to the massive public intervention schemes, is contracting significantly, 
as the public support is withdrawn. Current levels of new bank finance have fallen below pre- 
pandemic levels (Figure 6), which can partly also be attributed to the increase in interest rates 
seen up until 2024. 

Figure 5: Type of finance used in 2023 by 
SMEs (share of total)  

Figure 6: New bank lending to non-financial 
corporations  

  

Source: The Survey on the Access to Finance of 
Enterprises (SAFE), December 20231  

Source: European Central Bank, MFI Interest Rate 
Statistics2 

3.2 Public investment and infrastructure 

KPI What it measures Latest EU value 

KPI 16: Public investment Public investment (share of GDP) 3.49% (2023) 
3.24% (2022) 

Public investment has slowly trended up over the past years reaching 3.5% of GDP in 
2024, up from 3.1% of GDP in 2018 (KPI 16). While the EU level equals the US public 
spending that also stands at 3.5% of GDP, the funding landscape in the EU is fragmented and 
complex, with most funding carried out at national level. For example, in the case of R&D, 
93% of public funds invested annually are provided through national programmes102. 

At the EU level, the cohesion policy funds, the Recovery and Resilience Facility (RRF) 
and other instruments help finance the green and digital transition103. Since 2021, the RRF 
has paid out EUR 306 billion104, thorough implementation of national plans is needed to ensure 
timely and comprehensive disbursement of remaining amounts. The Cohesion Policy funds 
have disbursed EUR 249 billion in the period 2021 - 2024. The Innovation Fund will provide 
an estimated EUR 40 billion in the current decade for development and deployment of low-
carbon technologies, notably in energy intensive industries, power generation and energy 
storage.  

Despite relevant sources of public financing, such as InvestEU and STEP, a funding gap 
remains for scaling up manufacturing capacities, as less than 5% of the EU clean tech 
funding supports net-zero manufacturing at the highest technology readiness levels (8-9)105. 

 
102  Former Prime Minister Draghi, “The future of European competitiveness – A competitiveness strategy for Europe”, Part 

B, p.236. 
103  Overall, in 2023, the EU budget and NextGenerationEU dedicated 38% of their resources to climate-relevant measures, 

and 19% of their resources to the EU’s digital priorities. 
104  European Commission, Recovery and Resilience Scoreboard. 
105  Technology readiness levels are a measurement of the maturity of a technology, with 1 being the least mature (basic 

research) and 9 being the most mature (ready for launch/operations).  

https://commission.europa.eu/topics/strengthening-european-competitiveness/eu-competitiveness-looking-ahead_en
https://ec.europa.eu/economy_finance/recovery-and-resilience-scoreboard/disbursements.html?lang=en