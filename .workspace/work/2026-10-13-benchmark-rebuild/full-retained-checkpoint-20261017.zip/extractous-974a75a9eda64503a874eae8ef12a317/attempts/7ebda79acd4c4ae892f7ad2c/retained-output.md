15

Overview Progress Appendix

Carbon and Energy Waste and Circularity Packaging Water Biodiversity Human Rights Responsible Supply Chain Sustainable Products Employee Experience Health and Safety Inclusive Experiences Community Impact Responsible Business Practices

Engaging Our Suppliers on Our Decarbonization Journey

Se
t T

arg
et

Share Progress

Reduce Emissions

Set Target

Commit to credible reduction targets 
that support reaching net-zero carbon:

This alignment helps to ensure that our supply chain is 
moving in the same direction and at a pace consistent with 
our own goals. By setting credible targets, suppliers commit 
to a concrete path for emissions reduction, creating 
accountability and driving action.

What does this look like?

• Join The Climate Pledge or 
make a public commitment 
to reach net-zero carbon  
by 2040 or earlier  
(science-aligned).

• Amazon-specific 
commitment to reach  
net-zero carbon by 2040  
or commitment to use 
carbon-free energy.

Share Progress

Measure and regularly report  
performance progress:

This transparency helps to enable suppliers to understand 
their emissions profile, identify hotspots, and execute action 
plans to achieve their decarbonization targets.

What does this look like?

• Public disclosure of corporate 
carbon footprint through  
CDP, EcoVadis, or corporate  
Sustainability Report.

• Share emissions data  
with Amazon directly.

Reduce Emissions

Take action to reduce emissions over time:
We work with suppliers to identify and implement 
activities that reduce their emissions.

What does this look like?
• Adopt carbon-free energy for operations.

• Join The Climate Pledge joint action project(s).

• Pilot lower-carbon technologies with Amazon.

• Visit the Sustainability Exchange for tools to help 
meet target(s).

and resources that have helped us progress toward our 
own climate goals. Topics include carbon measurement, 
transitioning to carbon-free energy, decarbonizing 
buildings and transportation, reducing operational waste, 
and how to purchase high-quality carbon credits. We 
continue to expand and update it regularly—in 2025, we 
included access to content in eight languages, and will 
soon add new regional- and industry-specific content.

We announced a carbon credits service on the 
Sustainability Exchange  in early 2025 to offer high-
quality carbon credits to suppliers with decarbonization 
goals. Credits are only available to companies that have 
set a net-zero carbon emissions target for no later than 
2050, covering Scope 1, 2, and 3 emissions; measure and 
publicly report their carbon footprint on a regular basis; 
and commit to implementing decarbonization strategies in 
line with climate science.

In addition, we work to advance industry collaborations 
and engage suppliers across our business. In 2024, 
highlights included:

• We developed pilot projects to make it easier for 
suppliers to purchase renewable energy certificates 
and  make progress toward their decarbonization goals. 
IPG, a packaging and protective solutions provider, 
matched 100% of the  electricity to power the majority  
of products sold to Amazon in 2024. Pregis, a packaging 
supplier and Climate Pledge signatory, matched 100% 
of the electricity consumed to power operations that 
produce recyclable paper mailers provided to Amazon 
in 2024.

• We worked with our top suppliers on carbon 
measurement and reporting to improve the 
accuracy of emissions calculations and help enable 
suppliers and procurement professionals to manage 
carbon performance quantitatively alongside other 
performance metrics.

• Whole Foods Market encouraged suppliers to adopt 
climate-smart farming methods by partnering with 
Wolfe’s Neck Center, funding and recruiting stakeholders 
to implement regenerative and organic agriculture 
practices that reduce emissions and improve soil health.

• Whole Foods Market collaborated with Windfall Bio, 
a Climate Pledge Fund recipient, to successfully pilot 
its methane-eating microbes with dairy suppliers to 
convert manure emissions, which can be up to 80 times 
more potent than CO₂ emissions, into organic fertilizer.19

• Amazon Private Brands held carbon abatement 
workshops for suppliers focused on discussing challenges, 
identifying abatement opportunities, as well as 
collaboratively solving problems across materials, energy, 
sourcing, and packaging. We increased participation from 
10 suppliers in 2023 to 35 in 2024.

• Amazon Private Brands held a carbon-free energy forum 
with suppliers in China and Vietnam to promote increased 
use of carbon-free electricity within the Amazon Private 
Brands supply chain. 

• Amazon Devices received commitments from 93 suppliers 
in 2024, up from 49 suppliers in 2023, to reduce their 
manufacturing emissions. We also supported 38 Device 
suppliers—representing 80% of our direct manufacturing 
spend for Echo, Kindle, Fire tablet, Fire TV, Ring, Blink, 
and eero devices and accessories—in developing 
renewable energy plans.

• AWS partnered with suppliers across semiconductor and 
electronics manufacturing industries to set emission 
reductions roadmaps and increase the adoption of 
carbon-free electricity. AWS is also a member of SEMI’s 
Semiconductor Climate Consortium (SCC) and worked to 
increase access to carbon-free power and decarbonization 
standards and tools for the semiconductor industry.

https://www.aboutamazon.com/news/sustainability/amazon-carbon-credit-service-sustainability
https://www.aboutamazon.com/news/sustainability/amazon-carbon-credit-service-sustainability