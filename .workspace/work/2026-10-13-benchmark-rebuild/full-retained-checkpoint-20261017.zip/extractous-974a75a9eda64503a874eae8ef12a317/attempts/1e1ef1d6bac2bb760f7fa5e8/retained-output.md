Technology/IT consulting 20 4 1660

By firm type

Note: Numbers may not sum to 100%, because of rounding.

Source: Heidrick & Struggles US professional services partner compensation survey, 2024, n=143

Overall

$1.00bn–$5.00bn

$5.01bn–$20.00bn

More than $20.00bn

Less than $1.00bn

38 6 848

39

28

9

8

448

64

43 5 943

36 9 945

No Yes, to attract and/or retain them It varied too much to say Don’t know/prefer not to say

By firm revenue

Overall 38 6 848

Other 31 1950

Strategy consulting 49 7 1430

No Yes, to attract and/or retain them It varied too much to say Don’t know/prefer not to say

Strategy consulting respondents 
least often said they had to pay 
junior consultants more, while 
technology and IT consulting 
respondents most often said they 
had to pay junior consultants more. 

Junior talent (%)

In your most recent fiscal year, did your firm have to pay 
junior consultants notably more than in prior years?

In your most recent fiscal year, did your firm have to pay 
junior consultants notably more than in prior years?

Respondents at the largest firms 
least often said they needed to pay 
junior consultants more; still, two-
thirds of respondents at companies 
with revenue between $5 billion and 
$20 billion said that they did have 
to pay junior consultants notably 
more compared to prior years. 

Management/advisory 
consulting 41 354 2

2024 US PROFESSIONAL SERVICES PARTNER COMPENSATION SURVEY

14