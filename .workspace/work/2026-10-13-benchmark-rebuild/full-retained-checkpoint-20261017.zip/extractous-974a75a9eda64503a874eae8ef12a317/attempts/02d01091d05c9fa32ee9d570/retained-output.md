10

BURSA MALAYSIA BERHAD

OUR VALUE CREATION MODEL

Rewarding Our
Shareholders
through regular payment of 
dividends. Since our listing in 2005, 
we have returned more than 90% 
of our profits through dividends.

Advancing  
Our Business
to achieve continued growth 
and ensure the creation of  
long-term value.

Investing In  
Our Talent Pool
to develop a data-driven  
High-Performance Organisation 
(HPO) which is focused on 
growth and sustainable,  
long-term value creation.

Contributing
To Society
to continue empowering local 
communities through taxes, 
Yayasan Bursa Malaysia’s 
scholarships, donations and 
financial aid.

Sustaining  
Long-Term Value
for our future investment 
needs in order to create 
long-term sustainable value 
for our stakeholders.

TOTAL FINANCIAL VALUE CREATED IN 2019 : RM502.5 MILLION NON-FINANCIAL VALUE

2019

2018

2017

2016

2015

RM 112.3 million

105.9

112.6

107.1

105.0

2019

2018

2017

2016

2015

RM 133.7 million

135.3

137.5

128.6

133.9

2019

2018

2017

2016

2015

RM 66.9 million

78.2

76.5

68.4

73.1

2019

2018

2017

2016

2015

RM 168.2 million

11.6

12.3

11.3

12.0

2019

2018

2017

2016

2015

RM 21.4 million

23.9

23.3

20.3

22.0

Funds Reinvested >

Employee Remuneration and 
Investment >

Contributions to 
Our Communities >

Retained Earnings >

10.4 10.4

14.0

13.3

11.3

11.0

ENHANCING

CUSTOMER EXPERIENCE

Creating a more facilitative 
trading environment for 

investors, developing new 
innovative solutions such 

as e-services, and ensuring 
sound investor protection and 

governance

Offering a wide range of 
investment options and serving 
as one of the leading ASEAN 

destination for fundraising and 
Islamic capital market activities

SUPPORTING COMMUNITIES

Committed to being a 
responsible corporate citizen  

by contributing our time, 
expertise and knowledge to  

our community

BUILDING A HIGH-PERFORMANCE 

ORGANISATION

Committed to creating a work 
environment for our employees 

that is conducive for their 
personal and professional 

development, forging a culture 
that is innovative, engaging and 
rewarding while investing in the 

training of our employees

Dividend Per Share* >
(excluding special dividend)

Interim Dividend Final Dividend

OUTCOMES AND VALUE CREATED

For more information, refer to pages 53 to 75 
(MD&A)

For more information, refer to page 6  
(Our Products and Services and Our Market 
in the Who We Are Section)

For more information, refer to Chapter 11  
in our SR2019

For more information, refer to Chapter 10  
in our SR2019

For more information, refer to pages 88 to 95 
(Corporate Governance Overview)

For more information, refer to pages 96 to 101 
(Marketplace Report: Fair & Orderly Markets)