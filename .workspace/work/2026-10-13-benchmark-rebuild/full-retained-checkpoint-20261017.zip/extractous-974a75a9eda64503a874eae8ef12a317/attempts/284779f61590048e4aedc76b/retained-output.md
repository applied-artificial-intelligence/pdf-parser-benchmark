 173 

 

DO ADULTS HAVE THE SKILLS THEY NEED TO THRIVE IN A CHANGING WORLD? © OECD 2024 
  

Figure 4.13. Mismatches in qualifications, skills and field of study 

Employed adults aged 25-65 who are not self-employed 

 
Note: Does not include adults who were only administered the doorstep interview due to a language barrier (see Box 1.1 in Chapter 1 and 

Box 4.1). Mismatch measures are defined in Table 4.2 and Box 4.3. *Caution is required in interpreting results due to the high share of 

respondents with unusual response patterns. See the  ote for Poland in the Reader’s Guide. 

Countries and economies are ranked in descending order of the share of workers who are over-qualified (Panel A), over-skilled (Panel B) and 

field of study mismatched (Panel C). 

Source: Table A.4.12 in Annex A. 

  er qualified Under qualified

  er skilled Under skilled

E
ng

la
n
d 
(U

 
 

 a
p
a
n

Is
ra
e
l

 
e
w
  

ea
la
n
d

 
or
e
a

 i
th
ua

n
ia

G
e
rm

a
ny

C
an

ad
a

A
u
st
ri
a

U
ni
te
d 
S
ta
te
s

 
a
t 
ia

E
st
o
n
ia

H
u
ng

a
ry

C
 e

ch
ia

 
E
C
 
 a
v
er

a
g
e

Ir
el
a
n
d

S
w
e
de

n

S
p
a
in

 
e
n
m
a
rk

F
in
la
n
d

C
h
ile

F
ra
n
ce

S
lo
 a

k 
R
ep

u
b
lic

 
e
th
e
rl
a
n
d
s

 
o
rw

ay

It
a
ly

C
ro
a
tia

S
w
it
 e

rl
a
n
d

P
o
rt
ug

a
l

S
in
g
a
p
or
e

F
le
m
is
h 
R
e
g
io
n 
( 

E
 

P
o
la
n
d
 

 0

 0

 0

30

20

10

0

  .  ualification mismatc 

Is
ra
e
l

U
ni
te
d 
S
ta
te
s

C
an

ad
a

 
e
w
  

ea
la
n
d

E
ng

la
n
d 
(U

 
 

Ir
el
a
n
d

G
e
rm

a
ny

 
e
n
m
a
rk

C
ro
a
ti
a

S
lo
 a

k 
R
ep

u
b
lic

S
w
e
de

n

C
 e

ch
ia

 
e
th
e
rl
a
n
d
s

 
E
C
 
 a
v
er

a
g
e

H
u
ng

a
ry

F
ra
n
c
e

P
o
rt
ug

a
l

C
h
ile

A
u
st
ri
a

 
or
e
a

S
w
it
 e

rl
a
n
d

S
p
a
in

F
le
m
is
h 
R
e
g
io
n 
( 

E
 

S
in
g
a
p
or
e

E
st
o
n
ia

 
o
rw

ay

 
a
t 
ia

It
a
ly

F
in
la
n
d

P
o
la
n
d
 

 i
th
ua

n
ia

 a
p
a
n

 0

 0

 0

30

20

10

0

 B.   ill mismatc 

 
or
e
a

 a
p
a
n

 
e
w
  

ea
la
n
d

S
p
a
in

E
st
o
n
ia

C
 e

ch
ia

 
a
t 
ia

P
o
rt
ug

a
l

E
ng

la
n
d 
(U

 
 

It
a
ly

F
le
m
is
h 
R
e
g
io
n 
( 

E
 

U
ni
te
d 
S
ta
te
s

C
an

ad
a

F
ra
n
ce

 
E
C
 
 a
v
er
a
g
e

S
w
it
 e

rl
a
n
d

Ir
e
la
n
d

Is
ra
e
l

 i
th
ua

n
ia

S
lo
 a

k 
R
ep

u
b
lic

S
in
g
a
p
or
e

C
h
ile

H
u
ng

a
ry

S
w
e
de

n

P
o
la
n
d
 

 
e
n
m
a
rk

G
e
rm

a
ny

 
o
rw

ay

A
u
st
ri
a

C
ro
a
tia

 
e
th
e
rl
a
n
d
s

F
in
la
n
d

 0

 0

 0

30

20

10

0

 C.  ield of study mismatc