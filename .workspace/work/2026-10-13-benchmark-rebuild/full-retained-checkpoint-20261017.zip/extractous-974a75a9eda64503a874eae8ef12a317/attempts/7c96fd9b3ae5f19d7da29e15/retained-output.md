Net sales $23.1 billion, +5.7%, Net sales without fuel +7.1%, eCommerce +24%

• Comp sales strength driven by increases in 
transactions and unit volumes

◦ Transactions ex fuel: +5.4%
◦ Average ticket ex fuel: +1.3%

• Strength in food and health & wellness

• Share gains in grocery and general 
merchandise categories, including apparel 
and consumer electronics (per Circana)

• Growth in eCommerce sales of +24%; 
driven by momentum in delivery from club

• Digital penetration (members using Scan 
and Go or shopping online) hit all-time high

• Member's Mark grew high single-digits, 
outpacing segment comp

eComm Cont. 
without fuel +190 bps +180 bps +230 bps +290 bps +280 bps

1 Comp sales for the 14-week period ended January 31, 2025 compared to the 14-week period ended February 2, 2024.

Sam’s Club U.S. revenues

1.9%

3.5%

4.6%

3.7%

5.3%

3.1%

4.4%

5.2%

7.0% 6.8%

With fuel Without fuel

Q4 FY24 Q1 FY25 Q2 FY25 Q3 FY25 Q4 FY25

19

Sam's Club U.S. comp sales1