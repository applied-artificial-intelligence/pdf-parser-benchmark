FINANCIAL HIGHLIGHTS18

Net revenues  . . . . . . . . . . . . . . . . . . . . . . . . . $ 4,238,104 $ 3,862,743 $ 3,756,928 $ 3,699,852 $ 2,910,580

Operating income . . . . . . . . . . . . . . . . . . . . . . 950,860 699,729 746,538 599,892 515,197

Income from continuing operations  . . . . . . . . . 349,856 230,273 289,476 160,440 153,585

Net income  . . . . . . . . . . . . . . . . . . . . . . . . . . 412,332 243,697 292,435 169,815 160,744

Basic earnings per share

Income from continuing operations  . . . . . . $ 2.51 $ 1.55 $ 1.83 $ 1.01 $ 1.06

Net income per share  . . . . . . . . . . . . . . . . 2.95 1.64 1.85 1.07 1.11

Weighted average number of shares  . . . . . . . 139,663 148,930 157,809 158,771 145,300

Diluted earning per share

Income from continuing operations  . . . . . . $ 2.42 $ 1.52 $ 1.81 $ 1.00 $ 1.04

Net income per share  . . . . . . . . . . . . . . . . 2.85 1.61 1.83 1.06 1.09

Weighted average number of shares  . . . . . . . 144,666 151,592 159,940 160,822 147,901

Cash dividends per share (1)  . . . . . . . . . . . . . . $ — $ — $ — $ — $ 0.10 

At year-end

Total assets  . . . . . . . . . . . . . . . . . . . . . . . . . $11,115,029 $10,811,269 $10,568,698 $10,542,568 $10,785,720

Total debt, including capital leases  . . . . . . . 5,463,619 5,533,462 5,222,195 5,465,608 5,880,819

Stockholders’ equity  . . . . . . . . . . . . . . . . . 2,771,704 2,533,788 2,664,144 2,510,700 2,382,445

Stockholders’ equity per share  . . . . . . . . . . $ 19.75 $ 17.71 $ 17.24 $ 15.95 $ 14.97

Number of shares outstanding . . . . . . . . . . . . 140,370 143,096 154,574 157,396 159,130

(1) On December 13, 1999, the Board of Directors approved an initial quarterly cash dividend of $0.10 per share to stockholders of record on February 10, 2000. The dividend was
paid on March 1, 2000. As a result of the acquisition of Mirage Resorts, Incorporated, we announced on April 19, 2000 that the quarterly dividend policy was discontinued.

The acquisition of Mirage Resorts occurred on May 31, 2000. In June 2003, we ceased operations of PLAYMGMMIRAGE.com, our online gaming website (“Online”). In January
2004, we sold the Golden Nugget Las Vegas and the Golden Nugget Laughlin including substantially all of the assets and liabilities of those resorts (the “Golden Nugget
Subsidiaries”). In July 2004, we sold the subsidiaries that own and operate MGM Grand Australia. The results of Online, the Golden Nugget Subsidiaries and MGM Grand Australia
are classified as discontinued operations for all periods presented.

2004 2003 2002 2001 2000For the Years Ended December 31 

(in thousands except share and per share data)

2004

N
E

T
 R

E
V

E
N

U
E

$– $3,500 $3,750 $4,000 $4,250 $4,500  ($Millions)

2003

2002

2004

$– $600 $700 $800 $900 $1,000 ($Millions)

2003

2002

2004

$– $200 $250 $300 $350 $400 $450 ($Millions)

$412

$244

$292

2003

2002

$4,238

$3,863

$3,757

$951

$700

$747

O
P

E
R

A
T

I
N

G
 I

N
C

O
M

E
N

E
T

 I
N

C
O

M
E