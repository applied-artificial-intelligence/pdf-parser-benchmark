2024 UN E-GovErNmENt SUrvEy

148

C
h

ap
ter 4

Figure 4.11 Implementation of participation and engagement indicators in city portals

Most city portals incorporate feedback mechanisms to promote and facilitate resident engagement. 
Malé,16 the capital of the Maldives and its most populous city, pledges to process all duly completed 
feedback submissions within five business days. Rome allows residents to submit suggestions, 
comments, complaints, and even reports relating to local government activities or offices and is 
committed to responding within thirty days, identifying the relevant office and personnel overseeing 
the investigation and providing information on actions taken. The city of Dublin informs its residents of 
the avenues available to report various issues to designated service areas without requiring adherence 
to formal complaint procedures. Formal complaints directed towards the Dublin city council17 can be 
lodged via post, email or online through the citizen Hub, with assurances of a formal acknowledgment 
within three working days and an expected response from the relevant department within twenty-
one days. Dissatisfied individuals can escalate their complaint to the executive manager within fifteen 
working days and further to the Office of the Ombudsman if the problem persists.

E-voting is not strictly limited to electoral processes, often extending to decision-making on various 
initiatives, projects or ideas within city portals. The availability and utility of this option varies. Some 
platforms showcase e-voting functionality for specific projects or competitions, with evidence of 
past engagement but limited current activity. Others require registration to access e-voting results 
or offer opportunities for online voting on specific topics. In some instances, e-voting is integrated 
into participatory budgeting schemes. While these examples are encouraging, widespread 
implementation remains uncommon, with sporadic instances of e-voting observed across different 
municipalities. Although some platforms provide clear avenues for citizens to participate in e-voting 
opportunities, the policy impact of these contributions remains unclear in certain cases. Overall, 
while e-voting services are present in various forms, they often represent a minority among the 
participation mechanisms available within city portals.

E-government literacy 

In the 2024 edition of the E-Government Survey, UN DESA introduces the concept of e-government 
literacy to measure the ability of residents – especially vulnerable groups – to utilize e-government 
services and take advantage of e-participation opportunities. In the present analysis, e-government 
literacy is based on the assessment of key features within government portals, including support 
services, privacy protection, digital identity authentication, and access to online resources, as these 
indicators are aligned with enhancing digital literacy and engagement across diverse domains. 
Although e-government literacy was not a specific category in 2022, many of its indicators were 

18%

25%

31%

31%

32%

40%

42%

47%

66%

15%

24%

26%

31%

28%

37%

40%

40%

61%

0% 10% 20% 30% 40% 50% 60% 70%

E-voting

Feedback about consultation processes

Participatory budgeting

Announcement of upcoming
e-participation activities

Participatory land use planning

Online deliberation processes

Reporting of incidents in public spaces

Information on the public meetings
of the municipal council

Feedback/complaint submission

2022 2024