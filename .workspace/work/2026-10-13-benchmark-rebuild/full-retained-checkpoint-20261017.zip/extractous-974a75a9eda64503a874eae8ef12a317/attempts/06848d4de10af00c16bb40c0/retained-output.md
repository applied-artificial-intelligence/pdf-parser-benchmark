Investing in Education 2025 
10   Part 1: Early signs of a moderate rebound in investment in education  

 
 
 
 
 
 

 
 

The first part of this report looks at the latest data1 on education investment (2023)2 and long-term 
trends. 2022 marked the exit from any Covid-19-related measures for EU education systems (UNESCO, 2022). 
In some EU countries, learning outcomes started to recover in 2023 compared to the period right after 
COVID-19, thanks to compensatory measures in schools (e.g. targeted additional support for underachieving 
students or more focused curricula; see Schnepf et al., 2024). However, research at national level suggests that 
pandemic-related learning losses are likely to persist over the medium-to-long term without effective remedial 
policy action at system level (Di Pietro, 2023; Maldonado et al., 2024). Moreover, learning outcomes were 
already declining in the EU before the pandemic (European Commission, 2024b), pointing to structural 
challenges that education systems have to address, such as the impact of socio-economic background, teacher 
shortages, declining parental involvement and digital distraction (European Commission, 2025a).  

Public expenditure on education in the EU amounted to 9.6% of total public expenditure and 4.7% 
of GDP in 2023.3 At the country level, the former varied from 14.5% in Estonia and Sweden to 7.3% in Italy; 
the latter ranged from 7.2% in Sweden to 2.8% in Ireland (Figure 1).4 The correlation between these two 
indicators is strongly positive, but not perfect (Figure 2). This depends on the different size of total public 
expenditure in each economy,5 reflecting the variety of long-term approaches to welfare in EU countries.   

Figure 1. Public expenditure on education (2023) 

 
Notes:  Provisional data for BE, DE, ES, FR, PT, SK. See footnote 4 for IE. 
Source:  Eurostat COFOG data. Online data code: [gov_10a_exp]. 

 
1  Eurostat releases data on government expenditure by function (COFOG) for year t in late February/early March of year 

t+2. The most recent data available in 2025 refers to 2023. 
2  This report will use ‘investment in education’ interchangeably with ‘public expenditure on education’. 
3  In monetary terms, this amounted to €806 billion. 
4  The low value of this indicator for Ireland (2.8%) is explained by the specific structure of the Irish economy. In most 

countries, GDP and Gross National Product (GNP) are very close in value, but in Ireland GDP is larger than GNP because 
of negative net factor income: income outflows are much larger than income inflows due to the presence of many 
foreign-owned multinational firms, which pay their profits back to their owners abroad (Central Statistics Office, 2025). 
Consequently, public expenditure on education as a share of GNP would be higher than as a share of GDP. 

5  The mathematical relationship between the two indicators is expressed as:  
(expenditure on education/GDP) = (expenditure on education/total expenditure) * (total expenditure/GDP). 

https://ec.europa.eu/eurostat/databrowser/view/gov_10a_exp__custom_16025691/default/table?lang=en