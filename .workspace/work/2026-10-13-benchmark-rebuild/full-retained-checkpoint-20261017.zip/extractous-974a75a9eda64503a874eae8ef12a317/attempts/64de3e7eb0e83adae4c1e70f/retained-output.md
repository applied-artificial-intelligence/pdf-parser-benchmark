17 
 

3.3 Water Purifier Market Size 
 

The Indian water purifier market has exhibited continuous growth over the years. It has grown at a CAGR of 

~4.9% from INR 6,960 crore in FY2019 to INR 8,860 crore* in FY2024 and is further expected to grow at a 

CAGR of ~10.1% till FY2029 to reach a market value of INR 14,350 crore.  
*All the market value figures in this report are at the consumer price level, unless otherwise specified. 
 

The high growth rate of the water purifier market can be attributed to various factors, including increasing 

population, rising disposable income, growing water contamination, a surge in cases of water-borne diseases, 

increasing health consciousness among individuals, and the growth in electrification. As awareness of water 

contamination and the benefits of purified water increases, it is expected that more households will invest in water 

purifiers, driving market growth. In particular, Tier-2 cities in India are expected to experience higher growth in 

the near future.   

 

Exhibit 3.3: Indian Water Purifier Market- By Value (in INR crore) (FY) 

 

  
Source: Technopak Analysis 
Note: This does not include exports. 

Market size at consumer price level is the addition of mark up of industry level channel margins to the market size at wholesale level, which 
is on the manufacturer’s realization. 

 

3.3.1 Water Purifier (Product) Market in India 
 

The Indian water purifier product market has exhibited continuous growth over the years. It has grown at a CAGR 

of ~5% from INR 3,800 crore in FY2019 to INR 4,860 crore in FY2024 and is further expected to grow at a 

CAGR of ~10% till FY2029 to reach a market value of INR 7,830 crore. 

 

Exhibit 3.4: Indian Water Purifier Product Market- By Value (in INR crore) (FY) 

  
Source: Technopak Analysis 
 

3,800 
4,860 

7,830 

3,160 

4,000 

7,110 

2019 2024 2029 P

Service

Product

3,800 
4,860 

7,830 

2019 2024 2029 P

6,960 

 

 

 

 

 

 

 

 

 

 

 

 

 

 

 

 

 

 

 

 

 

 

 

 

 

 

 

 

 

 

 

 

 

 

 

 

 

8,860 

14,350