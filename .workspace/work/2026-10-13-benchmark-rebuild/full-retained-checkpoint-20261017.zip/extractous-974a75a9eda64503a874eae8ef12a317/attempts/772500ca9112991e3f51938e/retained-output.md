 59 

OECD EMPLOYMENT OUTLOOK 2024 © OECD 2024 
  

Annex Figure 1.C.1. Minimum wage evolution, May 2019 to May 2024 

Nominal and real minimum wage, cumulative percentage change since May 2019 

 

-20

-10

0

10

20

30

40

50

60

Australia

-20

-10

0

10

20

30

40

50

60

Belgium

-40

0

40

80

120

160

Canada 
Federal Jurisiction

Nominal minimum wage Real minimum wage

-20

0

20

40

60

Canada
Weighted

-20

-10

0

10

20

30

40

50

60

Chile

-20

-10

0

10

20

30

40

50

60

Colombia

-20

-10

0

10

20

30

40

50

60

Costa Rica

-20

-10

0

10

20

30

40

50

60

Czechia

-20

-10

0

10

20

30

40

50

60

Estonia

-20

-10

0

10

20

30

40

50

60

France

-20

-10

0

10

20

30

40

50

60

Germany

-20

-10

0

10

20

30

40

50

60

Greece

-30

-15

0

15

30

45

60

75

90

Hungary

-20

-10

0

10

20

30

40

50

60

Ireland

-20

-10

0

10

20

30

40

50

60

Israel