 67 

 

DO ADULTS HAVE THE SKILLS THEY NEED TO THRIVE IN A CHANGING WORLD? © OECD 2024 
  

As proficiency in literacy and numeracy is correlated (OECD, 2016[4]), adults with low proficiency in one 

domain are also likely to have low proficiency in other domains. Figure 2.5 shows the share of adults with 

low proficiency in all three domains. This share is highest in Chile (44%) and lowest in Japan (7%). 

Figure 2.5 also presents the percentage of low-performing adults in literacy and numeracy only. This share 

ranges between 48% in Chile and 8% in Japan. 

Figure 2.5. Share of adults who are low performing in more than one domain 

16-65 year-olds scoring at or below Level 1 in more than one domain  

 

Note: Includes adults who were only administered the doorstep interview due to a language barrier (see Box 1.1 in Chapter 1). *Caution is 

required in interpreting results due to the high share of respondents with unusual response patterns. See the  ote for Poland in the Reader’s 

Guide. 

Countries and economies are ranked in descending order of the share of adults performing at or below Level 1 in all three domains. 

Source: Table A.2.3 in Annex A. 

Aggregate inequality in the distribution of skills  

Aggregate skills inequalities can be measured by the dispersion of the distribution of skills within each 

country or economy. One measure of such dispersion is the inter-decile range, i.e. the distance between 

the 90th percentile of the national skills distribution (the score below which 90% of adults perform) and the 

10th percentile of the national skills distribution (the score below which 10% of adults perform). 

On average, the inter-decile range in literacy in participating OECD countries and economies is 140 points 

(Figure 2.6, Panel A). Inequality is particularly pronounced in Singapore and the United States, where the 

inter-decile range exceeds 160 points. The distribution is more compressed in Lithuania and 

the Slovak Republic, where the inter-decile range is below 115 points. 

In numeracy, the inter-decile range in participating OECD countries and economies averages 144 points 

(Figure 2.6, Panel B). The difference is widest in New Zealand, Portugal, Singapore and the United States, 

where the inter-decile range exceeds 160 points, while it is more compressed in Japan, Lithuania and 

the Slovak Republic, where the inter-decile range is below 130 points. 

In adaptive problem solving, the inter-decile range averages 119 points (Figure 2.6, Panel C). Variation is 

widest in New Zealand and the United States, with the inter-decile range exceeding 140 points. The skills 

distribution is more compressed in Lithuania and the Slovak Republic, where the inter-decile range is lower 

than 100 points. 

At or bel ow  e el 1 in literacy, numeracy and adapti e problem sol ing

At or below  e el 1 in literacy and numeracy

 0

  

 0

3 

30

2 

20

1 

10

 

0

C
h
ile

P
o
rt
ug

a
l

P
o
la
n
d 

It
al
y

Is
ra
e
l

 i
th
ua

n
ia

U
ni
te
d 
S
ta
te
s

H
un

g
a
ry

S
pa

in

F
ra
n
ce

 
or
ea

 
at
 i
a

C
ro
a
tia

 
ew

  
ea

la
nd

 
E
C
 
 a
ve

ra
g
e

A
us

tr
ia

S
in
g
a
p
or
e

C
 e

ch
ia

G
er
m
a
ny

S
w
it
 e

rl
a
nd

Ir
el
a
nd

S
lo
 a

k 
R
ep

u
bl
ic

E
ng

la
n
d 
(U

 
 

C
an

ad
a

F
le
m
is
h 
R
e
gi
o
n 
( 

E
 

 
e
nm

ar
k

E
st
o
ni
a

 
et
he

rl
a
n
ds

 
or
w
ay

F
in
la
nd

S
w
ed

e
n

 a
p
an