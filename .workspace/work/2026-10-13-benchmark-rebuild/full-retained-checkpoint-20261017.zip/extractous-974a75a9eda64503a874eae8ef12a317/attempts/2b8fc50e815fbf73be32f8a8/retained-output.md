The BEAT | June 2025

4.29%

4.06%

3.80%

3.62% 3.55%

4.49%

4.23%

3.95%

3.74%

3.61%

0.47%
0.58%

0.74%
0.83% 0.86%

2.48%

1.95%

1.66%
1.72%

1.85%

0.0%

1.0%

2.0%

3.0%

4.0%

5.0%

3M 6M 1Y 2Y 3Y

BOE

U.S. Federal Reserve

ECB

BOJ

4.27%

3.98%

3.54%

3.30%

3.50%

4.11%

3.92%
3.68% 3.66%

3.79%

0.55%
0.66%

0.82%

1.05%
0.99%

1.91%

1.76% 1.67%

1.88%

2.17%

0.0%

1.0%

2.0%

3.0%

4.0%

5.0%

3M 6M 1Y 2Y 3Y

BOE

U.S. Federal Reserve

ECB

BOJ

(1%)

0%

1%

2%

3%

4%

5%

6%

7%

8%

9%

10%

'98 '00 '02 '04 '06 '08 '10 '12 '14 '16 '18 '20 '22 '24

BOE U.S. Federal Reserve

ECB

BOJ

Monetary Policy

Source: Bloomberg, Factset as of 5/31/25. Data provided is for informational use only. See end of report for important additional information. Forecasts/estimates are based on current 
market conditions, subject to change, and may not necessarily come to pass.

Current 1-Mo. Ago 12-Mo. Ago

U.S. Federal Reserve 4.50% 4.50% 5.50%

BOE 4.25% 4.50% 5.25%

BOJ 0.50% 0.50% 0.10%

ECB 2.40% 2.40% 4.50%

Market Expectations for Future Central Bank RatesCentral Bank Policy Rates

BONDS

22