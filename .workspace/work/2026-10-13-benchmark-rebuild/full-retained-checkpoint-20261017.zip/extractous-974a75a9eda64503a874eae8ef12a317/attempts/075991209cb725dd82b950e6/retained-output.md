67European Innovation Scoreboard 2025

Slovakia (-17.8%-points), and Romania (-14.2%-points) all saw more moderate but 
consistent drop.

Box 5: Country level observations for Emerging Innovators

Hungary showed strong and continuous progress, rising from 62.1%-of the EU average 
in 2018 to 78.3% in 2025, with marked gains after 2021. 

Poland recorded consistent growth over the period, improving from 56.1 in 2018 to 74.2 
in 2025, with notable acceleration after 2022. 

Slovakia moved from 62.2 in 2018 to a high of 71.6 in 2024, before a modest drop to 
70.5 in 2025. 

Latvia remained relatively stable, increasing gradually from 59.0 in 2018 to 63.9 in 
2025, despite a small dip in 2021. 

Bulgaria improved steadily from 45.2 in 2018 to a peak of 53.8 in 2024, before a slight 
decline to 51.6 in 2025. 

Romania progressed slowly, rising from 34.2 in 2018 to 42.4 in 2025, despite a slight 
dip in 2023.

Figure 26: Performance Emerging Innovators

Note: Performance is relative to that of the EU in 2018. The graph on the left shows the average performance of 

the Emerging Innovators calculated as the unweighted average of the respective Member States. All vertical 

scales in Figure 23-Figure 26 span a range of 70.0%-points to allow an easy comparison of the results between 

the four performance groups.

20

30

40

50

60

70

80

90

'18 '19 '20 '21 '22 '23 '24 '25

S
um

m
ar

y 
in

no
va

tio
n 

in
de

x

Bulgaria

Hungary

Latvia

Poland

Romania

Slovakia

20

30

40

50

60

70

80

90

'18 '19 '20 '21 '22 '23 '24 '25

S
um

m
ar

y 
in

no
va

tio
n 

in
de

x