26 Swiss Re Institute sigma No 1/2025  

Number of catastrophic events: 336

In terms of sigma criteria, there were 336 catastrophes worldwide in 2024, up from 334 
in 2023. There were 228 natural catastrophes (up from 219 in 2023), and 108 man-
made disasters (down from 115 in 2023). 

Number of victims: 14 083

Worldwide, 14 083 people are believed to have died or gone missing in disaster events 
in 2024. Natural catastrophes claimed 10 822 victims. Man-made disasters claimed a 
further 3 261 victims.

Appendix: facts and figures

Figure 16 
Number of catastrophic events, 1970 ‒ 2024

Sources: Swiss Re Institute 

0

50

100

150

200

250

300

2024202120182015201220092006200320001997199419911988198519821979197619731970

Natural catastrophesMan-made disasters

Figure 17 
Number of victims, 1970 - 2024

Note: Scale is logarithmic: the number of victims increases tenfold per band. Source: Swiss Re Institute

1 000

10 000

100 000

1 000 000

10 000 000

2021 202420182015201220092006200320001997199419911988198519821979197619731970

Man-made disasters Natural catastrophes

1970: Bangladesh 
storm, Peru 
earthquake

1976: Tangshan 
Earthquake, China

1991: Cyclone Gorky, 
Bangladesh

2004: Indian Ocean
Earthquake and tsunami

2008: Cyclone Nargis,
Myanmar

2010: Haiti
Earthquake

2023: 
Turkey & Syria 

earthquake