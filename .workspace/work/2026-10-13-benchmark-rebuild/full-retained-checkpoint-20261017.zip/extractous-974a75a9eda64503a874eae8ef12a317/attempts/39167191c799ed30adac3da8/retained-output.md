Renewables 2025 Chapter 1. Renewable electricity 
Analysis and forecasts to 2030 
 

PAGE | 24  I E
A.

 C
C

 B
Y

 4
.0

. 

previously to a trend-based assessment supported by historical data (see the 
section below on the role of wind and solar PV in power systems).  

Solar PV alone accounts for over 60% of the generation increase, followed by wind 
(32%). The share of renewables in global electricity generation is projected to rise 
from 32% in 2024 to 43% by 2030, while the share of variable renewable energy 
sources is set to almost double to 28%. 

Global renewable power generation in 2024 and 2030, and change by technology 

 
IEA. CC BY 4.0. 

Notes: VRE = variable renewable energy. “VRE share” includes solar PV and wind. 
 

Hydropower electricity generation is expected to increase 7% over 2025-2030 as 
new projects become operational, mostly in emerging and developing countries. 
However, its share in global electricity generation decreases slightly, by almost 
one percentage point to 14% in 2030. Hydropower will account for just 30% of 
global renewable electricity generation in 2030, a sharp decline from over 80% 
two decades ago.  

In contrast, the role of solar PV and wind increases drastically: in 2030, variable 
renewables account for almost two-thirds of global renewable electricity 
generation, rising from less than 46% today. Solar PV is expected to generate 
more electricity than hydropower by the end of the forecast period and to become 
the largest renewable energy source. Onshore and offshore wind generation are 
also expected to grow rapidly, together reaching over 4 500 TWh by 2030.  

Clearly, the increased use of variable renewables raises the need for additional 
sources of power system flexibility. Nevertheless, bioenergy, geothermal and 
concentrated solar power expansions remain limited despite their critical role in 
integrating wind and solar PV generation into electricity systems around the world. 

15%

28%
32%

43%

0%

10%

20%

30%

40%

50%

60%

70%

80%

90%

0

2 000

4 000

6 000

8 000

10 000

12 000

14 000

16 000

18 000

2024 Hydropower Solar PV Wind Bioenergy Other
renewables

2030

Generation Change Generation

TW
h/

ye
ar

VRE share Renewables share