CONSULTANCY IN SPAIN / The 2024 industry in figures

10

/ /

14,517
13,714

12,944
12,19011,270

14,538 15,921

19,659

+0.1%+5.9%+5.9%+6.2% +9.5% +15.2%*

21,575

+9.7%

21,982

+8.8%*

2024

The revenue brought in by consulting firms in 2024 totaled 21,982 million euros, which accounts for 8.8% 
growth in comparison to the year before. This upward trend observed held steady another yet another 
year again, reaffirming the relevant contribution of consulting firms to the digital transformation within 
companies and government agencies, and the industry’s leading role in adapting business models to a 
continuously evolving environment.

Consulting Industry 
Revenue

The consulting industry grew 
8.8% in 2024, driven by increased 
revenue in the national market

 

The consulting industry continues to grow (millions of euros)

Source: AEC (Spanish Association of Consulting Firms)

In the last year, there was a new increase in 
revenue in the national market while there was a 
slight decrease in the foreign market. Revenue in 
Spain totaled 15,381 million euros, which accounts 
for 13.6% growth over 2023, while it totaled 6,601 
million euros in the international market, which 
is 1.1% less than the year before. This behavior 
reinforces the weight of the national market in the 
industry as a whole, all while indicating a slight 

*For a more accurate reading of the data, the comparative analysis of the evolution of revenue and employment between financial 
years 2021-2022 and 2023-2024 (variation rate) was completed taking into consideration only companies that have not gone throu-
gh significant integration or corporate reorganization processes.  These companies represented 82% of all sector revenue in 2021 
and 89% in 2023.

adjustment in the foreign market following several 
years of sustained growth.


	Botón 18: 
	Página 4: 
	Página 6: 
	Página 10: 
	Página 12: 
	Página 14: 
	Página 16: 
	Página 18: 
	Página 20: 
	Página 22: 
	Página 24: 
	Página 26: 
	Página 28: 
	Página 30: 
	Página 32: 
	Página 34: 
	Página 36: 

	  3: 
	Página 4: 
	Página 6: 
	Página 10: 
	Página 12: 
	Página 14: 
	Página 16: 
	Página 18: 
	Página 20: 
	Página 22: 
	Página 24: 
	Página 26: 
	Página 28: 
	Página 30: 
	Página 32: 
	Página 34: 
	Página 36: 

	Botón 19: 
	Página 4: 
	Página 6: 
	Página 10: 
	Página 12: 
	Página 14: 
	Página 16: 
	Página 18: 
	Página 20: 
	Página 22: 
	Página 24: 
	Página 26: 
	Página 28: 
	Página 30: 
	Página 32: 
	Página 34: 
	Página 36: