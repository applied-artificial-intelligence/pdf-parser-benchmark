116    

 

DO ADULTS HAVE THE SKILLS THEY NEED TO THRIVE IN A CHANGING WORLD? © OECD 2024 
  

Figure 3.6. Change in educational attainment of the adult population between cycles  

Difference in the shares of adults with below upper secondary, upper secondary and tertiary education (Cycle 2 

minus Cycle 1); 25-65 year-olds 

 

Note: Does not include adults who in Cycle 2 were only administered the doorstep interview due to a language barrier, to maximise the 

comparability across cycles (see Box 1.1 in Chapter 1 and Box 3.2). See Note 2 for an explanation of the classification of educational attainment. 

*Caution is required in interpreting results due to the high share of respondents with unusual response patterns. See the Note for Poland in the 

Reader’s Guide. 

Countries and economies are ranked in ascending order of the change in the share of tertiary-educated adults. 

Source: OECD (2018[4]; 2015[5]; 2012[6]), Survey of Adult Skills (PIAAC) databases, http://www.oecd.org/skills/piaac/publicdataandanalysis/  

(accessed on 23 September 2024); Table B.3.1 (Trend) in Annex B. 

Changes in skills proficiency by educational attainment 

Across the countries and economies participating in both cycles of the Survey of Adult Skills, declines in 

literacy proficiency were most widespread among low-educated adults (Figure 3.7). The average 

proficiency of adults with below upper secondary education significantly decreased between the two cycles 

in all countries and economies except in Canada, Denmark, Finland, Israel, Spain and Sweden. These 

decreases ranged from 12 points in the Flemish Region (Belgium) to 46 points in Lithuania. The proficiency 

of adults with upper secondary education fell in 19 countries and economies, remained unchanged in 7, 

and increased in Finland. Among tertiary-educated adults, average proficiency fell in 13 countries and 

economies, and only increased in Finland.  

Changes in numeracy followed a similar pattern, with declines in numeracy proficiency being more 

common among low-educated adults (see Table A.3.11 (N) in Annex A). Thirteen countries and economies 

showed a significant decrease in the average numeracy score of this group, while only Singapore recorded 

an increase. The average numeracy proficiency of tertiary-educated adults increased only in Canada, 

Estonia and Finland, and declined in Hungary, Israel, Italy, Korea, Lithuania, New Zealand, Poland and 

the Slovak Republic. Particularly large declines in the numeracy proficiency (over 20 points) of tertiary-

educated adults were found in Lithuania, Poland and the Slovak Republic.  

The widespread decline in proficiency among low-educated adults has widened disparities in proficiency 

by educational background in most of the participating countries and economies. Austria, France, Japan, 

New Zealand and Norway saw large increases in the proficiency gap between adults with below upper 

secondary and tertiary education (Figure 3.8) In contrast, in Singapore, which has the largest inequality in 

literacy by educational attainment, the gap changed less because proficiency declined among both low-

educated and highly educated adults. The gap narrowed in Poland due to declining literacy proficiency 

among tertiary-educated adults (Figure 3.7).  

 
or
e
a

Ir
el
an

d

F
le
m
is
h 
R
eg

io
n 
( 

E
 

 
en

m
a
rk

 
e
th
e
rl
an

d
s

F
ra
n
ce

E
ng

la
n
d 
(U

 
 

S
p
ai
n

 
o
rw

ay

E
st
on

ia

S
w
e
de

n

G
e
rm

an
y

U
ni
te
d 
S
ta
te
s

A
us

tr
ia

S
lo
 a

k 
R
ep

ub
lic

F
in
la
n
d

It
a
ly

C
 e

ch
ia

 a
pa

n

C
an

ad
a

P
ol
a
nd

 

 i
th
ua

n
ia

S
in
g
ap

or
e

C
hi
le

Is
ra
e
l

 
e
w
  

ea
la
n
d

H
u
ng

ar
y

Percentage point 
diffe rence

20

10

0

 10

 20

Upper secondary Tertiary elow upper secondary

Round, Cycle 1:    

http://www.oecd.org/skills/piaac/publicdataandanalysis/