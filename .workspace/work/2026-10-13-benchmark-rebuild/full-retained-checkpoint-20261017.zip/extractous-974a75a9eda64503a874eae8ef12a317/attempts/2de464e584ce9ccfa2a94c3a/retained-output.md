Continuing the last three years’ trend of steady 
climbing, projects in 2021 averagely had a contribution 
margin of 36.5%.

Drivers for increasing profit margins within the 
industry are the companies who manage to implement 
real-time visibility in their daily operations. 

IT solutions such as Business Intelligence and 
Professional Services Automation (PSA) software help 
companies facilitate this implementation.

Project profitability 
The steady climb continues - with a nice bump upwardsprojects

2017 2018 2020 20212019

Project contribution ratio 5 year trend:

Projects don’t provide you with the expected 
ROI? 
 Are your prices based on actual time   
 consumption, or do you price your fixed   
 price projects too cheap? 

 Do you remember to staff your projects’  
 junior tasks with junior resources only? 

Initiated Piloted Deployed Institutionalised Optimised

36.5%

31.7%

34.7%
35.4% 35.6%

Project contribution ratio across maturity levels 
Mature companies see higher profits on their projects 

15.4% 26.4% 37.7% 47.2% 55.5%

16