2.1  Perceptions of Media  
 Coverage of the War  
 in Ukraine

Kirsten Eddy and Richard Fletcher

On 24 February, Russia launched a full-scale 
invasion of Ukraine, marking the start of the 
biggest war in Europe since the Second World 
War. Major news organisations around the world 
have embedded journalists in Ukraine to cover 
bombings and violence in hard-hit towns and 
cities across broadcast, digital, and print media. 
Journalists, civilians, and politicians – most 
notably Ukrainian President Volodymyr Zelensky 
– have also taken to social networks like TikTok, 
Telegram, and Twitter to document the horrors 
of the war for a global audience in real time. 
The humanitarian crisis unfolding in Ukraine, 
along with the scale of the Western response to 
Russia’s invasion, has far-reaching political and 
economic effects. 

To better understand how people have been accessing news 
about the Russia–Ukraine conflict, and to explore the impact 
this might have on overall trends in attitudes and behaviours, we 
commissioned YouGov to carry out a separate follow-up survey in 
five countries: Brazil, Germany, Poland, the UK, and the US. These 
countries were selected because they represent different levels 
of proximity to the conflict, ranging from Poland, which borders 
Ukraine, to Brazil and the US, which are on different continents. 
Fieldwork took place from 29 March to 7 April 2022 – roughly 
one month after the invasion began. We polled around 1,000 
respondents in each country and samples were assembled using 
the same quotas as the main survey. The questionnaire contained 
several new questions specifically about the Russia–Ukraine 
conflict, as well a handful of key questions from the main Digital 
News Report survey on news interest, use, avoidance, and trust. 
This allows us to directly compare our ‘pre-conflict’ results from 
the main 2022 survey and the ‘during conflict’ follow-up survey. 
However, because the Russia-Ukraine conflict overlapped with 
other domestic news stories, not all changes we see will be a 
direct result of coverage of the conflict.

MOST PEOPLE ARE FOLLOWING THE CONFLICT 
CLOSELY

First, how much attention are people paying to news about the 
conflict? In all five countries, a majority are following the Russia–
Ukraine conflict at least somewhat closely. Although the conflict 
has global consequences, attention is highest in Germany, which 
is both geographically close to the conflict and where the effects 
are already filtering down to the lives of ordinary people, for 
example, in terms of energy prices. In Brazil, which is politically 
and geographically farther from the conflict, around 40% are  
not following it closely. 

Some of these findings are in line with earlier data on those who 
are not consuming any news sources at all in markets like the US 
and UK. But in countries like Brazil and Germany, the proportion 
of 18–24s not following the conflict at all is particularly high 
compared with other age groups. And in the US and UK, women 
are slightly more likely than men to not be paying close attention 
to the war.

REUTERS INSTITUTE FOR THE STUDY OF JOURNALISM / FURTHER ANALYSIS GRAPHS

Graph 1

PROPORTION WHO ARE FOLLOWING THE RUSSIA–UKRAINE 
CONFLICT CLOSELY – SELECTED MARKETS

Germany

Poland

UK

USA

Brazil

Q1_ukraine. How closely, if at all, are you following the current Russia–Ukraine conflict?  
Base: Total sample: Brazil = 1002, Germany = 1015, Poland = 1003, UK =  1191, USA = 1356.

0% 25% 50% 75% 100%

18

7

7

7

31

18

19

15

20

32

47

44

37

34

11

25

20

29

20

5

6

10

7

2

15

Extremely closely
Not very closely

Very closely
Not at all

Somewhat closely
Don’t know

Reuters Institute for the Study of Journalism   |   Digital News Report 202234