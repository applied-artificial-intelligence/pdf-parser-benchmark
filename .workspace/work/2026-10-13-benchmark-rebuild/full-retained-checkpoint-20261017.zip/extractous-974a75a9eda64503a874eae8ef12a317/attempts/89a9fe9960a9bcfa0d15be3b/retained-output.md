Energy Technology Perspectives 2024 Chapter 1: The state of manufacturing and trade 
  

PAGE | 34 I E
A.

 C
C

 B
Y 

4.
0.

 

 Global investment in clean energy technology and materials 
manufacturing, 2022-2023 

 
IEA. CC BY 4.0. 

Notes: FID = final investment decision. Materials includes investment associated with global capacity additions for crude steel 
and iron for steel, and alumina and primary production for aluminium. Only investments in new capacity are included. 
Completed projects include all projects in operation at end-2023. FID or under construction is as of end-June 2024.  
Sources: IEA analysis based on S&P Global (2024); WindEurope (2023); BNEF (2024a); GWEC (2023); (Wood Mackenzie 
(2024); InfoLink (2024); SPV Market Research (2024); BMI (2024); EV Volumes (2024); BNEF (2024b); BNEF (2024c); IEA 
(2024a); Atlas EV hub (2024); IFA (2024); OECD (2024b); CRU (2024); Oxford Economics Limited (2024b); CEPII (2024) as 
well as announcements by manufacturers and personal communications, gathered by the IEA.  

Investments in clean technology manufacturing grew by 50% year-on-year in 2023; much 
faster than investments in materials manufacturing.  

Cumulative investment in near-zero emissions technologies for materials 
production reached just under USD 6 billion in 2023, with iron and steel 
accounting for around 90% and ammonia for the rest. A further USD 15 billion of 
investment is expected to take place in projects that have either reached final 
investment decision or are already under construction. The majority of this is for 
ammonia facilities using low-emissions hydrogen for new energy applications like 
shipping and power generation. Only around USD 300 million of capital 
investment has been committed to near-zero emission aluminium production, and 
this is limited to demonstration projects with capacity typically around 1% of that 
of commercial-scale facilities. Commercial investment targeting emissions 
reductions in the aluminium industry is mostly limited to the utilisation of greater 
shares of low-emissions electricity (which reduces indirect emissions), energy 
efficiency and fuel switching in alumina production.  

Projecting forward investments for the project pipeline for clean technologies is 
highly uncertain, as projects may well be cancelled, postponed or brought forward 
according to changes in policy incentives and market conditions. Assuming the 
whole project pipeline is completed and there is no change in the inflation-adjusted 
cost of building manufacturing facilities, total investment in clean technology 
manufacturing projects is expected to stand at roughly USD 200 billion (in 2023 
dollars) in 2024 (Figure 1.4). Current projects alone point to nearly USD 180 billion 
per year of investment over the period 2025-30, around 35% of which is 

0

 5

 10

 15

 20

Completed
projects, 2023

FID or under
construction

0

 50

 100

 150

 200

 250

2022 2023

Bi
llio

n 
U

SD
 (2

02
3,

 M
ER

)

Batteries Electric vehicles Solar PV Wind Other

0

 10

 20

 30

 40

 50

 60

2022 2023

Aluminium Ammonia Steel

Clean technologies Materials (total) Materials
(near-zero emissions)