Employment and Social Developments in Europe 2024 

94 

households, primarily targeting older people and single-parents, while other vulnerable groups, such as single-
person households, households without children, and migrants, are often low on the priority list or not eligible for 
social housing.  (206) In addition to improving housing affordability, social housing can support macroeconomic 
objectives by easing supply bottlenecks, thereby mitigating house price pressures. This can in turn help to address 
labour shortages. (207) Social housing also plays a key role in housing first-type programmes for homeless people. 
In this respect, social and affordable housing policies underpin the EU social economy strategy. (208) More broadly, 
increasing the supply of housing can require a coherent mix of investments and reforms to address diverse 
issues such as the supply of basic infrastructure, spatial planning and other regulatory restrictions, or an 
insufficient supply of qualified labour. 

The stock of social housing is quite low in the EU, with big investment gaps. The lack of affordable, good 
quality housing has several structural drivers, including low incentives, bottlenecks in construction and investment 
gaps regarding in particular energy efficiency and social housing production. The construction of social housing 
has decreased across the EU in recent decades, and some countries, particularly in Eastern Europe, have 
privatised large parts of the social housing stock. (209) Currently, social housing as a proportion of the overall 
housing stock exceeds 20% in only three Member States: the Netherlands (34.1% in 2021), Austria (23.6% in 
2019) and Denmark (21.3% in 2022). It is between 10% and 20% in France (14% in 2018), Ireland (12.7% in 
2016) and Finland (10.9% in 2021). (210) Long waiting lists are common in Member States with both larger and 
small social housing stocks, reducing the effectiveness of social housing in improving housing affordability for 
the most vulnerable households. (211) This issue is intensified by tenants who continue to occupy social housing 
after their income improves. While this chapter focuses on the effects of housing policies on tenants and owner-
occupiers, supply-side policies such as investment in the construction and innovation of social housing form a key 
part of the broad range of housing policies that affect the availability and affordability of housing. 
 

Chart 3.15 

Public spending on housing increased but dispersion widened between 2014 and 2021 
Weighted EU average government expenditure on housing and variation across countries (in standard deviation), 2014-2021 

  

Note: Social housing is part of rent benefits and is included in the green line. 

Source: Eurostat [spr_exp_fho]. 

Click here to download chart. 

 
Between 2014 and 2021, government expenditure on housing benefits per inhabitant, aimed at 
improving access to housing, increased in the EU. Taking into account differences in the cost of living 
between countries, it went from 109 to 120 PPS per inhabitant (212) on average, ranging from less than 1 PPS per 
inhabitant in Bulgaria, Croatia and Portugal to over 300 PPS per inhabitant in Ireland and Finland in 2021. It was 
strongly driven by expenditure on rent benefits, mostly comprising housing allowances (86.2% of rent benefits in 
2021), with the exception of Belgium, Estonia, Ireland, Lithuania, the Netherlands, Romania and Slovenia, where 
social housing expenditure constituted a major share of rent benefits. Countries with the lowest initial levels of 
public spending on housing caught up more strongly between 2014 and 2021, (213) but the overall dispersion 

 
(206) (Eurofound, 2023b); (Scanlon, Fernández Arrigoitia and Whitehead, 2015); (Heylen, 2024).  
(207) (Whitehead, 2017); (European Commission, 2023f). 
(208) (European Commission, 2021c). 
(209) (Scanlon, Fernández Arrigoitia and Whitehead, 2015) ; (Whitehead, 2017) ; (Eurofound, 2023b).  
(210) See OECD Affordable Housing Database here. 
(211) (Eurofound, 2023b); (Pestel-Institut, 2024).  
(212) PPS is the artificial currency unit that eliminates price level differences between countries, i.e. one PPS can buy the same volume of 

goods and services in all countries. Government expenditure on housing in PPS is derived by dividing the government expenditure on 
housing of a country in national currency by the respective PPPs, which are obtained by comparing price levels for a basket of 
comparable goods and services representative of consumption patterns in the various countries. 

(213) Beta coefficient is negative (-0.03) and statistically significant at 5% significance level, primarily driven by the convergence in rent 
benefits (beta coefficient for benefits to owner occupiers is not statistically significant). 

0

25

50

75

100

125

150

2014 2015 2016 2017 2018 2019 2020 2021Pu
rc

ha
si

ng
 p

ow
er

 s
ta

nd
ar

d 
(P

PS
) 

pe
r 

in
ha

bi
ta

nt

EU average

Total expenditure on housing
Rent benefits
Social housing (included in rent benefits)
Benefits to owner occupiers

0

25

50

75

100

125

2014 2015 2016 2017 2018 2019 2020 2021

St
an

da
rd

 d
ev

ia
tio

n

Variation across countries

Total expenditure on housing
Rent benefits
Social housing (included in rent benefits)
Benefits to owner occupiers

https://ec.europa.eu/employment_social/empl_portal/publications/Esde2024/xls/Chap3/Chap3-Chart-3.15.xlsx
https://www.oecd.org/housing/data/affordable-housing-database/housing-policies.htm