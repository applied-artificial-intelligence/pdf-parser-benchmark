In perspective: 2022 and longer-term trends sigma 1/2023 Swiss Re Institute 7

Waves of high temperatures in Europe also inflicted a heavy human toll: according to the 
WHO, a series heatwaves in Europe caused at least an estimated 15 000 excess 
deaths.11 In spite of the heatwaves, one peril for which losses were below recent-year 
totals and historical averages were those for wildfire.

Longer-term loss trends

Losses from individual perils fluctuate year on year. That said, at on average 30% each, 
the contribution to global insured losses from the two biggest peril categories – tropical 
cyclones and SCS – have remained largely stable over the last 40 years (see Figure 3). 
On the east coast of the US, hurricanes (primary perils) originating in the North Atlantic 
are a main threat to residents and businesses.12 Though rare, when a major hurricane 
strikes, the losses can be very severe. As in the case of Hurricane Ian, just one peak 
tropical cyclone event can wreak very large losses.

SCS are categorised as secondary perils, occur more frequently and happen all over the 
world. Given the frequency, aggregated their annual loss amounts are less volatile.13 
Typically, losses resulting from SCS are lower than for primary perils, but there have been 
instances when a single SCS has resulted in insured losses of similar size to those 
coming in the wake of medium-sized hurricane. Noteworthy too is a marked step up in 
the share of all SCS to insured losses in the last decade. 

11 Statement – Climate change is already killing us, but strong action now can prevent more deaths, World 
Health Organization, 2 November 2022.

12 Primary perils are natural catastrophes that tend to happen less frequently, but have high loss potential. They 
can include secondary effects. Examples include tropical cyclones, earthquakes and European winter storms.

13 Secondary perils are independent natural catastrophe events that can happen frequently, typically generating 
low- to medium-sized losses. Examples include severe convective storms (thunderstorms, hail and tornadoes), 
drought, wildfire, snow, flash floods and landslides.

Table 1 
Insured crop losses due to drought  
in select markets, USD billion

 Source: CAN, PSR, Ministry of Emergency Management, Swiss Re

Country Economic losses Insured losses

Brazil 13 1

Europe 6.2 0.6

China 4.7 0.8

Morocco 0.25 0.04

Wildfire-related losses were less than in 
recent years.

At 30% each, the contributions of tropical 
cyclones…

…and SCS to annual insured losses have 
remained largely stable.

Figure 3  
Share of insured losses by peril type by decade

Source: Swiss Re Institute

0%

5%

10%

15%

20%

25%

30%

35%

40%

OthersDroughtsEuropean winter stormsWildfiresSevere convective stormsFloodsTropical cyclonesEarthquakes

3%

7%

1%

7%

31%

13%

29%

8%

1983–1992 1993–2002 2003–2012 2013–2022 40-year average (1983–2022)

https://www.who.int/europe/news/item/07-11-2022-statement---climate-change-is-already-killing-us--but-strong-action-now-can-prevent-more-deaths