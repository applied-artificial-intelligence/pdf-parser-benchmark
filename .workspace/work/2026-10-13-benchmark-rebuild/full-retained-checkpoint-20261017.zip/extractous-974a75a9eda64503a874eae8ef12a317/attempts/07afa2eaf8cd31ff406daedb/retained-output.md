Change in proved reserves by region for select energy companies

billion barrels of oil equivalent

Petroleum and Liquid Fuels Markets Team | Financial Review 2024                                               

May 2025

Changes in proved reserves were relatively small across all regions in 

2024

Data source: Evaluate Energy

Note: Mergers and acquisitions between companies may affect net reserve changes and comparisons between years. Each year shows 

change based on end-of-year totals as reported. Other world and associates includes the regions outside the ones identified in this figure and 

reserves held by associate companies regardless of location. Select energy companies includes 158 global oil and natural gas companies. The 

Appendix contains the full list of companies.

-25

-20

-15

-10

-5

0

5

10

15

20

25

2015 2016 2017 2018 2019 2020 2021 2022 2023 2024

other world and 

associates

Latin America

United States

net change

Canada

Europe

Middle East and 

Africa

Asia Pacific, 

Russia, and 

Central Asia

16