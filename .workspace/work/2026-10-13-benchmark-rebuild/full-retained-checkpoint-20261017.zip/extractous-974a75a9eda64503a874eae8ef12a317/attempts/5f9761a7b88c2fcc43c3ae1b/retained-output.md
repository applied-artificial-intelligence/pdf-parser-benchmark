A R T H U R  D .  L I T T L E

BEVs & BRAND LOYALTY:  
THE RISE OF CHINA

Shopping for a BEV may prompt customers to 
reconsider the different options and brands 
available to them, potentially reducing brand 
loyalty built up over many years in the ICE world. 
Globally, 19% of existing owners of premium 
brand models5 say they would be more likely 
to switch, compared to 17% of those who own 
volume brand vehicles. This shift is highest in 
India (58% premium and 42% volume) and lowest 
in Europe (9% premium and 8% volume) and 
the US volume market (3%). However, the US 
premium market is being and will continue to be 
disrupted, with over a quarter (28%) more likely 
to change.

5 Premium brands include: Volvo, Audi, BMW, Jaguar, Tesla, Lexus, Cadillac, Mercedes, and Nio; volume brands include: Citroën, Fiat, Ford, Hyundai, 
Jeep, Kia, Nissan, Opel, Peugeot, Renault, SEAT, Skoda, Toyota, Volkswagen, and BYD.

Chinese EV manufacturers are rapidly growing 
in terms of global presence. Their rising 
visibility (and lower prices) leads to potential 
tariffs and regulatory action in Europe and the 
US, including exclusion from some European 
national incentive programs, due to low content 
of European components. However, outside 
China more than half (60%) of respondents say 
they were not interested in purchasing a Chinese 
EV (see Figure 18), naming perception of quality 
and customer sales/service experience as the 
main reasons.

Figure 17. Factors encouraging EV purchase 

Source: Arthur D. Little

Environment

Trend & 
technology 
front-runner

Price

More fun to 
drive than
ICE cars 
(acceleration)

Source: Arthur D. Little

Figure 17. Factors encouraging EV purchase

82

80

46

21

79

83

56

20

80

79

36

16

69

80

27

23

70

86

20

18

60

75

15

15

84

89

50

23

81

81

48

34

71

85

33

20

What factors would encourage you to purchase an electric car?
(in %)

68

80

23

26

68

81

21

26

52

72

12

17

76

82

37

24

76

85

38

22

71

82

30

18

82

84

53

26

79

88

53

20

76

85

37

18

90

84

40

29

89

84

62

26

84

90

41

25

74

87

33

28

72

87

28

18

62

84

26

17

Conventional powertrain owners a) EV intenders Conventional powertrain owners b) EV non intendersEV or hybrid owners

Figure 18. Reasons for not purchasing a Chinese EV

Source: Arthur D. Little

Source: Arthur D. Little

Figure 18. Reasons for not purchasing a Chinese EV

22%

53%

47%

42%

30%

43%

19%

Poor quality

Challenges associated with
service or purchase

Brand reputation

Preference for domestic brands

Environmental, social &
governance standards

Vehicle design

51%

40%
45%

38%
38%

30%
37%

40%

22%

19%

16%

Why would you not be interested in purchasing an EV from a Chinese manufacturer?

GLOBAL OUTSIDE CHINA – 
60% of respondents would not 
be interested in purchasing an 
EV from a Chinese manufacturer

Conventional powertrain owners a) EV intenders

Conventional powertrain owners b) EV non-intenders

EV or hybrid owners

2 5