10 Swiss Re Institute sigma No 1/2025  Insured losses on trend

The absence of peak-loss years since 2017 should not be read as a signal that primary 
peril loss events, especially large “tail” events, are becoming less likely. History shows 
that annual losses from primary perils vary considerably, punctuated by peak loss years. 
The experience of Hurricanes Katrina, Wilma and Rita in 2005, or Harvey, Irma and 
Maria in 2017 illustrates the scale of huge losses that can result from primary perils. 
And also that in years when low-frequency high-severity events do strike, particularly in 
regions of high economic exposure, insured losses from all natural catastrophes can 
reach well above trend levels, sometimes 100% or more above trend. In the next chapter, 
we estimate and demonstrate the potential magnitude of insured losses in a next peak-
loss year and highlight scenarios that can cause such losses.

Figure 6 
Distribution of annual losses from primary and secondary perils in % deviation from trend (1995 ‒ 2024)

Source: Swiss Re Institute

0

2

4

6

8

10

12

700%
675%

650%
625%

600%
575%

550%
525%

500%
475%

450%
425%

400%
375%

350%
325%

300%
275%

250%
225%

200%
175%

150%
125%

100%
75%

50%
25%0%

–25%
–50%

–75%

–100%

–125%

–150%

Primary perils Secondary perils

Deviations from tend

2011 1999 2004 2005

2011, 2017

Number of years

…and it is a matter of when, not if, the next 
peak loss year will occur.