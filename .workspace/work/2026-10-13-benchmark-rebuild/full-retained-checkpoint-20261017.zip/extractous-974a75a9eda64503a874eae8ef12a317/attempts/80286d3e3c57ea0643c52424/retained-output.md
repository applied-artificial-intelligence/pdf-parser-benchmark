244    

OECD EMPLOYMENT OUTLOOK 2024 © OECD 2024 
  

5.3.2. Who pollutes the most? Carbon footprints linked to household consumption 

Energy consumption is a key driver of emissions, but it is not the only one. There are several reasons why 

energy spending is only a partial indicator of households’ carbon footprints. First, emissions from electricity 

generation vary enormously between countries, by a factor of 15 across the five countries considered here.20 

Relatedly, for each of the main fuel consumption categories, emissions vary by type of fuel (see Annex 

Figure 5.B.1), as do prices before accounting for carbon pricing. For lower-income or rural households, 

domestic fuels can include high shares of solid fuels (coal, coke, peat, firewood), which have much higher 

emission factors than liquid fuel. Emission factors are lower for natural gas, an energy source that can be more 

common in urban areas. Motor fuels are commonly more expensive than domestic fuels and produce fewer 

emissions per energy unit than firewood, coal, or heating oil. Per unit of fuel expenditure, emissions – and 

therefore also the effect of a given carbon price – thus tend to be higher for domestic fuels than for motor fuels. 

Second, non-fuel expenditures account for a large share of household spending.21 Per unit of spending, 

fuel use creates more emissions than other consumption, but due to the size of non-fuel spending, the 

production of non-fuel goods and services is a significant driver of carbon footprints. Across the five 

countries, direct emissions from households’ own use of fossil fuels mostly account for around half of the 

total emissions linked to consumption (Figure 5.5). These estimates incorporate all household 

consumption, following the “consumer responsibility” principle (see figure note). Fuel spending was a 

lesser driver of total emissions in France, partly reflecting the balance of spending on fossil fuels and 

electricity, but also the types of fuel (coal and other solid fuel, liquid fuel, gas) used by households and in 

production processes.22 Emissions linked to imported inputs or final goods (other than fuel) are also 

significant but comparatively small, accounting for less than 10% of emissions in each of the five countries. 

(This small share is reassuring in the context of the chapter’s later estimates of carbon price burdens, 

which do not account for differential carbon price trends in source countries.) 

Figure 5.5. Fuel expenditure is not the only driver of households’ carbon footprints 

Emissions from fuel (“direct”) and non-fuel (“indirect”) consumption, in percentage of total 

 
Note: “Direct” includes households’ own consumption of fossil fuels, both domestically sourced and imported. “Indirect, domestic” includes 
households’ own non-fuel, domestically sourced consumption. “Indirect imported” accounts for emissions linked to all other non-domestically 
sourced inputs and consumption goods. Estimates are based on the “consumer responsibility” principle, accounting for all household 
consumption. They therefore attribute emissions to the country where the final good is consumed, and this differs from the emissions per capita 
that are physically released in a given country. It is important to account for the consumption of imported goods in order to determine the carbon 
price embedded in households’ consumption baskets. 
Source: OECD calculations using IEA emissions factors for different fuels, World Input-Output Database (WIOD) as well as household budget 
surveys (2015 for EU countries, 2016 for Mexico, 2019 for Türkiye). 

StatLink 2 https://stat.link/hs30kq 

0

10

20

30

40

50

60

70

80

90

100

France Germany Poland Mexico Türkiye

Share of total (%)

Direct Indirect, domestic Indirect, imported

https://stat.link/hs30kq