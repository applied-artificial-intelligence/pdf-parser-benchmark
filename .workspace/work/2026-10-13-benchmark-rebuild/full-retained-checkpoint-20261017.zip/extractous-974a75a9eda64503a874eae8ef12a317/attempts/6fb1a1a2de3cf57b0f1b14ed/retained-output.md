Field Name Description

DBCS font Specifies a font number. A font number is 1 to 8, and each number is
defined in the Work with Source Overlay Fonts or the Work with PFD
Definition Fonts display. You can see the list of fonts and select one of
them by placing the cursor in this field and pressing F4. See 248 for
details.

Note: It is not checked if the specified font exists and is a DBCS font.
If it does not exist, some errors may occur when this text is printed. If
you specify a SBCS font, the result is unpredictable. Some unexpected
characters may be printed, or some errors may occur.

Character spacing
(Horizontal)

The data specified in the Horizontal prompt is used for calculating the
horizontal space that the characters of Text data occupy in a box
element.

When the measurement method is Row/Column, specify *CPI, 5.00,
10.00, 12.00, 13.30, 15.00, 16.70, 18.00, or 20.00.

When the measurement method is Inch, specify *CPI or the value in
inches from 0.01 to 22.75.

When the measurement method is Centimeter, specify *CPI or the
value in centimeters from 0.01 to 57.79.

The default value is *CPI which is the same value as Characters per
inch on the Define Overlay Specifications display or on the Define
PFD Specifications display.

The value specified in horizontal applies only to SBCS fonts. The
character space size of DBCS fonts is extracted from the font resource
on the iSeries system. If DBCS data is contained in the text data and
the font resource cannot be accessed when creating an overlay or
printing a database file member, the text data formatting in the box
may not be correct.

Character spacing
(Vertical)

The data specified in the Vertical prompt is used for calculating the
vertical space that the characters of Text data occupy in a box element.

When the measurement method is Row/Column, specify *LPI, 3.00,
4.00, 6.00, 7.50, 8.00, 9.00, or 12.00.

When the measurement method is Inch, specify *LPI or the value in
inches from 0.01 to 22.75.

When the measurement method is Centimeter, specify *LPI or the
value in centimeters from 0.01 to 57.79.

The default value is *LPI which is the same value as Lines per inch on
the Define Overlay Specifications display or on the Define PFD
Specifications display.

The value specified in Vertical applies to only SBCS fonts. The
character space size of DBCS font is extracted from the font resource
on the iSeries system. If DBCS data is contained in the text data and
the font resource cannot be accessed when creating an overlay or
printing a database file member, the text data formatting in the box
may not be correct.

Chapter 13. Design Operation 261