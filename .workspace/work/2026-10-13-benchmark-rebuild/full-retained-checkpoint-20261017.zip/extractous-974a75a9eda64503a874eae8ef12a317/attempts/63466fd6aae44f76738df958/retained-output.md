 121 

 

DO ADULTS HAVE THE SKILLS THEY NEED TO THRIVE IN A CHANGING WORLD? © OECD 2024 
  

Changes in the age structure of the population  

Over recent decades, all OECD countries have seen a steady increase in the share of older adults in the 

population. This trend is projected to continue, with the proportion of people aged 65 and over expected to 

increase from 18% in 2023 to 25% by 2050, and that of people aged 50 and over from 37% to 44% (OECD, 

2024[17]). In the years between the two cycles of the Survey of Adult Skills, most participating countries and 

economies have experienced a change in the age structure of their population (Figure 3.10). This shift was 

most pronounced in Austria, Germany, Italy and Korea, where the share of 55-65 year-olds increased by 

5 percentage points or more between 2012 and 2023. Among countries taking part in Round 2 of the first 

cycle, this share has grown by 5 percentage points in Lithuania and 4 percentage points in Singapore 

between 2015 and 2023.  

Figure 3.10. Change in the age composition of the adult population between cycles 

Difference in the relative size of 10-year age groups between cycles (Cycle 2 minus Cycle 1) 

 

Note: Adults aged 16-65; does not include adults who in Cycle 2 were only administered the doorstep interview due to a language barrier, to 

maximise the comparability across cycles (see Box 1.1 in Chapter 1 and Box 3.2). *Caution is required in interpreting results due to the high 

share of respondents with unusual response patterns. See the  ote for Poland in the Reader’s Guide. 

Countries and economies are ranked in descending order of the change in the share of 55-65 year-olds. 

Source: OECD (2018[4]; 2015[5]; 2012[6]), Survey of Adult Skills (PIAAC) databases, http://www.oecd.org/skills/piaac/publicdataandanalysis/  

(accessed on 23 September 2024); Table B.3.6 (Trend) in Annex B. 

Changes in skills proficiency by age 

Figure 3.11 presents differences in literacy proficiency between adults of the same age at the time of the 

first and second cycle (i.e. cohort effects). It shows how proficiency has changed between assessments 

within five different age groups across the participating countries and economies. The evolution of 

proficiency in the youngest age group will reflect, to a larger extent, current and recent changes in 

education, such as expanding participation or improving education quality due to recent reforms. In 

contrast, changes in proficiency among the older age groups may be the result of influences that occurred 

long before the period covered by the assessment – reaching as far back as the 1950s and 1960s, when 

the cohort aged 55-65 in the first Survey of Adult Skills began compulsory schooling. In addition, 

differences among older adults will also reflect more recent changes in the world of work that would have 

provided or limited their opportunities to maintain and develop skills.  

 
or
ea

G
er
m
a
ny

A
us

tr
ia

It
al
y

S
pa

in

 
et
he

rl
a
nd

s

Ir
el
a
nd

S
lo
 a

k 
R
ep

u
bl
ic

E
ng

la
n
d 
(U

 
 

C
an

ad
a

 
e
nm

ar
k

 
or
w
ay

F
le
m
is
h 
R
e
gi
o
n 
( 

E
 

F
in
la
nd

E
st
o
ni
a

U
ni
te
d 
S
ta
te
s

F
ra
n
ce

P
o
la
n
d 

S
w
ed

e
n

C
 e

ch
ia

 a
p
an

 i
th
ua

n
ia

S
in
g
a
p
or
e

C
hi
le

 
ew

  
ea

la
nd

Is
ra
e
l

H
un

g
a
ry

Percentage point 
difference

10

8

 

 

2

0

 2

  

  

 8

      year olds       year olds1  2  year olds 2  3  year olds

   Round, Cycle 1:

http://www.oecd.org/skills/piaac/publicdataandanalysis/