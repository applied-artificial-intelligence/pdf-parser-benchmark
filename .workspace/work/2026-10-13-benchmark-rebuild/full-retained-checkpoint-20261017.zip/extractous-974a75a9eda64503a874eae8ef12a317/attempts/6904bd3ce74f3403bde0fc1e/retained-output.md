Fundamentals — Sustainability at Ford — Products and Services — Environment — Social — Governance — Data — Appendices

13

Materiality Assessment

2
0

2
4

 
R

e
p

o
rt

 
F

in
a

n
ci

a
l 

a
n

d
 

S
u

s
ta

in
a

b
il
it

y
 

In
te

g
ra

te
d

 
F

o
rd

 

 — Sustainability Strategy — Sustainability Aspirations — Accelerating Progress — Create Sustainable Value — Human Rights Saliency Assessment — Stakeholders

Our Sustainability Strategy
ESRS 2 SBM-1

Our sustainability strategy is to make 
a positive impact on society and the 
environment.
Sustainability topics are entwined with our purpose: 
To help build a better world where every person is free 
to move and pursue their dreams. It’s at the heart of 
everything we do.

Our Strategies

We have developed these specific strategies to address 
the collective challenges the world faces and achieve 
our Sustainability Aspirations.

Read More

In Sustainability Aspirations on p.14

Climate Change Strategy 

To achieve our carbon neutrality goal, we are focusing 
on three areas that account for approximately 95% of our 
carbon dioxide emissions — our vehicles, our operations, 
and our supply chain. Addressing the largest emissions 
source, our vehicle use from a well-to-wheel perspective, 
Ford’s investment in electric vehicles is a core element of 
our climate change strategy. 

Read More

In Climate Change, Carbon Neutrality Overview on p.59

Energy Strategy

We are committed to sourcing 100% carbon-free 
electricity for our global manufacturing operations 
by 2035 through a mix of wind, solar power, nuclear, 
geothermal, biomass, and hydro. We are using our 
purchasing power to invest in renewable electricity, 
including in southeast Michigan.

Read More

In Climate Change — Achieving Carbon Neutrality on p.59

Sustainable Materials Strategy

Using recycled and renewable materials helps reduce 
waste and lower need for new materials. We aspire to 
use only recycled or renewable content in vehicle plastics. 
Our near-term target is to use 20% recycled or renewable 
plastics by 2025 in new vehicle designs for North America 
and Europe, including Turkey, and 10% for China. Ford’s 
closed loop recycling system maximizes aluminum 
recycling, reduces the energy needed to create new primary 
aluminum, and minimizes the need for raw materials.

Read More

In Circular Economy and End of Life on p.76

Waste Strategy

We are focused on managing and minimizing the waste 
we generate to reach true zero waste to landfill across 
our global operations. We aim to eliminate single-use 
plastics from our operations by 2030.

Read More

in Circular Economy and End of Life on p.76

Water Strategy

Ford is committed to reducing water use, aspiring to use 
freshwater only for human consumption and make zero 
water withdrawals for manufacturing processes in order 
to support freshwater availability in local communities. 
To further decrease our water consumption, we continue 
to integrate more water efficient processes and 
technologies in our manufacturing systems.

Read More

In Water Resources on p.82

Human Rights Strategy

Ford is committed to respecting human rights, including 
the right to clean air and clean water, across our entire 
business and value chain. This commitment guides our 

decision-making and our actions, and extends to our 
suppliers and business partners, from the origin of the 
raw materials used to make our products to the end of 
life of these products. Guided by our We Are Committed 
to Protecting Human Rights and the Environment policy, 
our goal is to ensure that everything we do, or that 
others do for us, meets or exceeds the minimum 
regulatory requirements and strives to create a positive 
impact on people and the planet. 

Read More

In Human Rights on p.88 

People Strategy

Diverse representation, equity, and inclusion are the 
bedrock of our people strategy. We are committed to 
finding, hiring, developing, and retaining great talent 
that is inclusive of everyone in the communities that 
we serve. We are committed to structural and systemic 
equity at every stage of the employee journey. Every 
employee is expected to support each other, to learn 
about people different than themselves, and disrupt 
bias in everyday behaviors and decisions. Ford supports 
a just transition by preparing our workforce and local 
communities for the transition to EVs. 

Read More

In Human Capital Management and Diversity, 
Equity, and Inclusion on p.104

Sustainability Reporting Strategy

Basis for Preparation of Sustainability Statement
ESRS 2 BP-1, ESRS 2 BP-2

This Integrated Sustainability and Financial Report 
has been prepared in alignment with the EU Corporate 
Sustainability Reporting Directive (CSRD) expectations 
around the structure of our sustainability statement 
on a global consolidated basis for Ford Motor Company 
and its wholly owned subsidiaries. 

The CSRD requires disclosures against the European 
Sustainability Reporting Standards (ESRS). Throughout 
the report you will see ESRS tags on some chapters 
or sections, such as the “ESRS 2 BP-1” above, indicating 
which disclosures we are addressing in that section.

All 2024 ESRS disclosures for Ford Motor Company 
are contained within this Integrated Sustainability and 
Financial Report. We are voluntarily phasing in these 
disclosures in the 2024 report, not all ESRS required 
disclosures are included at this time. We are working 
towards full CSRD reporting compliance in our 2025 
Integrated Sustainability and Financial Report.

Time horizons in this report are consistent with our 
climate reporting and cover three time horizons: short-
term (<5 years), medium-term (5–10 years), and long-
term (>10 years).

There are also disclosures in this report that stem from 
other regulations and frameworks including, but not 
limited to, the German Supply Chain Due Diligence Act, 
The Global Reporting Initiative (GRI), the Task Force on 
Climate-Related Disclosures (TCFD), and the United 
Nations Guiding Principles Reporting Framework 
(UNGPRF).

Read More

In Appendix 2 — CSRD Index on p.170 

 

 

In Appendix 4— TCFD Index on p.188

In Appendix 6— UNGPRF Index on p.191

https://corporate.ford.com/content/dam/corporate/us/en-us/documents/reports/we-are-committed-to-protecting-human-rights-and-the-environment-policy.pdf
https://corporate.ford.com/content/dam/corporate/us/en-us/documents/reports/we-are-committed-to-protecting-human-rights-and-the-environment-policy.pdf