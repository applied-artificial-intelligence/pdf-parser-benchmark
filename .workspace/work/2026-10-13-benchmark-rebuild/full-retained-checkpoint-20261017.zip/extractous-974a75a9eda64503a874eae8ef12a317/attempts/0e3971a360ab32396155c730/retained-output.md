 91 

OECD EMPLOYMENT OUTLOOK 2024 © OECD 2024 
  

Figure 2.8. Workers in green-driven and GHG-intensive occupations tend to have similar 
characteristics 

Gap in percentage points between the share of green-driven (respectively GHG-intensive occupations) in each 

characteristic and the share in the whole economy 

 

Note: The figure reports gaps in percentage points between the share of green-driven (Panel A) and GHG-intensive (Panel B) occupations by 
characteristics and the average share. Data refer to the average for 2015-19, except for Canada: 2017-19. In terms of age, youth are 15-34 years 
old, middle 35-54 years old, older 55+ year old. In terms of occupation, low-skill refers to Service and Sales Workers and Elementary 
Occupations (ISCO-08 5 and 9, medium-skill to Clerical Support Workers, Craft and Related Trades Workers and Plant and Machine Operators, 
and Assemblers (ISCO-08 4, 7 and 8), high-skill to Managers, Professionals and Technicians and Associate Professionals (ISCO-08 1, 2 and 
3). Low education refers to less than upper secondary, medium education to upper secondary, high education to more than upper secondary. 
Unweighted average of Australia, Austria, Belgium, Canada, Czechia, Denmark, Estonia, Finland, France, Germany, Greece, Hungary, Iceland, 
Ireland, Italy, Japan, Latvia, Lithuania, Luxembourg, the Netherlands, Norway, Poland, Portugal, Slovak Republic, Slovenia, Spain, Sweden, 
Switzerland, the United Kingdom and the United States. 
Reading: The share of women employed in green-driven occupations is 9 percentage points lower than the share of women employed on average. 
Source: Secretariat’s estimates based on version 24.1 of the O*NET database and the following country-specific sources: Australian Labour 
Force Survey (gender, age); Canadian Labour Force Survey (gender, age, education); Japanese Labour Force Survey (gender, age); 
United States: Current Population Survey; All other countries: EU Labour Force Survey. 

StatLink 2 https://stat.link/y5167t 

In conclusion, the implementation of ambitious measures to combat climate change will result in decreased 

employment levels within GHG-intensive industries to the benefit of renewable energy generation as well as 

a larger number of industries that will be instrumental to make the transition happen, such as certain 

segments in construction and transport. This reallocation may also give rise to disparities across workers and 

regions. The analysis shown in this section suggests that, even if the reallocation process will go well beyond 

the two relatively small groups of GHG-intensive and green-driven occupations, these two groups have some 

similarities in common in terms of the characteristics of the workers who hold them that could help to make 

the transition manageable. And yet, the risk of widening inequalities across demographic groups and 

geographical areas is real – see Botta (2019[77]); OECD (2021[2]); and Chapters 3 and 4. In particular, the 

analysis has shown that green-driven occupations are a heterogenous group of jobs: fast-growing green new 

and emerging occupations are typically high-skill and employ highly educated workers in urban areas while 

the much larger but less dynamic groups of green-enhanced skills occupations and green increased demand 

ones are on average relatively more medium- and low-skill and employ many more low-educated workers. 

Interestingly, the characteristics of the workers employed in declining GHG-intensive occupations are 

remarkably similar to those of the workers more exposed to high temperatures, as shown in Box 2.2. This 

suggests that while climate change mitigation policies may have costs for some groups of workers, there 

are also labour market costs of inaction for these same groups. 

-10

-5

0

5

10

15

W
om

en

M
en

Y
ou

th

M
id

dl
e

O
ld

er

Lo
w

-s
ki

ll

M
ed

iu
m

-s
ki

ll

H
ig

h-
sk

ill

Lo
w

M
ed

iu
m

H
ig

h

Gender Age Occupation Education

p.p.
A. Green-driven occupations

-10

-5

0

5

10

15

W
om

en

M
en

Y
ou

th

M
id

dl
e

O
ld

er

Lo
w

-s
ki

ll

M
ed

iu
m

-s
ki

ll

H
ig

h-
sk

ill

Lo
w

M
ed

iu
m

H
ig

h

Gender Age Occupation Education

p.p. B. GHG-intensive occupations

https://stat.link/y5167t