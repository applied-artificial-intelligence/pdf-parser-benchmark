Chapter 3. Regional Wealth Inequality
Figure 3.6. The rising capital share in global income

Capital share of income Labor share of income

1980 1990 2000 2010 2020 1980 1990 2000 2010 2020
30%

40%

50%

60%

70%

30%

40%

50%

60%

70%

S
ha

re
 o

f t
ot

al
 fa

ct
or

−
pr

ic
e 

G
D

P

East Asia

Europe

Latin America

MENA

North America & Oceania

Russia & Central Asia

South & Southeast Asia

Sub−Saharan Africa

World

Capital and income as a share of total factor−price GDP, 1980–2025

Interpretation. This figure shows trends in the composition of income between labor and capital. At the global
level, the share of income going to labor declined from 61% in 1980 to 53% in 2025. Meanwhile, the capital share
increased from 39% to 47% over the same period. This shift reflects a combination of rising returns to capital,
growing depreciation (CFC), and stagnating labor compensation in many regions. Capital shares are substantially
larger in poorer regions than in richer ones. Sources and series: Dietrich et al. (2025).

Sub-Saharan Africa is concentrated at thevery low end, with minimal representationbeyond the lower deciles. Europe and NorthAmerica & Oceania are overrepresented atthe top tail and dominate the highest wealthbrackets.
Compared with the income distributionshown earlier in Figure 2.5, the contrastis clear: wealth inequality is larger thanincome inequality. Regions that accountfor a substantial share of middle-incomeearners, such as East Asia and parts of South& Southeast Asia, remain underrepresentedat the very top of the wealth distribution,while Europe and North America & Oceaniaare disproportionately present there. Putdifferently, location still shapes an individual’schances of reaching the top of the globalwealth ladder.Figure 3.8 disaggregates household netwealth in 2025 into four groups: the bottom50%, the middle 40%, the next 9%, and thetop 1%, for each world region. The pictureis stark: in every region, the top 10% ownsthe majority of wealth, while the bottomhalf owns almost none. Across regions, thebottom 50% holds between 1% and 5%of total wealth: just 1% in North America

& Oceania, Sub-Saharan Africa, and theMiddle East & North Africa; 3% in Europe,Latin America, and Russia & Central Asia;and 5% in South & Southeast Asia and EastAsia. Put plainly, in every region, half of thepopulation owns no more than 5% of thatregion’s wealth.
By contrast, the top 10% controls60–74% of wealth, about 60% in Europe;65–70% in South & Southeast Asia, EastAsia, Latin America, and North America &Oceania; 70% in Sub-Saharan Africa; 73%in the Middle East & North Africa; and 74%in Russia & Central Asia. In every region,one-tenth of the population owns at least60% of all wealth.
Disaggregating the top 10% shows howconcentrated the very top is. The top 1%alone holds a quarter of all wealth in Europe(25%), around a third in North America &Oceania (34%), South & Southeast Asia(35%), Sub-Saharan Africa (36%), LatinAmerica (36%), the Middle East & NorthAfrica (37%), and an excessively high 46%in Russia & Central Asia. In several regions,North America & Oceania, Latin America,the Middle East & North Africa, Sub-SaharanAfrica, and Russia & Central Asia, the top

81