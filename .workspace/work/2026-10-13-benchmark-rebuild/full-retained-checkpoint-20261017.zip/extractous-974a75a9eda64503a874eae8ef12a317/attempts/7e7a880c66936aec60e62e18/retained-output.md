A3 Methodology

The study employs a structured approach to 
estimate the GovTech market size (1) and its 
GovTech opportunity for the public sector (2) by 
2034. The methodology integrates an analysis of 
public sector IT spending, expert opinions and 
established models to produce reliable estimates 
of both market growth and societal impact.

1. Assessment of the GovTech market size

a. Determination of sector focus: Calculation 
of the market comprises four sectors: public 
services, education, healthcare/life sciences 
and transport.

b. Projecting IT spending: Growth projections 
extended to 2034 by applying the average 
annual growth rate of 8% (based on 2022-2028 
data) (see Figure 5).13,14 

IT spending in various sectors (in $ billions in 2024 and 2034) with an estimate growth rate 
of 8% per annum

F I G U R E  5

$1,570 2034

$220

$170
$70

2024

$40

$90

$70

$670

Public sector Education Healthcare and life science Transport

A2 Additional information for the country cases

Azerbaijan: For more information, see: Centre for 
the Fourth Industrial Revolution Azerbaijan

Bahrain: For more information, see: Information & 
eGovernment Authority

Brazil: For more information, see: Ministry of 
Management and Innovation in Public Services

Germany: For more information, see: CIO Bund

Malaysia: For more information, see: MyDIGITAL

Rwanda: For more information, see: IremboGov

Ukraine: For more information, see: Ministry of 
Digital Transformation

The Global Public Impact of GovTech: A $9.8 Trillion Opportunity 29

https://www.4sim.gov.az/az
https://www.iga.gov.bh/en/
https://www.iga.gov.bh/en/
https://www.gov.br/gestao/pt-br
https://www.gov.br/gestao/pt-br
https://www.cio.bund.de/Webs/CIO/DE/startseite/startseite-node.html
https://www.mydigital.gov.my/
https://irembo.gov.rw/
https://thedigital.gov.ua/
https://thedigital.gov.ua/