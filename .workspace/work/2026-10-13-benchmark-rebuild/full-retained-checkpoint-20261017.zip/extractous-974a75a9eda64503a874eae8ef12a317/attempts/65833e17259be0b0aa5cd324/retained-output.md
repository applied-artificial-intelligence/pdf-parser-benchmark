Note: Numbers may not sum to 100%, because of rounding.

In 2024, on average, the time from 
when respondents joined their firm 
to when they started their current 
role is 3.2 years, which suggests 
that these respondents joined their 
firms in more-senior roles. One-
third of respondents joined their 
current firm in their current role.

Current role information (%)

How many years 
have you been a 
partner at your 
current firm or 
any other firm?

How many years 
have you been with 
your current firm?

How many years 
have you been in 
your current role?

Less than 1 year

1–3 years

4–5 years

6–10 years

More than 10 years

2
6

13
9

18
12

24
38

39
39

2
N/A

11
8

22
26

17
19

19
20

29
27

N/A
1

16
9

42
42

23
22

10
21

7
7

Prefer not to answer

Source: Heidrick & 
Struggles US professional 
services partner 
compensation survey, 
2024, n=149

Source: Heidrick & 
Struggles US professional 
services partner 
compensation survey, 
2024, n=153

Source: Heidrick & 
Struggles US professional 
services partner 
compensation survey, 
2024, n=151

2024 2022

Diverse region, inclusive workforces: Diversity and inclusion policy and practice in Asia PacificHEIDRICK & STRUGGLES

9