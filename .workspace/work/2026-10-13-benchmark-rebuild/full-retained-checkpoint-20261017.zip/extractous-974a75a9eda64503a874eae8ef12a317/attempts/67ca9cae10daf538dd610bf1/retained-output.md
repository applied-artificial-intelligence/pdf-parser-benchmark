 79 

 

DO ADULTS HAVE THE SKILLS THEY NEED TO THRIVE IN A CHANGING WORLD? © OECD 2024 
  

Figure 2.12. Share of women among STEM and non-STEM graduates 

Share of tertiary-educated 25-65 year-olds who graduated from each field of study who are women  

 

Note: Does not include adults who were only administered the doorstep interview due to a language barrier, as information on field of study was 

not collected for those respondents (see Box 1.1 in Chapter 1). STEM stands for science, technology, engineering and mathematics. Educational 

attainment is based on the International Standard Classification of Education (ISCED) 2011, grouped into below upper secondary (ISCED 1, 2 

and 3 short), upper secondary (ISCED 3 and 4) and tertiary (ISCED 5, 6, 7 and 8). Where possible, foreign qualifications are included as the 

closest corresponding level in the respective national education systems. *Caution is required in interpreting results due to the high share of 

respondents with unusual response patterns. See the Note for Poland in the Reader’s Guide. 

Countries and economies are ranked in descending order of the percentage of STEM graduates who are women. 

Source: Table B.3.4 in Annex B. 

When comparing tertiary-educated men and women who have studied STEM fields, data from the 2023 

Survey of Adult Skills show that, on average, women score 8 points lower in numeracy (Figure 2.13). This 

gap is narrower than the gap among all tertiary-educated adults (16 points; see Table A.2.9 (N) in Annex 

A). Accounting for other relevant characteristics only marginally helps to explain this gap. 

Among tertiary-educated adults who have chosen STEM fields, women have a small and statistically 

insignificant advantage in literacy over men (1 point); this gap increases to 2 points and becomes 

statistically significant after accounting for differences in other background characteristics. In contrast, men 

in this group have a small but statistically significant advantage over women in adaptive problem solving 

(3 points), which reduces to 2 points after accounting for relevant socio-demographic characteristics (see 

Table A.2.9 (L, A) in Annex A). 

These results show that the gender gap in numeracy persists even when comparing men and women who 

made similar educational choices. Factors other than the observable socio-demographic characteristics 

examined in this report would need to be investigated in order to understand the reasons behind such 

differences and to design initiatives that aim at reducing this gender gap. The first cycle of the Survey of 

Adult Skills also found an advantage for men in numeracy (10 points) among adults working in STEM 

occupations (OECD, 2015[43]). 

 

 

STE  on STE 

80

 0

 0

 0

 0

30

20

10

0

P
or
tu
g
a
l

C
ro
at
ia

S
w
e
de

n

 a
t 
ia

Is
ra
e
l

Ir
el
an

d

S
lo
 a

k 
R
ep

ub
lic

C
 e

ch
ia

E
st
o
ni
a

It
a
ly

 
e
nm

ar
k

S
in
g
ap

or
e

U
ni
te
d 
S
ta
te
s

 
o
rw

ay

 
E
C
 
 a
ve

ra
g
e

F
ra
n
ce

F
le
m
is
h 
R
eg

io
n 
( 

E
 

S
p
ai
n

 
e
th
e
rl
a
nd

s

C
an

ad
a

 
e
w
  

ea
la
n
d

 i
th
ua

n
ia

F
in
la
n
d

P
ol
a
nd

 

 
or
e
a

H
u
ng

ar
y

A
us

tr
ia

S
w
it 

er
la
n
d

G
e
rm

a
ny

E
ng

la
nd

 (
U
 
 

C
hi
le

 a
pa

n