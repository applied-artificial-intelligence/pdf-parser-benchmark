The BEAT | June 2025

Corporate Earnings Growth

EQUITIES

Source: FactSet as of 5/31/25. Expected EPS Growth is defined as the expected % change in the EPS growth from the beginning of the current calendar year though the end of the 
calendar year. 2024 EPS Growth is defined as the % change in EPS from the beginning of the year through the end of the year. Data provided is for informational use only. See end of 
report for important additional information. Forecasts/estimates are based on current market conditions, subject to change, and may not necessarily come to pass.

36

Regions/Styles

S&P 500 Sectors

33.37

13.93 13.18 12.85
9.22 7.53 7.27 5.47 3.57 3.37

1.31

28.97

7.38

18.22

10.48
17.31

7.46
0.15 3.02 0.50

(10.0)

0.0

10.0

20.0

30.0

40.0

50.0

Russell 2000 Russell 1000
Growth

MSCI World ex
USA Small Cap

MSCI EM S&P 500 MSCI Asia Pac MSCI World Russell 1000
Value

MSCI EAFE MSCI Europe

Expected EPS Growth

2024 EPS Growth

17.59 15.81 14.52

8.73 7.82 6.88 6.67
3.64

0.68
0.09

-13.03

18.96

23.85

4.01
0.04

-10.24

18.74

12.52

4.13

16.84

2.17

-17.82(20.0)

(10.0)

0.0

10.0

20.0

30.0

Info. Tech. Communications Health Care Industrials Materials Financials Utilities Real Estate Discretionary Staples Energy

Expected EPS Growth

2024 EPS Growth