www.acea.auto 11 

Figure 3: Top 10 global car producers 

 

SOURCE: S&P GLOBAL MOBILITY