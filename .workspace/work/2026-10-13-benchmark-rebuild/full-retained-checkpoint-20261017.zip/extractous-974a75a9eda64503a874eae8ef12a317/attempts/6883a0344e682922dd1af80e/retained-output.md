The job market was hotter than ever in the professional 
services industry in 2021.

While headcount growth took a big jump from 5.5% in 
2020 to 9.1% in 2021, this figure could be much higher, 
if talent attrition didn’t also skyrocket.

While the good news is that layoffs were down by 11% 
compared to 2020, annual, voluntary talent attrition 
went up by 42% to 9.8%.

Headcount growth 
Hiring was heating back up in 2021 - but so was attrition

2017 2018 2020 20212019

5 years of bumpy headcount growth:

Having trouble attracting talent? 

 Do you have a clearly defined and marketed  
 career ladder, talent and mentoring   
 program within your organisation?

Initiated Piloted Deployed Institutionalised Optimised

Headcount growth across maturity levels
In the hunt for the best talent, mature companies manage 
to find and attract the people they need

7.0% 7.8% 9.0% 13.4% 15.4%

9.1%9.2%

7.7%

9.0%

5.5%

19