Chapter 2: Social convergence in the EU: taking stock 

61 

 

Chart 2.12 

Considerable and persistent variation in attitudes across the EU 
Proportion of population holding attitudes supporting gender equality (%) by country clusters, 1990-2017 

     

Note: Chart shows the following country clusters: west (Austria, Germany, France, the Netherlands); north (Denmark, Estonia, Finland, Sweden); south (Spain, Italy, Portugal); central 
(Czechia, Hungary, Poland, Slovenia, Slovakia); and east (Bulgaria, Lithuania, Latvia, Romania). Data on ‘children don’t suffer’ missing for Austria in 1999, and data for ‘women don’t 
prefer home’ missing for Austria in 1999 and Sweden in 1990. 

Source: DG EMPL calculations based on European Values Survey data 

Click here to download chart. 

 
Women and people with higher educational attainment (or incomes) are more likely to support 
gender equality in the labour market. Over the 1990-2017 period, women in the EU were around 8 pp more 
likely than men to reject the stereotypes that working motherhood harms children, that women prefer family over 
paid work and that men have a preferential right to scarce jobs (Chart 2.13). These views were also more 
common among people with higher educational attainment or (to a lesser extent) higher incomes. For example, 
those holding tertiary qualifications were around 13-17 pp more likely to report these attitudes than those 
without upper secondary or tertiary qualifications.  At the same time, people who are aged 65+, are religious, or 
have more traditional voting preferences are more likely to think that working motherhood harms children, and 
that paid work is valued differently by women and men (Chart 2.13). The differences in attitudes across 
population groups showed little change over the 1990-2017 period. 

1990 1999 2008 2017

Share household 
chores

0

10

20

30

40

50

60

70

80

90

100

1990 1999 2008 2017

Children do not suffer

1990 1999 2008 2017

Women do not prefer 
home

1990 1999 2008 2017

Scarce jobs accessible

West
North
South
Central
East

https://ec.europa.eu/employment_social/empl_portal/publications/Esde2024/xls/Chap2/Chap2-Chart-2.12.xlsx