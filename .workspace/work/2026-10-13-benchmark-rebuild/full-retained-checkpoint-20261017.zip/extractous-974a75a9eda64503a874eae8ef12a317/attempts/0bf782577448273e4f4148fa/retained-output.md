What are some things that I need to be aware of when 
taking alprazolam (Xanax®)? 

• Tell your doctor or pharmacist if you are allergic to 
alprazolam (Xanax®), or if you are allergic to any other 
medicines, foods, or substances 

• Before using this medicine, tell your doctor if you have 
glaucoma, liver disease, or lung disease 

• This medicine is a controlled substance and may be 
habit forming with long-term use 

• This medicine may make you drowsy. Do not drive or 
do other tasks or actions that call for you to be alert or 
have clear eyesight until you know how the medicine 
affects you 

• Avoid drinking alcohol (beer, wine, liquor, or mixed 
drinks). Drinking alcohol will increase your risk of side 
effects 

• Talk to your doctor before taking this medicine if you 
are pregnant, plan on getting pregnant, or if you are 
breastfeeding. You should not take this medicine while 
pregnant or breastfeeding 

• If you have been taking this medicine for more than 10 
days, talk with your doctor before stopping. You may 
want to slowly stop this medicine 

• If you drink grapefruit juice or eat grapefruit often, talk 
with your doctor before taking this medicine 

• If you stop smoking, talk with your doctor. How much 
medicine you take may need to be changed 

• Ask your doctor or pharmacist how to get rid of unused 
medicine. Do not put this medicine in the trash or flush 
down the toilet 

• Store in a cool, dry place. Protect from light and do not 
store in the bathroom 

Who should know I am taking alprazolam (Xanax®)? 

• Keep a list of all your medicines (prescription, natural 
products, supplements, vitamins, over-the-counter) and 
give it to your healthcare provider (doctor, nurse, nurse 
practitioner, pharmacist, or physician assistant) 

Are there any interactions with other drugs that I need 
to worry about? 

• There are many drug interactions that may increase 
your risk of side effects 

• Do not start new prescription, over-the-counter 
medicines, or herbal and dietary supplements without 
telling your doctor 

What side effects could occur with alprazolam 
(Xanax®)? 

• Upset stomach, throwing up, or diarrhea 

• Headache 

• Feeling dizzy; rise slowly over a few minutes when 
sitting or lying down 

What does alprazolam (Xanax®) do? 

• It is used to treat symptoms of anxiety 

• It is used to treat panic attacks 

How should alprazolam (Xanax®) be used? 

• Use this medicine as directed by your doctor 

• Many times this medicine is ordered to be taken on an 
as-needed basis 

• Take with or without food. Take with food if it causes an 
upset stomach 

What should I do if I forget to take a dose of alprazolam 
(Xanax®)? 

• Many times this medicine is ordered to be taken on an 
as-needed basis. Take s directed by your doctor 

• Take a missed dose as soon as you remember 

• If it is almost time for your next dose, skip the missed 
dose and go back to your normal dose time 

• Do not take 2 doses at the same tie or extra doses 

• Big change in balance 

• Change in thinking clearly and with 
logic 

• Feeling very tired or weak 

• Any sign of a severe allergic reaction 
including: rash; hives; red, swollen, 
blistered or peeling skin with or 
without fever; wheezing; tightness of 
chest or throat; trouble breathing or 
talking; swelling of face, lips, tongue 
or throat 

If you have any of the following side effects, call your doctor or visit the emergency room 
immediately: