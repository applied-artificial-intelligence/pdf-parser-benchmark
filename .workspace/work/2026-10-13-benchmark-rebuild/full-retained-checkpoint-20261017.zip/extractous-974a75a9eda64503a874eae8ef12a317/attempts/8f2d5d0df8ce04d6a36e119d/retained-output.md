Mandiant M-Trends 2025 Report 32

Data leak sites 
(DLS) are websites 
that publish stolen 
data of companies 
that refuse to pay 
a ransom. While 
this data is skewed 
toward targets 
who refused to 
pay attackers’ 
ransom demands, 
it is still useful for 
understanding 
broad trends 
in extortion 
operations.

Ransomware Operations
RANSOMHUB
The RANSOMHUB ransomware-as-a-service (RaaS) and associated DLS launched in early 2024. 
By the second half of 2024, RANSOMHUB RaaS became the most prolific DLS that Mandiant 
tracks, taking the top spot from LockBit after its activity declined following law enforcement 
action. RANSOMHUB was also tied for most frequently observed ransomware in Mandiant 
incident response investigations performed in 2024. Mandiant currently tracks multiple threat 
clusters that have used this ransomware brand, including UNC2165, UNC5227, and others. 

Jan Feb March April May June July Aug Sept Oct Nov Dec

C
ou

nt
 o

f D
LS

 L
is

tin
gs

100

0

150

50

200

0

RANSOMHUB
LockBit

LockBit vs. RANSOMHUB DLS Listings, 2024

UNC216518 is a financially motivated threat cluster that has been active since at least 2019 and 
has conducted ransomware and data theft extortion operations using HADES, LOCKBIT, CONTI, 
and RANSOMHUB ransomware. UNC2165 has primarily gained access to victim organizations 
from FAKEUPDATES infections, although, since late 2020, some intrusions appeared to leverage 
stolen credentials. UNC2165 has used various methods to escalate privileges conducting 
Mimikatz and Kerberoasting attacks, targeting authentication data stored in the Windows 
registry, and searching for documents or files associated with password managers or that may 
contain plaintext credentials. Historically, UNC2165 operations heavily relied on BEACON for 
lateral movement and to maintain access to the victim environment; however, since late 2023, 
UNC2165 has used the MYTHIC post-exploitation framework and VIPERTUNNEL tunneler in  
intrusions. In most cases, UNC2165 has also stolen data from victims using Rclone or MEGASync.

UNC5227 is a financially motivated threat cluster active since at least November 2023 that has  
monetized access via ransomware deployment and data theft extortion. In some cases, UNC5227 
has gained access to victim networks via brute-force attacks or stolen VPN credentials obtained 
from a separate threat cluster. UNC5227 relies on open-source tools, including MIMIKATZ and 
OPENSSH, to compromise additional accounts and move laterally through the network. They 
have also used PORTLIGHT, a custom Windows PowerShell utility for port-forwarding access 
using SecureShell (SSH) to maintain persistence, which may be exclusive to UNC5227. UNC5227 
also uses EXMATTER, a private file upload tool, on compromised devices for data staging and 
theft before deploying ransomware. UNC5227 has deployed LOCKBIT.BLACK, ALPHV, RHYSIDA, 
and RANSOMHUB ransomware, based on direct observations as well as overlaps observed in the 
wild with EXMATTER and reverse Secure Shell (SSH) infrastructure.