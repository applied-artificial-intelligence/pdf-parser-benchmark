145

C
h

ap
ter 4

Chapter 4 • LoCaL e-Government DeveLopment 

of the assessed portals, signaling an area in need of improvement. The availability of municipality 
budget information has improved but remains suboptimal at just under 58 per cent. More than 
two thirds of the city portals assessed now provide access to sports and cultural information and 
resources. The Government of Singapore12 offers a range of online services to support immigrants, 
fostering community integration and cultural acclimatization. The portal includes resources such 
as Your Neighbourly Welcome Guide, which offers new residents insights into local culture and 
encourages community bonding by sharing stories from established residents. The suite of available 
programmes includes home visits, community learning activities, and the Singapore citizenship 
Journey, culminating in a formal citizenship ceremony. Additionally, the portal features forums for 
residents to share opinions and facilitates annual meetings, allowing new immigrants to actively 
contribute to and benefit from community activities.

Figure 4.7 Implementation of content provision indicators in city portals: sectoral information

Figure 4.8 Implementation of content provision indicators in city portals: addressing everyday needs

35%

48%

50%

58%

67%

70%

74%

76%

30%

45%

49%

54%

63%

68%

70%

74%

0% 10% 20% 30% 40% 50% 60% 70% 80%

Services in partnership with civil society

Help desk access

Information for vulnerable groups

Municipality budget information

Sports and cultural information

Information about provided services

Municipality information

Municipality contact details

2022 2024

46%

46%

53%

54%

61%

63%

38%

39%

53%

52%

55%

56%

0% 10% 20% 30% 40% 50% 60% 70%

Justice information

Employment information

Education information

Social welfare information

Environmental information

Health information

2022 2024