RHODIUM GROUP  |  ENERGY & CLIMATE TAKING STOCK 2025 

20 
 

FIGURE 9 

Liquified natural gas exports 
Trillion cubic feet 

 
Source: Rhodium Group 
Note: The high, mid, and low ranges reflect uncertainty around future fossil fuel prices, economic growth, clean energy technology 
costs, and growth in LNG export capacity. 

International trade has an even bigger effect on US production of oil and other liquid fuels. 
Domestic consumption varies little, mostly due to the slow electrification of the vehicle 
fleet. Across the economy, domestic demand for liquid fuels increases by 1-5% in 2030 
compared to 2024 levels and changes by -5% to +5% in 2040 (Figure 10). Domestic 
production levels vary widely across scenarios, from a 21% decrease relative to 2024 
levels in 2040 in the low emissions case to a 40% increase in 2040 in the high emissions 
case. The level of net exports mostly causes this variation in production.    

Mid: 10 Tcf, +129%

Low: 8 Tcf, +94%
from 2024 levels

High: 11 Tcf, +150%

0

2

4

6

8

10

12

2024 2026 2028 2030 2032 2034 2036 2038 2040