49 © The Economist Intelligence Unit Limited 2024

Industry outlook 2025
Challenges, opportunities and trends to watch in six sectors

As a result, progress on the build-out 
of public healthcare systems will 
remain slow, as it has been since 
the pandemic. About a decade 
ago, when the UN’s sustainable 
development goals were adopted, 
2023 was set as the target year for 
achieving the so-called triple billion 
targets, which included extending 
UHC to 1bn additional people. 
During the pandemic these targets 

were deferred to 2025 but it now 
seems that this timeline will also be 
missed, jeopardising the even more 
ambitious targets set for 2030. We 
also expect minimal progress in 
lowering the unaffordable out-of-
pocket health costs for rural and 
poorer populations across Africa, 
Asia and Latin America.

Medical tourism will drive 
healthcare investment

Medical tourism will be a major 
driver of global health and 
pharmaceutical investment in 2025, 
as high prices in North America 
and western Europe cause people 
to travel abroad to access cheaper 
healthcare. Several countries, 
including Thailand, Turkey, the UAE 

and Mexico,  will focus on becoming 
top destinations for medical tourists 
by developing specialisms and 
boosting recruitment. Malaysia 
aims to become a premium medical 
tourism destination by 2025,  
under its Healthcare Travel 
 Industry Blueprint. 

% change in nominal US$ terms

% change in real US$ terms
Healthcare spending as a % of GDP

Source: World Bank, OECD, EIU.
Copyright © The Economist 
Intelligence 
Unit 2024. All rights reserved.

Global health spending will 
grow in real terms in 2025
The world's healthcare expenditure as 
a % of GDP will be largely unchanged  

2019 2020 2021 2022 2023 2024 2025
−8

−6

−4

−2

0

2

4

6

8

10

12

Healthcare spending fell inHealthcare spending fell in
real terms after the covid-real terms after the covid-

19 pandemic19 pandemic

Healthcare spending fell in
real terms after the covid-

19 pandemic

2018