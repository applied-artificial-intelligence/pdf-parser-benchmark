 23 

OECD EMPLOYMENT OUTLOOK 2024 © OECD 2024 
  

As for employment rates, they progressed more for women than for men in most OECD countries 

compared to pre-pandemic level, indicating that gender gaps in employment rates are narrowing in many 

OECD countries. Interestingly, data suggest that the higher the employment gender gap in Q4 2019, the 

greater was the growth in women’s employment rate between Q4 2019 and Q1 2024 (Annex Figure 1.A.1). 

Unemployment rates remain at historically low levels in many OECD countries (Figure 1.3). The 

unemployment rate for the OECD was already at its pre-COVID-19 level in January 2022 – before Russia’s 

full-scale invasion of Ukraine. Since then, the unemployment rate declined by a further 0.4 percentage 

points and stood at 4.9% in May 2024 after a record low of 4.8% in September 2023. Unemployment rates 

are below their levels of January 2022 in 17 OECD countries, and above that level by more than 

0.5 percentage points in 10 countries. 

The most recent data also suggest stable unemployment rates across countries, with only 

13 OECD countries having experienced an increase of more than a quarter of a percentage point over the 

past six months. Gender differences in the changes in unemployment rates between December 2019 and 

May 2024 are generally small: while not shown here, the gender gap in unemployment rates was rather 

stable on average for the OECD area except for Colombia, Costa Rica and Greece where it decreased by 

more than 2 percentage points. 

Figure 1.3. Unemployment rates remain at historically low levels in many countries 

Unemployment rate (percentage of labour force), seasonally adjusted data 

 

Note: The labour force population includes all those aged 15 or more. Euro Area refers to the 20 Eurozone countries. The labour force population 

includes all those aged 15 or more. The latest month refers to Q1 2024 for New Zealand and Switzerland; February 2024 for Iceland, 

March 2024 for the United Kingdom; April 2024 for Chile, Costa Rica and Türkiye; and June 2024 for Canada and the United States. 

Source: OECD (2024), “Unemployment rate” (indicator), https://doi.org/10.1787/52570002-en (accessed on 9 July 2024). 

StatLink 2 https://stat.link/1z75tu 

1.1.2. Labour force participation rates continue to increase while average hours worked 

are slightly below their pre-COVID-19 levels in several countries 

Labour force participation rates among the working age population have continued to increase in most of 

the OECD countries over the past year or so1 (Figure 1.4, Panel A). In Q1 2024, labour force participation 

rates were 1.3 percentage points higher than at the end of 2019 on average across the OECD. More than 

0

2

4

6

8

10

12

14

16

18
%

Latest (May 2024) Pre-crisis (December 2019) January 2022 Increased over the last 6 months

https://doi.org/10.1787/52570002-en
https://stat.link/1z75tu