Chapter 1: Main employment and social developments 

25 

 

Chart 1.6 

Employment rates rose in all population groups 
Employment rate by sex, age group, educational attainment level and citizenship (% of population of respective group), EU, 2023 

   

Note: % of population aged 20-64 for all groups, except by educational attainment (% of population aged 25-54). No data for International Standard Classification of Education (ISCED) 
3-4 GEN and VOC before 2021. ISCED (0-2) less than primary, primary and lower secondary education; ISCED (3-4 GEN) general upper secondary and post-secondary non-tertiary 
education; ISCED (3-4 VOC) upper secondary and post-secondary non-tertiary education; ISCED (5-8) tertiary education. 

Source: Eurostat [lfsi_emp_a, lfsa_ergaedn]. 

Click here to download chart. 

 
The employment rate in rural regions continued to increase, surpassing 75% for the first time. It is 
close to the employment rate of the total population at the EU level (75.3%), with differences across Member 
States.  

Increases in the numbers of permanent and full-time workers were the primary reason for the rise in 
employment. The proportion of temporary employment among individuals aged 15-64 in the EU dropped 
significantly during the COVID-19 pandemic in 2020 and has not returned to the same levels (23.1 million or 
11.6% in 2023, 1.6 pp below the 2019 rate and 0.5 pp lower than in 2022). Comparison of the growth rates of 
employment (+1.2%) and temporary employment (-3.8%) shows that more people have permanent contracts. 
The share of part-time workers aged 15-64 in the EU increased by 0.2 pp in 2023 (to 17.8%, or 35.4 million 
people), still below the 2019 rate (19.4%). The share of workers in temporary (12.8%) and part-time (28.5%) 
employment remained significantly higher among women than men (10.5% and 8.4%, respectively). The gender 
gap remained stable in both temporary employment (at 2.3 pp) and in part-time employment (at 20.1 pp). Care 
duties remain the main reason for part-time employment (21.2%), followed by no full-time job found (19.4%) 
and education and training (14.2%). The proportion of involuntary part-time employment as a share of total part-
time employment further decreased to 19.4% in 2023 (-1.5 pp) following a consistent trend since 2014.  

Working conditions have improved over the last decade. The number of workers working long hours 
decreased by nearly one-quarter compared to 2014, reaching 6.9% in 2023. Similarly, the share of workers with 
atypical working time was 33.9% in 2023, having decreased by nearly 5 pp over a 10-year period, with only a 
slight increase in 2021 due to the COVID-19 pandemic. The proportion of people working more than one job 
remained remarkably stable between 2020 and 2023 (3.9%), only a slight decrease since 2013 (-0.3 pp). 

3.2. Unemployment rates 

In 2023, unemployment levels remained at record lows. The unemployment rate among people aged 15-
74 declined modestly in both the EU (by 0.1 pp, to 6.1%) and euro area (by 0.2 pp, to 6.6%), reaching the lowest 
rates ever recorded by Eurostat. Compared to 2022, the reduction was 0.1 pp for both men (to 5.8%) and women 
(to 6.4%) (Chart 1.7). Among the signs of ongoing labour hoarding (as companies retain their employees despite 
an expected decrease in output in the short term) the unemployment rate is expected to remain broadly stable in 
2024, at 6.1%, before falling slightly in 2025, to 6.0%. (23) In 2023, the unemployment rate remained far higher 
for people with education levels up to lower secondary (11.9%, -0.4 pp from 2022) than for those with upper 
secondary and post-secondary (non-tertiary) education (5.6%, -0.1 pp from 2022) or with tertiary education 
(3.8%, stable from 2022). 

In 13 Member States, the unemployment rate declined compared to 2022. In most cases, the decrease 
was less than 1.0 pp, with the exception of Greece (-1.4 pp, to 11.1%). It remained stable in Romania (5.6%) and 
France (7.3%), and increased by between 0.1 pp and 0.9 pp in the remaining 11 Member States. (24)  

 
(23) (European Commission, 2024a) 
(24) Changes in unemployment in 2023 compared to 2022: 
• Decrease: Belgium (-0.1 pp), Germany (-0.1 pp), Poland (-0.1 pp), Ireland (-0.2 pp), Slovakia (-0.3 pp), Slovenia (-0.3 pp), Italy (-0.4 pp), 

Latvia (-0.4 pp), Malta (-0.4 pp), Cyprus (-0.7 pp), Croatia (-0.9 pp), Spain (-0.8 pp), Greece (-1.4 pp). 
• Stable: France, Romania. 

 

0

10

20

30

40

50

60

70

80

90

100

W
om

en

M
en

15
-2

4

25
-5

4

55
-6

4

IS
CE

D
 0

-2

IS
CE

D
 3

-4
 G

EN

IS
CE

D
 3

-4
 V

O
C

IS
CE

D
 5

-8

N
at

io
na

ls

M
ob

ile
 w

or
ke

rs

N
on

-E
U

 w
or

ke
rs

To
ta

l 2
0-

64

2022 2023 2012

https://ec.europa.eu/employment_social/empl_portal/publications/Esde2024/xls/Chap1/Chap1-Chart-1.6.xlsx