Executive Summary
Figure 15. We need political action but political coalitions aredifficult to form

Higher−educated voters voting for left−wing
parties (democratic, labor, social−
democratic, socialist, green, etc.)

Top−income voters voting for right−wing
parties (other parties)

−20%

−15%

−10%

−5%

0%

5%

10%

15%

19
60

−6
4

19
65

−6
9

19
70

−7
4

19
75

−7
9

19
80

−8
4

19
85

−8
9

19
90

−9
4

19
95

−9
9

20
00

−0
4

20
05

−0
9

20
10

−1
4

20
15

−1
9

20
20

−2
5D

iff
er

en
ce

 (
pp

):
 to

p 
10

%
 m

in
us

 
bo

tto
m

 9
0%

 v
ot

in
g 

le
ft

 (% of top 10% educated voting left) minus
(% of bottom 90% educated voting left)

 (% of top 10% earners voting left) minus
(% of bottom 90% earners voting left)

Education and income divides in Western democracies, 1960−2025

Interpretation. In the 1960s, both higher−educated and high−income voters were less likely to vote for left−wing
(democratic / labor / social−democratic / socialist / green) parties than lower−educated and low−income voters by
more than 10 percentage points. The left vote has gradually become associated with higher education voters,
giving rising to a multi−elite party system. Figures correspond to five−year averages for Australia, Britain, Canada,
Denmark, France, Germany, Italy, the Netherlands, Norway, Sweden, Switzerland, and the U.S. Estimates control
for income/education, age, gender, religion, church attendance, rural/urban, region, race/ethnicity, employment
status, and marital status (in country−years for which these variables are available). Sources and series: Gethin
et al. (2021) and World Political Cleavages and Inequality Database (wpid.world).

Figure 16. Divides between large cities and smaller towns havereached levels unseen in a century

Urban voters
vote more for
left parties

80%
90%

100%
110%
120%
130%
140%
150%
160%
170%
180%

18
40

18
60

18
80

19
00

19
20

19
40

19
60

19
80

20
00

20
20

Le
ft 

vo
te

: 
ur

ba
n 

50
%

 v
s.

 r
ur

al
 5

0%
(%

 o
f n

at
io

na
l a

ve
ra

ge
)

European elections 1994–2024

French legislative elections 1848–2022

Interpretation. This panel shows the ratio of the left−wing vote in urban areas to that in rural areas. It compares
the 50% most urban with the 50% most rural (by agglomeration size). In both European elections (1994–2024)
and legislative elections (1848–2022), the urban–rural gap widens markedly from the mid−1990s onward, with a
sharp rise in the 2024 European election. Sources and series: Cagé and Piketty (2025) and
unehistoiredunconflitpolitique.fr.

Ratio of left wing vote beween urban and rural areas, 1848−2022

24