46    

OECD EMPLOYMENT OUTLOOK 2024 © OECD 2024 
  

Figure 1.20. Job strain in OECD European countries, 2021 

Percentage of employees aged 16-64 in OECD European countries, 2021 

 

Note: Countries are ordered in Panel A by descending order of the incidence of job strain. “Average” is the unweighted average of the 

25 OECD European countries shown in this Chart. Figures in Panel B refer to the difference between job demands and job resources, capturing 

the degree of strain. Highly strained: Cases where the number of job demands exceeds by at least two the number of job resources. Moderately 

strained: Cases where the number of job demands exceeds by one the number of job resources. 

For further details on methodology, see Annex 1.B. 

Source: OECD calculations based on the European Working Conditions Telephone Survey (EWCTS) 2021 of the European Foundation for the 

Improvement of Living and Working Conditions (Eurofound). 

StatLink 2 https://stat.link/9qidkp 

Country differences in the share of workers’ experiencing job strain are likely to reflect different factors, 

such as different sectoral and occupational structures, different labour and employment policies,29 as well 

as different phases of the pandemic and policy responses to it. Moreover, as data display results for 2021, 

i.e., a year after most OECD European countries implemented lockdown measures and social distance 

requirement, results may also be affected by teleworking. For instance, those who were able to work from 

home fared best, while frontline workers during the COVID-19 pandemic fared poorly on several fronts and 

reported much higher exposure to physical risks than those working from home (Eurofound, 2022[21]). 

Controlling for a number of observable factors, such as individual characteristics, occupation structures 

and teleworking, explains some of the country variation30 in job strain, notably in the case of Luxembourg, 

Spain and Switzerland.31 Yet, significant cross-country variation remains unexplained that might be 

attributed to differences across countries in policy, norms, expectations, or attitudes towards job. 

0

5

10

15

20

25
%

A. Incidence of job strain

Both sexes Men Women

FRA

CZE

FIN

BEL

POL

DEU

AUT

ESPSWE
DNK

GRC

NOR

CHE

Average

IRL

GBR

ITA

SVK

LVA

HUN

LTU

LUX

PRT

NLD

EST
SVN

0

1

2

3

4

5

6

7

6 7 8 9 10 11 12 13 14

% of employees highly strained

% of employees moderately strained

B. Degrees of job strain

https://stat.link/9qidkp