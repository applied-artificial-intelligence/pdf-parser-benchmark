146    

OECD EMPLOYMENT OUTLOOK 2024 © OECD 2024 
  

industries also participate less frequently in formal and non-formal education and training programmes 

(Figure 3.5, Panel A). However, despite their relatively low educational attainment, they are less likely to 

earn low wages (i.e. a wage in the bottom two deciles of the wage distribution) and slightly more likely to 

earn high wages (i.e. a wage in the upper two deciles) than workers in other sectors. Indeed, higher wages 

in high-emission industries reflect higher firm wage premia, i.e. employers paying higher wages 

irrespective of workforce composition, rather than differences in skills among workers.6 Workers in high-

emission industries are further much more likely to be male, somewhat older and more likely to live in rural 

areas (Figure 3.5, Panel A). The combination of low skills, relatively high wages and living in rural areas, 

in particular, could have potentially important implications for the costs of job displacement. 

Figure 3.5. Workers in high-emission industries differ markedly from other workers 

Characteristics of workers in high-emission and low-emission sectors, EU-28 countries, 2018/19, percentage of each 

category 

 

Note: Data refer to the share of each category, expressed in percentages, except for age (average number of years). Low education refers to 

less than upper secondary, high education to more than upper secondary, tertiary. Participation in formal and non-formal education and training 

refers to participation over the 4 weeks prior to survey response in the EU-LFS. Cities refer to densely populated areas, rural areas refer to thinly 

populated areas. Towns and suburbs (intermediate density areas) are not shown. * High (low) wages refer to the top (bottom) two deciles of the 

hourly pay from the main job. ** High (low) wage premia refer to the top (bottom) two deciles of the firm-related wage premia distribution obtained 

from a regression of hourly pay onto categorical firm identifiers, age groups, gender, and education levels, and exclude Finland, Iceland, 

Luxembourg and Slovenia. Agriculture is excluded. 

Source: Eurostat, EU-LFS, 2019; Eurostat, Structure of Earnings Survey, 2018 (deciles). 

StatLink 2 https://stat.link/a710ng 

3.2. Analysing the consequences of job loss in high-emission industries 

This section provides an in-depth examination of the costs of job displacement in high-emission sectors 

based on harmonised linked employer-employee data from 14 OECD countries and a consistent 

econometric framework – see Barreto et al. (forthcoming[11]) for more details. 

3.2.1. Methodology and data for analysing job displacement in high-emission industries 

Determining the cost of job displacement for a given worker poses some methodological challenges. 

Ideally, one would like to compare the outcomes of the same worker in two states of the world, one in 

which the worker loses employment and another in which the worker continues to be employed. As this is 

0

10

20

30

40

50

Women Age Low-
educated

High-
educated

In formal
education or

training

In non
formal

education
and training

Rural Cities Low wage* High wage* Low wage
premia**

High wage
premia**

%

High-emission industries Rest of the economy

https://stat.link/a710ng