Source: Cetera Investment Management, National Bureau of Economic Research. Data as of 9/30/2025. 11

U.S. Economic Expansions and Recessions

*Current 

Expansion

37

45

39

24

106

36

58

12

92

120

73

128

65

11 10
8

10 11

16

6

16

8 8

18

2

0

20

40

60

80

100

120
#
 o

f 
M

o
n
th

s

Year Expansion Started

Expansion

Recession