65

C
h

ap
ter 2

Chapter 2 • Global trends in e-Government

Public procurement services

A total of 135 countries (70 per cent) have dedicated e-procurement portals, an increase of 4 per 
cent since 2022. The number of countries that issue digital invoices through their e-procurement 
portals has increased by almost 7 per cent and now stands at 101 (52 per cent). Nearly all countries 
in Europe (93 per cent) have e-procurement portals, and most (86 per cent) offer digital invoicing. In 
Asia and the Americas, about 80 per cent of countries have portals, but fewer (60 and 54 per cent, 
respectively) issue digital invoices. The gap is wider in Oceania and Africa, where the corresponding 
proportions are 57 versus 21 per cent and 39 versus 26 per cent, respectively. It is worth mentioning 
that once e-procurement portals are set up, it may take some time for countries to integrate digital 
invoicing. In the Americas, for instance, the number of countries with e-procurement portals has 
risen by 5.7 per cent since 2022, whereas the number of countries offering digital invoicing has 
increased by 14.3 per cent (see figure 2.24).

2.5.7 Targeted services for people in vulnerable situations

The number of countries providing information and services that target specific vulnerable populations 
decreased by an average of 5 per cent between 2022 and 2024. As shown in figure 2.25, the 
sharpest decline (13.5 per cent) is recorded for immigrants; this is an alarming shift given that in 
2022 the services aimed at supporting immigrants were provided by the highest number of countries 
(163, compared with 141 countries in 2024). The provision of services for women (148 countries) 
and people living below poverty line (132 countries) has also declined (by 8.6 and 8.3 per cent, 
respectively). The same is true for youth services (a drop from 155 to 152 countries, representing a 
1.9 per cent decline), and for services supporting persons with disabilities (a drop from 157 to 155 

Figure 2.24 Number and percentage of countries with e-procurement platforms and digital invoicing  
 capabilities, global and regional data, 2022 and 2024

Sources: 2022 and 2024 United Nations E-Government Surveys.

Very high EGDI
High EGDI
Middle EGDI
Low EGDI

193 UN Member States

Americas

Africa

Asia

Europe

Oceania

Very high EGDI
High EGDI
Middle EGDI
Low EGDI

127
countries,

66%

88
countries,

46%

19
countries,

35%

10
countries,

19%

26
countries,

74%

14
countries,

40%

36
countries,

77%

26
countries,

55%

39
countries,

91%

35
countries,

81%

7
countries,

50%

3
countries,

21%

4.1%

6.7%

3.7%

7.4%

5.7%

14.3%

4.3%

4.3%

2.3%

4.7%

7.1%

135 countries,
70%

101 countries,
52%

21 countries,
39%

14 countries,
26%

28 countries,
80%

19 countries,
54%

38 countries,
81%

28 countries,
60%

40 countries,
93%

37 countries,
86%

8 countries,
57%

3 countries,
21%

0%

20%

40%

60%

80%

100%

E-procurement
platform

Digital
invoicing

E-procurement
platform

Digital
invoicing

E-procurement
platform

Digital
invoicing

E-procurement
platform

Digital
Invoicing

E-procurement
platform

Digital
invoicing

E-procurement
platform

Digital
invoicing

193 UN Member States Africa Americas Asia Europe Oceania

Number and percentage of countries globally and in each region, 2022 

2024

2022

Percentage increase since 2022 Number and percentage of countries globally and in each region, 2022