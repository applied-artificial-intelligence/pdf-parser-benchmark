V E H I C L E C A P A C I T Y

Current Installed Annual Vehicle Capacity

Region Model Capacity Status

California Model S / Model X 100,000 Production

Model 3 / Model Y 550,000 Production

Shanghai Model 3 / Model Y >950,000 Production

Berlin Model Y 375,000 Production

Texas Model Y >250,000 Production

Cybertruck >125,000 Pilot production

Nevada Tesla Semi - Pilot production

Various Next Gen Platform - In development

TBD Roadster - In development

Installed capacity ≠ current production rate and there may be limitations discovered as production rates 
approach capacity. Production rates depend on a variety of factors, including equipment uptime, 
component supply, downtime related to factory upgrades, regulatory considerations and other factors.

Market share of Tesla vehicles by region (TTM)
Source: Tesla estimates based on latest available data from ACEA; Autonews.com; CAAM – light-
duty vehicles only
TTM = Trailing twelve months

7

During the quarter we brought down several production lines for upgrades at 
various factories, which led to a sequential decline in production volumes. We made 
further progress smoothing out the delivery rate across the quarter, with September 
accounting for ~40% of Q3 deliveries this year, compared to September accounting 
for ~65% of Q3 deliveries in 2022.

US: California, Nevada and Texas

At Gigafactory Texas, we began pilot production of the Cybertruck, which remains 
on track for initial deliveries this year. We are expecting the Model Y production rate 
in Texas to grow very gradually from its current level as we ramp additional supply 
chain needs in a cost-efficient manner. Production of our higher density 4680 cell is 
progressing as planned, and we continue building capacity for cathode production 
and lithium refining in the U.S.

China: Shanghai

Other than scheduled downtime in Q3, our Shanghai factory has been successfully 
running near full capacity for several quarters, and we do not expect a meaningful 
increase in weekly production run rate. Giga Shanghai remains our main export hub.

Europe: Berlin-Brandenburg

Model Y remained the best-selling vehicle of any kind in Europe year-to-date (based 
on the latest available data as of August). Similar to Texas, further production ramp 
of Model Y will be gradual.

0%

1%

2%

3%

4%
US/Canada Europe China