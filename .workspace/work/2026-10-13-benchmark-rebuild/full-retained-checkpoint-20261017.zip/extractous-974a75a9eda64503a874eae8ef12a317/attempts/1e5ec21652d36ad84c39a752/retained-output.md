24

2025 Global Automotive Consumer Study | Key Findings: Global Focus Markets

23%

25%

37%

38%

40%

49%

49%

51%

18%

23%

26%

29%

36%

27%

23%

25%

18%

21%

17%

13%

11%

11%

11%

11%

6%

10%

8%

5%

6%

5%

5%

6%

2%

4%

3%

2%

2%

3%

3%

3%

32%

18%

9%

12%

4%

6%

8%

5%

Japan

South Korea

Germany

UK

China

US

Southeast Asia

India

Every day 3-4 times per week 1-2 times per week 2-3 times per month Once a month Once every few months

Half of surveyed consumers in India, Southeast Asia, and the United States say they drive their vehi-
cle every day—roughly twice the number of consumers in Japan and South Korea who say the same, 
perhaps reflecting a difference in the quality and/or availability of mass transit across markets.    

Frequency of driving personal vehicle 

Note: Percentages may not add up to 100 due to rounding. 
Q70. How often do you drive your current vehicle?
Sample size: n = 1,001 [China]; 1,507 [Germany]; 1,000 [India]; 1,000 [Japan]; 1,012 [Republic of Korea]; 6,029 [Southeast Asia]; 1,505 [UK]; 1,002 [US]

Even though surveyed consumers in India drive a lot, many younger consumers there would be willing  
to give up vehicle ownership in favor of a MaaS solution. In contrast, only 1 in 3 younger consumers in  
Germany would be willing to do the same.

Willingness to give up vehicle ownership in favor of MaaS (% somewhat willing/willing/very willing) – 18- to 
34-year-old respondents

70%

54% 54%

44%
38% 37% 37% 35%

India China Southeast Asia US Japan Rep. of Korea UK Germany

Q63. To what extent would you be willing to give up vehicle ownership in favor of a fully available mobility-as-a-service (MaaS) solution going forward?
Sample size: n = 261 [China]; 344 [Germany]; 404 [India]; 191 [Japan]; 246 [Republic of Korea]; 2,116 [Southeast Asia]; 392 [UK]; 286 [US]