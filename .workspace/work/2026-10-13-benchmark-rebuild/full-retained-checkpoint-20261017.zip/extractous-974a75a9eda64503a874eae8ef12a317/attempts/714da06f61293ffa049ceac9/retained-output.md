Energy Technology Perspectives 2024 Chapter 1: The state of manufacturing and trade 
  

PAGE | 44 I E
A.

 C
C

 B
Y 

4.
0.

 

Materials production 
The rate of expansion of global capacity for producing key materials is generally 
much slower than for clean technology manufacturing, as they also serve the 
needs of other manufacturing sectors and construction, where materials demand 
is growing less rapidly. In the case of crude steel, nearly 60 Mt per year of new 
capacity was added on a net basis worldwide in 2023, boosting total capacity by 
around 2.5% (Figure 1.9). Around 40% of the steelmaking capacity added in 2023, 
and 50% in 2022, was associated with iron production, whereas the remainder 
consisted of standalone steelmaking capacity, much of which is used to recycle 
scrap steel in electric furnaces. This is reflected in the greater absolute quantities 
of steelmaking capacity added over the past 4 years (105 Mt cumulatively) relative 
to ironmaking capacity (70 Mt cumulatively), despite the fact that it takes around 
1.1 tonnes of iron to make a tonne of steel, when not using any scrap.  

 Global net manufacturing capacity additions for selected materials, 2020-
2023 

  
IEA. CC BY 4.0. 

Notes: RoW = Rest of World. Capacity additions exclude regions where capacity has fallen. Aluminium refers to primary 
production capacity only.  
Sources: IEA analysis based on IFA (2024); IEA (2024c); OECD (2024b); GEM (2024); and CRU (2024).  

China, India and the Middle East have together accounted for more than half of global net 
capacity additions for key materials and their intermediates since 2020. 

Installed primary aluminium production capacity grew by just 1% in 2023, reflecting 
a slowdown in China as production levels approached annual limits imposed by 
the government (S&P Global, 2022). Capacity for alumina production grew by 
around 5% in both 2022 and 2023.  

Ammonia capacity expanded by 7 Mt, or 3%, in 2022 – equivalent to around eight 
modern plants being completed – but was virtually unchanged in 2023. While the 
pipeline of electrolysis projects for ammonia for energy applications is growing 

0

 25

 50

 75

20
20

20
21

20
22

20
23

20
20

20
21

20
22

20
23

M
t

China European Union India Middle East United States RoW

Crude steel Iron

0

 3

 6

 9

20
20

20
21

20
22

20
23

Ammonia

0

3

6

9

20
20

20
21

20
22

20
23

20
20

20
21

20
22

20
23

Aluminium Alumina