Renewables 2025 Chapter 1. Renewable electricity 
Analysis and forecasts to 2030 
 

PAGE | 81  I E
A.

 C
C

 B
Y

 4
.0

. 

and Greece, where the difference could have been as much as 30-50 percentage 
points. In the Low-RES scenario, the energy security challenges during the 2022 
energy crisis would have been significantly more severe. 

Net imports of coal and natural gas, actual and in Low-RES scenario, 2023 

 
IEA. CC BY 4.0. 

Notes: RES = renewable energy source. The difference in volume of net imports between the Low-RES scenario and 
actual in Brazil is equal to 230%. 
 

The United Kingdom expanded its non-hydro renewable electricity generation 
nearly sixfold between 2010 and 2023. As a result, the share of its electricity 
supply met by imported fossil fuels decreased from around 45% in 2013 to less 
than 25% in 2023, despite declining domestic coal and gas output. In the Low-RES 
scenario, import dependence would have approached 60% by 2023. 

In China, despite massive domestic coal production, imports made up about 10% 
of the country’s total coal supply in 2023 – and nearly 40% of its natural gas. 
Without deployment of renewables over the past decade, China’ s fossil fuel-
based electricity generation would have been more than 25% higher. This would 
have potentially required a doubling of fossil fuel imports, raising China’s electricity 
supply import dependence from 7% to nearly 25%. 

Brazil, with one of the lowest fossil fuel import dependencies among large 
economies – around 5% in 2023 – would also have experienced significant 
impacts. Without wind and solar energy deployment, fossil-based generation 
would have needed to rise by around 170 TWh, primarily from imported natural 
gas. Imports of natural gas would have increased nearly five-fold, pushing 
electricity import dependence to almost 30%, despite the country’s large 
hydropower base. 

0%

20%

40%

60%

80%

100%

120%

0

 50

 100

 150

 200

 250

Ac
tu

al

Lo
w

 R
ES

Ac
tu

al

Lo
w

 R
ES

Ac
tu

al

Lo
w

 R
ES

Ac
tu

al

Lo
w

 R
ES

Ac
tu

al

Lo
w

 R
ES

Ac
tu

al

Lo
w

 R
ES

Ac
tu

al

Lo
w

 R
ES

Ac
tu

al

Lo
w

 R
ES

Ac
tu

al

Lo
w

 R
ES

Japan India Korea GermanyTürkiye Italy France UK Brazil

M
to

e

Net imports for other use Net imports for power Difference (%)

0%

20%

40%

60%

80%

100%

120%

0

 100

 200

 300

 400

 500

 600

 700

 800

Ac
tu

al

Lo
w

 R
ES

Ac
tu

al

Lo
w

 R
ES

China EU

M
to

e