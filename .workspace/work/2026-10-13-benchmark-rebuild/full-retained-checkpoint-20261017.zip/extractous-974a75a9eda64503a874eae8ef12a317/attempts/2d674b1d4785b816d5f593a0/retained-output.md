1969 1979 2000 2015

600-

W 500-

CL
@ 300

200-

age annual growth rate of overall GDP compared to 1979 (in brackets).

•16 fa

•12

Q
O

Q.

1969 1974 1979 1985 1990 1995 2000 2005 2010 2015
Years

FIG.2.10. Energy and nuclear power planning study for Algeria: past and future trends in overall and per capita GDP
and distribution by sector (in Algerian dinars (DA)). A: Agriculture. MI: Manufacturing industries. C: Construction.
E: Energy. El: Extractive industries. S: Services (including transport).

n
a
H
W