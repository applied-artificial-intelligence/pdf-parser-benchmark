 159 

OECD EMPLOYMENT OUTLOOK 2024 © OECD 2024 
  

low-emission industries, and the second component captures the structural effect, i.e. unexplained 

differences in the cost of job displacement between high- and low-emission industries holding 

composition constant. A similar decomposition can be used to shed light on the drivers of differences in 

the cost of job displacement in high-emission industries between countries. The results of the 

decomposition between industries within countries and within industries between countries are 

presented in Figure 3.12. 

The role of occupational composition 

While the baseline analysis for all countries focuses on the role of firm and worker composition in 

explaining differences in the cost of job displacement between industries and countries, for a subset of 

countries with information 3-digit occupations (ISCO), it is possible to go further by analysing the role of 

differences in the composition of occupations. Occupations are categorised into five groups based on 

their task content following Autor, Levy and Murnane (2003[50]): non-routine manual, routine-manual, 

non-routine cognitive analytic, routine-cognitive and non-routine interactive. The analysis reveals that 

occupational composition plays an important role in explaining differences in the earnings losses of 

displacement between high- and low-emission industries, on average across countries analysed 

(Figure 3.13). More specifically, the concentration of routine-manual occupations accounts for 32% of 

the difference in earnings losses between high- and low-emission industries. This suggests that 

displaced workers in emission-intensive occupations may have difficulty finding another job because 

opportunities in the same occupation are limited and they lack the skills to move to other occupations 

with higher skill requirements. 

Figure 3.13. The concentration of manual routine occupations in high-emission industries 
contributes to higher earnings losses from job displacement 

Oaxaca-Blinder Decomposition, difference in earnings losses between high- and low-emission sectors including 

occupational measures 

 

Note: Average across Germany, Finland, Portugal, Hungary and Sweden. Each bar represents the contribution of a given occupational 
measure to the overall difference in earnings losses between high- and low-emission sectors based on an Oaxaca-Blinder decomposition. 
The reference category is non-routine interactive. 
Source: National linked employer employee data, see Annex Table 3.B.1 for details. 

StatLink 2 https://stat.link/w1n74g 

 

-0.07 -0.06 -0.05 -0.04 -0.03 -0.02 -0.01 0 0.01

Routine cognitive

Non-routine cognitive analytic

Routine manual

Non-routine manual

Firm size

Firm wage premia

Worker FE

Tenure

Gender

Age

Unexplained

Explained

Difference

Earnings relaitve to pre-displacement average, p.p.

https://stat.link/w1n74g