EMISSIONS (continued)

Reducing Scope 3 Emissions and 
Engaging Suppliers and Licensees

Recognizing the complex challenge of achieving 
our Scope 3 GHG emissions targets, we have 
collaborated extensively across the company to 
develop our pathway and identify levers for a 
Scope 3 emissions reduction journey.

Strategies to reduce our broader value chain 
emissions include: working with strategic 
suppliers to increase operational efficiency and 
the adoption of renewable energy; exploring less 
carbon-intensive materials for our products and 
productions; employing sustainable design in 
new buildings; identifying climate-friendly food 
and beverage options; and exploring additional 
employee commuting programs. In fiscal 2024, 
through a capacity-building program, we 
collaborated with the consultancy firm 
Guidehouse, through the Supplier Leadership on 
Climate Transition program, to help 40 of our 
higher emitting suppliers and licensees develop 
their own emissions reduction targets in 
alignment with the latest guidance from SBTi. 

While we develop and implement our value 
chain decarbonization strategies, we will 
continue to improve our data collection and 
reporting methodologies.

Like most companies setting aspirational Scope 3 
targets, these are challenging goals, and success 
is not guaranteed. Achieving our target will 
depend on several external factors, including 
global policies toward clean energy solutions, 
actions by our suppliers to reduce their emissions, 
global economy-wide transitions to cleaner fuels, 
the availability of economically feasible solutions 
at scale, and consumer behavioral changes. 

WATER

  

Water is a highly localized issue, and our 
strategy incorporates individualized 
considerations in each geography. We continue 
to implement site-specific water strategies at our 
high-impact sites, including our global parks and 
corporate campuses. 

Watershed Stewardship

We have performed regional water studies and 
continue to collaborate with local stakeholders, 
including nonprofits, to promote the overall 
health of regional watersheds. In fiscal 2024, we 
supported a project in The Bahamas with The 
Nature Conservancy to help protect coastal 
communities by reducing the impacts of storm 
surge and flooding.

Water Conservation

We remain committed to implementing water 
conservation measures across our operations. 
During production on 20th Century Studios' 
Kingdom of the Planet of the Apes, which was 
released in fiscal 2024, the special effects team 
was able to use, and then recycle, water needed 
for filming. They sourced 60,000 liters of water 
that was treated and returned to the Sydney, 
Australia, water system after filming concluded.

Sustainable Seafood 

Responsibly selecting and sourcing seafood is an 
important aspect of our commitment to protect 
the health of our oceans. In fiscal 2024, our U.S. 
parks, U.S. resorts, and cruise line sourced 96% 
sustainable seafood.†

Table of 
Contents

Introduction & 
Our Approach

Governance

People

Environment

Emissions

Water

Waste

Materials

Sustainable Design

Nature

Data & 
Frameworks

23

We follow global frameworks to 
measure Scope 1, 2, & 3 GHG emissions:

Learn more:

2030 Water Goals

• Implement localized watershed 
stewardship strategies

• Source sustainable seafood†

GHG Protocol

2030 Environmental Goals White Paper

2024 CDP Survey Response

 † Disneyʼs definition of sustainable seafood can be found in our 2030 Environmental Goals White Paper. The breakdown of sustainable seafood in 
fiscal 2024 was 6% Best Choice, 70% Eco-certified, 5% Good Alternative, 4% Avoid, 15% Fishery Improvement Projects, and 1% Unrated.

https://ghgprotocol.org/
https://impact.disney.com/resources/2030-environmental-goals-white-paper/
https://impact.disney.com/resources/cdp-survey-response-2024/
https://impact.disney.com/resources/2030-environmental-goals-white-paper/