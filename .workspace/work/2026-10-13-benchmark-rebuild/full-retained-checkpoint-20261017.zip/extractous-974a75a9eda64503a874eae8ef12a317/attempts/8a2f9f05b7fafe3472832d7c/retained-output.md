Employment and Social Developments in Europe 2024 

62 

 

Chart 2.13 

Attitudes towards women’s position in the labour market vary between population groups 
Marginal change in probability of holding a given attitude (pp) by population group, 1990-2017, EU 

                    

Note: Probability differences reported against the following comparison groups: gender (men); age (20-39); educational attainment (finished education by 15 years of age); income 
(lowest income tercile); children (having at least one child); employment status (not in employment); town size (town of 500 000 inhabitants or more); religion (non-religious); 
political preferences (left-wing). Only statistically significant results (p-value<0.1) reported. Data on children don’t suffer missing for Austria in 1999; data for women don’t prefer 
home missing for Austria in 1999 and Sweden in 1990. 

Source: DG EMPL calculations based on European Values Survey data. 

Click here to download chart. 

 

5. EU INITIATIVES TO SUPPORT SOCIAL CONVERGENCE 
The EU supports social convergence through its cohesion policy. Since the 1950s, the main vehicle to 
foster territorial, economic and social convergence among Member States is European cohesion policy, delivered 
and implemented through the cohesion policy funds, including the European Development Fund, the Cohesion 
Fund, the European Social Fund+ and Just Transition Fund.  It aims to correct imbalances between countries and 
regions while delivering on the Union's political priorities, especially the green and digital transitions. Although the 
funds support all Member States and regions, a large share is concentrated on less developed countries and 
regions to foster their catching-up and reduce economic, social and territorial disparities in the EU, encouraging 
territorial cooperation and addressing needs of outermost regions. More recent funding instruments, such as the 
Recovery and Resilience Facility (RRF) which provides EUR 648 billion to Member States (in 2022 prices) for 
implementing reforms and investments to make their economies and societies more sustainable, resilient and 
prepared for the green and digital transitions, also contribute to promoting social convergence. (106) 

Several initiatives launched within the European Pillar of Social Rights aim to reduce disparities 
among Member States and regions. Proclaimed in Gothenburg in 2017, the European Pillar of Social Rights 
outlines 20 key principles necessary to progress towards a strong social Europe. To strengthen the 
implementation of the Pillar, the European Pillar of Social Rights Action Plan was adopted in 2021, containing 
more than 70 legislative and non-legislative actions to promote convergence of socio-economic outcomes in the 
Member States and proposing concrete targets. (107) Key policy initiatives supporting social convergence include 

 
(106) Please see Recovery and Resilience Facility (2020-2024) – mid-term evaluation (europa.eu). 
(107) An employment rate of 78% among the population aged 20-64, a 60% target for adults in training every year, and a reduction of at 

least 15 million in the population at risk of poverty or social exclusion (including at least five million children). 

-20.0 -10.0 0.0 10.0 20.0

Politics right

Politics centrist

Religious

Town size <20,000

Employed

No children

High income

Medium income

Higher education

Secondary education

Aged 65+

Aged 40 to 64

Women

Children don't suffer Women don't prefer home

Scarce jobs accessible Share household chores

https://ec.europa.eu/employment_social/empl_portal/publications/Esde2024/xls/Chap2/Chap2-Chart-2.13.xlsx
https://commission.europa.eu/about-european-commission/departments-and-executive-agencies-old/economic-and-financial-affairs/evaluation-reports-economic-and-financial-affairs-policies-and-spending-activities/mid-term-evaluation-recovery-and-resilience-facility-rrf_en