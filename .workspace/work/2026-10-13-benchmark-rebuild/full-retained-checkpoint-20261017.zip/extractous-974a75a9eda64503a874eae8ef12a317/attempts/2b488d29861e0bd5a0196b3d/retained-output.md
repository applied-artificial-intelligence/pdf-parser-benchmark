Renewables 2025 Chapter 1. Renewable electricity 
Analysis and forecasts to 2030 
 

PAGE | 110  I E
A.

 C
C

 B
Y

 4
.0

. 

Development of investment criteria in the past five years for new renewable generation 
and storage projects 

 
IEA. CC BY 4.0. 

Notes: IRR = internal rate of return. WACC = weighted average cost of capital. The IRR to WACC spread represents the 
value created by the project over the minimum required return. 
Analysed companies (6): EDP S.A.; Enel SpA; ENGIE SA; Orsted A/S; RWE AG; SSE Renewables Limited. 
Source: IRR-WACC spread targets announced in companies’ annual reports, investment plans and publications of 2021-
2025. 
 

Risk mitigation along the value chain: Focus on supply chains  
In response to trade policy changes, industry players are redesigning activities 
along their value chains. For instance, major solar PV manufacturers are pushing 
for further vertical integration. By owning or managing more parts of the supply 
chain, they can increase control over costs and strategic planning. A prevalent 
strategy is to localise supply chain elements by establishing or boosting domestic 
production capacities. This can reduce costs by avoiding trade tariffs and increase 
resilience through self-sufficiency. 

For wind manufactures, complex and strained logistics networks have created 
challenges in the past. Standardisation and reliance on proven solutions can 
reduce component-related costs, while designs adapted to transport-related 
infrastructure constraints (e.g. ports and shipping) can minimise bottlenecks. 

Healthy Balance sheets: Steady debt and shareholder 
remuneration  
The utilities and renewable IPPs we analysed often highlight their goal of 
maintaining a steady balance sheet and sustainable debt levels. Most of these 
large utilities and renewable IPPs have been (and plan to continue) sustaining a 
net debt-to-EBITDA ratio of less than four. 

0

50

100

150

200

250

300

350

400

2021 2022 2023 2024 2025

Ta
rg

et
 IR

R
 to

 W
AC

C
 s

pr
ea

ds
 (b

ps
)

Average threshold

Highest observed
threshold

Lowest observed
threshold