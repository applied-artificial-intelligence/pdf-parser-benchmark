Renewables 2025 Chapter 1. Renewable electricity 
Analysis and forecasts to 2030 
 

PAGE | 36  I E
A.

 C
C

 B
Y

 4
.0

. 

Expanded state-level auctions, the Capacity Investment Scheme and strong  
corporate demand support growth. These incentives, coupled with continued 
distributed solar PV expansion, will help Australia exceed its 2030 capacity 
ambitions. 

The renewable electricity capacity forecast for the ASEAN region has been 
revised almost 15% upwards from last year, primarily owing to improved outlooks 
for Viet Nam, Thailand and the Philippines. Between 2025 and 2030, ASEAN 
countries are expected to add over 95 GW of renewable energy capacity – nearly 
double the deployment of the previous six-year period. More than half of these 
additions will come from solar PV.  

Viet Nam is the region’s leader, accounting for over 40% of total growth, followed 
by Indonesia (20%). Both countries are anticipated to accelerate capacity 
expansion significantly towards 2030, particularly if remaining barriers are 
addressed under the accelerated case. Overall, the combination of more 
ambitious policy targets, strengthened implementation frameworks and increased 
adoption of grid flexibility solutions could enable renewable deployment in ASEAN 
to reach 70% above the main case – the highest upside potential of all major 
regions.  

Net capacity additions in ASEAN, main and accelerated cases, 2020-2030 

 
IEA. CC BY 4.0. 

Note: ASEAN = Association of Southeast Asian Nations. 
 

Viet Nam is expected to add 40 GW of renewable energy capacity over 2025-
2030, led by onshore wind and utility-scale PV. In April 2025, it updated its national 
Power Development Plan (PDP8) to significantly raise its 2030 ambitions, 
particularly for solar PV, prompting a 20% upwards revision to our forecast. The 
government also enabled direct PPAs between large consumers and generators, 
providing an additional boost to utility-scale deployment.  

0

 5

 10

 15

 20

 25

2020 2022 2024 2026 2028 2030

G
W

Main case

Viet Nam Indonesia Philippines Thailand Rest of ASEAN

2020 2022 2024 2026 2028 2030

Accelerated case