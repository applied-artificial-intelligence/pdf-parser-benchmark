Through dividends and share repurchases
Amounts in billions, except as noted.  Dollar changes may not recalculate due to rounding.

• Share repurchases during the 
quarter totaled $1,497 million 
representing 9.5 million shares, at 
an average price of $156.61 per 
share

• Remaining share repurchase 
authorization is $16.5 billion

Returns to 
shareholders $2.7 $2.2 $2.0 $1.6 $3.0

Returns to shareholders

$1.5 $1.5 $1.5 $1.5 $1.5

$1.2

$0.7
$0.5 $0.1 $1.5

Dividends Share repurchases

Q4 FY23 Q1 FY24 Q2 FY24 Q3 FY24 Q4 FY24

9