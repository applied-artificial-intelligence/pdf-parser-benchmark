BALANCE SHEET HIGHLIGHTS 
AS OF 31 DECEMBER 2023

Total Assets (S$’000) 6,068,711

Total Borrowings1 (S$’000) 2,322,400

Unitholders’ Funds (S$’000) 3,311,192

Market Capitalisation (S$’000) 1,563,486

Total Operating Expenses2 to NAV (%) 2.4

Notes:
1 Includes OUE REIT’s share of OUB Centre Limited’s loan and OUE Allianz Bayfront LLP’s loan.  

OUE REIT’s interest in One Raffles Place and OUE Bayfront are held via its indirect interest in OUB 
Centre Limited and direct interest in OUE Allianz Bayfront LLP, respectively

2 The total operating expenses incurred by OUE REIT Group and OUE REIT’s proportionate share 
of operating expenses incurred by its joint venture amount to approximately S$78.1 million.  
The amount included all fees and charges paid/payable to the Manager and interested parties

DISTRIBUTION  
PER UNIT (“DPU”)
FY 2023

2.09¢

NET ASSET VALUE 
(“NAV”) PER UNIT
(as of 31 Dec 2023)

S$0.60

PORTFOLIO VALUATION
(as of 31 Dec 2023)

S$6,276.5m

AGGREGATE LEVERAGE
(as of 31 Dec 2023)

38.2%

PROPORTION OF  
FIXED RATE DEBT
(as of 31 Dec 2023)

66.3% 
HOSPITALITY 
SEGMENT  
REVPAR

S$250

SINGAPORE  
OFFICE COMMITTED 
OCCUPANCY 
(as of 31 Dec 2023)

95.2%

SINGAPORE  
OFFICE RENTAL 
REVERSION

12.0%
PROPORTION OF  
UNSECURED DEBT
(as of 31 Dec 2023)

69.5% 

WEIGHTED AVERAGE 
ALL-IN COST OF DEBT
(as of 31 Dec 2023)

4.3%
per annum

(%)

Singapore 92.5
China 7.5

PORTFOLIO ASSET VALUE BY GEOGRAPHY 
(By proportionate interest)

(%)

Office 50.5
Hospitality 32.2
Retail 17.3

FY 2023 REVENUE CONTRIBUTION BY SEGMENT
(By proportionate interest)

ANNUAL REPORT 2023 09