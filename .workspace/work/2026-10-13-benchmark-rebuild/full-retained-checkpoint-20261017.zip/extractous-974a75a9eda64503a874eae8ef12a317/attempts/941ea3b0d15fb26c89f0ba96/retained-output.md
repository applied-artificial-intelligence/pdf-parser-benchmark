62    

OECD EMPLOYMENT OUTLOOK 2024 © OECD 2024 
  

Annex Figure 1.C.2. Real wages in selected OECD countries resulting from collective agreements 

Year-on-year percentage change, Q1 2018 to Q1 2024 

 

Note: International comparability of data on negotiated wages is affected by differences in definitions and measurement. Statistics are representative 
of all employees covered by a collective wage agreement for Austria, Belgium, the Euro Area (20), France, Germany, Italy, the Netherlands, Sweden, 
and the United States. In Canada, statistics refer to collective bargaining settlements of all bargaining units covering 500 or more employees (units 
of 100 or more employees for the Federal Jurisdiction). For Australia and Canada, statistics refer only to employees affected by an increase of the 
negotiated wage at date. Wage increases in Austria, Belgium, the Euro Area (20), Germany, Italy, the Netherlands, Sweden, and the United States 
refers to the average increase in negotiated wages (wages of union workers for the United States) weighted by the employment composition for a 
reference year (Laspeyres index). The reference year of the employment composition used is 2009 for Sweden, 2010 for Belgium and the 
Netherlands, January 2015 for the Euro Area (20), 2015 for Germany and Italy, 2016 for Austria, and 2021 for the United States. For Australia, 
Canada and France, wage increases refer to the average increase in negotiated wages weighted by the number of employees affected in the period 
considered. Private sector for Germany refers to all industries excluding agriculture, public administration, education, health, and other personal 
services (Sections B to N of the NACE rev. 2). 
Source: OECD calculations based on national data on negotiated wages, see Annex Table 1.C.3.in (Araki et al., 2023[11]) for further details; and 
OECD (2024), “Prices: Consumer prices”, Main Economic Indicators (database), https://doi.org/10.1787/0f2e8000-en (accessed on 28 June 2024). 

StatLink 2 https://stat.link/wz8xun 

-10

-8

-6

-4

-2

0

2

4

6

8

2018 2019 2020 2021 2022 2023 2024

%
Euro Area

-10

-8

-6

-4

-2

0

2

4

6

8

2018 2019 2020 2021 2022 2023 2024

%
Australia

-10

-8

-6

-4

-2

0

2

4

6

8

2018 2019 2020 2021 2022 2023 2024

%
Austria

Basic wage (all sectors) Basic wage (private sector)

Wage incl. lump sums and special payments (all sectors) Wage incl. lump sums and special payments (private sector)

-10

-8

-6

-4

-2

0

2

4

6

8

2018 2019 2020 2021 2022 2023 2024

%
Belgium

-10

-8

-6

-4

-2

0

2

4

6

8

2018 2019 2020 2021 2022 2023 2024

% Canada

-10

-8

-6

-4

-2

0

2

4

6

8

2018 2019 2020 2021 2022 2023 2024

%
France

-10

-8

-6

-4

-2

0

2

4

6

8

2018 2019 2020 2021 2022 2023 2024

%
Germany

-10

-8

-6

-4

-2

0

2

4

6

8

2018 2019 2020 2021 2022 2023 2024

% Italy

-10

-8

-6

-4

-2

0

2

4

6

8

2018 2019 2020 2021 2022 2023 2024

% Netherlands

-10

-8

-6

-4

-2

0

2

4

6

8

2018 2019 2020 2021 2022 2023 2024

%
Sweden

-10

-8

-6

-4

-2

0

2

4

6

8

2018 2019 2020 2021 2022 2023 2024

% United States

https://doi.org/10.1787/0f2e8000-en
https://stat.link/wz8xun