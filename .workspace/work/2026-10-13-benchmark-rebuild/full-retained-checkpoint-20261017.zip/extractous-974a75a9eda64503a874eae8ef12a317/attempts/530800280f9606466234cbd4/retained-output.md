Energy
Use 100 percent carbon-
free electricity in all 
manufacturing by 2035

Read More

In Climate Change — Achieving 
Carbon Neutrality on p.59

Achieve 32% renewable electricity by 2023 
and 100% carbon-free electricity by 2035

• In 2023 our global manufacturing operations used:
– 50.8% Renewable electricity
– 70.5% Carbon-free electricity

• Currently our manufacturing facilities in Europe, Mexico, and Ohio have the equivalent of 100% carbon-free
electricity sourcing

• Ford Argentina manufacturing facilities achieved 80% renewable electricity
• In 2023, Ford and our joint venture partners installed on-site solar panels at Sacramento HVC/HCC Regional

Distribution Daventry Parts Distribution Center, Ford Thailand Manufacturing, Auto Alliance Thailand, and
multiple Changan Ford plants

7 AFFRODABLEAND CLEAN ENERGY   12 RESPONSIBLE CONSUMPT ION AND  PRODUCTI ON 13 CLIMATE  ACTION 

Materials
Use only recycled or 
renewable content in 
vehicle plastics

Read More

In Circular Economy and 
End of Life on p.76

Expand our use of sustainable materials 
focusing on plastics, battery recycling, and 
sustainable sourcing

• More than 85%4 of our vehicle parts and materials are recycled and reused at their end of life
• Established an interim target of 20% renewable and recycled plastics by 2025 in new vehicle designs for

North America, Europe, and Turkey, and 10% in China
• Recover up to 20 million pounds of high-strength, military-grade, aluminum alloy per month through the

closed loop recycling system used to build F-series
• Used nine industry- and world-first plant-based materials in our production vehicles since 2000

11 SUSTAINABLE CITIES 
AND COMMUNITIES 

12 RESPONSIBLE 
CONSUMPTION AND 

PRODUCTION 

Waste
Reach true zero waste 
to landfill across our 
operations

Eliminate single-use 
plastics from our 
operations by 2030

Read More

In Circular Economy and 
End of Life on p.76

Global reduction of waste generated from 
manufacturing by 5% (absolute volume) 
(2022 baseline)

• 86 zero waste to landfill (ZWTL) sites
•

 

77% of manufacturing facilities are true ZWTL
11 SUSTAINABLE CITIES AND COMMUNITIES 12 RESPONSIBLE 

CONSUMPTION AND 
PRODUCTION 

Global reduction of waste disposed from 
manufacturing by 10% (absolute volume) 
(2022 baseline)

• Ford facilities around the world sent approximately 16,300 metric tons of waste to landfill, 8% less than in 2022

Work with selected suppliers to reduce our 
collective environmental footprint

• Increased number of suppliers participating in the M2030 climate program, helping suppliers establish
science-based targets, and measure, manage, and reduce climate emissions, water usage, and waste

Fundamentals — Sustainability at Ford — Products and Services — Environment — Social — Governance — Data — Appendices

16

Materiality Assessment — Sustainability Strategy — Sustainability Aspirations — Accelerating Progress — Create Sustainable Value — Human Rights Saliency Assessment — Stakeholders

Accelerating Progress
— continued
ESRS 2 SBM-1

Sustainability Aspirations Goals Progress
UN Sustainable 
Development Goals

F
o

rd
 I

n
te

g
ra

te
d

 S
u

s
ta

in
a

b
il
it

y
 a

n
d

 F
in

a
n

ci
a

l 
R

e
p

o
rt

 2
0

2
4