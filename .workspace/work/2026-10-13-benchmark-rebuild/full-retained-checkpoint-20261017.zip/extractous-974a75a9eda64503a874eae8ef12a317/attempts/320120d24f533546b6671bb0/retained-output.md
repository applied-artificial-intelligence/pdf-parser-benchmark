2025 Global Automotive Consumer Study | Key Findings: Global Focus Markets

More than half of surveyed consumers in China owned the same brand of vehicle prior to their current car, 
but nearly a third of survey respondents say they are first-time owners, signaling a need to build strong 
customer relationships to help ensure forward brand loyalty.

Percentage of consumers whose prior vehicle was from the same brand as current vehicle

Q6. Was your prior vehicle from the same brand?
Sample size: n = 852 [China]; 1,114 [Germany]; 646 [India]; 452 [Japan]; 618 [Republic of Korea]; 3,488 [Southeast Asia];  
1,044 [UK]; 821 [US]

However, three quarters of surveyed consumers in China say they intend to switch to another brand of 
vehicle the next time they are in-market, signaling the intensity of the competitive landscape in China. 
Conversely, consumers surveyed in Japan are generally more brand loyal, but the intended defection rate 
is rising across many global markets on a year-over-year basis.     

Percentage of consumers intending to switch to another brand* of vehicle

*Includes switching to a different brand from the same parent or a different brand from a different sales parent.
Q5. What brand is the vehicle you drive most often? Q26. What brand are you considering most for your next vehicle?  
[Brand switching percentage is based on a calculation involving these two questions.]
Sample size: n = 830 [China]; 1,073 [Germany]; 633 [India]; 398 [Japan]; 589 [Republic of Korea]; 3,807 [Southeast Asia]; 959 [UK]; 786 [US]

55% 55% 54% 51% 47% 45% 43% 42%

15%

36% 31% 45% 48%

31%
48% 51%

31%

9% 14%
4% 5%

25%
9% 7%

China Japan India Germany US Southeast Asia Rep. of Korea UK

Yes No Current car is my first vehicle

76%
72% 71%

63%
56% 54%

46%
39%

73%
78%

62%
57%

54%
51%

41%
35%

China India Southeast Asia Rep. of Korea UK US Germany Japan

2025

2024

15