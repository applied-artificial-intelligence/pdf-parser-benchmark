Chapter 6. Climate, a Capital Problem
Figure 6.2. Emissions are highly concentrated among the rich,especially when looking at ownership

10%
3%

43%

20%

47%

77%

15%

41%

0%
10%
20%
30%
40%
50%
60%
70%
80%
90%

Bottom 50% Middle 40% Top 10% Top 1%

S
ha

re
 in

 to
ta

l e
m

is
si

on
s

Consumption Private ownership

Emissions shares by groups

Interpretation. The figure shows the share of global GHG emissions attributable to the bottom 50% and the top 1%
of the world population. Emissions are separated into consumption−based (emissions from production attributed to
final consumers) and ownership−based (scope 1 emissions from firms and assets owned by individuals). Private
ownership−based emissions (representing around 60% of total emissions) do not include government−owned or
direct household emissions. The total volume of emissions covered by the ownership−based approach is relatively
close to that explicitly accounted for in the consumption−based approach presented here. The latter assumes that
emissions associated with government activities and investments, typically representing 30%–40% of total
emissions are distribution−neutral (Bruckner et al. (2022)). Groups are defined by consumption−based emissions
and wealth respectively, but both distributions are highly correlated. Sources and series: Bruckner et al. (2022) and
Chancel and Rehm (2025b).

middle-income groups, nearly all emissionsare linked to essential consumption —transportation, heating, or electricity. Forthe top 10%, and especially for the top1%, emissions from capital ownershipdominate, accounting for 75–95% of theirtotal footprint in France, Germany, and theUnited States. This also means that thewealthiest have a far greater capacity toreduce emissions without compromisingtheir living standards.
Taking a global view, net ownershippositions reveal how investors in high-incomecountries profit from pollution abroad.Figure 6.4 shows that major Europeaneconomies, Japan, and South Korea exhibitlarge positive net ownership-emissionpositions. In France, adjusting forinternational investment raises nationalemissions by 36%, reflecting the factthat French investors own pollutingproduction facilities abroad whose emissionsexceed those generated domestically byforeign-owned firms.
By contrast, manymiddle- and low-incomecountries show negative net positions: part

of the emissions from their domesticproduction is ultimately attributable toforeign investors in richer countries.
These patterns point to a crucialimplication: climate regulations andtaxation should take asset ownershipinto account. Evidently, stronger regulationson high-carbon investments are necessary.In addition, a carbon tax on wealth, basedon the carbon content of owned assets or ofinvestments, would arguably be significantlymore progressive than a consumption-basedlevy. It would ensure that those who profitmost from carbon-intensive activities, oftenacross borders, contribute their fair share tothe transition to a greener economy.

119