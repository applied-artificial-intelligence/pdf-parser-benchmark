Chapter 5. Exorbitant Privilege
Figure 5.2. Rich countries receive 1% of their GDP from the restof the world due to financial privilege

−6%
−5%
−4%
−3%
−2%
−1%

0%
1%
2%
3%

1980 1990 2000 2010 2020

E
xc

es
s 

yi
el

d 
 (

%
 o

f g
ro

up
 G

D
P

),
 M

E
R

Bottom 20%

20%−40%

40%−60%

60%−80%

Top 20%

By income group

−6%
−5%
−4%
−3%
−2%
−1%

0%
1%
2%
3%

1980 1990 2000 2010 2020

China

EASA (excl. China)

Europe

LATA

MENA

NAOC

RUCA

SSAF

SSEA

By world region

Interpretation. These two panels show excess yield income (privilege), defined as the difference between the
return on foreign assets and liabilities, as a share of national GDP across different country groupings. The left
panel presents data by per capita income quintiles. It shows that only the top 20% richest countries enjoy
consistently positive excess yield income (1% of their combined GDP by 2025). This privilege stems from the
centrality of these rich countries in the monetary and financial system. The right panel shows this pattern by
world regions. Financial privilege is overwhelmingly concentrated in East Asia, North America & Oceania, and
Europe, while the other regions face consistent financial burden relative to their GDP. Sources and series:
wir2026.wid.world/methodology and Nievas and Sodano (2025).

Excess yield (assets−liabilities) as % of group GDP, 1970−2025

comparing returns on investments directly.The richest 20% consistently earn moreon their assets abroad and pay less ontheir liabilities. Over the last half-century,global returns on assets have fallen forall, but the decline has been steepest forpoorer countries. More importantly, theliability costs have remained high or evenincreased for the poorer countries. Onlythe richest 20% have experienced a largedecrease in liability costs. The result is astructural advantage for rich countries: theyare “charged less” on what they owe.
These patterns are not the accidentaloutcome of market forces. They stem frompolicy design and institutional dominance.For instance, regulatory standards suchas Basel III increased the demand for“safe” assets, consolidating the role ofU.S. Treasuries and European sovereignbonds. Credit rating agencies, largelybased in advanced economies, reinforce theperception of safety for rich-country debtand risk for poorer-country debt. Centralbanks worldwide accumulate reserves indollars and euros, further entrenching thesystem. The broader implication is that the

richest economies do not simply benefit fromprivilege; they actively shape and maintainit. By controlling the currencies, rules, andinstitutions at the center of global finance,they secure a rentier position that channelsincome from the rest of the world, therebyexacerbating inequality across countries.
Barriers for reducing inequality across countries
The financial asymmetries documentedin this chapter are not only technicalimbalances; they translate directly intobarriers for development. Figure 5.8illustrates how poorer countries systematicallytransfer resources to richer ones, constrainingtheir fiscal capacity and long-term growthprospects.

The bottom 80% of countries devotea significant share of their GDP to netincome outflows, which can be seen as thecost of financing the privilege for the top20%. These outflows, averaging 2–3% ofGDP each year, represent resources thatcould otherwise be invested in schools,hospitals, or infrastructure. The cost is
106