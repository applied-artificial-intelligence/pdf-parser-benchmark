 161 

 

DO ADULTS HAVE THE SKILLS THEY NEED TO THRIVE IN A CHANGING WORLD? © OECD 2024 
  

The average total variation in wages accounted for by numeracy and literacy skills and education increased 

slightly between the two cycles of the Survey of Adult Skills, from 14% to 15%, although this relatively 

stable picture conceals considerable changes in many countries (Figure 4.8). Looking at the variation in 

wages accounted for by skill proficiency reveals an increase of 1.3 percentage points, from 4.5% to 5.8%, 

between cycles. This increase was most pronounced in Czechia (8 percentage points) and France 

(7 percentage points). On the other hand, there were marked decreases in Singapore (7 percentage 

points), the United States (6 percentage points) and Israel (6 percentage points). The change is 

particularly striking in Singapore, where proficiency in literacy and numeracy accounted for the greatest 

share of variation in wages of any country in the first cycle. 

Figure 4.8. Trends in the contribution of education and skills to variation in wages  

Variation explained by skills and education, Cycle 1 and Cycle 2 

 

Note: Employed adults aged 25-65 not in formal education; does not include adults who were only administered the doorstep interview due to a 

language barrier (see Box 1.1 in Chapter 1 and Box 4.1). Decomposition calculates the percentage contribution to variance in log wages of the 

following factors: skills proficiency (numeracy and literacy), years of education, job tenure, field of study (9 categories) and individual 

characteristics (age, gender, immigrant background, and whether one lives with a partner or has children); wages are (log) gross hourly earnings 

for employed and self-employed individuals, including bonuses, in PPP-adjusted 2022 USD. See Fields (2003[43]) for further details on the 

decomposition method. Cycle 1 data refer to 2012 for all countries except for Chile, Israel, Lithuania, New Zealand, Singapore (all 2015) and 

Hungary (2017). All Cycle 2 data refer to 2023. Only countries and economies that participated in both cycles of the Survey of Adult Skills are 

presented. *Caution is required in interpreting results due to the high share of respondents with unusual response patterns. See the Note for 

Poland in the Reader’s Guide. 

Countries and economies are ranked in descending order of the share of the variation in wages explained by skills and education in Cycle 2. 

Source: OECD (2018[35]; 2015[36]; 2012[37]), Survey of Adult Skills (PIAAC) databases, http://www.oecd.org/skills/piaac/publicdataandanalysis/  

(accessed on 23 September 2024); Tables A.4.9a (L, N) in Annex A. 

As this analysis shows, skills and education continue to be rewarded in the labour market, particularly in 

terms of wages, which have a much clearer relationship with numeracy and literacy skills than with 

employment. As discussed above, one explanation for the smaller relationship with employment is the 

comparatively tighter labour markets that prevailed during the second cycle (2022-23) compared to the 

first cycle (2011-17) of the survey; high demand for labour may have led to high employment rates 

regardless of skill proficiency. Although much of the variation in wages remains unexplained, information-

processing skills and, particularly, education do explain a substantial proportion. It is perhaps unsurprising 

that education remains more important for wages, as it captures a much wider range of the knowledge, 

skills and attitudes that are rewarded in the labour market (Durlak et al., 2011[17]; Heckman and Kautz, 

 ears of education   Cycle 1 Skills   Cycle 1  ears of education   Cycle 2 Skills   Cycle 2

 0

3 

30

2 

20

1 

10

 

0

S
in
g
a
po

re

G
er
m
a
ny

F
in
la
n
d

H
u
ng

a
ry

E
ng

la
nd

 (
U
 
 

 
et
he

rl
a
nd

s

C
hi
le

C
an

ad
a

C
 e

ch
ia

F
ra
n
ce

 
ew

  
ea

la
n
d

S
w
e
de

n

 
E
C
 
 a
ve

ra
g
e

S
p
ai
n

U
ni
te
d 
S
ta
te
s

 
e
nm

ar
k

It
a
ly

E
st
o
ni
a

A
us

tr
ia

 
or
w
ay

F
le
m
is
h 
R
e
gi
o
n 
( 

E
 

 a
p
an

 i
th
ua

n
ia

Ir
el
an

d

P
ol
a
nd

 

S
lo
 a

k 
R
ep

ub
lic

Is
ra
e
l

 
or
e
a

 

http://www.oecd.org/skills/piaac/publicdataandanalysis/