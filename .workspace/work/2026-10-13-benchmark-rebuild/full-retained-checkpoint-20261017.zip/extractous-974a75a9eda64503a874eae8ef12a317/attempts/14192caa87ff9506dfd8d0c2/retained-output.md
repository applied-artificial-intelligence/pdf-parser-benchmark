These changes are in large part driven by the emerging habits of 
a new generation of social natives as they come into adulthood. 
In the next chart, which shows main access by age in the UK, we 
find that millennials within our 25–34 group (orange line) and 
those older than 35 (magenta line) have only slightly changed 
preferences over time, but the 18–24 group (turquoise line) has 
become significantly less likely to use a news website or app. 
This is another illustration that this youngest generation, which 
has grown up with social media, is not just different but is more 
different than the one that came before.

For further analysis see Section 2.3: The Changing News Habits  
and Attitudes of Younger Audiences

IS FACEBOOK LOSING ITS SHEEN? 

Each year since 2014, we have tracked the different social networks 
used for any purpose and for news across 12 countries. Facebook 
usage for any purpose (60%) is down five percentage points since 
its peak in 2017 and is now at a similar level to YouTube. Instagram 
(40%), TikTok (16%), and Telegram (11%) are the only networks to 
have grown in the last year.

Once again, most of these changes – such as the decline in Facebook 
use over the last few years – result from shifts in behaviour of the 
youngest cohort of social natives, not older respondents, who tend to 
have more entrenched habits. In the following chart from the UK, we 
illustrate how the attention of this group has gradually shifted – from 
Facebook, to Instagram, and now to TikTok.

When it comes to news usage specifically, Facebook remains the 
most important network across our basket of 12 countries, but has 
dropped by 12 percentage points since 2016. Twitter has largely 
stagnated over the last decade in terms of its user base, though it 
remains hugely influential with journalists and politicians. Confusion 
over its future direction is likely to persist following the attempt to 
take over the company by Elon Musk8 and the subsequent loss of 
senior executives. Meta-owned Instagram is now more widely used 
for news, while TikTok has overtaken Snapchat from a low base.

REUTERS INSTITUTE FOR THE STUDY OF JOURNALISM / EXECUTIVE SUMMARY GRAPHS

Graph 29

PROPORTION WHO START THEIR NEWS JOURNEY WITH  
A NEWS WEBSITE OR APP – BY AGE – UK

Q10. Thinking about how you got news online (via computer, mobile, or any device) in the last 
week, which were the ways in which you came across news stories? Base: 2018–22; 18–24 ≈ 200, 
25–34 ≈ 300, 35+ ≈ 1500.

Coronavirus

53%
52%
52% 

28% 

45%
49%

0%

25%

50%

75%

100%

35+
25-34
18-24

   20222021202020192018201720162015

18-24 25-34 35+

Gap opening up 
between 18-24s 

and the rest

Decline mirrors 
rise in social 
media use 
by 18-24s

REUTERS INSTITUTE FOR THE STUDY OF JOURNALISM / EXECUTIVE SUMMARY GRAPHS

Graph 30

PROPORTION THAT USED EACH SOCIAL NETWORK FOR ANY 
PURPOSE IN THE LAST WEEK (2014-22) – AVERAGE OF  
12 MARKETS

Q12a. Which, if any, of the following have you used in the last week for any purpose? Base: 
Total 2014–22 sample in selected markets (most n ≈ 2000). Note: From 2015–21 the 12 countries 
included are: UK, USA, Germany, France, Spain, Italy, Ireland, Denmark, Finland, Japan, Australia, 
and Brazil.  In 2014 we did not poll in Australia or Ireland.

27%
24%

0%

25%

50%

75% Telegram
TikTok
YouTube
WhatsApp
Snapchat
Instagram
Twitter
Facebook Messenger
Facebook

 202220212020201920182017201620152014

51%

17%

60%60%

31%

8% 5% 2% 5%

21%19%
16%
12%11%

34%

61%

53%

Facebook
Snapchat WhatsApp YouTube Telegram TikTok

Facebook Messenger Twitter Instagram

40%

REUTERS INSTITUTE FOR THE STUDY OF JOURNALISM / EXECUTIVE SUMMARY GRAPHS

Graph 32

27%
24%

0%

25%

50% TikTok
YouTube
WhatsApp
Snapchat
Instagram

Facebook Messenger
Twitter

Facebook 202220212020201920182017201620152014

7%
4%
2%

PROPORTION THAT USED EACH SOCIAL NETWORK FOR NEWS 
IN THE LAST WEEK (2014-22) – AVERAGE OF 12 MARKETS

Q12b. Which, if any, of the following have you used in the last week for news? Base: Total 2014–22 
sample in selected markets (most n ≈ 2000). Note: From 2015–21 the 12 countries included are: UK, USA, 
Germany, France, Spain, Italy, Ireland, Denmark, Finland, Japan, Australia, and Brazil.  In 2014 we did not 
poll in Australia or Ireland.

15%

7%

30%

36%

6%
2% 1% 1%

11%9%

19%
16%

Facebook
Snapchat WhatsApp YouTube TikTok

Facebook Messenger Twitter Instagram

12%

REUTERS INSTITUTE FOR THE STUDY OF JOURNALISM / EXECUTIVE SUMMARY GRAPHS

Graph 31

PROPORTION OF 18–24s (SOCIAL NATIVES) WHO USED 
EACH SOCIAL NETWORK FOR ANY PURPOSE IN THE LAST 
WEEK (2014–22) – UK

Q12a. Which, if any, of the following have you used in the last week for any purpose?  
Base: 2014–22: 18–24s ≈ 200.

27%
24%

0%

25%

50%

75%

100% WhatsApp
TikTok
Instagram
Facebook

 202220212020201920182017201620152014

17%

62%
51%

78%

20%

4%

Facebook WhatsAppTikTokInstagram

68%

32%

18-24 cliff edge started in 2018 which  
is when Instagram started to take over

8 https://www.cnbc.com/2022/04/26/elon-musks-twitter-takeover-sets-up-a-potential-clash-with-europe.html

Reuters Institute for the Study of Journalism   |   Digital News Report 202224