2025 Professional Services Maturity™ Benchmark  Finance & Operations Pillar 
  

 

 

© 2025 Service Performance Insight, LLC www.workday.com/professionalservices 193 

FINANCE AND OPERATIONS PILLAR 

The Finance and Operations pillar encompasses the responsibilities typical of the CFO 
in prominent PSOs. This aspect is integral to the role of the Chief Service Executive 
across all PS organizations, regardless of their size. In this service performance pillar, 
SPI Research evaluated 38 key performance indicators related to revenue, margin 
achievement, and operating expenses. The analysis includes detailed profit and loss 
statements and expense ratios categorized by organization size, geography, and 
industry. 

SPI Research has noted operational trends in Figure 31, indicating a deterioration of 
financial and operational performance. The ability to meet revenue targets (margins) 
also declined in 2024 as problems related to sales and service delivery became more 
pronounced. Achieving targets and maintaining high revenue levels per consultant is 
crucial, and these metrics are heavily influenced by operational success. The data 
emphasizes the necessity for PSOs to reassess their performance in sales and delivery and make 
necessary adjustments to enhance both areas in 2025. 

Figure 31:  Finance & Operations Trends of Note 

Source: SPI Research, February 2025 

Finance and Operations Maturity 

Figure 32 illustrates the significance of reaching higher levels of performance. The gap between Level 1 and 
Level 5 performance is substantial. Profitability at Level 5 is notably higher, which should capture the 
attention of executives. However, since numerous factors influence profitability, they must evaluate 
improvements across the organization. Level 5 organizations operate at a much higher financial standard 
than their peers, with much of their success attributed to structured service delivery and enhanced 
visibility throughout the organization. Rapid changes in the industry mean that PSOs capable of efficiently 
preparing for and managing these changes will thrive in the long term.