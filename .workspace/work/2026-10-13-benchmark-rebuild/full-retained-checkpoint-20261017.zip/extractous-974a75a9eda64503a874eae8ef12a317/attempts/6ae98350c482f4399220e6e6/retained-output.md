Fundamentals Sustainability at Ford Products and Services Environment Social Governance Data Appendices

Materiality Assessment Sustainability Strategy Sustainability Aspirations Accelerating Progress Create Sustainable Value Human Rights Saliency Assessment Stakeholders

 —   —   —   —   —   —   — 

21

 —   —   —   —   —   — 

How We Create 
Sustainable Value 
ESRS 2 SBM-1

Our Enablers

Human Capital
• 174,000 employees1

• 8,000+ dealerships
• 1,600+ Tier 1 suppliers
• 10 Employee Resource Groups

Social Capital
• Community Relations department focused on engagement with 

manufacturing communities
• Community engagement for 70+ years through Ford Motor 

Company Fund, our philanthropic arm
• Partnerships with nonprofits, community organizations, and Ford 

dealers in 40+ countries
• Strategic partnerships with investors, industry bodies, and partner 

companies
• Blue Table Forum
• STEM programs and EV training centers to develop future 

workforce

Financial Capital
• Fully allocated $4.21 billion through two Green Bond issuances 

under our Sustainable Financing Framework, all proceeds went 
towards Clean Transportation 

Manufactured Capital
• 41 manufacturing and assembly plants6

• Product Development Center
• Modernizing EV production

Intellectual Capital
• 2,133 global patents issued
• 379 patents issued in EV technology
• Connectivity and connected services
• FordPass network
• Global Data Insight and Analytics
• D-Ford human-centered design process

Natural Capital
• 10.09 billion kWh of energy used
• 50.8% of electricity used at manufacturing facilities was 

renewable, and 70.5% carbon-free
• 15.6 million cubic meters of water used globally
• 9 renewable materials used

Our Businessè è

1 Design
We consider sustainability criteria 
to reduce our vehicles’ impacts

2 Responsible Sourcing 
We require suppliers to have 
environmental and social standards 
aligned with ours

3 Logistics (inbound)
We encourage our logistics providers 
to transport and deliver materials and 
parts efficiently

4 Manufacturing
We invest in lean processes and 
world-class factories to create 
positive impact

5 Logistics (outbound)
We encourage our logistics 
providers to transport finished 
vehicles efficiently

6 Sales and Service
We are reimagining customer 
experience by listening and 
adapting to their needs

7 Our Vehicles in Use
We are continuously improving 
our vehicles' environmental 
impact, safety, and quality

8 Mobility
We are exploring new solutions to 
support urban mobility

9 End of Vehicle Life
Over 85%4 of our vehicle parts and 
materials are recycled and reused 

Our Purpose
To help build a better world, where every person 
is free to move and pursue their dreams.

Our Impact in 2023

Employees
• Health and wellbeing programs for 

employees and families
• Competitive salaries and benefits
• Employee training and development
• Culture of caring and inclusion

Customers
• 4.413 million wholesale vehicles sold 

globally
• 130,905 EVs sold globally
• Access to EV charging networks
• Remote Pickup & Delivery and Mobile 

Service vans
• Improved vehicle safety and driver assist 

technologies
• 109 safety recalls and 7.8 million passenger 

vehicle recalls globally

Investors
• Strong balance sheet
• Financial flexibility to invest in Ford+ 

growth plan
• Disciplined capital allocation
• Focus on total shareholder return
• More transparent reporting for investors

Suppliers
• Training to build capacity to manage 

supply chain sustainability issues
• Integrated sustainability metrics into 

sourcing decisions
• Sustainability best practices shared with 

suppliers through best practice climate 
program

• CO2e emission reduction targets collected 
and assessed to develop joint roadmap 
supporting carbon neutrality aspiration

• Increased transparency into supply chains 
to support responsible sourcing of raw 
materials

Communities and Society
• Invested $73.7 million in charitable 

contributions
• 2.3 invested in communities globally 

since 1949
• 1.7 million employee volunteer hours since 

2005 through the Ford Volunteer Corps
• Responsible mineral sourcing program 

provides training to advance financial literacy 
for women in the Democratic Republic of 
the Congo 

Planet
• 387 million metric tons of greenhouse gases 

(GHGs) emitted total (Preliminary 2023 Scope 
1, 2, and 3)

• 47% reduction in Scope 1 and 2 operations 
(manufacturing + non-manufacturing) GHG 
emissions since 2017

• 19% reduction in total Scope 3 GHG emissions 
since 2019

• Used 15.6 million cubic meters of water, 
achieving a 19.4% reduction from 2019

• 86 true zero waste to landfill sites
• Sent 16.3 million kilograms of waste to 

landfill and recycled 938.8 million kilograms 
• Recycle millions of pounds of aluminum 

per month