F I G U R E  4 Share of global exchange reserves, global export invoicing and foreign transaction by currency

While the US dollar will likely continue to play a 
significant role as a reserve and funding currency, it is 
becoming less dominant as a medium of exchange 
for financing goods and services trade. Amid a trend 
towards greater trade regionalization, the renminbi 
and euro are expected to become more important 
within Asian and European trade.13 Data from 
October 2024 shows that the renminbi is the second 
largest global currency in the trade finance market, 
with a share of 5.8%, just ahead of the euro but 
behind the US dollar, which has a share of around 
83%.14 Digital currencies, including wholesale central 

bank digital currencies (CBDCs), could provide 
alternative cross-border payment rails, creating a 
more diverse global financial landscape. 

Moreover, rising debt levels in the United States 
raise questions about debt sustainability, while 
growing domestic political polarization could 
undermine the independence of US institutions. 
Over time, these developments could reduce 
confidence in the dollar and lead to a more 
multipolar currency system.

Even as financial integration continued to deepen 
in the 2000s, challenges to the system began to 
emerge. A crucial turning point came after the 
terrorist attacks on 11 September 2001, which 
shifted some governments’ view of the financial 
system not just as economic infrastructure, but as a 
powerful tool of economic statecraft.

Economic statecraft broadly refers to the use of 
economic tools and policies by a state to achieve 
its foreign-policy and domestic objectives. Such 
measures can include punitive steps such as 
sanctions, designed to pressure norms-violating 
countries and to protect the issuing government’s 
interests, as well as inducements, such as trade 
agreements aimed at improving relationships and 
fostering cooperation.

1.3 Use of the financial system for economic statecraft

Global exchange reserves Share of export invoicing Share of daily foreign transactions

Billions of US dollars%

GBPEUR RMBJPYUSD

0

10

20

30

40

50

60

70

80

90

100

0

10

20

30

40

50

60

70

80

90

100

58%

20%

6%
2%

48%

$88

$31

$13
$17

$7

22%

7%
4% 4%5%

Note: To calculate share of export invoicing, project team used the Bloomberg Intelligence FX Strategy Dashboard and Global SWIFT data as a proxy 
using inbound and outbound traffic processed via SWIFT. To calculate share of foreign transactions, project team used the turnover of OTC foreign 
exchange instruments by currency, “net-net” basis, 2022 daily averages in billions of USD.

Source: Share of global foreign exchange reserves: IMF’s Currency Composition of Official Foreign Exchange Reserves Q2 2024. Share of export 
invoicing: Bloomberg Intelligence FX Strategy Dashboard. Share of foreign transactions: BIS Triennial Survey, Data Portal. Oliver Wyman analysis

 Economic 
statecraft broadly 
refers to the use of 
economic tools and 
policies by a state to 
achieve its foreign-
policy and domestic 
objectives.

Navigating Global Financial System Fragmentation 12