The BEAT | June 2025

Global Bond Yields Are on the Rise – Not Unique to the U.S.

TOP THEMES

Source: Bloomberg, MSIM. As of May 20, 2025. For illustrative purposes only. Not a recommendation to buy or sell any security. It is not possible to invest directly in an index. The views 
and opinions expressed are those of the portfolio management team at the time of writing/of this presentation and are subject to change at any time due to market, economic, or other 
conditions, and may not necessarily come to pass.  Forecasts/estimates are based on current market conditions, subject to change, and may not necessarily come to pass. Past 
performance is not indicative of future results.

Long duration assets are being repriced globally, not just in the U.S. In fact, U.S. long-dated bond yields have risen less so 

than in other major regions thus far in 2025.

Japanese Bond Yields Have Risen to Historic Levels

U.S. 30-year yield (LH), Japan 30-year yield (RH)

10

0.0%

0.5%

1.0%

1.5%

2.0%

2.5%

3.0%

3.5%

1.0%

2.0%

3.0%

4.0%

5.0%

6.0%

7.0%

20
00

20
02

20
04

20
06

20
08

20
10

20
12

20
14

20
16

20
18

20
20

20
22

20
24

Ja
pa

n 
30

Y 
Yi

el
d

U
S 

30
Y 

Yi
el

d

US 30Y Yield (LH) Japan 30Y Yield (RH)

Japanese bond yields have 
risen to record highs…

-60

-40

-20

0

20

40

60

80

100

Dec 2024 Jan 2025 Feb 2025 Mar 2025 Apr 2025

United States Japan Germany

U.S. Bond Yields Have Risen Least in 2025

YTD cumulative change (in bps)