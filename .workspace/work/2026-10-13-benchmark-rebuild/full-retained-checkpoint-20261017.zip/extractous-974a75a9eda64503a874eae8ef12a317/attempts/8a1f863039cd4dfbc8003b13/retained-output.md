20    

OECD ECONOMIC OUTLOOK, INTERIM REPORT MARCH 2025 © OECD 2025 
  

Figure 11. Public debt levels have increased 
Gross debt 

 
Note: The chart shows general government financial liabilities for Australia, Canada, Japan, Korea and the United States, and general 
government gross debt in percent of GDP (Maastricht definition for euro area countries). Latest data point for Argentina, Brazil, China, India, 
Indonesia, Mexico, South Africa and Türkiye is 2024Q2; Australia, Japan and Korea is 2023Q4. For Korea the earliest available data refers to 
2008Q4. 
Source: Eurostat; IMF Sovereign Debt Investor Base database; OECD Economic Outlook 116 database; Office for National Statistics; and 
OECD calculations. 

International cooperation and structural policy reforms are especially important 

at the current juncture 

33. Governments need to find ways of addressing their concerns together within the global trading 

system to avoid a significant ratcheting up of retaliatory trade barriers between countries. As already 

highlighted, a broad-based further increase in trade restrictions would have significant negative impacts 

on living standards. Efforts to avoid further trade fragmentation should be coupled with reforms that 

strengthen the resilience of supply chains, including by encouraging firms to diversify both suppliers and 

buyers. Diversification would be aided by common or shared regulatory standards on key intermediate 

production inputs between countries. Countries should also not lose sight of the opportunities for potential 

benefits from collectively agreeing to lower the current tariff and non-tariff barriers on goods and services. 

In an illustrative scenario in which all countries act to lower their average effective tariff rates by 1½ 

percentage points (relative to those assumed in the baseline projections), global output would be raised 

by close to 0.3% by the third year and global inflation reduced by close to ¼ percentage point on average 

in the first three years (Figure 12).