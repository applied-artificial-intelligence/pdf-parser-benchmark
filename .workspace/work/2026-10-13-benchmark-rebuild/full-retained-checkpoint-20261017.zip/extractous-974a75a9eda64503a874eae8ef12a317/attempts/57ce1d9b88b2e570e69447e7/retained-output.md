60    

OECD EMPLOYMENT OUTLOOK 2024 © OECD 2024 
  

 

-20

-10

0

10

20

30

40

50

60

Japan

-20

-10

0

10

20

30

40

50

60

Korea

-30

-15

0

15

30

45

60

75
Latvia

Nominal minimum wage Real minimum wage

-30

-15

0

15

30

45

60

75

Lithuania

-20

-10

0

10

20

30

40

50

60

Luxembourg

-60

-30

0

30

60

90

120

150

Mexico

-20

-10

0

10

20

30

40

50

60

Netherlands

-20

-10

0

10

20

30

40

50

60

New Zealand

-40

-20

0

20

40

60

80

100

Poland

-20

-10

0

10

20

30

40

50

60

Portugal

-20

-10

0

10

20

30

40

50

60

Slovak Republic

-20

-10

0

10

20

30

40

50

60

Slovenia

-20

-10

0

10

20

30

40

50

60

Spain

-200

0

200

400

600

800

Türkiye

-20

-10

0

10

20

30

40

50

60
United Kingdom