Planet continued

Growing our products and services 
that support a low carbon future
Across our global businesses, we offer dedicated ESG 
investment strategies that include criteria related to climate 
change. Both the Perpetual Ethical SRI Fund and Perpetual 
Ethical SRI Credit Fund exclude companies or issuers that 
derive five per cent or more of their total revenue from fossil 
fuel exploration and production. The Perpetual ESG Real Return 
Fund predominantly invests in funds with fossil fuel exclusions 
with the exception of some ETFs, which provide asset class 
exposure, but where we cannot mandate the exact criteria.

Trillium offer a range of values-aligned, ESG-integrated 
investment products, all of which currently have no direct fossil 
fuel exposure.9 This includes the Trillium Global Sustainable 
Opportunities Fund, available to clients in the US and Australia, 
which is a sustainability-themed strategy that invests in 
companies providing products and services to meet specific 
sustainability challenges, including climate change. 

Two of Trillium’s funds were launched in Europe in FY22: the 
longstanding Trillium ESG Global Equity Fund, which is also 
available in the US and Australia and has been fossil fuel-free 
since its inception in 1999, and the Trillium ESG Global Conviction 
Fund, run by the newly formed Trillium UK team, which supports 
net carbon neutrality by 2050 and aligns with a potential 
temperature increase of 1.5°C.

Robust data and a clear and consistent scoring methodology are 
critical to understanding, managing and reporting on companies, 
ESG strategies and performance. Perpetual Digital is finalising the 
development and launch of an ESG and Carbon Risk score rating 
solution to provide industry-consistent ratings, reports and industry 
benchmarking for authorised deposit-taking institutions (ADIs), which 
previously may have not had the level of focus or detailed data and ESG 
reporting capability to support their ESG and climate performance.

The ESG and Carbon Risk score rating was developed by Laminar 
Capital in conjunction with ISS – a global provider of corporate 
governance and responsible investment solutions for institutional 
investors and corporations. The score assesses companies’ risks and 
opportunities based on a broad range of ESG criteria and themes:

1.  Climate, social and 
governance risks

2. Industry-specific issues

3.  Impact of products and 
services on the SDGs

4.  Industry sustainability 
risk profile

5.  Relevance of the EU 
taxonomy10 for SMEs

The ESG and Carbon Risk score will be launched in FY23 to provide ADI 
clients and their stakeholders with more meaningful and balanced ESG 
data and insights. This will help ADIs to obtain access to investment 
where previously they may have been negatively screened out of 
the investment universe by potential investors. These insights will 
be further leveraged through the establishment of sector-specific 
roundtables where Perpetual will work with ADIs and investors on 
benchmarking and strategies to drive best practice ESG outcomes for 
their businesses.

Building on their existing ESG investment capabilities, in FY22, 
Barrow Hanley launched the Barrow Hanley Global ESG Value 
Fund and the Barrow Hanley Concentrated Emerging Markets 
ESG Fund in Europe. Barrow Hanley takes into consideration 
ESG factors, alongside other criteria, when assessing risks and 
making investments in these funds such as GHG emissions, 
vulnerability to climate change and biodiversity.

For Perpetual Corporate Trust, supporting the development 
of sustainability, ESG and green products has been an 
increasing focus. In FY22, this included Laminar Capital 
developing an ESG and Carbon Risk score rating, who 
partnered with the Institutional Shareholder Services group 
of companies (ISS), to create this tool (see case study below).

9.  Trillium’s funds have no direct investment in any companies that explore 
for, extract, process or refine fossil fuels, or generate power from coal, oil 
or gas. Trillium funds may hold companies that have indirect exposure to 
fossil fuels if the company has demonstrated a verified commitment to a 
low carbon business model.

10.  The EU taxonomy is a classification system, establishing a list of 
environmentally sustainable economic activities.

Case study 
Perpetual Digital’s new ESG and Carbon  
Risk score rating

Perpetual Sustainability Report 2022

Introduction Perpetual’s Prosperity Plan Planet People Communities Governance KPIs

18