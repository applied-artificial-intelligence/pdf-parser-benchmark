69

C
h

ap
ter 2

Chapter 2 • Global trends in e-Government

Affordability plays a key role in digital access and engagement. The cost of Internet and active 
mobile broadband subscriptions as a percentage of gross national income (GNI) per capita remains 
significantly higher in Africa (10.4 per cent) and Oceania (7.6 per cent) than in other parts of the 
world, contributing to the digital divide (see figure 2.29).

Table 2.8 Affordability of mobile data and voice services, mobile broadband and cellular subscriptions  
 per 100 inhabitants, and percentage of individuals using the Internet, by region, 2022 and 2024

Affordability 

Active mobile broadband 

subscriptions per 100 

inhabitants

Mobile cellular 

telephone subscriptions 

per 100 inhabitants

Percentage of individuals 

using the Internet

Mobile data and voice 

high consumption 

basket price (as a 

percentage of GNI per 

capita)

2024 2022 2024 2022 2024 2022 2024 2022

Africa 10.4 - 54.4 42.77 88.95 83.68 43.4 33.01

Americas 3.8 - 72.8 65.96 102.83 101.92 77.1 67.81

Asia 2.8 - 88.5 80.5 106.05 105.93 71.9 63.21

Europe 1.1 - 105.2 97.9 116.75 113.86 89.5 85.52

Oceania 7.6 - 42.4 43.15 73.76 72.53 65.0 43.59

193 UN Member States 5.2 - 76.5 68.47 100.73 98.32 68.3 59.14

Sources: ITU, Statistics for individuals using the Internet (2022 and 2024), available at https://www.itu.int/en/ITU-D/Statistics/Pages/
stat/default.aspx; ITU, “Mobile data and voice high-consumption basket”, DataHub, available at https://datahub.itu.int/data/?i=34619.

Figure 2.28 Percentage change at the global and regional levels in Internet usage and in active mobile  
 broadband and mobile cellular subscriptions per 100 inhabitants, 2022-2024

Sources: 2022 and 2024 United Nations E-Government Surveys.

Very high EGDI
High EGDI
Middle EGDI
Low EGDI

193 UN Member States

Americas

Africa

Asia

Europe

Oceania

Very high EGDI
High EGDI
Middle EGDI
Low EGDI

27.3

6.3

31.4

10.4

0.9

13.6
9.9

0.1

13.8

7.5

2.5
4.6

-1.8

1.7

49.0

11.7

2.5

15.4

-10

0

10

20

30

40

50

60

Percentage change in active mobile
broadband subscriptions

per 100 inhabitants

Percentage change in mobile
cellular telephone subscriptions

per 100 inhabitants

Percentage change in
Internet usage among individuals

Africa Americas Asia Europe Oceania 193 UN Member States

EDGI 2024  levels
Very high EGDI
High EGDI
Middle EGDI
Low EGDI

Very high EGDI
High EGDI
Middle EGDI
Low EGDI

https://www.itu.int/en/ITU-D/Statistics/Pages/stat/default.aspx
https://www.itu.int/en/ITU-D/Statistics/Pages/stat/default.aspx
https://datahub.itu.int/data/%3Fi%3D34619