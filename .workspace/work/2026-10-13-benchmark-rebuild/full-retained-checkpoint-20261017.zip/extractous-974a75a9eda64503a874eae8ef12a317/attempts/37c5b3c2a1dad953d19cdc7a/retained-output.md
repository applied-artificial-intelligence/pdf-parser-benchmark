NUCLEAR FUEL CYCLE COST 501

60 -

50-

00
O

I--\-
<D
Q.

</) 30 -

P
ri

ce
 in

o

10-

-•w-

-120

-100

-80-

-60-

-40-

e

—20- •

<3

: i
: i

* * " "
/ /

/

Co
(bas

i
i

i
i

r
(

II
7
/
k

ista
sdo

//

/

s

n< 19
fi US

^ — "

curr

80 d
GNP

S

— ' *

enf (

ollar
defl

iollai

5

3<or]

\

\
\

•S :

/

A* A1* 4?

FIG.F.3. Uranium transaction values.

the gaseous diffusion plants. Another factor was a shift in US Government policy
to recover fully the costs of enrichment services provided to utilities. Recent
developments, however, point to stable prices in constant currency in the short
term and possibly to a downward trend in the medium term owing to over-capacity,
increased competition and technological advances.

Figure F.4 shows the price change in uranium enrichment services in the USA
from 1970 to 1982 in both current and 1980 dollars.

F.4. UNIT FUEL CYCLE COSTS

Table F.I lists the various components of the nuclear fuel cycle along with
unit prices as they have evolved during the past years. Three representative years