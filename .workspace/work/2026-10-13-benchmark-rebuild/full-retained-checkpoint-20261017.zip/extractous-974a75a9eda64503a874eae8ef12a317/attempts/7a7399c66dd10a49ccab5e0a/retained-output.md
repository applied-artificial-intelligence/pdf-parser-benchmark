77

C
h

ap
ter 2

Chapter 2 • Global trends in e-Government

Figure 2.34 Percentage of countries in special situations that have implemented organizational features of  
 the OSI institutional framework subindex, 2024

Figure 2.35 Percentage of countries in special situations with legislative frameworks relevant to e-government  
 development, 2024

Source: 2024 United Nations E-Government Surveys.

Source: 2024 United Nations E-Government Surveys.

193 UN Member States

Americas

Africa

Asia

Europe

Oceania

Very high EGDI
High EGDI
Middle EGDI
Low EGDI

Yes No Metrix Yes No MetrixMetrix Yes No MetrixMet Yes No MetrixMetr Yes No

SIDS LDCs LLDCs LDC/LLDCs LDC/SIDS

97%

97%

68%

97%

100%

89%

67%

84%

100%

94%

75%

84%

100%

88%

69%

88%

100%

100%

50%

100%

Links on the national portal to any
subnational/local government agencies

Availability of organizational structure
and/or chart of the government

Information on national portal about a national
Chief Information Of�cer (CIO) or equivalent

Availability of names/titles of heads of
government agencies/departments/ministries

Yes No Yes No Yes No Yes No Yes No

Yes No MetrixMetrix Yes No MetrixMet Yes No MetrixMetr Yes No

SIDS LDCs LLDCs LDC/LLDCs LDC/SIDS

Linear (average EGDI for high-income group)

Organizational aspects of the institutional framework

EDGI 2024  levels
Very high EGDI
High EGDI
Middle EGDI
Low EGDI

Very high EGDI
High EGDI
Middle EGDI
Low EGDI

Very high EGDI
High EGDI
Middle EGDI
Low EGDI

193 UN Member States

Americas

Africa

Asia

Europe

Oceania

Very high EGDI
High EGDI
Middle EGDI
Low EGDI

Yes No Metrix Yes No MetrixMetrix Yes No MetrixMet Yes No MetrixMetr Yes No

SIDS LDCs LLDCs LDC/LLDCs LDC/SIDS

19%

32%

19%

27%

22%

54%

65%

65%

62%

54%

11%

13%

18%

20%

33%

53%

62%

64%

60%

51%

22%

25%

34%

34%

56%

78%

78%

91%

88%

72%

6%

13%

19%

19%

38%

75%

69%

81%

75%

56%

25%

13%

13%

25%

63%

38%

38%

13%

AI

Cloud

Misinformaiton,
disinformation or fake news

E-participation

Open government data

Freedom of or access to information act

E-government or digital government

Cybersecurity

Data privacy and data protection

Digital ID

Yes No Yes No Yes No Yes No Yes No
SIDS LDCs LLDCs LDC/LLDCs LDC/SIDS

Availability of legislation, policy or strategy documents on: 

Policies on open government data, e-participation, artificial intelligence, cloud computing, and 
protecting the public against misinformation, disinformation and/or fake news are found in about 3 
out of 10 llDcs, 2 out of 10 SIDS, and 1 out 10 lDcs.