Energy Efficiency 2024 Chapter 3. System-wide themes 

PAGE | 83  I E
A.

 C
C

 B
Y

 4
.0

. 

3.3 Finance  

Efficiency investment is resilient and projected to reach 
about USD 660 billion in 2024  

Combined public and private investment in end-use sectors on efficiency, 
including electrification, is set to increase slightly by nearly 4% in 2024, matching 
the all-time high in annual investment of about USD 660 billion set in 2022. This 
is around 10% more than all upstream oil and gas investment in 2024. Investment 
has risen by a strong 45% since 2019, as the energy crisis and Covid-19 pandemic 
prompted massive government spending to stimulate consumer investment in 
energy efficiency. Since 2019, end-use investment in transport risen by an 
estimated 77%, followed by 34% for buildings and 13% in industry.  

More recently, investment trends have been more mixed. Between 2022 and 
2024, investment is estimated to have declined by 7% in the buildings sector and 
risen by 14% in transport, while it stayed steady in the industrial sector. Spending 
on efficient electrification is rising rapidly, primarily through EVs in China, Europe 
and North America. However, most other areas of efficiency spending are 
declining from recent highs as the effects of high energy prices ease and Covid-19 
stimulus spending winds down. As a result, overall global end-use investment has 
plateaued over the last two years, with higher inflation and interest rates making it 
more expensive to implement and finance energy efficiency upgrades.  

Global investment in energy efficiency, electrification and renewables for end uses by 
sector and region, 2019-2024e 

 
IEA. CC BY 4.0. 

Notes: An energy efficiency investment is defined as the incremental spending on new energy-efficient equipment or the full 
cost of refurbishments that reduce energy use. The intention is to capture spending that leads to reduced energy 
consumption. 2024e are estimated values.  
Source: IEA (2024), World Energy Investment. 

0

 250

 500

 750

2019 2020 2021 2022 2023 2024e

Bi
llio

n 
U

SD
 (2

02
2)

Industry Buildings Transport

0

 250

 500

 750

2019 2020 2021 2022 2023 2024e
Other Asia Pacific (excl. China)
China Europe
North America

https://www.iea.org/reports/world-energy-investment-2024/overview-and-key-findings
https://www.iea.org/reports/world-energy-investment-2024