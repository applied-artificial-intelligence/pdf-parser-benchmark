Renewables 2025 Chapter 1. Renewable electricity 
Analysis and forecasts to 2030 
 

PAGE | 32  I E
A.

 C
C

 B
Y

 4
.0

. 

EU installed renewable capacity in 2024 and 2030 vs REPowerEU 2030 targets (left) and 
shares of renewables in final energy consumption in 2030 (right)  

 
IEA. CC BY 4.0. 

Note: RED = Renewable Energy Directive. NECP = National Energy and Climate Plan. 
Sources: REPowerEU ambitions for total renewable capacity are from REPowerEU Plan SWD (2022) 230 final; wind and 
solar PV are from Implementing the REpowerEU Action Plan. The solar PV ambition is in AC, as it is similar to the “almost 
600 MW by 2030” target identified in the EU Solar Energy Strategy SWD (2022) 148 final. The 2030 EU offshore wind 
ambition is from Delivering on the EU Offshore Renewable Energy Ambitions, and the onshore wind aim is the difference 
between the 520-GW REPowerEU ambition and the 111-GW offshore wind target in Delivering on the EU Offshore 
Renewable Energy Ambitions. All solar PV values are in AC, including for the main and accelerated cases, and all solar PV 
totals are calculated in AC. The member-state ambition is estimated from NECPs. 
 

In June 2024, member states submitted their final updated NECPs outlining their 
voluntary contributions towards the EU goal. However, the European 
Commission’s assessment of these final NECPs indicates that, in aggregate, they 
reach only a 40% renewable share – falling 2.5 percentage points short of the 
binding EU target and 5 percentage points below the REPowerEU ambition. This 
gap suggests that REPowerEU capacity aims are not aligned with final individual 
NECPs.  

The second reason for the forecast shortfall in meeting EU-wide ambitions is that 
persistent challenges to faster solar and wind uptake require stronger policy 
attention. In the accelerated case, EU capacity reaches 1 255 GW5 by 2030, on 
track to reach the REPower EU target. Achieving more rapid expansion will require 
four key policy actions: 

 Introduce auctions to provide revenue certainty. Because auctions for long-
term contracts provide revenue certainty, financing costs can drop. Clearer 
visibility over future auction schedules would help developers plan where to 
concentrate resources and co-ordinate future investment efforts.  

 
 

5 For this total, solar PV is calculated in AC instead of DC, and pumped storage is excluded for comparability with the 
1 236-GW REPowerEU target. Total capacity in the main case with solar PV calculated in DC is 756 GW in 2024 and 
1 123 GW in 2030; for the accelerated case it is 1 260 GW. 

0

 250

 500

 750

1 000

1 250

1 500

2024 2030 2030
REPowerEU

G
W

Accelerated Other Wind Solar PV

25%

30%

35%

40%

45%

50%

RED II RED III
Binding target Aspirtational target

REPowerEU target Assessment of final
updated NECPs

https://eur-lex.europa.eu/resource.html?uri=cellar:fc930f14-d7ae-11ec-a95f-01aa75ed71a1.0001.02/DOC_1&format=PDF
https://eur-lex.europa.eu/legal-content/EN/TXT/PDF/?uri=CELEX:52022SC0230&from=EN
https://eur-lex.europa.eu/resource.html?uri=cellar:516a902d-d7a0-11ec-a95f-01aa75ed71a1.0001.02/DOC_1&format=PDF
https://eur-lex.europa.eu/legal-content/EN/TXT/?uri=CELEX%3A52023DC0668
https://eur-lex.europa.eu/legal-content/EN/TXT/?uri=CELEX%3A52023DC0668
https://eur-lex.europa.eu/legal-content/EN/TXT/?uri=CELEX%3A52023DC0668
https://eur-lex.europa.eu/resource.html?uri=cellar:fc930f14-d7ae-11ec-a95f-01aa75ed71a1.0001.02/DOC_1&format=PDF