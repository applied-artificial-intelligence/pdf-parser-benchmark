In Focus

20

The result of this destabilization of the US insurance market has led 

state regulators and governance agencies to request more data and 

transparency from the insurance market on how they are accounting 

for climate risk and where their portfolios are invested. This has come 

in the form of more disclosure requests from places such as the 

US Federal Insurance Office, the National Association of Insurance 

Commissioners (NAIC), and individual state insurance departments. 

In November 2023, the US Senate Budget Committee sent letters 

to 41 insurance companies requesting information on their plans to 

address increased underwriting losses from climate disasters and on 

investment decisions involving fossil fuel projects. The US Securities 

and Exchange Commission (SEC) is also expected to release a long-

delayed series of climate-related risk disclosure rules in 2024, which 

will include an accounting of companies’ greenhouse gas emissions 

(Scope 1, 2, and 3).

The US has trailed other parts of the world, notably Europe, in 

requiring more climate disclosures. Nevertheless, as insurability 

becomes a more complex issue for the private market, state, and 

federal officials are trying to understand the underlying issues — 

leading to more questions. Most focus tends to be on the insurance 

markets in Florida, California, and Louisiana, but the reality is that 

the insurability and affordability issue is a 50-state problem. Case in 

point — A 2023 study noted that Oklahoma had the highest average 

homeowner insurance premium at USD5,317 per year — or nearly 

double the national average of USD2,777. This was based on a policy 

with USD300,000 of dwelling coverage, a USD300,000 liability limit, 

and a USD1,000 deductible.

As homeowners seek the most affordable insurance rates, there are 

some strategies to consider. There are “risk-based insurance pricing” 

options, which can be used as a form of incentivization. Insurers may 

offer lower premiums to customers if they improve the structural 

integrity of their homes through retrofitting, for example, or use 

modern construction practices that meet or exceed state or local 

building code requirements. There are known technological and 

engineering improvements to limit risk to a home via higher-quality 

siding or roofing. The Insurance Institute for Home and Business 

Safety (IBHS), has available impact-resistant shingle performance 

ratings in the fight against hail damage. While not an explicit insurance 

product, there are incentivization programs now being offered by 

the US federal government that promote clean energy transition and 

improved construction practices. As an example, the 2022 Inflation 

Reduction Act extended the clean energy Investment Tax Credit that 

provides up to a 30% credit for various wind, solar, energy storage, 

and other renewable energy projects. 

Figure 11: Total global reinsurance dedicated capital  |  Data and Graphic: Gallagher Re

2015 FY 2016 FY 2017 FY 2018 FY 2019 FY 2020 FY 2021 FY 2022 FY 2023 HY

200

400

600

800

U
SD

 b
ill

io
n

449

709

486

629

526

427

672

725

615

Alternative Capital (Excludes Life, Accident, and Health)
Major Regional & Local Reinsurers + Pro-Rated Portion of Capital w/in Major Groups
Index

https://www.insurance.com/home-and-renters-insurance/home-insurance-basics/average-homeowners-insurance-rates-by-state 
https://ibhs.org/hail/shingle-performance-ratings/