34  D I G I T A L  P R O G R E S S  A N D  T R E N D S  R E P O R T  2 0 2 5  

Internet speed increased significantly in HICs and UMICs between 2023 and 2024, whereas 
speed in LMICs and LICs stagnated. Median fixed internet speeds in HICs and UMICs increased 
by more than 50 percent. In LMICs and LICs, marginal improvements kept median download 
speeds below 25 megabits per second for both mobile and fixed broadband in 2023 and 2024 
(refer to figure 2.7). The disparity in internet speed translates into substantial differences in 
download times.

Within-country disparities in broadband speeds generally narrowed from 2019 to 2024 but remain 
pronounced, especially in SSA. The authors created a coefficient of variation (CV) of the logarithm 
of download speeds as a measure of within-country internet speed inequality.3 Within-country 
speed inequality tends to be higher in LICs (refer to figure 2.8). In 2024, fixed broadband inequality 
was most pronounced in MENA, SAR, and SSA, with median CV values exceeding 0.15. Mobile 
speed inequality was highest in LAC and SSA. Although median inequality has generally declined, 
mobile broadband speed inequality rose in LAC and MENA. This reflects ongoing infrastructure 
projects that initially benefit certain areas, as seen in Cuba, where the introduction of the Arimao 
cable in early 2023 coincides with an inequality exceeding 0.5.

Gaps in data consumption across country income groups continue to widen, with HICs increasingly 
leaving others behind. In HICs and UMICs, annual fixed broadband traffic per capita is nearly 
10 times the mobile traffic per capita (refer to figure 2.9). Total data traffic per capita in HICs 
reached nearly 1,400 gigabytes (GB) in 2023, around 400 GB in UMICs, 100 GB in LMICs, and 
only 5 GB in LICs.

FIGURE 2 .7 Median fixed and mobile download speed, by country income group, 2023 and 2024

0

50

100

150

0

50

100

150

HICs UMICs LMICs
Region

LICs

Fixed broadband speed (mbps) Mobile broadband speed (mbps)

Fixed 2023 Fixed 2024 Mobile 2023 Mobile 2024

Sources: Original figure for this publication calculated using data from Ookla (https://www.speedtest.net/global-index).
Note: HICs = high-income countries; LICs = low-income countries; LMICs = lower-middle-income countries; mbps = megabits per 
second; UMICs = upper-middle -income countries.

https://www.speedtest.net/global-index