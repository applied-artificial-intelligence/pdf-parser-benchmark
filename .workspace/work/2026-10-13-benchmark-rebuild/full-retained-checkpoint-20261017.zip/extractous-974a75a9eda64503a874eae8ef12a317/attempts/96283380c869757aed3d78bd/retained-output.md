27 https://www.reuters.com/world/americas/chiles-record-breaking-drought-makes-climate-change-very-easy-see-2021-08-10/
28 https://about.netflix.com/en/news/net-zero-nature-our-climate-commitment
29 https://www.theguardian.com/environment/2021/mar/31/seaspiracy-netflix-documentary-accused-of-misrepresentation-by-participants and https://www.independent.co.uk/voices/

bbc-david-attenborough-nature-documentaries-fake-a8291961.html

On the other hand, in markets with the highest levels of interest, 
there is less left–right polarisation. We can see this dynamic 
play out in Greece and Portugal. In Greece, the difference in the 
proportion of people on the political left versus right who are 
interested in climate change news is only 16pp, while in Portugal 
it is just 10pp.

Another influence on our figures may be the impacts of climate 
change itself. Many countries have witnessed extreme weather 
events linked to climate change; Greece and Portugal, for instance, 
have suffered from devastating wildfires in recent years, and Chile 
continues to suffer from severe drought, which has made climate 
change ‘easy to see’.27 It may be that audiences are more interested 
in news about the topic when they are not so polarised and can 
clearly see the negative effects of extreme weather where they live.

REUTERS INSTITUTE FOR THE STUDY OF JOURNALISM / FURTHER ANALYSIS GRAPHS

Graph 31

A cow is seen on land that used to be filled with water, at the Aculeo Lagoon in Paine, Chile January 9, 2019. REUTERS Rodrigo Garrido.

A cow is seen on land that used to be filled with water, at the Aculeo Lagoon in Paine, Chile 
January 9, 2019. REUTERS Rodrigo Garrido.

REUTERS INSTITUTE FOR THE STUDY OF JOURNALISM / FURTHER ANALYSIS GRAPHS

Graph 32

0% 25% 50% 75%

43

51

40

39

39

20

23

14

56

55

58

44

48

37

35

33

59

61

62

45

41

56

49

55

Right

Centre

Le�

USA

Norway 

Australia

Japan

S. Korea

Chile

Portugal

Greece

PROPORTION INTERESTED IN CLIMATE CHANGE NEWS –  
BY POLITICAL LEANING – SELECTED MARKETS

Q1d_2022. Which of the following types of news, if any, are you interested in? Q1F. Some people 
talk about ‘left’, ‘right’, and ‘centre’ to describe parties and politicians. With this in mind, where 
would you place yourself on the following scale? Base: Left/Centre/Right: Greece = 272/1137/189, 
Portugal = 513/832/257, Chile = 261/977/192, South Korea = 373/1277/260, Japan = 65/1249/140, 
Australia = 390/1035/298, Norway = 385/1082/296, USA = 459/778/498.

Left Centre Right

16pp 
gap

10pp 
gap

36pp 
gap

41pp 
gap

REUTERS INSTITUTE FOR THE STUDY OF JOURNALISM / FURTHER ANALYSIS GRAPHS

Graph 33

PROPORTION WHO PAY ATTENTION TO EACH SOURCE  
FOR CLIMATE CHANGE NEWS – BY AGE – ALL MARKETS

C1_2022a. When it comes to climate change news, which of the following sources, if any, do you 
pay most attention to? Please select all that apply. Base: U35/35+ in all markets = 28,001/65,431. 
Total sample in all markets = 93,432. Note: Attention to ‘scientists/experts/academics’ as a source 
was asked but data excluded as they are mostly accessed via other sources. 

U35 35+

0% 25% 50%

42

33

13

9

13

10

11

34

32

17

16

14

12

8

35+

U35

Don't pay attention
to climate change

Politicians and
political parties

Ordinary
people

Celebrities/social media
personalities/activists

Smaller or alternative
news sources

Major news
organisations

Documentaries
(TV or �lm)

0% 25% 50%

42

33

13

9

13

10

11

34

32

17

16

14

12

8

35+

U35

Don't pay attention
to climate change

Politicians and
political parties

Ordinary
people

Celebrities/social media
personalities/activists

Smaller or alternative
news sources

Major news
organisations

Documentaries
(TV or �lm)

39% 
total

33% 
total

14% 
total

11% 
total

13% 
total

10% 
total

10% 
total

SOURCES OF CLIMATE CHANGE NEWS

Beyond interest, we can examine the sources people say they pay 
most attention to for climate change news. Overall, across the 
markets we cover, more people say they pay attention to 
documentaries (39%) than to major news organisations (33%) for 
information about this topic. This is the case across all markets in the 
aggregate, as well as across age groups.

This disparity between the use of documentaries and major news 
organisations for climate change news is also the case across many 
individual markets. In Greece, for instance, there is a large gap in 
the proportion of people paying attention to documentaries (55%) 
versus major news organisations (35%). Exceptions to this trend are 
markets like Japan, where larger proportions of people say they pay 
attention to major news organisations (41%) than documentaries 
(27%). But, more often than not, respondents across most markets 
say that documentaries draw their attention.

It may be that films and television shows, from Al Gore’s 2006 An 
Inconvenient Truth – which drew global attention to climate change – 
to the numerous nature documentaries produced since then by the 
BBC (e.g. Blue Planet II), Netflix (e.g. Seaspiracy), and Disney+ (e.g. 
Elephant), pack a bigger punch and remain more memorable to 
people than daily news reports. These are films and television series 
which, while not always about climate change, combine stunning 
visuals with compelling storytelling and environmental messages, 
reaching millions of people. Netflix says its series Our Planet, 
narrated by Sir David Attenborough, pictured right, has reached 
100m households since its release in 2019.28 While 
some documentaries have been criticised for their 
accuracy,29 the emotive power of these films 
certainly seems to resonate with audiences. Their 
popularity here is also further evidence of the 
importance of TV in driving attention to climate 
change information – something we noted in 2020.

Reuters Institute for the Study of Journalism   |   Digital News Report 2022 55

https://www.independent.co.uk/voices/bbc-david-attenborough-nature-documentaries-fake-a8291961.html
https://www.independent.co.uk/voices/bbc-david-attenborough-nature-documentaries-fake-a8291961.html