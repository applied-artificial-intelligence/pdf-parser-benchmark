CEO Letter

8   |   Visa

Farewell, guest checkout

Since the rise of the consumer internet 
30 years ago, ecommerce checkout has 
been cumbersome, requiring consumers 
to manually enter card details, retype 
shipping information, remember 
passwords and navigate multiple 
screens. That era is ending. Manual 
entry guest checkout is headed toward 
extinction, replaced by seamless, secure 
and frictionless payment experiences.

The share of Visa ecommerce 
transactions using manual entry guest 
checkout has dropped from 44 percent in 
2019 to just 16 percent in 2025, and among 
our top 25 ecommerce sellers, it is less 
than four percent. Just as smartphones 
replaced the need to remember phone 
numbers and search engines replaced 
remembering URLs, manual entry is 
giving way to faster and easier options. 
Card-on-file commerce, where merchants 
store credentials for recurring payments, 
and "button" checkout via digital wallets 
from technology platforms and financial 
institutions now account for 84 percent of 
Visa ecommerce transactions.9

Share of Visa ecommerce transactions by checkout type 

44%

56%

2019

35%

65%

2020

30%

70%

2021

26%

74%

2022

24%

76%

2023

19%

81%

2024

16%

84%

2025

Card-on-file & 
“button” checkout

Manual entry 
guest checkout

Note:	Reflects	Visa	processed	transactions,	among	card-not-present	approved	transactions.	Card-on-file	
includes	both	tokenized	and	non-tokenized	card-on-file	transactions.	Data	represents	share	of	transactions	in	
September	of	each	year.	Excludes	Russia,	China	and	Visa	Direct	in	Peru.

Hello, tokenization 

This shift away from manual entry 
guest checkout is powered by Visa’s 
tokenization technology. Tokenization 
replaces sensitive card information with 

a unique, secure digital identifier that can 
only be used in the specific context it was 
issued. Even if intercepted, it is useless 
to anyone else, keeping payments safe. 
It is the technology that enables both 
digital wallet checkout experiences and 
secure card-on-file systems. For more 
than a decade, Visa has been the driving 
force behind the use of tokenization 
in payments. Today, more than 50 
percent of ecommerce transactions in 
our ecosystem are tokenized, driving 
closer to our ultimate goal of 100 percent 
tokenization.9 This technology delivered 
an authorization lift of nearly five percent 
for ecommerce sellers, resulting in more 
than $110 billion in incremental sales in 
2024.10 In addition, transactions using 
Visa tokens had more than 35 percent 
lower fraud, saving $1.1 billion for the 
year.10 We are augmenting tokens with 
enhanced data, passkeys and other 
innovations to continue improving 
the speed and security of ecommerce 
transactions.

Tokenized share of Visa ecommerce transactions

Non-tokenized 
transactions

Tokenized 
transactions

2019 2020 2021 2022 2023 2024 2025

93%

13%

87%

26%

74%

36%

64%

45%

55%

54%

46%96%

44%% 77%%

Note:	Reflects	Visa	processed	transactions,	among	card-not-present	approved	transactions.	Tokenized	
transactions	include	both	"button"	checkout	and	tokenized	card-on-file	transactions.	Data	represents	share	of	
transactions	in	September	of	each	year.	Excludes	Russia,	China	and	Visa	Direct	in	Peru. 9	 Among Visa processed card-not-present transactions. 

Excludes	Russia,	China	and	Visa	Direct	in	Peru.
10	 Calendar	year	2024. Excludes prepaid volumes.