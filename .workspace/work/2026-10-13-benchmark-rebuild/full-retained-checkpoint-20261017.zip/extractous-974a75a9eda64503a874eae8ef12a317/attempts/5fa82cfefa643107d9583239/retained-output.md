 19 

OECD ECONOMIC OUTLOOK, VOLUME 2025 ISSUE 2 © OECD 2025 
  

Panel A), portending an increase in tariff collection in the coming months.2 The extent of the gap between 

revenues and estimated effective tariffs differs across types of goods. Tariff collection rates on cars and 

parts as well as steel and aluminium, which have been in place for some time and have few global 

exceptions, are closer to their effective tariff rates than is the case for other goods. 

Figure 1.7. The impact of US tariffs is increasingly being felt  

 
Note: In Panel A, the monthly average 2025 estimated effective tariff rate is based on applicable rates to products and countries at the time they 

became effective, weighted by country-specific product shares of United States imports in 2024. The estimates include updated weights for 

compliance of imports from Canada and Mexico (see Box 1.2 for more details). Data before 2025 based on WITS average effective tariff rates, 

corrected for Section 301 actions on China undertaken between 2018 and 2024. 2025 tariff revenues estimated as a share of import values 

including cost, insurance and freight, based on monthly data from US Census Bureau. Data before this are from USITC (2025) "U.S. imports for 

consumption, duties collected, and ratio of duties to value, 1891-2024".  Data in Panel B are based on import values. Goods which face no new 

tariffs in 2025 are all goods exempted from country-specific tariff increases as of August 2025, excluding goods imports in these categories from 

China (since the additional 20 percentage point tariff increase imposed on China in March 2025 is unaffected by the exemption). 

Source: OECD Economic Outlook 118 database; US Census Bureau; United States International Trade Commission; World Integrated Trade 

Solution (WITS); and OECD calculations. 

StatLink 2 https://stat.link/tvyw09 

Despite the lagged effects of higher tariffs, there is a sharp decrease in the value of US imported goods 

subject to tariffs compared to non-tariffed goods (Figure 1.7, Panel B). This suggests that tariffs are 

affecting demand, and will continue to weigh on trade volumes as announced tariffs come into full effect. 

This could in turn further weigh on the estimated effective tariff rate, reducing the divergence with collected 

duties. Continued strength in demand for technology products should still provide some support for global 

trade, although new export orders for manufacturing in most large economies remain relatively weak 

outside of the Asian emerging-market economies. Trade policy uncertainty has fallen from recent peaks, 

but recent announcements about further changes to bilateral tariff barriers and the possible broadening of 

licencing requirements for rare earth materials in China could add to uncertainty. 

Box 1.2. US tariff rates: in law and in effect 

In recent months the United States has continued to announce additional tariff increases on imports from 

most countries, alongside separate sector-specific tariffs on steel and aluminium, cars and parts, trucks, 

buses, timber, and copper. This box discusses some of the issues involved in calculating the aggregate 

 
2 The effective tariff rate in November 2025 is shown as 14.6% in Figure 1.7 rather than 14.0%. This is because a 

monthly average tariff rate is used in Figure 1.7 whereas the latter reflects the effective tariff rate following the policy 
changes that occurred by mid-November.  

https://stat.link/tvyw09