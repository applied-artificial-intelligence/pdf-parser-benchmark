Chapter 3. Regional Wealth Inequality
Figure 3.4. Since the 1970s, North America & Oceania hasshifted into the largest net debtor

As % of regional GDP As % of world GDP

1800 1830 1860 1890 1920 1950 1980 2010 1800 1830 1860 1890 1920 1950 1980 2010
−20%

−10%

0%

10%

20%

30%

−100%

−50%

0%

50%

N
et

 fo
re

ig
n 

as
se

ts
, M

E
R

East Asia

Europe

Latin America

MENA

North America & Oceania

Russia & Central Asia

South & Southeast Asia

Sub−Saharan Africa

World

Net foreign wealth across regions, 1800−2025

Interpretation. Between 1800 and 1914, Europe accumulated a rising share of global foreign assets. By 1914, its
net foreign wealth reached 71% of its own GDP. These assets largely vanished after World War I. Measured as a
share of world GDP, Europe’s foreign wealth in 1914 was about 6 times larger than East Asia’s foreign wealth in
2025 (12%) and about 18 times larger than that of MENA (4%). During the 20th century, North America &
Oceania emerged as a major foreign asset holder, peaking in 1950 at 8% of world GDP. Over the same period,
East Asia transitioned to one of the world’s largest foreign asset holders. By 2025, its net foreign wealth stood at
12% of world GDP. In contrast, North America & Oceania held −18%, meaning other regions now hold more
assets in North America & Oceania than it holds abroad. Sources and series: Bauluz et al. (2025), Nievas and
Piketty (2025), and wir2026.wid.world/methodology.

financial crisis, recovery in the 2010s, anda renewed decline after COVID-19. Europehas followed a steadier path, but its privatewealth also fell more sharply than the globalaverage after 2020. South & Southeast Asiahas steadily built up private wealth, rankingfourth globally, while the Middle East &North Africa overtook Russia & Central Asiaduring the 2010s. By contrast, Latin Americaand Sub-Saharan Africa remain far belowthe world average, reflecting weaker assetaccumulation relative to income.
The picture of public wealth is evenmore striking (right-hand-side panel). EastAsia stands out as the only region withsubstantial and rising public wealth, thanksto sustained public savings and significantstate ownership of assets. The Middle East& North Africa, Sub-Saharan Africa, LatinAmerica, and Russia & Central Asia maintainmodestly positive levels, but these arewell below those in East Asia. Europe andSouth & Southeast Asia hover close to zero,showing little capacity to build collectivewealth. In North America & Oceania, publicwealth is negative: governments owe morethan they own, with rising public debts

offsetting limited state assets.
Overall, the world has become wealthier,but the ownership of this wealth hasshifted toward individuals and corporations.Governments, by contrast, have seen theirnet position weaken, narrowing their fiscalcapacity to invest in collective goods orrespond to crises. This imbalance betweenexpanding private fortunes and stagnantpublic reserves is now a defining feature ofthe global economy. This shift toward privatebalance sheets raises a second question:how are the flows of income dividedbetween labor and capital? Figure 3.6answers this.Figure 3.6 tracks how the income flow issplit between labor and capital since 1980.Globally, labor’s share falls from about 61%in 1980 to 53% in 2025, while capital’s sharerises from 39% to 47%. This rebalancingtoward capital income mirrors the wealthpatterns in Figure 3.5 (more wealth overall,and most of it private).8
As for regional patterns, North America& Oceania and Europe retain comparativelyhigher labor shares (and lower capital

79