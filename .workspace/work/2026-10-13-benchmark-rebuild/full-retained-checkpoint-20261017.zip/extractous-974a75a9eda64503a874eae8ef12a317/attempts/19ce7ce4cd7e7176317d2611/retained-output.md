Brent crude oil front-month futures prices

dollars per barrel (b)

Petroleum and Liquid Fuels Markets Team | Financial Review 2024                                               

May 2025

Proved reserves declined in value in 2024 because of lower crude oil 

prices

Data source: Intercontinental Exchange, Bloomberg L.P.

Note: SEC=U.S. Securities and Exchange Commission

$75.89

$78.70

$83.55

$87.42

$83.44 $78.36

$86.60

$79.52

$77.52

$73.56

$73.10

$71.83

$0

$10

$20

$30

$40

$50

$60

$70

$80

$90

$100

Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec

Brent 2024 first-day-of-month average = $79.12/b

Brent 2023 first-day-of-month average = $82.83/b

first-day-of-month price

9

The U.S. Securities and 

Exchange Commission 

(SEC) requires companies 

to value proved reserves 

based on an average of the 

first-day-of-the-month price 

for the preceding 12-month 

period.