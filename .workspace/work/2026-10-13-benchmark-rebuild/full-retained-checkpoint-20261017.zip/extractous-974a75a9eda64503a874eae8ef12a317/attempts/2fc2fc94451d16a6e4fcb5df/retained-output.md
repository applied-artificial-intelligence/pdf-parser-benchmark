2.1  Perceptions of Media  
 Coverage of the War  
 in Ukraine

REUTERS INSTITUTE FOR THE STUDY OF JOURNALISM / FURTHER ANALYSIS GRAPHS

Graph 3

PROPORTION WHO SOMETIMES OR OFTEN ACTIVELY AVOID 
THE NEWS – SELECTED MARKETS

Q1di 2017. Do you find yourself actively trying to avoid news these days? Base: Total pre/during-conflict 
samples: Brazil = 2022/1002, Germany = 2002/1015, Poland = 2009/1003, UK = 2410/1191, USA = 2036/1356. 
Note: Pre-conflict sample from the main 2022 DNR survey. During-conflict sample from 29 March to 7 April. 

0% 25% 50% 75%

UK 46 | 46

Germany 29
Pre-conflict During conflict

36
Poland 41 47
USA 42 46

Brazil 54 55

As we have seen with other major world events, people turn more 
to TV news at times of crisis. When asking respondents which news 
source they are paying the most attention to when it comes to the 
Russia–Ukraine conflict, television tops the list for three of the 
five countries – with the most attention to TV news on the conflict 
spread out geographically, from Germany (46%) and Brazil (44%). 
In the US and Poland, online news sites, non-mainstream sites, and 
social media combined account for a larger share – but TV is still 
the most widely used individual source for news about the conflict.

REUTERS INSTITUTE FOR THE STUDY OF JOURNALISM / FURTHER ANALYSIS GRAPHS

Graph 2

PROPORTION WHO PAY MOST ATTENTION TO EACH SOURCE 
FOR NEWS ABOUT THE RUSSIA–UKRAINE CONFLICT – 
SELECTED MARKETS

Q2_ukraine. When it comes to the current Russia–Ukraine conflict, which ONE of the following 
sources of news, if any, are you paying most attention to? Base: Total sample: Brazil = 1002, 
Germany = 1015, Poland = 1003, UK =  1191, USA = 1356.

0% 25% 50%

BrazilTelevision
USA

UK
Germany

Poland

44
31

39
46

38

BrazilOnline news sites 
from major news 
organisations

USA
UK

Germany
Poland

13
18

23
14

20

BrazilOnline  
(news sites + 
non-mainstream 
sites + social)

USA
UK

Germany
Poland

41
40

33
24

40

BrazilSocial media  
sites USA

UK
Germany

Poland

23
13

7
6

11

BrazilRadio
USA

UK
Germany

Poland

5
6

9
9

2

BrazilNon-mainstream  
sites (e.g. specialist 
websites, or  
alternative sites)

USA
UK

Germany
Poland

5
9

4
9

3

BrazilConversations with 
colleagues, friends,  
or family

USA
UK

Germany
Poland

5
5

5
5

3

BrazilPrinted  
newspapers USA

UK
Germany

Poland

4
4

1

1

3

We see some differences in preferred sources by both age and market. 
For instance, the same splits we see in TV versus social media use 
between younger and older cohorts also applies to the most 
important platform for following the Russia–Ukraine conflict. In the 
UK, for instance, more than half (55%) of those 55 or older, but only 
13% of 18–24s, are paying the most attention to TV news on the 
Russia–Ukraine conflict. And nearly eight times as many 18–24s (15%) 
are paying the most attention to social media news on the war as 
those 55 and older (2%). Further, while TV is especially dominant for 
information about the conflict in countries like Germany, social media 
are a particularly important source in Brazil, with 23% of people 
paying the most attention to these platforms for related information.

HOW HAS THE CONFLICT INFLUENCED PEOPLE’S 
NEWS BEHAVIOURS AND ATTITUDES?

We also used this follow-up survey to explore whether the trends 
we described in the Executive Summary – namely, decreases in 
news use and interest and increases in news avoidance – were 
reversed by the extensive coverage of the Russia–Ukraine 
conflict. We did this by repeating the same key questions (albeit 
to a different sample of respondents) and looking for differences 
between the ‘pre-conflict’ sample from the main 2022 survey and 
the ‘during conflict’ follow-up survey. Of course, we need to be 
cautious about attributing all changes to coverage of the conflict. 
Major domestic stories – such as the ‘Partygate’ scandal in the UK 
– were unfolding in parallel, and these may also have influenced 
people’s attitudes and behaviours around news.

In general, we find little evidence that these long-term trends 
have been reversed – even temporarily – and in some cases there’s 
possible evidence that they have been accelerated. The clearest 
example of this is news avoidance. In Germany, Poland, and the 
US, the proportion who say they sometimes or often actively avoid 
the news has increased. The biggest increase of all was in Germany 
(+7pp), but significant increases can also be seen in Poland (+6pp) 
and the US (+4pp). To put some of these changes in context, the 
increase of 7pp in Germany in just two months is larger than the 
5pp increase we saw in the five years from 2017 to 2022. We know 
that one of the main reasons people avoid the news is because of 
the negative effect it has on their mood, so it would be unsurprising 
if the deeply depressing and concerning nature of conflict has 
caused more people to turn away from it. In the UK and Brazil, 
where news avoidance was already high, we do not see evidence 
of a further increase – but it is equally important to note that it has 
not decreased either. Furthermore, in these two countries, news 
avoidance has already increased markedly in recent years – by 11pp 
from 2019 to 2022 in the case of the UK, and by 20pp in Brazil.

Reuters Institute for the Study of Journalism   |   Digital News Report 2022 35