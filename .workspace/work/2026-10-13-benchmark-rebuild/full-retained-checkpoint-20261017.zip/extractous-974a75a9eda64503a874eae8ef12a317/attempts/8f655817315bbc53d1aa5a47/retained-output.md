Chapter 1: Main employment and social developments 

29 

(9.7%). (32) In addition, 64.2% of the population aged 25-64 declared that they had improved their knowledge, 
skills, or competences in informal ways, such as through exchanges with a family member, friend, or colleague 
(31.1%), alone (on electronic devices (53.2%), using printed material (37.8%)), visiting learning centres (8.4%), or 
attending guided tours (15.4%). 

Most people did not see the need to undertake 
training, while those who did cited schedules, 
family reasons and costs as their main reasons for 
not participating in education or training. In 2022, 
42.4% of respondents aged 25-64 did not want to 
participate in education or training because they did not 
see the need (75.9%). Of those who wanted to participate 
and could not (10.2%) or those who participated but 
wanted to participate more (15.7%), 25.3% listed training 
schedules as the main barrier to their participation, while 
16.0% cited family reasons, and 15.2% highlighted costs 
(Chart 1.12). (33)  

Progress towards the EU target of at least 60% of 
adults participating in learning every year by 2030 
is limited. The level of participation of people aged 25-
64 in formal or non-formal learning (excluding guided-
on-the-job training for the monitoring of the target) was 
at 34.4% in 2011, 37.4% in 2016 and 39.5% in 
2022.  (34) In a context where labour and skills shortages 
constitute a challenge for EU competitiveness, 

investment in skills continues to be of the utmost importance, especially towards a fair green and digital 
transition. The Commission promotes investment in skills, notably through the new European Skills Agenda, and 
the action plan for the implementation of the European Pillar of Social Rights. 

3.6. Public expenditure on labour market policies and social protection 

In the years following the COVID-19 pandemic, total public expenditure remained sustained and then 
slowly returned to pre-pandemic levels. Overall, in both nominal terms and as a share of GDP, government 
expenditure increased in 2020 and remained at high, albeit declining, levels in 2021 in response to the economic 
and social challenges of the pandemic (Chart 1.13, left chart). In 2022, total public expenditure as a share of GDP 
returned to similar levels to 2012. The areas of public expenditure that experienced the strongest growth during 
the first year of COVID-19 pandemic were spending on social protection (+2.6pp between 2019 and 2020, to 
21.9% of GDP) and economic affairs (35) (including many COVID-19 pandemic-related measures; +1.7 pp, to 
6.1% of GDP), and health (+1.0 pp, to 8.0%).%), which reflects the measures put in place to mitigate the socio-
economic effects of the crisis as well as the additional demand for healthcare, medical appliances and medicines. 
In 2022, public expenditure higher than in 2019 included economic affairs (+1.4pp, to 5.8% of GDP), health 
(+0.6pp, to 7.6%) and housing (+0.4pp, to 1%), while social protection spending as a share of GDP almost fully 
reverted to its pre-pandemic level (+0.1pp, to 19.4%), mainly reflecting positive developments in the labour 
market. (36) 

 
(32) Taking into consideration all objectives, not just those related to jobs, 53.9% of employed people, 29.2% of unemployed people and 

24.4% of people outside the labour force participated in formal or non-formal education and training. 
(33) Other personal reasons (9.3%), lack of support from employer or public services (8.4%), no suitable offer of education or training (7.8%), 

health or age reasons (6.7%), other reason (4.4%), course booked out (2.8%), distance (2.7%), and too few registrations (1.7%). 
(34) Definition of the indicator monitoring the target differs from published data on the Eurobase and excludes guided-on-the-job (GOTJ) 

learning activities. The specially calculated data excluding GOTJ training for EU and all Member States, including disaggregation by sex, 
age groups and educational attainment, are available from Eurostat here. 

(35) It includes, among others, administration of general economic, commercial and labour affairs, formulation and implementation of 
policies, regulation or supervision of activities, support to programmes or schemes, promotion of policies and programmes, 
administration of sectoral affairs and services, grants, loans or subsidies supporting sectors, administration and operation of 
government agencies engaged in applied research, grants, loans or subsidies to support applied research by non-government bodies. 
More details in the Manual on sources and methods for the compilation of COFOG statistics here. 

(36) Based on latest available administrative data, which extends to 2022. 

 

Chart 1.12 

Schedule, family reasons and costs are the most 
common barriers to participation in education or 
training 
Main reason for not participating (or not participating more) for willing respondents, 
2022, EU 

           

Note: ‘Course booked out’ and ‘Too few registrations’ were not proposed in 2011 and 
2016. Percentages calculated based on respondents who answered the 
question (non-response rate was 11.3% in 2011, 5.7% in 2016, 9.8% in 2022). 

Source: Eurostat [TRNG_AES_179], Directorate-General for Employment, Social Affairs 
and Inclusion (DG EMPL) calculations. 

Click here to download chart. 
 

0

5

10

15

20

25

30

2011 2016 2022

https://ec.europa.eu/eurostat/web/education-and-training/information-data/policy-context
https://ec.europa.eu/eurostat/documents/3859598/10142242/KS-GQ-19-010-EN-N.pdf
https://ec.europa.eu/employment_social/empl_portal/publications/Esde2024/xls/Chap1/Chap1-Chart-1.12.xlsx