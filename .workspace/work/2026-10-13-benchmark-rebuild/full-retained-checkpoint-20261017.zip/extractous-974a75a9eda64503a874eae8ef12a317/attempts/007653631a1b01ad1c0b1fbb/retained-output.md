Chapter 2. Regional Income Inequality

0%

100%

200%

300%

400%

500%

600%

700%

1970 1975 1980 1985 1990 1995 2000 2005 2010 2015 2020 2025

P
er

 c
ap

ita
 n

at
io

na
l i

nc
om

e
(%

 o
f w

or
ld

 a
ve

ra
ge

, 2
02

5 
P

P
P

 €
)

0−100k

100k−1m

1m−10m

10m−50m

50m−100m

100m−500m

over 500m

Figure B2.2.2. Per capita national income by country size, 1970–2025

Interpretation. Ultra−small countries (pop. <100k) have consistently had above−average per capita income,
increasing from 290% of the world average in 1970 to 400% in 2025. In contrast, the most populous countries
(pop. >500m) remain significantly below average: from 20% in 1970 to 80% in 2025. This size−income gradient
has remained persistent across decades. Population groups are defined using 2025 country sizes. Sources and
series: Gómez−Carrera et al. (2024) and wir2026.wid.world/methodology.

71