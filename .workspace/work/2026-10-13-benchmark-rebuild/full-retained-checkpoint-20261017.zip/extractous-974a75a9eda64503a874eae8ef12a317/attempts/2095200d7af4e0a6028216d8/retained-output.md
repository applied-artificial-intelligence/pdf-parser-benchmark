Illustration of the Policy 
The charts below illustrate how much EDs could earn under different performance 
scenarios in one financial year:

• Minimum – basic salary, pension 
or cash in lieu of pension and 
benefits, no bonus and no vesting 
of the LTIP.

• Target - basic salary, pension or 
cash in lieu of pension, benefits, and:
– A bonus of 100% and a LTIP of 

350% of basic salary (with notional 
LTIP vesting at 50% of maximum) 
for the Group CEO.

– A bonus of 100% and a LTIP of 
225% of basic salary (with notional 
LTIP vesting at 50% of maximum) 
for the Group CFO.

• Maximum – basic salary, pension or 
cash in lieu of pension, benefits, and:
– A bonus of 200% and a LTIP of 

350% of basic salary (with notional 
LTIP vesting at maximum) for the 
Group CEO.

– A bonus of 150% and a LTIP of 
225% of basic salary (with notional 
LTIP vesting at maximum) for the 
Group CFO.

• Maximum with share price 
appreciation – indicative maximum 
remuneration, assuming a notional 
LTIP vesting at maximum and 
share price appreciation of 50% 
on the LTIP.

Potential earnings by pay element - Amanda Blanc

Potential earnings by pay element - Charlotte Jones

Notes to the charts
1. The charts are illustrative only and the actual value EDs could earn is subject to business performance and share 

price movement to the date of vesting of the LTIP and of the deferred share element of the annual bonus
2. Fixed pay consists of basic salary, pension as described in table 1, and estimated value of benefits provided under 

the Policy, excluding any one-offs. Actual figures may vary in future years.
3. The value of the deferred element of the annual bonus assumes a constant share price and does not include 

additional shares awarded in lieu of dividends that may accrue during the vesting period
4. The value of the LTIP assumes a constant share price (with the exception of the maximum with share price 

increase scenario) and does not include additional shares awarded in lieu of dividends that may accrue during the 
vesting period

5. The LTIP is as proposed to be awarded in 2025, which would vest in 2028, subject to the satisfaction of 
performance conditions. The shares would then be subject to a further two-year holding period.

Directors’ Remuneration Policy

141

£m

2025 Minimum 2025 Target 2025 Maximum 2025 Maximum with 
share price 

appreciation

0.0

5.0

10.0

£m

£0.9

£2.5m

£3.7m

£4.5m

2025 Minimum 2025 Target 2025 Maximum 2025 Maximum with 
share price 

appreciation

0.0

2.5

5.0

£1.5m 25%
30%

44%

62%

24%

14%

52%

30%

18%

£8.2m

£10.4m

100%

56%

25%

19%

46%

31%

24%
30%

35%

34%

£4.9m

Remuneration elements
Fixed pay Annual bonus LTIP

A
viva plc

Annual Report and Accounts 2024
Strategic 
Report

G
overnance 

R
eport

IF RS Financial 
Statem

ents
O

ther 
Inform

ation

100%


	Button3: