reporting very fast real wage growth.9 When 
both China and Türkiye are excluded, global 
real wage growth is measured at 1.7 per cent 
in 2024, which still remains the largest in-
crease recorded since 2010.

Figure 3.2 presents estimates similar to those 
of figure 3.1 but focusing on G20 countries, 
which account for roughly 85 per cent of 
global GDP and about around 60 per cent of 
world’s wage employees. Real wage growth 
across all G20 countries is represented in 
the figure, along with separate real wage 
growth estimates for the group of advanced 
G20 economies and the group of emerging 
G20 economies.

9.  Türkiye reported real wage growth of 38.8 per cent in 2023 and 27.2 per cent in 2024. The most recent figures for 
inflation in Türkiye are 72.3 per cent in 2022, 53.9 per cent in 2023 and 60.9 per cent in 2024.

10.  The figure is 0.1 percentage points higher than what estimated in the Global Wage Report 2022–23 using data for the 
first half of 2022. While modest at the aggregate level, this revision is the result of important changes in the estimates 
for advanced G20 economies and emerging G20 economies, which ended up compensating for each other.

11.  Average real wage growth in advanced G20 economies has been revised downward by 0.6 percentage points, 
from –2.2 per cent to –2.8 per cent, while average real wage growth in emerging G20 economies has been revised 
upward by 1.0 per cent, going from 0.8 per cent to 1.8 per cent. The lowered estimate for advanced G20 economies 
is driven by lower yearly real wage growth in the Republic of Korea and Australia compared to estimates that used 
data for just the first half of 2022, while the higher estimate for emerging G20 economies is justified by high real 
wage growth in India, the Russian Federation and Türkiye.

 X  Figure 3.1. Annual average global real monthly wage growth, 2006–24 (percentage)

Source:  ILO estimates based on official national sources as recorded in ILOSTAT and the ILO Global Wage Database.

2.1

2.4

0.6
0.8

1.8

0.9

1.5
1.7

1.4 1.4
1.6

0.9
1.2

1.3
1.1

0.8

-1.5

1.3

2.3

2.7

3.1

1.2

1.6

2.4

1.6

2.2
2.5

1.9 1.9
2.1

1.5

1.9 1.9

1.5
1.8

-0.9

1.8

2.7

-2.0

-1.0

0.0

1.0

2.0

3.0

4.0

Ch
an

ge
 (%

)

2006
2007

2008
2009

2010
2011

2012
2013

2014
2015

2016
2017

2018
2019

2020
2021

2022
2023

2024

Global Global (without China)

mated at 6.0 per cent, the highest value re-
corded in the last ten years.

Due to the large share of global wage employ-
ees that they represent, the real wage growth 
rate of G20 countries in 2024 is similar to the 
growth rate estimated at the global level, 
standing at 3.1 per cent. After two years of 
negative growth, real wages in advanced G20 
economies are projected to return to growth 
in 2024, with a 0.9 per cent increase, while 
wage growth in emerging G20 economies 
is projected to remain almost unchanged at 
5.9 per cent.

 ▶3.2. 
Regional wage 
trends
Figure 3.3 presents regional real wage growth 
trends to complement the analysis at the 
global level. When looking at regional-level 
data, the evolution of real wage growth re-
veals substantial heterogeneity. While real 
wage growth declines driven by the cost- 
of-living crisis are evident in all regions in 
2022, the ways in which real wages evolved in 
the years preceding and following 2022 vary 
considerably from region to region.

In Northern America (Canada and the United 
States), from 2006 until the COVID-19 pan-
demic in 2020, real wage growth fluctuated 
between 0 and 1 per cent in most years. As 

 X  Figure 3.2. Annual average real monthly wage growth in the G20 countries, 2006–24 
(percentage)

 Notes: Advanced G20 economies comprise Australia, Canada, France, Germany, Italy, Japan, the Republic of Korea, the 
United Kingdom of Great Britain and Northern Ireland, and the United States. Emerging G20 economies comprise Argentina, 
Brazil, China, India, Indonesia, Mexico, the Russian Federation, Saudi Arabia, South Africa and Türkiye.

Source: ILO estimates based on official national sources as recorded in ILOSTAT and the ILO Global Wage Database

2.
9

0.
6

8.
0

3.
2

0.
7

8.
6

1.
4

-1
.1

5.
9

1.
7

0.
7

3.
2

2.
7

1.0
5.

6
1.8

-0
.3

5.
1

2.
6

0.
2

6.
4

2.
7

0.
4

5.
9

1.
6

0.
5

3.
2

2.
0

1.7
2.

2
2.

2
1.0

4.
0

1.5
0.

4
3.

2
2.

2
0.

7
4.

2
1.

8
1.0

3.
0

2.
2

1.8
2.

7
2.

1
0.

5
4.

3
-0

.8
-2

.8
1.

8 2.
3

-0
.5

6.
0

3.
1

0.
9

5.
9

-4

-2

0

2

4

6

8

10

2006
2007

2008
2009

2010
2011

2012
2013

2014
2015

2016
2017

2018
2019

2020
2021

2022
2023

2024

G20 G20 advanced economies G20 emerging countries

Ch
an

ge
 (%

)

13Global Wage Report 2024–25
3. Wage trends