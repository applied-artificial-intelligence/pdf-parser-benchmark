 51 

OECD EMPLOYMENT OUTLOOK 2024 © OECD 2024 
  

Annex Figure 1.A.3. Real wages remain below 2019 levels in several countries 

Cumulative percentage change in real hourly wage since Q4 2019 

 

Note: This Chart is a version of Figure 1.9 (Panel B) without any adjustments for seasonality in the CPI series. Otherwise noted, nominal hourly 

wages refer to a constant-industry-structure “wages and salaries” component of the labour cost index. Statistics refer to the private sector only 

for Costa Rica, Japan, Korea, Mexico and the United States. Nominal wage series are seasonally adjusted for all countries except for Canada, 

Costa Rica, Israel, Japan, Korea, Mexico, New Zealand and Switzerland. Nominal hourly wage presents a significant amount of unreported 

income for Mexico. 

†: Nominal hourly wage refers to the actual wage i.e. without any adjustment for sources of compositional shifts for Costa Rica, Israel, Korea, 

Mexico and the United Kingdom, and thus comparing these results with the other countries requires caution. Moreover, nominal hourly wage 

refers to the average monthly wages per employee job for Israel, and to the average weekly earnings for the United Kingdom. 

‡: Nominal hourly wage controls for additional sources of compositional shifts, such as regions for Australia, Canada and New Zealand, job 

characteristics and workers’ characteristics for Australia and New Zealand, gender for Switzerland, and occupations for the United States. For 

Switzerland, the quarterly estimates refer to the annual Swiss wage index. 

Real hourly wage is estimated by deflating the nominal hourly wage by the consumer price index (CPI-all items). 

Countries are ordered by descending order of the cumulative percentage changes in real hourly wages in Q1 2024 compared to Q4 2019. OECD 

is the unweighted average of the 35 OECD countries shown in this chart (not including Chile, Colombia and Türkiye). The trough refers to the 

quarter where real hourly wages were at their lowest value for the indicated country since Q4 2021. The latest date available refers to Q3 2023 

for Israel, and Q4 2023 for Canada, Costa Rica, Israel, Japan, Korea, Mexico and New Zealand. 

Source: OECD calculations based on the Wage Price Index (Australian Bureau of Statistics) for Australia; the Fixed weighted index of average 

hourly earnings for all employees (Statistics Canada) for Canada; the Encuesta Continua de Empleo (Instituto Nacional de Estadística y Censos) 

for Costa Rica; the Labour cost index by NACE Rev. 2 activity (Eurostat) for the European countries except the United Kingdom; the Wages 

and Employment Monthly Statistics (Central Bureau of Statistics) for Israel; the Labour Force Survey at Establishments (Ministry of Employment 

and Labour) for Korea; the Monthly Labour Survey (Ministry of Health, Labour and Welfare) for Japan; the Encuesta Nacional de Ocupación y 

Empleo y Encuesta Nacional de Ocupación y Empleo Nueva Edición (Instituto Nacional de Estadística y Geografía) for Mexico; the Labour 

Cost Index (Stats NZ) for New Zealand; the Swiss Wage Index (Federal Statistical Office) for Switzerland; the Monthly Wages and Salaries 

Survey (Office for National Statistics) for the United Kingdom; and Employment Cost Index (Bureau of Labor Statistics, retrieved from FRED) 

for the United States. OECD (2024), “Prices: Consumer prices”, Main Economic Indicators (database), https://doi.org/10.1787/0f2e8000-en, 

(accessed on 21 June 2024). 

StatLink 2 https://stat.link/m9kfd5 

-15

-10

-5

0

5

10

15

20
%

Q1 2024 or latest Trough since Q4 2021

https://doi.org/10.1787/0f2e8000-en
https://stat.link/m9kfd5