Average total cash 
compensation
Overall 2023 average total cash 
compensation for partners at 
professional services firms was 
$672,000. Despite almost a quarter 
being pessimistic (see chart at the 
top of page 20), partners at strategy 
consulting firms saw the highest total 
cash compensation, almost double the 
average total cash compensation of 
their peers in management consulting.

Unsurprisingly, total cash compensation 
rose by tenure as a partner, though 
partners with current firm tenure at 
between three and five years saw the 
lowest total cash compensation. 

Average total cash compensation was 
relatively steady across gender and 
racial or ethnic groups—with white 
people and men only slightly outearning 
their lesser-represented counterparts.

Average total cash compensation ($ thousands)

State of professional services 
partner compensation

Overall (n= 155)

Strategy consulting (n= 47)

Management/advisory consulting (n= 64)

Technology/IT consulting (n= 27)

Other (n= 17)

Less than $1.00bn (n= 37)

$1.00bn–$5.00bn (n= 23)

$5.01bn–$20.00bn (n= 29)

More than $20.00bn (n= 61)

Less than 6 years (n= 34)

6–10 years (n= 56)

11–15 years (n= 26)

More than 15 years (n= 31)

Less than 3 years (n= 37)

3–5 years (n= 43)

6–10 years (n= 30)

More than 10 years (n= 42)

Less than 2 years (n= 28)

2–3 years (n= 49)

4–5 years (n= 32)

More than 5 years (n= 41)

Men (n= 119)

Women (n= 19)

Racial or ethnic minority (n= 39)

White (n= 116)

O
ve

ra
ll

Fi
rm

 ty
pe

Fi
rm

 re
ve

nu
e

Te
nu

re
 a

s 
pa

rt
ne

r
Te

nu
re

 a
t fi

rm
Te

nu
re

 in
 

cu
rr

en
t r

ol
e

G
en

de
r

Ra
ce

/ 
et

hn
ic

ity
1,069

421

415

555

521

598

868

920

449

1,039

776

650

656

936

641

472

651

908

727

497

688

622

646

638

672

Source: Heidrick & Struggles US professional services partner compensation survey, 2024

Diverse region, inclusive workforces: Diversity and inclusion policy and practice in Asia PacificHEIDRICK & STRUGGLES

21