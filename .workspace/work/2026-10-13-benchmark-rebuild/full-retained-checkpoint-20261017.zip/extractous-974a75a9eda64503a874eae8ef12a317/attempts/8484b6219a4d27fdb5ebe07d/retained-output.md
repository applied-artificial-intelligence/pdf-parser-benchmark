By tenure in their current role, there is a 
correlation between revenue targets and 
tenure in role for those who are either 
new in their role or are more tenured. 
More-junior respondents identified lower 
personal targets, while more-senior 
respondents identified higher targets.

Respondents in their current role for 
two to three years have slightly higher 
personal revenue targets than their 
counterparts with tenure between four 
and five years: 48% of respondents with 
two to three years’ tenure reported 
personal revenue targets below  
$10 million, while 63% of respondents 
with four to five years of experience 
reported the same. And 28% of 
respondents with two to three years’ 
tenure in their current role reported 
personal revenue targets of $20 
million or more, while only 19% of 
respondents with four to five years 
of experience reported the same.

0

18 10

7

21 14

21 24

11 20

7 12

8

87

Less than 
2 years

4–5 years More than 
5 years

2–3 years

Personal revenue targets, by tenure in role

Less than $1.00m

$1.00m–$3.00m

$3.01m–$6.00m

$6.01m–$10.00m

$10.01m–$15.00m

$15.01m–$20.00m 

$20.01m–$25.00m 

$25.01m–$30.00m

More than $30.00m

Prefer not to answer

Note: Numbers may not sum to 100%, because of rounding.

Source: Heidrick & Struggles US professional services partner compensation survey, 2024, n=155

4 2

4

0

22

19

19

13

13

6

3

3

3

0

0

7

0

12

10

10

15

24

7

12

2

Practice leader

Regional leader

Office leader

No

What is your current role? Do you have any additional 
firm leadership roles?

9

54

7

30

Current role information (%)

Source: Heidrick & Struggles US professional services 
partner compensation survey, 2024, n=187

Source: Heidrick & Struggles US professional services 
partner compensation survey, 2024, n=169

Respondent 
demographics
Compared to 2022, there is a slightly 
higher share of respondents (70%) 
who say they have an additional firm 
leadership role. The vast majority of 
respondents are at the partner level.

Partner (or partner-equivalent)

Pre-partner

7

93

Personal revenue targets (%)

2024 US PROFESSIONAL SERVICES PARTNER COMPENSATION SURVEY

8