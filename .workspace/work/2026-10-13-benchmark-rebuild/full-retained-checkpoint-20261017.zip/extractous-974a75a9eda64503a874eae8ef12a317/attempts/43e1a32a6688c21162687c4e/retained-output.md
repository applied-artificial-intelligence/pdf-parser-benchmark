Chapter 2: Social convergence in the EU: taking stock 

49 

 

Chart 2.5 

Growing disparities in skill supply pose challenges to regional development 
Tertiary education attainment and adult participation in learning (last 4 weeks) (% of population aged 30-34), and cross-regional variation (measured by standard deviation), 2007-
2023, EU-NUTS2 

                   

Note: Standard deviation is a measure of cross-regional variation, the higher the standard deviation, the higher the cross-regional variation. 

Source: DG EMPL calculations based on Eurostat datasets edat_lfse_04, trng_lfse_04. 

Click here to download chart. 

 
 
 

Figure 2.2 

Regional variation in tertiary education attainment ranged from 28-48% in most NUTS2 regions 
Tertiary educational attainment, 2023 (% of people aged 30-34), NUTS 2 regions 

 

Note: Tertiary educational attainment (% of people aged 30-34) by NUTS2 regions, 2023. 

Source: Eurostat, edat_lfse_04 IMAGE Interactive map generator. 

Click here to download figure. 

 
While participation in adult learning improved somewhat at the EU level, disparities increased 
including in relation to the development of basic digital skills. The indicator for adult learning 
participation (over the last four weeks) stood at 7.9% in 2007, increasing to 10.1% in 2014, and 12.8% in 
2023. (82) However, differences in national (and regional) participation rates widened, ranging from 1.4% to 

 
(82) Analysis refers to the European Pillar of Social Rights Social Scoreboard indicator of adult participation in learning in the past 4 weeks 

(LFS) and not to the adult participation in learning in the last 12 months (Adult Education Survey (AES)) indicator that monitors the EU 
 

0

2

4

6

8

10

12

14

0

10

20

30

40

50

2007 2010 2013 2016 2019 2022

Tertiary education attainment

Average (left axis)

Standard deviation (right axis)
0

2

4

6

8

0

5

10

15

2007 2009 2011 2013 2015 2017 2019 2021 2023

Adult learning participation

Average (left axis)

Standard deviation (right axis)

https://ec.europa.eu/employment_social/empl_portal/publications/Esde2024/xls/Chap2/Chap2-Chart-2.5.xlsx
https://ec.europa.eu/employment_social/empl_portal/publications/Esde2024/xls/Chap2/Chap2-Figure-2.2.png