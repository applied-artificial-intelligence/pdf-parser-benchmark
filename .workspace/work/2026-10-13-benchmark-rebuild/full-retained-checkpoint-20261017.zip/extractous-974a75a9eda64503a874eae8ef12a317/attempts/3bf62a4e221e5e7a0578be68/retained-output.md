 27 

OECD ECONOMIC OUTLOOK, VOLUME 2025 ISSUE 2 © OECD 2025 
  

Figure 1.15. Elevated equity valuations are supported by the higher expected earnings of 
technology companies 

 

Note: Panel A shows monthly values of the cyclically adjusted price-to-earnings ratio (CAPE), computed with 10-year average earnings adjusted 

for subsequent changes in consumer prices. The value for November 2025 is based on observations up to 19 November.  

Source: LSEG; and OECD calculations. 

Spreads on high-yield corporate bonds remain close to historical lows, despite a recent uptick, and 

investment-grade bond yields have declined in recent months. Low credit risk premia and sustained 

portfolio inflows in the United States and the euro area have helped to support strong corporate bond and 

leveraged loan issuance during the first three quarters of 2025 (Figure 1.16, Panel A). Bank credit growth 

has also been recovering gradually in major advanced economies, albeit from low levels, supported by an 

ongoing decline in lending rates (Figure 1.16, Panel B). 

Emerging-market economies have benefitted from higher global risk appetite. A weaker US dollar and 

declining exchange rate volatility have made emerging-market assets relatively more attractive. This has 

been accompanied by strong growth in equity prices, partly driven by a substantial rise of AI-related 

equities, with the main exception of India, where the stock market has been broadly flat, possibly reflecting 

the marked rise in the US tariff rate on imports of goods from India. Spreads on corporate bonds issued 

by emerging-market companies have continued to fall, reaching their lowest levels since 2007. In the 

sovereign bond markets of most emerging-market economies, long-term yields have broadly eased since 

June and spreads on US dollar-denominated bonds have declined. 

In contrast, developments in sovereign debt markets in advanced economies have been less favourable. 

Ten-year yields have edged up in recent months in many jurisdictions and 30-year yields have increased 

by larger amounts, steepening the long end of the yield curve. Amid ongoing quantitative tightening and 

large net government debt issuance needs in the near future, that steepening could reflect growing 

concerns about long-run fiscal sustainability. In the United States, the 10-year sovereign yield has been 

underpinned by a persistently high estimated real term premium. In France, mounting political challenges 

have clouded the fiscal outlook, markedly widening French-German sovereign spreads since mid-August.