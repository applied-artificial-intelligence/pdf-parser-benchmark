7

0 2 4 6 8
0.0

0.2

0.4

0.6

0.8

1.0

1.2

1.4 (a)

 T=0.04
 T=0.07
 T=0.1

g
(r
)

r

0 2 4 6 8

0.4

0.6

0.8

1.0

(b)

 T=0.5
 T=1.0
 T=2.0g

(r
)

r
FIG. 7: Radial distribution functions of GCM for a set of
isotherms at the density ρ = 0.5 (a) - T = 0.04; 0.07 and 0.1;
(b) - T = 0.5; 1.0 and 2.0.

of the entropies along two isotherms. One can see that
both at high and low temperature the difference between
excess entropy and pair contribution to it is rather large.
This discrepancy is small at low densities, but greatly
increases at the density about 0.4. Note that this density
corresponds to a character distance l ∼ 1/ρ1/3 ≃ 1.35,
that is l ≃ σ1. It allows to conclude that the interplay of
the distances starts at this density and it is this interplay
which makes the excess entropy and pair excess entropy
difference to increase rapidly.

Fig. 13 shows the diffusion coefficient scaling with the
pair part of the excess entropy. As is seen from the figures

0.0 0.2 0.4 0.6 0.8 1.0

-1.4

-1.2

-1.0

-0.8

-0.6

-0.4

-0.2

0.0 (a)
 T=0.04
 T=0.07
 T=0.1

S
e
x

0.0 0.2 0.4 0.6 0.8 1.0

-0.15

-0.10

-0.05

0.00

(b)  T=0.5
 T=1.0
 T=2.0

S
e
x

FIG. 8: Excess entropy of GCM for a set of isotherms. (a) -
T = 0.04; 0.07 and 0.1; (b) - T = 0.5; 1.0 and 2.0.

even at high temperatures the curve is not straight while
at low temperatures the curve becomes very strange.
Definitely the exponential relation between the diffusion
coefficient and pair excess entropy is not valid.

The diffusion scaling with the full excess entropy is
shown in the figure 14 (a) and (b). One can see from these
pictures that the scaling rule works good for the temper-
atures T = 0.5 and T = 0.4 but already for T = 0.35
the deviation from the linear behavior occurs. This de-
viation develops more as the temperature decreases. At
T = 0.25 a self crossing loop occurs. This loop even en-
larges at lower temperatures. It is worth to note that the
curve at low temperature T = 0.2 consists of two linear