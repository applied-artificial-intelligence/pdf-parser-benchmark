Australia Properties

Centrally located in Perth’s prime 
retail stretch, the David Jones 
Building sits on a freehold site of 
approximately 71,473 sq ft in the 
Perth CBD in Australia. It enjoys 
dual frontage to the bustling Murray 
Street Mall and Hay Street Mall, the 
only two retail pedestrian streets in 
the city. 

The property is a few minutes’ 
walk from the Perth station and is 
also linked seamlessly to another 
major shopping centre via a 
covered walkway. The four-storey 
property, which has heritage-
listed components (including a 
building constructed circa 1910 
that was formerly the Savoy Hotel), 
is anchored by the David Jones 
department store.

As at 30 June 2024, the property’s 
committed occupancy was 99.3%. 
David Jones Pty Limited occupies 
approximately 95.1% of the total 
gross lettable area and accounts 
for 87.1% of the gross rent for David 
Jones Building as at 30 June 2024. 

David Jones
Building
Four-storey heritage-listed building for retail use.

Tenure 

Freehold
Number Of Tenants
(As at 30 June 2024)

7
(including an anchor tenant)

Purchase Price

S$145.7M

Market Valuation
(As at 30 June 2024)

S$111.6M

Total Gross Lettable Area
(As at 30 June 2024)

259,098 SQ FT

The long-term lease with David 
Jones provides for an upward-only 
rent review every three years and 
expires in 2032. A rental uplift was 
secured in August 2023. 

Besides David Jones, six specialty 
stores occupy a gross lettable area 
of about 10,764 sq ft and comprise 
international and national brands such 
as Rosendorff Diamonds, Superdry, 
Sushi Gin and The Body Shop.

Notes:
(1) Based on committed leases as at the reporting date.
(2) Based on gross rent as at 30 June 2024 and excludes gross turnover rent.
(3) Includes the David Jones lease.

Top 5 Tenants based on gross rent(2)

1. David Jones Pty Limited

2. Lorna Jane Pty Ltd 

3. Clyde and Associates Pty Ltd 

4. The Body Shop Australia Pty Ltd 

5. Gin Sushiya Pty Ltd 

99.3%

98.3%

(As at 30 June 2024)

(As at 30 June 2023)

Occupancy Rate(1)Retail Trade Mix
By Gross Rental Contribution 
(As at 30 June 2024)

 David Jones 
(Anchor Tenant)

 Jewellery
 Fashion
 Health & Beauty
 Food & Beverage

87.1%

3.9%
3.5%
2.8%
2.7%

3.5 0.0 0.0 0.0 96.5(3)

FY
24/25

FY
25/26

FY
26/27

FY
27/28

Beyond
FY 27/28

0

20

40

60

80

100

Lease Expiry Profile by gross rent(1)

(%)

42 STARHILL GLOBAL REIT