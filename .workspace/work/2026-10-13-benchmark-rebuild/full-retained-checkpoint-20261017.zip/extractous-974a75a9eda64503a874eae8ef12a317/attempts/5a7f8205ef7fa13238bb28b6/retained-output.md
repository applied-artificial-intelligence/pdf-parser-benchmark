SMBC Loans (Nonconsolidated)

SMFG 2011168

Millions of yen
Year ended March 31 2011 2010
Write-off of loans ............................................................................................. ¥70,775 ¥102,663
Note: Write-off of loans include amount of direct reduction.

Write-Off of Loans

Millions of yen
March 31 2011 2010
Iceland ............................................................................................................. ¥1,233 ¥1,112
Ukraine ............................................................................................................ 1,010 160
Pakistan ........................................................................................................... 68 61
Argentina ......................................................................................................... 6 4
Total ................................................................................................................. ¥2,318 ¥1,339
Ratio of the total amounts to total assets ....................................................... 0.00% 0.00%
Number of countries ........................................................................................ 4 4

Specific Overseas Loans

Millions of yen
March 31 2011 2010
Consumer loans .............................................................................................. ¥15,369,284 ¥15,400,531

Housing loans .............................................................................................. 14,490,768 14,497,508
Residential purpose ................................................................................. 11,141,658 11,010,697

Others .......................................................................................................... 878,516 903,023
Note: Housing loans include general-purpose loans used for housing purposes as well as housing loans and apartment house acquisition loans.  

Consumer Loans Outstanding

Millions of yen

Balance at beginning
of the fiscal year

Increase during
the fiscal year

Decrease during the fiscal year Balance at end
of the fiscal yearYear ended March 31, 2011 Objectives Others

General reserve for possible loan losses.................. ¥491,033 ¥483,315 ¥    — ¥491,033* ¥483,315
[4,617]

Specific reserve for possible loan losses ................. 260,622 227,935 59,791 200,831* 227,935
[1,720]

For nonresident loans ........................................... 28,665 44,601 5,719 22,945* 44,601
[1,720]

Loan loss reserve for specific overseas countries ... 184 272 — 184* 272
Total .......................................................................... ¥751,840 ¥711,522 ¥59,791 ¥692,049 ¥711,522

[6,338]
Amount of direct reduction ....................................... ¥475,487 ¥496,205

[2,554]

* Transfer from reserves by reversal or origination method

Note: Figures in brackets [ ] indicate foreign exchange translation adjustments.

Millions of yen

Balance at beginning
of the fiscal year

Increase during
the fiscal year

Decrease during the fiscal year Balance at end
of the fiscal yearYear ended March 31, 2010 Objectives Others

General reserve for possible loan losses.................. ¥504,379 ¥497,582 ¥     — ¥506,310*1, 2 ¥495,650
[2,270]

Specific reserve for possible loan losses ................. 284,799 267,351 109,562 180,245*1, 2 262,343
[18]

For nonresident loans ........................................... 71,028 35,393 35,048 40,988*1, 2 30,385
[10]

Loan loss reserve for specific overseas countries ... 417 184 — 417*1 184
Total .......................................................................... ¥789,596 ¥765,118 ¥109,562 ¥686,973 ¥758,178

[2,288]
Amount of direct reduction ....................................... ¥477,529 ¥478,042

[1,954]

*1  Transfer from reserves by reversal or origination method

*2  “Others” under “Decrease during the fiscal year” include the amount transferred to Sumitomo Mitsui Banking Corporation (China) Limited in connection with a busi-

ness transfer. The transferred amount comprises ¥1,931 million for the general reserve for possible loan losses and ¥5,008 million for the specific reserve for pos-

sible loan losses for nonresident loans.

Note: Figures in brackets [ ] indicate foreign exchange translation adjustments.

Breakdown of Reserve for Possible Loan Losses