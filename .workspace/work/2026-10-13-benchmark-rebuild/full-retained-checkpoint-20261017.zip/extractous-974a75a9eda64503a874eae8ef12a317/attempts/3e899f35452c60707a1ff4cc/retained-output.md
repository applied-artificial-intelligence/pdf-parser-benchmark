 243 

OECD EMPLOYMENT OUTLOOK 2024 © OECD 2024 
  

5.3.1. Energy spending is one key driver of household emissions 

Carbon prices affect household budgets both directly through households’ own fuel consumption, and 

indirectly via the consumption of other goods and services that give rise to CO2 emissions during the 

production process. The direct effect is shaped by the pattern of expenditures on heating and transport 

(fossil-)fuel (Figure 5.4). The figure also shows spending on electricity, which is a derived good, whose 

production can be fuel intensive.16 Energy-related emissions embodied in the full set of derived goods, 

including, e.g. food and public transport, form one part of the overall carbon footprints presented in the 

next sub-section. 

Poor households save less than the rich, or they dissave, and total consumption therefore accounts for 

larger portions of their income than for better-off households. In four of the five countries included in 

Figure 5.4, such a regressive spending pattern holds also for energy consumption. This is particularly 

visible in Poland and Türkiye, where low-income households spent more than one fifth of their incomes on 

energy.17 Spending on electricity and heating is also regressive in the other European countries. This 

makes them particularly vulnerable to energy poverty.18 But the share of resources devoted to some 

categories of energy can in fact increase with income. Spending shares for motor fuel are increasing with 

income in Mexico and Poland, reflecting both income inequality and unequal car ownership. In Germany, 

motor fuel spending is mostly flat. Mexico is the only country where richer households devote bigger 

portions of their income to energy overall, confirming that energy can be a luxury item in middle-income 

countries.19 Average spending shares also vary strongly across countries, with plausible drivers including 

average incomes, climatic factors, as well as energy taxation and subsidies. 

Figure 5.4. Poorer households typically spend large parts of their income on energy, but spending 
is “top-heavy” in some middle-income countries 

Household expenditures on fuel and other energy, as a percentage of disposable income, by income decile 

 

Note: Groups 1-10 refer to income deciles (equivalised disposable household income). Heating fuel includes expenditure on gas (natural gas 

and town gas), liquified hydrocarbons, kerosene and other liquid fuels, coal and other solid fuels. Motor fuel includes expenditure on diesel and 

petrol for transportation. 

Source: OECD calculations using household budget surveys (2015 for EU countries, 2016 for Mexico, 2019 for Türkiye) and WIOD input-output 

data (for electricity). 

StatLink 2 https://stat.link/h71u94 

0

5

10

15

20

25

1 2 3 4 5 6 7 8 9 10 1 2 3 4 5 6 7 8 9 10 1 2 3 4 5 6 7 8 9 10 1 2 3 4 5 6 7 8 9 10 1 2 3 4 5 6 7 8 9 10

Germany France Mexico Poland Türkiye

%

Income decile

Heating fuels Motor fuels Electricity

https://stat.link/h71u94