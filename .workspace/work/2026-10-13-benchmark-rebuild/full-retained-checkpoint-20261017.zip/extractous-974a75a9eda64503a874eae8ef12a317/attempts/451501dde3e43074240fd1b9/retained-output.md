of such failures. Although skip hyperconnections increase
the failure-resiliency of distributed DNNs, they do not make
the learned weights more prepared for such failures. This is
because all neural network components are present during
training, as opposed to inference time where some physical
nodes may fail. In order to account for the learned weights
being more adapted to specific failure scenarios, we intro-
duce failout regularization, which simulates inference-time
physical node failure conditions during training.

During training, failout “fails” (i.e., shuts down) a physi-
cal node, to make the learned weights more adaptive to such
failures and the distributed neural network more failure-
resilient. By “failing” a physical node, we mean temporar-
ily removing the neural network components that reside on
the physical node, along with all their incoming and outgo-
ing connections. Failout’s training procedure could be done
offline, and would not necessarily be employed during run-
time. Therefore failing physical nodes would be temporarily
removing their neural network components in simulation.

When the neural components of a given physical node
shut down using failout, the neural layers of the upstream
physical node that are connected to the failing physical node
will not receive information from the failing physical node,
forcing their weights to take into account this situation and
utilize the received information from the skip hyperconnec-
tion. In other words, failout forces the information passage
through the skip hyperconnections during training, hence
adapting the weights of the neural network to account for
these failure scenarios during inference.

Formally, consider a neural network which is distributed
over V different nodes vi, i ∈ [1, V ], where for each vi, we
define its failure rate (probability of failure) fi ∈ [0, 1]. Fol-
lowing this, we define a binary mask b with V components,
where its i-th element bi follows a Bernoulli distribution,
with a mean equal to 1−fi, that is bi ∼ Ber(1−fi). During
training, for each batch of examples, a new mask b is sam-
pled, and if bi = 0, the neural components of physical node
vi are dropped from computation (vi’s output is set to zero
in simulated off-line training), thus simulating a real failure
scenario. Formally, if Yi denotes the output of node vi, then
Yi = biHi(Xi), where Hi(.) is a non-linear transform on
Xi, the input of physical node vi.

Consider a vertically distributed DNN where the nodes
are numbered in sequence 1, 2, . . . , V from downstream to
upstream (cloud). In this setting, for ResiliNet we can derive
an equation for Xi+1, the input to node vi, as

Xi+1 = Yi � Yi−1, (1)

where the operator � is defined as: in Xi+1 = Yi � Yi−1,
when node vi is alive Xi+1 = Yi, and when node vi fails,
Xi+1 = Yi−1. In this definition, we can see that the skip hy-
perconnection is only active when there is a failure, which
corresponds to ResiliNet. In the experiments, we also con-
sider a case where skip hyperconnections are always active
(we call it ResiliNet+), for which eq. (1) is modified to

Xi+1 = Yi ⊕ Yi−1. (2)

Although, superficially, failout seems similar to dropout
(Srivastava et al. 2014), failout removes a whole segment of

n1

i

n2

n3

n4

m1

i

m2

m3

Health MobileNet

z1

i

z2

z3

ResNet

1

2

3

4

3

5

5

4

4

9

111

Figure 1: Distributed
neural network setup and
number of layers on each
node.

Config Health + Vanilla Health + dFG Health + ResiliNet
Low 55.66 75.33 88.16
Medium 75.58 86.69 94
High 86.57 92.21 95.88
No-Failure 97.86 97.91 97.03

 A
vg

 A
cc

ur
ac

y 
(%

)  

49

59

69

79

89

99

(a) Health Experiment
Hazardous Poor Normal NoFailure

Vanilla DFG ResiliNet

Config Camera + Vanilla Camera + dFG Camera + ResiliNet
Low 78.41 88.32 91.09
Medium 91.26 95.04 95.54
High 97.86 98.33 98.79
No-Failure 98.86 98.54 99.1

 A
vg

 F
-m

ea
su

re
 (%

)  

75

80

85

90

95

100

(b) Camera Experiment
Hazardous Poor Normal NoFailure

Raw result (incorrect by keras)

imagenet + Vanilla imagenet + dFG imagenet + 
ResiliNet

0,0 0.1 0.1 0.1

0,1 0.1 3.23 37.41

1,0 0.1 7.3 41.94

1,1 58.5619 57.84 53.0

Low 39.854092 40.9628 47.662
Medium 50.0849245 50.29255 50.98325
High 55.10095552 54.764128 52.2248
No Failure 58.5619 57.84 53.0

Raw result corrected

imagenet + Vanilla imagenet + dFG imagenet + 
ResiliNet

0,0 0.1 0.1 0.1
0,1 0.1 10.23 46.41
1,0 0.1 14.3 52.94
1,1 65.0619 64.84 66.0
Low 44.274092 47.7528 59.452
Medium 55.6424245 57.25755 63.54825
High 61.21615552 61.758528 65.0592
No Failure 65.0619 64.84 66.0

Config imagenet + Vanilla imagenet + dFG imagenet + 
ResiliNet

Low 44.274092 47.7528 59.452
Medium 55.6424245 57.25755 63.54825
High 61.21615552 61.758528 65.0592
No Failure 65.0619 64.84 66.0

 A
vg

 A
cc

ur
ac

y 
(%

)  

36

42

48

54

60

66

(b) MobileNet Experiment
Hazardous Poor Normal NoFailure

Config resnet + Vanilla resnet + dFG resnet + ResiliNet
Low 66.8715896 75.2779844 77.5998442
Medium 80.9894727 84.3155412 84.5
High 87.9141416 89.1371939 88.24
No Failure 92.692013 92.377987 90.7

 A
vg

 A
cc

ur
ac

y 
(%

)  

45

54.8

64.6

74.4

84.2

94

(c) ResNet Experiment
Hazardous Poor Normal NoFailure

1

Figure 2: Average performance

neural components, including neurons and weights, for a dif-
ferent purpose of failure-resiliency of distributed DNNs (and
not only regularizing the neural network). Another distinc-
tion between failout and dropout is in their behavior during
inference. In dropout, at inference, the weights of connec-
tions are multiplied by the probability of survival of their
source neuron to account for model averaging from expo-
nentially many thinned models. Furthermore, DNN units are
not dropped during inference in dropout, making the model
averaging a necessity. In contrast, failout does not multiply
weights of hyperconnections by the probability of survival,
since, during inference, physical nodes may fail, though not
necessarily at the same rate as during training. Said differ-
ently, failout does not use the model ensemble analogy as
used in standard dropout, hence does not need the mixed
results of the model ensembles. To verify our hypothesis,
we conducted experiments using different datasets in a set-
ting where the weights of hyperconnections are multiplied
by the probability of survival of the physical nodes, and we
observed a sheer reduction in performance.

Experiments
We compare ResiliNet’s performance with that of DFG
(Yousefpour et al. 2019) and vanilla (distributed DNN with
no skip hyperconnections and no failout).

Scenarios and Datasets
Vertically distributed MLP: This is the simplest scenario
for a distributed DNN in which the MLP is split vertically
across physical nodes shown in the left of fig. 1.

For this scenario, we use the UCI health activity classifi-
cation dataset (“Health” for short), described in (Banos et al.
2015). This dataset is an example of an IoT application for
medical purposes where the inference task will run over a
long period of time. The dataset is comprised of readings
from various sensors placed at the chest, left ankle, and right
arm of 10 patients. There are a total of 23 features, each cor-
responding to a type of data collected from sensors. For this