distance between particle clusters resulting from the demixing process that occurs already in the

bulk liquid and is not related to the front instability at all. Note that one finds a similar sequence

of regimes (i) to (iv) when increasing the particle-particle interaction strengths for fixed εnl (see

Ref. [41]) for further details.

1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2
εnl

0

5

10

15

20

25

<f
>

(i)(ii)(iii)(iv)

FIG. 3: (Colour online) Dependence of the mean finger number left behind by the unstable dewetting

front on the particle-liquid interaction strength εnl. The regions marked (i) to (iv) are discussed in the

main text. The insets display typical snapshots obtained in the four different regions. Particles are black,

liquid is grey (green online) and the empty substrate is white. The remaining parameters are kT = 0.2,

M = 20, µ = −2.2, ρavn = 0.1, εnn = 2.0, domain size 1200 × 1200. For the insets, from left to right,

εnl = 1.2, 1.4, 1.45, 1.8.

We note also that the fingering process may be viewed as self-optimising the front motion – i.e.

the front keeps its average velocity constant by expelling particles into the fingers. A similar effect

exists for dewetting polymer films [18], where liquid is expelled from the growing moving rim

which collects the dewetted polymer. There, the surplus liquid is left on the surface as a droplet

pattern.

The kinetic Monte Carlo model is a very useful tool that helps one to understand the pattern

formation in drying nanoparticle suspensions. One has, however, to keep in mind the restrictions

13