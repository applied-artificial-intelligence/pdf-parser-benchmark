PwC 18Semiconductor and beyond 2026 

The future of intelligent infrastructure

As AI applications push the required data 
volume for processing, and as the scale of data 
centers grows in response, operational expenses 
for cooling and electricity have reached 
astronomical levels. Companies are now seeking 
ways to operate more cost-effectively.

The first way to do so while boosting AI 
performance is to utilize data-center-specific 
chips. These chips are crucial for achieving high 
performance because they are built to handle 
the intensive computational demands of data 
processing more efficiently than general-
purpose processors. To get the desired level of 
performance, companies are turning to these 
specialized chips to meet their needs.

However, even if designed specifically for data 
centers, standard chips are designed for 
multiple customers and thus contain functions 
that a given customer might not use. Therefore, 
big techs like cloud service providers are 
developing their own AI accelerators specifically 
designed for their own data center applications. 

By developing AI chips tailored to specific 
workload, companies can reduce cost and power 
while achieving higher performance. The 
demand for AI accelerators is expected to rise as 
the need for cost reduction grows with increased 
data-processing demand. 

Therefore, the revenue share of AI accelerators 
among chips used in data centers can grow at a 
very fast pace, reaching around 50% of total 
data center chips.

In addition to AI accelerators, other data-
center-specific chips such as data processing 
units (DPUs) and advanced memory chips such 
as HBM can also rise. HBM reduces a data 
processing bottleneck, supporting high-
performance GPUs, and data processing units 
(DPUs) offload CPU networking workloads by 
handling data transmission. Sales of these data-
center-specific chips may continue to grow as 
they become essential. 

18

AI accelerators in the data center (Unit: $ Billion)

50

100

150

200

250

300

40

0

10

20

30

0

50

60

70

80

90

100

35%

’24 ’25F ’26F ’27F ’28F ’29F

52%

’30F

(%)

Data center semiconductors Portion of AI accelerator

Source: PwC analysis