Appendix

72

Figure 42: Total number of billion-dollar economic loss natural catastrophes; losses adjusted to 2023 USD  |  Data and Graphic: Gallagher Re

Figure 43: Total number of billion-dollar insured loss natural catastrophes; losses adjusted to 2023 USD  |  Data and Graphic: Gallagher Re

Total Number of Billion-Dollar Events: Economic and Insured (1990–2023)

Weather / Climate Other Natural Perils

1990 1992 1994 1996 1998 2000 2002 2004 2006 2008 2010 2012 2014 2016 2018 2020 2022

10

20

30

40

50

60

70

1990 1992 1994 1996 1998 2000 2002 2004 2006 2008 2010 2012 2014 2016 2018 2020 2022

5

10

15

20

25

30

35

Weather / Climate Other Natural Perils