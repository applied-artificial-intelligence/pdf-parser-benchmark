Source: Cetera Investment Management, FactSet, YCharts. The annual total return includes dividends. The annual max decline is the 

largest price decline in each calendar year. Return and max drawdown data based on closing prices. Data as of 12/31/2024. 
15

S&P 500 Annual Total Return and Max Drawdown

32.5%

-4.9%

21.5%22.6%

6.3%

31.7%

18.7%

5.3%

16.6%

31.7%

-3.1%

30.5%

7.6%
10.1%

1.3%

37.6%

23.0%

33.4%

28.6%

21.0%

-9.1%

-11.9%

-22.1%

28.7%

10.9%

4.9%

15.8%

5.5%

-37.0%

26.5%

15.1%

2.1%

16.0%

32.4%

13.7%

1.4%

12.0%

21.8%

-4.4%

31.5%

18.4%

28.7%

-18.1%

26.3%
25.0%

-17.1%

-18.4%

-16.6%

-6.9%

-12.7%

-7.7%
-9.4%

-33.5%

-7.6% -7.6%

-19.9%

-5.7%

-6.2%

-5.0%

-8.9%

-2.5%

-7.6%

-10.8%

-19.3%

-12.1%

-17.2%

-29.7%

-33.8%

-14.1%

-8.2%
-7.2%

-7.7%
-10.1%

-48.8%

-27.6%

-16.0%

-19.4%

-9.9%

-5.8%
-7.4%

-12.4%

-10.5%

-2.8%

-19.8%

-6.8%

-33.9%

-5.2%

-25.4%

-10.3%
-8.5%

-50.0%

-40.0%

-30.0%

-20.0%

-10.0%

0.0%

10.0%

20.0%

30.0%

40.0%

1980 1985 1990 1995 2000 2005 2010 2015 2020

Annual Total Return Annual Max Drawdown

1980 - 2024
Average Annual Total Return: 13.5%
Average Annual Max Drawdown: -14.1%