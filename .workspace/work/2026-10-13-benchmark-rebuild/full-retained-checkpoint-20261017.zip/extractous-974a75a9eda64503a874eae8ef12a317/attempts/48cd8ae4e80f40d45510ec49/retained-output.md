Chapter 2: Social convergence in the EU: taking stock 

59 

all men, resulting in a gender gap of about 22 pp (Chart 2.9). This gap increased since 2008, when it stood at 
about 19 pp. Over the same period, the variation in gender segregation in education and health activities across 
countries decreased (Chart 2.9). In other words, the EU Member States converged, but towards a somewhat more 
unequal outcome. 

Involvement of women in unpaid care has dropped somewhat since 2007, but women remain 
considerably more engaged in unpaid care than men. In 2022, one in four men in the EU were involved 
daily in unpaid care, and around one in three in housework (Chart 2.10). For women, the corresponding shares 
were 34% and 63%, respectively. The proportion of men involved in unpaid care remained relatively stable since 
2007. Female involvement in unpaid care dropped slightly (by about 6 pp), reflecting the increased availability of 
formal childcare (see Chapter 3(Cedefop, n.d.)). The share of women doing housework on a daily basis dropped by 
16 pp over the same period (notably since 2016), while the involvement of men increased by 10 pp. 

The evidence of convergence in gender gaps in unpaid work is mixed over time and varies 
considerably between Member States. In several countries, the share of women involved daily in unpaid care 
is at least 15 pp higher than men, while in others there is little difference. Although the magnitude of cross-
country differences has remained similar since 2007 (Chart 2.10), some evidence points towards countries with 
larger gaps catching-up with those with smaller gaps. The gender gap in housework varies between 12 pp and 44 
pp across countries. The gap has converged since 2016, but there is no evidence of catching-up by countries with 
the largest gaps. 
 

Chart 2.10 

Limited upward convergence in gender gaps in unpaid work 
Daily involvement in unpaid care and housework by gender, and cross-country variation in gender gaps (standard deviation), 2007-2022, EU-27 

                    

Note: Involvement in unpaid care defined as ‘People caring for and educating their children or grandchildren, elderly or people with disabilities, every day (%, 18-74 population)’. 
Involvement in housework defined as ‘People doing cooking and/or housework, every day (%, 18-74 population)’. Standard deviation is a measure of cross-country variation, the 
higher the standard deviation, the higher the cross-country variation. 

Source: DG EMPL calculations based on EIGE’s Gender Statistics Database 

Click here to download chart. 

 
Gender segregation in the labour market and unequal division of unpaid work are firmly rooted in 
persistent stereotypes about gender-specific skills and household roles. (101) Challenging such 
stereotypes is crucial to promote gender equality in the labour market. This is a key objective of the gender 
equality policy outlined in the EU Gender Equality Strategy 2020-2025. (102) The remainder of this section 
explores trends and convergence in attitudes towards the involvement of women and men in paid and unpaid 
work based on data collected in the European Values Survey between 1990 and 2017 for the 20 Member States, 
for which data are consistently available over such a long-time span. (103) 

4.2. Attitudes to women’s work and sharing unpaid work 

Increasingly positive attitudes to women’s involvement in paid work are consistent with long-term 
reductions in the gender employment gap. The share of people who do not believe that children suffer when 
mothers are in paid work increased from less than 40% in 1990 to more than 60% in 2017, with similar 
proportions among women and men. A comparable increase applies to the share of people who do not consider 
women to be primarily interested in home and children rather than paid work (Chart 2.11). The proportion of 

 
(101) (Bertrand, 2020); (EIGE, 2023); (EIGE, 2018) 
(102) See EU Gender Equality Strategy 2020-2025 here.  
(103) The analysis builds on previous research on attitudes in this area, covering earlier developments in the EU context ( (Knight and Brinton, 

2017); (Grunow, Begall and Buchler, 2018); (Brinton and Lee, 2016); (Scarborough, Sin and Risman, 2019)) 

0
10
20
30
40
50
60
70
80
90

2007 2012 2016 2022

a) Gap at EU level

Unpaid care (% Men) Unpaid care (% Women)

Housework (% Men) Housework (% Women)

0

2

4

6

8

10

12

14

2007 2012 2016 2022

b) Cross-country variation

Unpaid care Housework

https://ec.europa.eu/employment_social/empl_portal/publications/Esde2024/xls/Chap2/Chap2-Chart-2.10.xlsx
https://commission.europa.eu/strategy-and-policy/policies/justice-and-fundamental-rights/gender-equality/gender-equality-strategy_en