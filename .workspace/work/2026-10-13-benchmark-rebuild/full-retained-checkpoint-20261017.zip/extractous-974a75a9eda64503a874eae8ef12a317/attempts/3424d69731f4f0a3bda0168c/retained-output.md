103 

Figure 3.5 Proportion (%) of employed population in KIA among total employment, by sex, 

2021 

 
Source: Eurostat – Human resources in science and technology (online data code: hrst_st_ncat) and Eurostat – EU-

LFS – Active population by sex, age and citizenship (online data code: lfsa_agan). 

Notes: Definition differs, see metadata: ES, FR; Break in time series: EU-27, BE, BG, CZ, DK, DE, EE, IE, EL, ES, FR, HR, 

IT, CY, LV, LT, LU, HU, MT, NL, AT, PL, PT, RO, SI, SK, FI, SE, IS, NO, RS; Reference year differs: ME: 2020, MK: 2020, 

TR: 2020, UK: 2019. 

17.0

22.5

21.3

21.8

21.5

28.4

27.0

22.3

21.1

25.7

25.6

30.8

31.2

24.9

29.4

22.3

40.4

30.8

26.9

23.1

31.4

33.5

30.5

33.4

26.2

35.1

35.0

37.4

31.0

37.9

39.3

38.3

32.0

40.8

56.8

32.1

32.5

35.0

36.5

37.5

41.6

42.5

42.7

42.7

44.4

44.8

45.2

45.2

45.4

45.5

46.1

46.1

46.1

46.2

46.2

46.3

47.5

47.5

47.8

48.4

48.5

48.7

50.4

52.8

53.0

54.2

54.8

56.3

58.2

59.7

23.3

25.6

26.9

28.3

29.0

34.5

33.6

31.7

30.9

34.0

34.1

38.0

38.0

35.0

36.9

34.1

43.1

38.0

35.9

33.9

37.7

40.2

38.5

40.4

37.0

41.5

41.5

42.8

41.0

45.1

46.3

46.1

43.3

49.1

58.1

0 10 20 30 40 50 60 70

RO

TR

MK

RS

BG

ES

IT

HR

PL

CZ

ME

PT

FI

LT

EU-27

LV

NL

AT

HU

SK

EL

DK

DE

FR

EE

NO

CY

MT

SI

UK

IE

BE

IS

SE

LU

Total

Women

Men