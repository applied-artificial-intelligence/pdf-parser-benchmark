Executive Summary
Figure 13. The international financial system generates moreinequality

The centrality of the U.S. dollar, and now other currencies, 

in the global financial system allows rich economies to borrow

at very low rates.

−5%
−4%
−3%
−2%
−1%

0%
1%
2%
3%
4%
5%
6%
7%

1970 1975 1980 1985 1990 1995 2000 2005 2010 2015 2020 2025

E
xc

es
s 

yi
el

d 
as

 %
 

of
 c

ou
nt

ry
 G

D
P,

 M
E

R

BRICS

China

Eurozone

Japan

Russia

United States

Excess yield (assets−liabilities) as % of country GDP, 1970−2025

Interpretation. This graph shows excess yield income, defined as the difference between the return on foreign
assets and liabilities, as a share of national GDP. The figure shows that the exorbitant privilege once exclusive to
the United States has become a broader rich−world phenomenon. The United States maintains a substantial
privilege of 2.2% in 2025. The Eurozone follows with 1% by 2025. Japan stands out with a privilege of 5.9% by
2025. In contrast, BRICS countries face a consistent burden of around 2.1%, highlighting their role as net
providers of capital to wealthier economies. Notes. Positive values represent income gains from financial
privilege; negative values represent financial burden. BRICS countries comprise Brazil, Russia, India, China, and
South Africa. Sources and series: Nievas and Sodano (2025) and wir2026.wid.world/methodology.

Figure 14. Privileged countries face lower liability costs bypolitical design, not market dynamics

0%

10%

20%

30%

40%

50%

60%

70%

80%

90%

1976 1986 1996 2006 2016

S
ha

re
 o

f g
lo

ba
l r

es
er

ve
s 

by
 c

ur
re

nc
y

U.S. dollar

Euro

Pound sterling

Japanese yen

Chinese renminbi

Other currencies

Swiss franc

Interpretation. Rich countries are the issuers of international reserve currencies, which are then used in
international transactions and as a reserve of value around the globe.These currencies dominate central bank
reserves due to international financial rules like Basel III, locking in persistent demand. This leads to persistently
lower borrowing costs. Sources and series: Nievas and Sodano (2025) and wir2026.wid.world/methodology.

Share of global reserves by currency, 1976−2022

23