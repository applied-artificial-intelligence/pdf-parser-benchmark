5

Current Trends and Challenges in the Global Economy 

The chapter is structured as follows. Section B examines the emerging risks to post-COVID-19 growth trend 
at the global level. It finds that divergence within key regional blocks and between major economies clouds the 
fragile growth of 2023, with downside risks lingering into 2024. Section C analyses the sectoral contribution to 
global demand growth in G20 economies. Section D identifies some of the key dimensions of the asymmetry 
between growing corporate concentration on the one hand and thinning fiscal policy space on the other. 
Section E discusses credit, investment and the impact of monetary policy on income and wealth inequality. 
Section F explores inflation, distribution and the easing or persistence of inflationary trajectories. Section G 
looks at labour costs and inequality. Section H concludes.

B. GLOBAL GROWTH LANDSCAPE: DIVERGENCE 
UNDER THE CLOUDS OF UNCERTAINTY

The growth of the world economic output is expected to decelerate to 2.4 per cent in 2023, before registering 
a small uptick to 2.5 per cent in 2024. (table I.1). These are among the lowest growth rates of the last four 
decades, outside of crisis years. Moreover, the figure for 2023 is below the conventional threshold of 2.5 per 
cent which marks recession in the global economy. These projections are subject to downside risks which 
have increased in recent months. 

All regions, except for East and Central 
Asia, are expected to post slower growth 
this year than in 2022, with the largest 
drop (2.3 points) occurring in Europe. 
Likewise, among G20 countries, only 
Brazil, China, Japan, Mexico and the 
Russian Federation are expected to see 
a growth improvement, with considerable 
variation. Of particular concern, given 
the ambitious development and 
climate targets set by the international 
community with a 2030 delivery date, 
growth in 2023 and 2024 is also set 
to fall below the average for the five-
year period before the pandemic, in all 
regions. Latin America is the exception, 
where growth in the earlier period was 
particularly weak (ECLAC, 2023). 

In 2023, global growth showed 
uneven deceleration. Larger emerging 
economies are unlikely to provide a robust 
offset to slower growth in advanced 
economies. With tighter monetary 
policy, low investment (figure I.1), and 
limited government spending, the world 
economy is experiencing a lacklustre 
recovery reminiscent of the aftermath of 
the 2008–2009 financial crisis. 

Figure I.1  Private investment is slowing down sharply again
Growth of private investment
(Percentage change)

2015 17 19 21 23

Developed countries Developing countries

-6

-4

-2

0

2

4

6

8

10

Source: UNCTAD calculations based on the United Nations Global Policy Model 
and database.

Note: GDP at constant 2015 prices, PPP.

I