Listening  
to Music

Listening to /  
Watching Podcasts

Using  
Social Media

Watching  
Videos

Playing  
Video Games

Reading

Multitasking is the time multiplier across all major technology and 
media behaviors 

 7

MULTITASKING1 BEHAVIOR BY ACTIVITY2, U.S., 2024 VS. 2025, % ADULTS AGED 18+ WHO ENGAGE IN EACH ACTIVITY

1. “Multitasking” is defined as simultaneously doing another activity, such as working, cleaning, cooking, or exercising.  2. Figures do not 
sum due to rounding. 
Sources: Activate analysis, Activate 2024 Consumer Technology & Media Research Study (n = 4,004), Activate 2025 Consumer 
Technology & Media Research Study (n = 4,026)

Consumers who multitask1 all, almost all, or most of the time when…

2pp 3pp 0pp 0pp 2pp

32%

45%
49%

55%
62%

72%

30%

44%
49%52%

61%

72%
2024
2025

CONSUMER TIME AND ATTENTION

1pp