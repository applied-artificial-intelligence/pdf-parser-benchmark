 25 

OECD EMPLOYMENT OUTLOOK 2024 © OECD 2024 
  

In Q1 2024, hours worked per employed person were below their pre-COVID-19 levels in 20 of the 

31 countries with recent data available (Figure 1.5). The average decline in hours worked since Q4 2019 

across all countries with available data is rather small – just above 1%.3 In most countries, this decline 

follows a trend that pre-dates the COVID-19 crisis, though with some notable accelerations in Austria, 

Finland, Hungary, Ireland, Korea, the Slovak Republic and Spain. Among the five countries where hours 

worked had been increasing before the COVID-19 crisis, only the Netherlands, Portugal and the 

United States, saw a decline of more than 1% in the aftermath of the pandemic. 

Evidence for Europe indicates that the decline in hours worked over the past 20 years is largely driven by 

an increase in part-time and a reduction in hours within jobs (as opposed to a compositional shift to jobs 

typically requiring fewer hours) (Astinova et al., 2024[5]; ECB, 2021[6]). However, the decline in average 

hours worked since the COVID-19 crisis has not been associated with widespread up-ticks in part-time 

employment. On the contrary, annual data for 2022 point to a slight decrease in the incidence of part-time 

in most OECD countries relative to 2019.4 

Overall, the cross-country comparison does not lend support to the hypothesis of a generalised post-

COVID change in preferences over work-life balance that might have reduced willingness to work, but 

more evidence is needed to understand patterns observed in specific countries. 

Figure 1.5. The post-pandemic decline in average hours worked per worker is generally consistent 
with long-term trends 

Percentage change, seasonally adjusted data 

 

Note: Average hours worked per worker is defined as the total hours worked divided by total employment, except for Belgium where it refers to the 

average hours worked of employees, Korea, where it refers to the average usual weekly hours worked per employed, New Zealand, where it is 

defined as the total paid hours divided by filled jobs, and the United States where it refers to the average usual weekly hours worked per wage and 

salary workers. Statistics are not seasonally adjusted for Canada and Mexico and periods reported for those countries refer to Q4 2004-Q4 2019 

and Q4 2004-Q4 2023, and Q4 2005-Q4 2019 and Q4 2005-Q4 2023, respectively. The latest quarter available refers to Q3 2023 for Israel, and to 

Q4 2023 for Belgium and the United Kingdom. OECD is an unweighted average of the 31 OECD countries shown in this Chart (not including Chile, 

Colombia, Costa Rica, Iceland, Japan, Switzerland and Türkiye). Euro Area refers to the 20 Eurozone countries. 

Source: OECD (2024), “Quarterly National Accounts”, OECD National Accounts Statistics (database), https://doi.org/10.1787/data-00017-en 

(accessed on 21 June 2024) for all countries except Australia, Korea, New Zealand, and the United States; Australian Labour Account (Australian 

Bureau of Statistics) for Australia, Economically Active Population Survey (Statistics Korea) for Korea, Quarterly Employment Survey (QES – Tables 

QEM034AA and QEM025AA, Stats NZ) for New Zealand, and Current Population Survey (CPS, Bureau of Labor Statistics) for the United States. 

StatLink 2 https://stat.link/kudyaz 

-25

-20

-15

-10

-5

0

5
%

Q1 2005-Q4 2019 Q1 2005-Q1 2024

https://doi.org/10.1787/data-00017-en
https://stat.link/kudyaz