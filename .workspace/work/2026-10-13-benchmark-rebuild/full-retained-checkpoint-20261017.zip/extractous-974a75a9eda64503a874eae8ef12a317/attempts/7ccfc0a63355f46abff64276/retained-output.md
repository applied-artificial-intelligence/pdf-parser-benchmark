And while 25–34s have largely embraced many of the same 
networks as social natives in their daily lives and news habits, they 
have remained much more loyal to Facebook (9pp higher for news 
than social natives) – the network this cohort largely grew up with 
– and have been slower to move to new networks like TikTok (5pp 
lower for news than social natives).

What makes these networks so appealing to some younger 
audiences? Qualitative interviews reveal that they are drawn to the 
informal, entertaining style of visual media (and particularly online 
video) platforms – describing it as more personalised and diverse 
than TV, as a resource for rapidly changing events such as the 
Russia–Ukraine conflict, and as a venue for niche interests, from 
pop culture to travel to health and well-being.

On TV we always see the same things, but on YouTube, 
Spotify, TikTok, we have a range of diversity. … We can 
get all this and see that there is diversity, society far 
beyond just what we live.
Male, 18, Brazil

A TV reporter who also has a TikTok page gives us 
regular updates … feels comforting and more intimate 
than watching on TV news.
Female, 22, UK

I find [YouTube] more digestible than mainstream 
media. I also find YouTube to be more interesting 
because it is more specifically geared towards me. 
Male, 23, USA

However, the popularity of online video does not mean text- and 
audio-based formats don’t still have a big role to play in young 
people’s news habits. Under 35s still largely say they prefer to mostly 
read (58%) rather than mostly watch (15%) news – particularly, as 
our qualitative research finds, when looking for live updates and 
summaries or when keeping up with what is happening on a ‘need to 
know’ basis. Some say they seek out a mix of text and video content 
to better understand information. Others, particularly in Asia-Pacific 
and Latin American markets, are drawn to audio-based formats like 
podcasts that allow users to multitask while they listen. There is not 
a one-size-fits-all approach or medium through which newsrooms 
can attract younger audiences.

REUTERS INSTITUTE FOR THE STUDY OF JOURNALISM / FURTHER ANALYSIS GRAPHS

Graph 13

27%
24%

0%

25%

50% Snapchat
TikTok 
WhatsApp
Instagram
YouTube
Twitter
Facebook

20222021202020192018201720162015

PROPORTION OF 18–24s WHO USED EACH SOCIAL NETWORK 
FOR NEWS IN THE PAST WEEK – UK

Q12B. Which, if any, of the following have you used for news in the last week? Base: 18–24s from 
2015–22 (n ≈ 200).

Facebook
SnapchatWhatsApp

YouTube
TikTok

Twitter Instagram

WHY YOUNGER AUDIENCES AVOID NEWS 

And yet, as more news outlets and formats compete for audiences’ 
time and attention, we continue to see longer-term falls in interest 
and trust in news across age groups and markets – particularly among 
younger audiences. Under 35s are the lowest-trusting age groups, 
with only a third (37%) of both 18–24s and 25–34s across all markets 
saying they trust most news most of the time, compared with nearly 
half of those 55 and older (47%). Young people also increasingly 
choose to avoid the news, with substantial rises in avoidance among 
social natives since we last asked this question in 2019. Across all 
markets, around four in ten under 35s often or sometimes avoid the 
news now, compared with a third (36%) of those 35 and older. 

Why is this happening? Most often, younger audiences (under 
35) say the news has a negative effect on their mood (34%) and, 
most recently, that there is too much news coverage of topics 
like politics or Coronavirus (39%). In particular, the longstanding 
criticism of the depressing or overwhelming nature of news 
persists among young people. For instance, in the UK, two-thirds 
(64%) of news avoiders under 35 say the news brings down their 
mood. Our qualitative research participants described forming 
habits of avoiding this negativity.

I tend to try and limit the amount of negative news I 
consume, especially first thing in the morning and last 
thing at night. I don’t want it to affect my day or make 
me worry. 
Female, 29, UK 

Depending on my mood, if I see news that I know is bad, is 
going to upset me, sometimes I leave it and read it later.
Male, 24, Brazil

Young people, particularly digital natives (27%), also at times avoid 
the news because they perceive it as biased or untrustworthy. As 
under 35s grew up in the digital age and have been socialised by 
older generations to be critical of the information they consume, 
our qualitative research suggests they take a particularly sceptical 
approach to all information and often question the ‘agenda’ of 
purveyors of news. In this sense, mainstream news brands are not 
inherently more valued for impartiality by some young people, and 
their wariness of bias at times pushes them away from consuming 
news altogether.

REUTERS INSTITUTE FOR THE STUDY OF JOURNALISM / FURTHER ANALYSIS GRAPHS

Graph 14

PROPORTION WHO SOMETIMES OR OFTEN ACTIVELY AVOID 
NEWS – BY AGE (2017–22) – ALL MARKETS

Q1di_2017. Do you find yourself actively trying to avoid news these days? Base: 18–24/25–34/35+ in all 
markets from 2017–22: 2017 = 7991/12,711/51,103, 2019 = 8272/13,361/54,116, 2022 = 11,304/16,862/65,266. 
Note: 36 markets in 2017, 38 markets in 2019, 46 markets in 2022.

0%

25%

50%
35+

25-34

18-24

202220192017

42%
40%

36%

25%

50%
35+

25-34

18-24

202220192017

18-24 25-34 35+

Reuters Institute for the Study of Journalism   |   Digital News Report 2022 43