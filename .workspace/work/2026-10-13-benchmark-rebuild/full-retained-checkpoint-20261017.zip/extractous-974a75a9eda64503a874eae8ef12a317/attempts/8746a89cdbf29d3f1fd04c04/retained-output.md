 15 

OECD ECONOMIC OUTLOOK, VOLUME 2025 ISSUE 2 © OECD 2025 
  

up about 15.5% of total world merchandise trade, with two-thirds of that originating in Asia, 3% in Europe 

and 2.5% in North America (WTO, 2025a). 

Figure 1.2. Trade growth has been resilient  

 
Note: The data correspond to quarterly trade of goods and services in volume (average of exports and imports). In Panel A, “Advanced 

economies” include OECD member countries other than Chile, Colombia, Costa Rica, Mexico, and Türkiye. “Other emerging Asia” includes 

Hong Kong (China), Indonesia, Malaysia, the Philippines, Singapore, Chinese Taipei, Thailand and Viet Nam. “Other emerging market 

economies” are all remaining emerging-market economies. In Panel B annual growth rates are shown for 2022-2024. “North America” includes 

Canada, Mexico and the United States. “Other AEs” in Panel B are the 33 advanced economies who are OECD members excluding “North 

America”, Ireland and Switzerland. “Other EM Asia” corresponds to “Other emerging Asia” in Panel A. “Other EMEs” are the remaining 

emerging-market economies not shown separately.   

Source: OECD Economic Outlook 118 database; and OECD calculations. 

StatLink 2 https://stat.link/dnwhs2 

Figure 1.3. Strong tech-related demand is supporting trade, particularly in Asia 

 
Note: Panel A is based on 2022 data. The green bar shows that almost 20% of OECD domestic value added of the manufacturing industry was consumed 
as a final good by the United States; the red bar shows that around 13% of G20 EME domestic value added of the information industry was consumed as a 
final good by China. South-East Asian economies include Hong Kong (China), Malaysia, the Philippines, Singapore, Chinese Taipei, Thailand and Viet Nam. 
The G20 emerging-market economies include Argentina, Brazil, India, Indonesia, Saudi Arabia and South Africa. Manufacturing includes all ISIC codes 10 to 
33; business services from 45 to 82; and the information industry shows ISIC codes 25 and 58 to 63. Panel B is based on values of exports. The Chinese 
Taipei tech indicator includes integrated circuits; dynamic random access memory integrated circuits; bare printed circuit boards; computer storage devices; 
and computer parts and accessories; the Korean tech exports indicator is based on semiconductors. 
Source: OECD Trade in Value Added (TiVA) 2025 edition; Korean Ministry of Trade, Industry and Resources; Chinese Taipei Ministry of Finance; 
and OECD calculations. 

StatLink 2 https://stat.link/lv53mq 

https://stat.link/dnwhs2
https://stat.link/lv53mq