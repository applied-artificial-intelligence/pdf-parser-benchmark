 75 

 

HEALTH AT A GLANCE: EUROPE 2024 © OECD/EUROPEAN UNION 2024 
  

Table 2.2. Overview of behavioural and environmental risk factors among older people compared to younger people 

  People aged 18-64 People aged 65 or over 

Behavioural risk factors  

Physical inactivity (% reporting to spend less than 150 minutes per week)  65% 78% 

Physical inactivity (% reporting to do physical activity less than once a week) 43% 52% 

Obesity rate 15%  18%  

Nutrition (% not eating any vegetable or fruit a day) 35% 25% 

Smoking rate (% smoking daily) 22% 9% 

Alcohol consumption (% reporting heavy drinking at least once a month) 21% 11% 

Environmental risk factors (mortality) 

Air pollution (% of deaths attributable to air pollution) 3% (people aged < 70) 4% (people aged 70+) 

Extreme temperature (% deaths attributable to heat or cold wave) 2% (people aged < 70) 4% (people aged 70+) 

Note: Data refer to 2019 for physical activity (duration), nutrition, smoking, alcohol consumption; 2021 for air pollution and extreme temperature;2022 for obesity and 

physical inactivity (frequency). 

Source: Eurostat (hlth_ehis_pe2e, ilc_hch07b, ilc_hch10, hlth_ehis_al3e, hlth_ehis_sk3e, hlth_ehis_fv3e) and IHME GBD for environmental risks. 

2.5.2. Physical activity decreases sharply with age, despite being crucial for mitigating the negative 
effects of ageing 

Physical activity is one of the most important activities that people can do to avoid or slowdown the negative consequences of 

ageing. It reduces the risks of many chronic conditions and falls, promotes mental health, and reduces cognitive functioning 

decline. WHO released in 2020 new guidelines on physical activity and sedentary behaviour for different age groups, including 

people aged over 65. These guidelines recommend at least 150-300 minutes of moderate intensity physical activity or 

75-150 minutes of vigorous intensity physical activity per week for older adults. As part of their weekly physical activity, it is also 

recommended that older adults do varied physical activity that emphasises functional balance at least three days per week. Older 

adults should also limit the amount of time spent being sedentary (WHO, 2020[14]). 

The share of people meeting the WHO recommendation on physical activity declines with age in all EU countries (Figure 2.17). On 

average across the EU, it drops from 35% among those aged 18 to 64 years to 22% among those aged over 65. In 11 EU countries, 

less than 10% of people aged over 65 meet these guidelines. Only in Norway, the Netherlands and Sweden did at least half of the 

older population meet the WHO recommendations. This highlights the need for policies to promote appropriate physical activity among 

older adults, but also among young adults, as the shares of people reporting sufficient physical activity are low across all age groups. 

Figure 2.17. Only 22% of people aged over 65 meet the WHO recommendation on minimum physical activity per week 

 
Note: The EU average is weighted. 

Source: Eurostat (hlth_ehis_pe2e) (the data refer to 2019). 

StatLink 2 https://stat.link/79bcw8 

0

10

20

30

40

50

60

70

80

From 18 to 64 years 65 years or over

% of people reporting to spend 150 minutes or more per week of physical activity

https://stat.link/79bcw8