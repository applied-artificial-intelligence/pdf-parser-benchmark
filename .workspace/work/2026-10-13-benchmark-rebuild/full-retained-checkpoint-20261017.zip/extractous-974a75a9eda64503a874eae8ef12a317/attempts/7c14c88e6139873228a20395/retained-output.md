Rajoo made a break-through 
and introduced its first plug 
assist, roll fed thermoforming 
m a c h i n e ,  c h r i s t e n e d  
DISPOCON

Launched the first ever sheet 
line for PET at Plastindia 2000

Launched As ia ' s  
highest output 3 
layer blown film line 
with stack die(UCD) 
during Plastindia

Developed a CE 
compliance high 
output sheet line for 
processing rPET with 
7 0 0  k g / h r  a n d 
e x p o r t e d  t o 
germany

Developed Asia's 
f i rst resin sack 
three layer blown 
f i l m  l i n e  a n d 
exported to Iran

Entered into technical 
col laborat ion with 
Commodore Inc. USA 
for manufacture of 
XPS sheet line and 
thermoformer.

D e v e l o p e d  a n d 
supplied Asia's first sheet 
l i n e  f o r  p h y s i c a l l y 
foamed PE sheets using 
ca rbon d iox ide  as 
blowing agent

1998 1999 2000 2001 2002 2004 2005 2006 20072003

Introduced world's 
highest output TQPP 
downward extrusion 
blown film line at 
P las t i v i s ion  2002,  
christened AQUAFLEX

Introduced India's 
first Electro-hydro-
pneumatic plug-
assist thermoformer 
w i t h  i n - m o u l d  
cutting for PP & PS 
containers

A w a r d e d  E x p o r t 
Excellence Certificate 
f rom Eng inee r i ng 
E x p o r t  P r o m o t i o n 
Council of India in 
recognition of highest 
exports during the 
year

Developed Asia's first 
seven layer blown 
film line and exported 
to Columbia

Developed Asia's first 
seven layer blown film 
l ine incorporat ing 
C o n i c a l  S p i r a l 
Stack(INCOIS) die

Developed Asia's first 
three layer wide width 
b l o w n  f i l m  l i n e 
incorporating die dia 
1200 mm and 4000 mm 
LFW w i th  max imum 
output is 1200 kg/hr

Asia's first 2 layer 
PPTQ film plant - 
150 kg/hour

Awarded with GUJARAT 
GAURAV AWARD for its 
outstanding contributions 
to the plastic industry

Developed Asia's first 
ever 2000mm width 
physically foam sheet 
line

5 layer stack 
die (UCD) with 
h o r i z o n t a l 
spirals - f i rst 
time in Asia & 
4th in the world

Secured ISO 9001 
certification 

T E C H N O L O G Y      L L C

8 th
38  ANNUAL REPORT : 2024-2025 www.rajoo.com

3
8
 Y

EA
R
S 

O
F 

LE
A

D
ER

SH
IP