P&C | AXA Group earnings deviation with different levels of Nat Cat cost1 in 2025

44

Average expected Nat Cat charges

2.5
2.7

2024 2025

Group underlying earnings deviation to average Nat Cat charges in 2025

In Euro billion

net of reinsurance, post-tax net of reinsurance, pre-tax

Median
(50th)

€+0.1bn

€+0.8bn
€+0.7bn

€+0.6bn

1/10y
(10th)

1/5y
(20th)

1/20y
(5th)

€-1.3bn

€-0.8bn

€-0.4n

1/10y
(90th)

1/5y
(80th)

1/20y
(95th)

More severe years
Negative deviation in ca. 40% of cases

1. Natural catastrophe cost defined as Aggregate Exceedance Probability (AEP) of all natural perils worldwide, net of tax and reinsurance. Deviation is compared to a normalized
level, which represents costs associated with natural catastrophes expected in an average year (ca. 4.5 points of estimated FY25 GEP, undiscounted and net of reinsurance).

Full Year 2024 Earnings 

Estimated
impact on GEP

ca.

4.5%
ca.

4.5%

Less severe years
Positive deviation in ca. 60% of cases