sigma 1/2023 Swiss Re Institute 27

Facts and figures

Number of catastrophic events: 285
Based on sigma criteria, there were 285 catastrophes worldwide in 2022, down from 
306 in 2021. There were 187 natural catastrophes, up from the 186 in 2021, and 98 
man-made disasters (down from 120 in 2021). 

Number of victims: more than 35 000
Worldwide, 35 157 people are believed to have died or gone missing in disaster events 
in 2022. Natural catastrophes claimed over 32 600 victims, and man-made disasters 
over 2500. 

Appendix 1: 2022 – the year in review

Figure 19  
Number of catastrophic events, 1970‒2022

Source: Swiss Re Institute

0

50

100

150

200

250

300

202120182015201220092006200320001997199419911988198519821979197619731970

Man-made disasters Natural catastrophes

Figure 20  
Number of victims, 1970‒2022

Note: Scale is logarithmic: the number of victims increases tenfold per band. Source: Swiss Re Institute

1 000

10 000

100 000

1 000 000

10 000 000

202120182015201220092006200320001997199419911988198519821979197619731970

Man-made disasters Natural catastrophes

1991: Cyclone Gorky, 
Bangladesh

1970:
Bangladesh Storm

2004: Indian Ocean
Earthquake and tsunami

2010: Haiti
Earthquake

2008: Cyclone Nargis,
Myanmar

2013: Typhoon
Haiyan, Philippines

2015: Earthquake
in Nepal

1976: Tangshan 
Earthquake, China

2022:
Heatwaves 
in Europe