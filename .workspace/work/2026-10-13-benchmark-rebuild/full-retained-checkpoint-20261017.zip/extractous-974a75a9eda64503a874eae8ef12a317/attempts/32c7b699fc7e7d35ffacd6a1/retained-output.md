37European Innovation Scoreboard 2025

Figure 12: Innovation performance of the EU27 Member States in the Digitalisation 
dimension

Note: All performance scores are relative to that of the EU in 2018 for each dimension. Horizontal coloured bars 

represent countries’ performance in 2025, while diamonds and vertical bars indicate their performance in 2018 

and 2024, respectively. The colours denote each country’s overall performance group based on the 2025 SII.