What Next for the Global Car Industry? Chapter 1: The global car industry 
An Energy Technology Perspectives Special Report in context 
 

22 

I E
A.

 C
C

 B
Y 

4.
0.

 

Figure 1.2 Sales share of SUVs and pick-up trucks by market, 2010-2024 

  
 IEA. CC BY 4.0. 

Notes: Sales share includes segments SUV-A to SUV-E and pick-up trucks. 
Source: IEA analysis based on Marklines.  
 

Beyond consumer preferences for larger cars, regulatory frameworks have also 
contributed to SUV sales growth. For example, the US Corporate Average Fuel 
Economy (CAFE) Standards set separate requirements for passenger cars and 
light trucks based on the footprint of the vehicle. Under this framework, SUVs are 
classified as light trucks, and the standards for model years 2012-2016 required 
greater efficiency improvements for passenger cars than for light trucks. Similarly, 
EU CO2 standards for cars also included emissions target adjustments for 
carmakers selling heavier-than-average cars until 2025. Differentiated emission 
targets and the higher profit margins on larger models help explain why 
automakers have increasingly chosen to produce bigger cars. However, as the 
EU CO2 standards enter the new enforcement period for 2025-2029, specific 
manufacturer CO2 targets have been revised based on the latest market data. As 
a result, previous CO2 emission allowances granted to manufacturers of heavier-
than-average cars have been cancelled. See the box Cars are getting heavier 
despite material substitution efforts below for more on the impact of car size 
increases.  

The share of global car manufacturing located in China 
has grown substantially  

The car market is highly globalised: in most countries, consumers can buy cars 
from all major original equipment manufacturers (OEMs), even though different 
carmakers have typically focused on different markets and powertrains. Nearly all 
the cars sold worldwide today are manufactured by carmakers with headquarters 
in either the European Union, the United States, Japan, China or Korea, and are 
manufactured in those countries or regions. In 2008, the majority of global car 
production took place in Europe (25% of global car output), North America (25%), 

0%

20%

40%

60%

80%

2010 2012 2014 2016 2018 2020 2022 2024

Global China
North America Other advanced economies
Europe Other emerging and developing economies

https://www.govinfo.gov/content/pkg/FR-2010-05-07/pdf/2010-8159.pdf
https://theicct.org/sites/default/files/publications/EU-LCV-CO2-2030_ICCTupdate_201901.pdf
https://publications.jrc.ec.europa.eu/repository/handle/JRC133502