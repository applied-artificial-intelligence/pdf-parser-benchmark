MANAGEMENT’S DISCUSSION AND ANALYSIS

Voice-over-cable telephony services are provided over a dedicated
DOCSIS network. Our offerings ensure a high quality of service by
including network redundancy as well as network and customer
premise backup powering. Our cable telephony service includes a rich
set of features, such as TV Call Display, three-way calling and Home &
Away™ voicemail that allows customers to be notified of and listen to
their voicemail over MMS or the Web. In addition, we offer a wireless
alternative to a fixed-line service.

COMPETITION
Cable television competes:
• increasingly with alternative, Canadian multi-channel Broadcasting

Distribution Undertakings (BDUs), including Bell TV, Shaw Direct,
satellite TV services, and Internet Protocol television

• with over-the-air local and regional broadcast television signals
received directly through antennas, and the illegal reception of
US direct broadcast satellite services

• with television shows and movies streaming over the Internet
through providers like Netflix and Apple TV.

Cable Internet competes with other ISPs that offer residential and
commercial dial-up and high-speed Internet access services. Rogers
Hi-Speed Internet services compete directly with:
• Bell’s DSL Internet service in Ontario
• Bell Aliant’s DSL/fibre and FTTH Internet services in New Brunswick

and Newfoundland
• various resellers using wholesale telco DSL and cable Third Party

Internet Access (TPIA) services in local markets.

Cable telephony competes with:
• Bell’s wireline phone service in Ontario
• Bell Aliant’s wireline phone service in New Brunswick and

Newfoundland and Labrador
• ILEC local loop resellers (such as Primus) as well as VoIP service

providers (such as Vonage and Skype) riding over the Internet access
services of ISPs

• Wireless home phone products.

ACQUISITION
In January 2013, we announced a multi-part strategic transaction with
Shaw to acquire Mountain Cable (Shaw’s cable system in Hamilton,
Ontario), and to secure an option to purchase Shaw’s Advanced
Wireless Services spectrum holdings in 2014. As part of the agreement,
we sold our one-third equity interest in the TVtropolis specialty TV
channel to Shaw. Mountain Cable provides cable television, Internet
and telephony services to an area covering approximately 59,000
homes in and around Hamilton, Ontario. On May 1, 2013, we closed on
a portion of the multi-part agreement with Shaw to buy 100% of
Mountain Cable, and paid $398 million, according to the terms of the
agreement.

CABLE FINANCIAL RESULTS

(In millions of dollars, except percentages)
Years ended December 31

20131 2012 % Chg

Operating revenue

Television $ 1,809 $ 1,868 (3)

Internet 1,159 998 16

Phone 498 477 4

Service revenue 3,466 3,343 4

Equipment sales 9 15 (40)

Operating revenue – Cable 3,475 3,358 3

Operating expenses

Cost of equipment (6) (20) (70)

Other operating expenses (1,751) (1,733) 1

(1,757) (1,753) –

Adjusted operating profit – Cable $ 1,718 $ 1,605 7

Adjusted operating profit margin 49.4% 47.8%
Additions to property, plant and

equipment 1,105 832 33

1 Results of operations include Mountain Cable’s operating results as of May 1, 2013
(the date of acquisition).

CABLE SUBSCRIBER RESULTS 1

Years ended December 31
(Subscriber statistics in thousands) 2013 2012 Chg

Cable homes passed 3,978 3,810 168
Television

Net losses (127) (83) (44)

Total television subscribers 2 2,127 2,214 (87)
Internet

Net additions 63 73 (10)

Total Internet subscribers 2 1,961 1,864 97
Phone

Net additions 42 23 19

Total phone subscribers 2 1,153 1,074 79
Total service units 2,3

Net additions (losses) (22) 13 (35)

Total service units 5,241 5,152 89

1 Subscriber count is a key performance indicator. See “Key Performance Indicators”.
2 On May 1, 2013, we acquired 40,000 television subscribers, 38,000 digital cable

households, 34,000 cable high-speed Internet subscribers and 37,000 cable telephony
lines from our acquisition of Mountain Cable. These subscribers are not included in
net additions, but do appear in the ending total balance for December 31, 2013. The
acquisition also increased homes passed by 59,000.

3 Includes television, Internet and phone subscribers.

(IN THOUSANDS)
CABLE SUBSCRIBER BREAKDOWN 

2013

2012

2011

1,153 1,961

1,074 1,864

1,052 1,793

2,127

2,214

2,297

InternetPhone Television

42 ROGERS COMMUNICATIONS INC. 2013 ANNUAL REPORT