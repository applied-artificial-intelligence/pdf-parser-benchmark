 129 

 

DO ADULTS HAVE THE SKILLS THEY NEED TO THRIVE IN A CHANGING WORLD? © OECD 2024 
  

across time due to changing patterns of immigration, including return migration in the country of origin. In 

any event, the skills of long-term migrants are more strongly influenced by conditions in the host country. 

Changes in their skills over time can therefore offer insights into the effectiveness of the host country’s 

policies in fostering integration. 

Figure 3.15. Change in literacy proficiency between cycles, by immigrant background  

Adjusted and unadjusted difference in mean literacy scores between cycles (Cycle 2 minus Cycle 1) 

 

Note: Adults aged 16-65; does not include adults who in Cycle 2 were only administered the doorstep interview due to a language barrier, to 

maximise the comparability across cycles (see Box 1.1 in Chapter 1 and Box 3.2). Unadjusted differences are the differences between the 

averages in each cycle. Adjusted differences are based on a method analogous to post-stratification that reweights the samples in Cycle 2 so 

that the groups by immigrant background have the same demographic characteristics as in Cycle 1 (see Note 1). Demographic characteristics 

considered are: age and gender. Darker colours denote differences that are statistically significant at the 5% level. 

Japan and Poland are excluded due to small numbers of foreign-born adults. 

Countries and economies are ranked in descending order of the unadjusted change in literacy proficiency among foreign-born adults of foreign-

born parents. 

Source: OECD (2018[4]; 2015[5]; 2012[6]), Survey of Adult Skills (PIAAC) databases, http://www.oecd.org/skills/piaac/publicdataandanalysis/ 

(accessed on 23 September 2024); Table A.3.14 (L) in Annex A. 

F
in
la
n
d

 
e
nm

ar
k

S
w
e
de

n

C
an

ad
a

E
st
o
ni
a

It
a
ly

 
or
w
ay

E
ng

la
nd

 (
U
 
 

C
 e

ch
ia

S
p
ai
n

Ir
el
an

d

 
et
he

rl
a
nd

s

F
le
m
is
h 
R
e
gi
o
n 
( 

E
 

F
ra
n
ce

U
ni
te
d 
S
ta
te
s

G
er
m
a
ny

A
us

tr
ia

S
lo
 a

k 
R
ep

ub
lic

 
or
e
a

 i
th
ua

n
ia

Is
ra
e
l

C
hi
le

S
in
g
a
po

re

 
ew

  
ea

la
n
d

H
un

g
ar
y

F
in
la
n
d

 
e
nm

a
rk

S
w
ed

e
n

C
an

ad
a

E
st
o
ni
a

It
al
y

 
o
rw

ay

E
ng

la
n
d 
(U

 
 

C
 e

ch
ia

S
p
ai
n

Ir
el
an

d

 
et
he

rl
a
nd

s

F
le
m
is
h 
R
e
gi
o
n 
( 

E
 

F
ra
n
ce

U
ni
te
d 
S
ta
te
s

G
er
m
a
ny

A
us

tr
ia

S
lo
 a

k 
R
ep

ub
lic

 
or
ea

 i
th
ua

n
ia

Is
ra
el

C
hi
le

S
in
g
a
po

re

 
ew

  
ea

la
nd

H
un

g
a
ry

Ad ustedUnad u sted

30

20

10

0

 10

 20

 30

  0

30

20

10

0

 10

 20

 30

  0

   Round, Cycle 1:

http://www.oecd.org/skills/piaac/publicdataandanalysis/