 117 

OECD EMPLOYMENT OUTLOOK 2024 © OECD 2024 
  

Annex 2.C. Additional figures 

Annex Figure 2.C.1. One in eight green-driven occupations is concentrated in GHG-intensive 
industries 

Percentage of total employment, average 2015-19 

 

Note: Data refer to the average for 2015-19, except for Canada: 2017-19 and New Zealand: 2018. OECD: Unweighted average of countries 

shown. GHG: greenhouse gases.  

Source: Secretariat’s estimates based on version 24.1 of the O*NET database and the following country-specific sources: Australian Labour 

Force Survey; Canadian Labour Force Survey; Japanese Labour Force Survey; United States: Current Population Survey; All other countries: 

EU Labour Force Survey. 

StatLink 2 https://stat.link/urlw1n 

0

5

10

15

20

25

30

%
Mixed green-driven and GHG-intensive occupations Residual green-driven occupations

https://stat.link/urlw1n