MATERIALS

  CG-AA-430a.2

Our materials goals focus on reducing the 
environmental impacts of high-volume or high-
impact materials in our consumer products 
business, while also helping our manufacturing 
network become cleaner and safer. Collaboration 
with suppliers is underway to test and scale 
innovative material solutions, focusing on 
enabling commercially viable advancements and 
bringing these changes to life.

A key component of our work toward these goals 
is the use of a Disney-approved manufacturing 
certification or assessment, such as the Higg 
FEM. The Higg FEM assessment serves as a 
foundational tool for understanding 
environmental impacts within facilities that 
manufacture Disney-branded products. In 
calendar 2024, more than 70% of facilities 
utilized by vendors† completed the Higg FEM.

In 2024, we continued our efforts to source 
sustainable materials and recycled plastics for 
our products and packaging. We launched 
Create Your Own plush headbands, in which all 
plush attachments contain 100% recycled 
content stuffing. We followed a similar approach 
for three Tianaʼs Bayou Adventure Critters plush 
toys and nine Inside Out 2 plush toys, which all 
contain 100% recycled content stuffing. 
Combined, these efforts represent 6.8 metric 
tons of recycled content and 8.8 metric tons of 
potential carbon dioxide (CO2) emissions avoided. 

In order to assess environmentally-preferred 
choices made at the product level, we are 
currently investing in programs and software that 
can quantitatively track the progress of our 
consumer products business against the 
companyʼs environmental goals. These systems 
are expected to be rolled out by the end of 
calendar 2025.  ‡ §

SUSTAINABLE DESIGN 

      

Disneyʼs sustainable design strategy enables us 
to plan, build, and operate our facilities while 
minimizing emissions, water, and waste. As our 
businesses grow and new assets are built, we 
follow a set of internal Sustainable Design 
Standards that are aligned with our 2030 goals.

We worked to reduce our impacts on the 
environment throughout the design, 
construction, and operation of Disney Lookout 
Cay at Lighthouse Point, Disney Cruise Line's 
newest island destination in The Bahamas, which 
welcomed guests for the first time in 2024. For 
example, up to 90% of the expected electricity 
demand for the island destination has been 
designed to be met by on-site solar panels, 
equipped with battery storage. The site uses a 
reclaimed water system for irrigation, washdown, 
and flushing within its facilities. and features an 
innovative, open-trestle pier which extends to 
deep waters and prevented the dredging of a 
ship channel.

Our new state-of-the-art complex in New York 
City (shown below), which opened in fiscal 
2024, has been designed to meet and exceed 
Disney's 2030 Environmental Goals. The 
building is on track to receive two LEED 
Platinum certifications in 2025—one for New 
Construction Core and Shell, and one for Interior
—the highest level of certification from the U.S. 
Green Building Council. 

Newly constructed Disney Vacation Club 
cabins at Disneyʼs Fort Wilderness Resort in 
Walt Disney World Resort, were designed with 
sustainability in mind and opened to guests 
in summer 2024. The cabins were built on 
the existing land footprint with original cabin 
materials salvaged for reuse or recycling. 
Our pre-fabrication strategy minimized waste 
during construction. The new cabins will be 
60% more efficient than the baseline design. 
They incorporate a heat reflective roof, high-
efficiency HVAC units, LED lighting, and include 
electric vehicle charging. Landscaping at the 
new cabins uses native vegetation and does not 
require irrigation. 

Table of 
Contents

Introduction & 
Our Approach

Governance

People

Environment

Emissions

Water

Waste

Materials

Sustainable Design

Nature

Data & 
Frameworks

25

† Only includes facilities utilized by in-scope vendors to manufacture Disney-branded products for U.S. Disney stores, U.S. Theme Park Merchandise, and Disneystore.com. The Higg Index is a suite of tools for the measurement of value chain sustainability. The Higg Facility Environmental Module (Higg FEM) tool 
assesses environmental impacts of product manufacturing at facilities. 

‡ See footnote 6 on p. 34.
§ Zero waste to landfill is defined as 90% operational waste diversion, including thermal waste-to-energy for Walt Disney World Resort, Disneyland Resort, Disneyland Paris, and Disney Cruise Line.

2030 Materials Goals for
Disney-Branded Products

• Paper will contain 100% recycled content 
or lower impact alternatives for products 
and packaging

• Wood will contain 100% recycled content 
or lower impact alternatives for products 
and packaging

• Palm oils used as an ingredient in Disney-
branded products will be from certified sources 

• Textiles used in Disney-branded products 
will be from recycled content or lower 
impact alternatives

• Plastic in products and packaging will 
contain at least 30% recycled content or 
lower impact alternatives

• Packaging will be designed for reuse, 
recycling, or composting 

• Facilities that manufacture Disney-branded 
products will maintain a Higg Facility 
Environmental Module (FEM) or Disney-
approved manufacturing assessment

2030 Sustainable 
Design Goals

• Design new projects to achieve near net zero 
GHG emissions,‡ maximize water efficiency, 
and support zero waste operations§

• Achieve 90% diversion of construction waste 
across new projects in the U.S. and Europe