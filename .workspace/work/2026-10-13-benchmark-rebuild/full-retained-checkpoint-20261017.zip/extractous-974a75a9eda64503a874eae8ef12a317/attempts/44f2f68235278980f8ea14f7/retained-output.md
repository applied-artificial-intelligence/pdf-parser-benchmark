Task 1 Strategic PV Analysis and Outreach – 2025 Snapshot of Global PV Markets    

 

11 

 

(Brazil, Germany, Türkiye, Italy and France for example), the sheer volume that can be 

installed in individual utility scale systems is leading to this segment outpacing distributed 

growth around the world. Newer applications such as floating PV and linear PV are more often 

within the centralised market, whilst agriPV and parking canopies exist across both the 

centralised and decentralised segments. The increase in deployment of prosumer and self-

consumption remuneration models tends to be limited to smaller capacity systems, with a 

larger number of unit systems but much lower capacities. 

2 CUMULATIVE INSTALLED CAPACITY IN THE WORLD 

In 2024, the global cumulative installed capacity reached 2.25 TW, as shown in Figure 5. 

It took more than 40 years to reach a cumulative capacity of 1.18 TW (in 2022), but just 2 

years to double this. China now has nearly 50% of cumulative worldwide capacity. Growth in 

cumulative capacity remained over 35% — above average for the past 10 years. Within the 

Top Ten of total cumulative installed capacities (see Table 1 above), where last year the 

Chinese cumulative capacity was just over double that of Europe, this year it is triple — the 

faster growth rates in annual capacity leaving the EU and other countries lagging. There is still 

a long gap before Japan, who slipping to 5th place and has a slowing market, will be overtaken 

in cumulative capacity— the next markets would have to improve on this year’s annual 

volumes over at least 5 years to catch up the more than 40 GW gap. 

As India and the UK join the IEA PVPS programme in 2025, the cumulative volume of 

installations outside of IEA PVPS will become marginal.  

0

100

200

300

400

500

600

2014 2015 2016 2017 2018 2019 2020 2021 2022 2023 2024

GWp FIGURE 4: SEGMENTATION OF PV INSTALLATION 2014-2024

ROOFTOP UTILITY SCALE

5Source: IEA PVPS, Becquerel Institute