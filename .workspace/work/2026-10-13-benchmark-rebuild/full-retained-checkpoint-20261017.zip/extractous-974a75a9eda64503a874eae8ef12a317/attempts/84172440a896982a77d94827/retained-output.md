Vehicle Deliveries 
(millions of units)

K E Y M E T R I C S Q U A R T E R L Y
(Unaudited)

Operating Cash Flow ($B)
Free Cash Flow ($B)

Net Income ($B)
Adjusted EBITDA ($B)

26

0.0

0.1

0.2

0.3

0.4

0.5

1Q
-2

02
2

2Q
-2

02
2

3Q
-2

02
2

4Q
-2

02
2

1Q
-2

02
3

2Q
-2

02
3

3Q
-2

02
3

4Q
-2

02
3

1Q
-2

02
4

2Q
-2

02
4

3Q
-2

02
4

4Q
-2

02
4

-3

-2

-1

0

1

2

3

4

5

6

7

1Q
-2

02
2

2Q
-2

02
2

3Q
-2

02
2

4Q
-2

02
2

1Q
-2

02
3

2Q
-2

02
3

3Q
-2

02
3

4Q
-2

02
3

1Q
-2

02
4

2Q
-2

02
4

3Q
-2

02
4

4Q
-2

02
4

0

1

2

3

4

5

6

7

8

1Q
-2

02
2

2Q
-2

02
2

3Q
-2

02
2

4Q
-2

02
2

1Q
-2

02
3

2Q
-2

02
3

3Q
-2

02
3

4Q
-2

02
3

1Q
-2

02
4

2Q
-2

02
4

3Q
-2

02
4

4Q
-2

02
4