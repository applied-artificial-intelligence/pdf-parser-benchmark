The BEAT | June 2025

Local Sovereign Currency Yields

ALTERNATIVES

Past performance is no guarantee of future results. 
It is not possible to invest directly in an index. *German Rate. Source: Bloomberg as 5/31/25. Data provided is for informational use only. See end of report for important additional 
information.

46

Developed Market Local Interest Rates % (1 Year) Emerging Market Local Interest Rates % (1 Year)

1.05

0.36

3.29

3.42

3.34

4.56

5.02

4.29

4.78

4.33

5.11

-0.27

0.74

1.56

1.76

1.91

2.56

3.17

3.40

3.83

4.00

4.12

-5.00 0.00 5.00 10.00 15.00

Swiss Franc (CHF)

Japanese Yen (JPY)

Danish Krone (DKK)

Euro (EUR) *

Swedish Krona (SEK)

Canadian Dollar (CAD)

New Zealand Dollar (NZD)

Australian Dollar (AUD)

British Pound (GBP)

Norwegian Krone (NOK)

U.S. Dollar (USD)

Current 1 Yr Prior

2.36

3.56

5.38

4.85

4.86

6.02

6.46

6.65

9.18

11.34

9.62

10.49

20.70

40.18

1.54

2.86

3.95

4.26

5.03

5.62

6.03

6.17

7.91

8.27

8.71

14.64

22.12

42.67

0.00 10.00 20.00 30.00 40.00 50.00

Thai Baht (THB)

Malaysian Ringgit (MYR)

Peruvian New Sol (PEN)

Polish Zloty (PLN)

Chilean Peso (CLP)

Philippine Peso (PHP)

Indonesian Rupiah (IDR)

Hungarian Forint (HUF)

South African Rand (ZAR)

Mexican Peso (MXN)

Colombian Peso (COP)

Brazilian Real (BRL)

Nigerian Naira (NGN)

Turkish New Lira (TRY)

Current 1 Yr Prior