2024 UN E-GovErNmENt SUrvEy

52

C
h

ap
ter 2

2.5.2 OSI subindices 

The subsections above have highlighted areas that require further attention if countries wish to 
strengthen overall e-government development (as reflected in their respective EGDI levels). In 
cases where improvements in online services provision (OSI values) are necessary, it is important to 
understand which specific aspects of this component require attention. The main Survey findings for 
each of the five OSI subindices are presented below.

As shown in figure 2.9, the institutional framework (IF) is better developed than other aspects of 
online services provision in all regions. content provision (cP) has the next highest subindex value, 
followed by services provision (SP), technical characteristics (TEc) and e-participation (EPI). At the 
regional level, Europe is leading in terms of average OSI and subindex values, followed by Asia, the 
Americas, Oceania, and Africa – the one exception being that the technical aspects of the OSI are 
slightly better developed in Africa than in Oceania. 

Figure 2.9 Values for OSI subindices (IF, CP, SP, TEC and EPI) at the regional and global levels, 2024

Legend:

Linear (global OSI average)

Linear (average OSI for Africa)

Linear (average OSI for Asia)

Linear (average OSI for Europe)

Linear (average OSI for Oaceania)

193 UN Member States

Africa

Asia

Europe

Oceania

Linear (average OSI for the Americas)Americas

193 UN Member States

Americas

Africa

Asia

Europe

Oceania

Very high EGDI
High EGDI
Middle EGDI
Low EGDI

0.4919

0.5363

0.5606

0.6644

0.8079

0.5754

0.00 0.25 0.50 0.75 1.00

EPI

TEC

SP

CP

IF

193 UN Member States Linear (global average OSI)

0.4736

0.5411

0.5797

0.6730

0.8171

0.5797

0.5754

0.00 0.25 0.50 0.75 1.00

EPI

TEC

SP

CP

IF

Americas

0.6642

0.7263

0.7688

0.8501

0.9395

0.78360.5754

0.00 0.25 0.50 0.75 1.00

EPI

TEC

SP

CP

IF

Europe

0.3001

0.4167

0.3583

0.4815

0.6852

0.3862 0.5754

0.00 0.25 0.50 0.75 1.00

EPI

TEC

SP

CP

IF

Africa

0.5462

0.5984

0.6311

0.7471

0.8562

0.6401

0.5754

0.00 0.25 0.50 0.75 1.00

EPI

TEC

SP

CP

IF

Asia

0.3748

0.3839

0.4174

0.5000

0.6914

0.4378 0.5754

0.00 0.25 0.50 0.75 1.00

EPI

TEC

SP

CP

IF

Oceania

Legend:

Linear (global OSI average)

Linear (average OSI for Africa)

Linear (average OSI for Asia)

Linear (average OSI for Europe)

Linear (average OSI for Oaceania)

193 UN Member States

Africa

Asia

Europe

Oceania

Linear (average OSI for the Americas)Americas

193 UN Member States

Americas

Africa

Asia

Europe

Oceania

Very high EGDI
High EGDI
Middle EGDI
Low EGDI

0.4919

0.5363

0.5606

0.6644

0.8079

0.5754

0.00 0.25 0.50 0.75 1.00

EPI

TEC

SP

CP

IF

193 UN Member States Linear (global average OSI)

0.4736

0.5411

0.5797

0.6730

0.8171

0.5797

0.5754

0.00 0.25 0.50 0.75 1.00

EPI

TEC

SP

CP

IF

Americas

0.6642

0.7263

0.7688

0.8501

0.9395

0.78360.5754

0.00 0.25 0.50 0.75 1.00

EPI

TEC

SP

CP

IF

Europe

0.3001

0.4167

0.3583

0.4815

0.6852

0.3862 0.5754

0.00 0.25 0.50 0.75 1.00

EPI

TEC

SP

CP

IF

Africa

0.5462

0.5984

0.6311

0.7471

0.8562

0.6401

0.5754

0.00 0.25 0.50 0.75 1.00

EPI

TEC

SP

CP

IF

Asia

0.3748

0.3839

0.4174

0.5000

0.6914

0.4378 0.5754

0.00 0.25 0.50 0.75 1.00

EPI

TEC

SP

CP

IF

Oceania

Source: 2024 United Nations E-Government Survey.

Legend:

Linear (global OSI average)

Linear (average OSI for Africa)

Linear (average OSI for Asia)

Linear (average OSI for Europe)

Linear (average OSI for Oaceania)

193 UN Member States

Africa

Asia

Europe

Oceania

Linear (average OSI for the Americas)Americas

193 UN Member States

Americas

Africa

Asia

Europe

Oceania

Very high EGDI
High EGDI
Middle EGDI
Low EGDI

0.4919

0.5363

0.5606

0.6644

0.8079

0.5754

0.00 0.25 0.50 0.75 1.00

EPI

TEC

SP

CP

IF

193 UN Member States Linear (global average OSI)

0.4736

0.5411

0.5797

0.6730

0.8171

0.5797

0.5754

0.00 0.25 0.50 0.75 1.00

EPI

TEC

SP

CP

IF

Americas

0.6642

0.7263

0.7688

0.8501

0.9395

0.78360.5754

0.00 0.25 0.50 0.75 1.00

EPI

TEC

SP

CP

IF

Europe

0.3001

0.4167

0.3583

0.4815

0.6852

0.3862 0.5754

0.00 0.25 0.50 0.75 1.00

EPI

TEC

SP

CP

IF

Africa

0.5462

0.5984

0.6311

0.7471

0.8562

0.6401

0.5754

0.00 0.25 0.50 0.75 1.00

EPI

TEC

SP

CP

IF

Asia

0.3748

0.3839

0.4174

0.5000

0.6914

0.4378 0.5754

0.00 0.25 0.50 0.75 1.00

EPI

TEC

SP

CP

IF

Oceania

Legend:

Linear (global OSI average)

Linear (average OSI for Africa)

Linear (average OSI for Asia)

Linear (average OSI for Europe)

Linear (average OSI for Oaceania)

193 UN Member States

Africa

Asia

Europe

Oceania

Linear (average OSI for the Americas)Americas

193 UN Member States

Americas

Africa

Asia

Europe

Oceania

Very high EGDI
High EGDI
Middle EGDI
Low EGDI

0.4919

0.5363

0.5606

0.6644

0.8079

0.5754

0.00 0.25 0.50 0.75 1.00

EPI

TEC

SP

CP

IF

193 UN Member States Linear (global average OSI)

0.4736

0.5411

0.5797

0.6730

0.8171

0.5797

0.5754

0.00 0.25 0.50 0.75 1.00

EPI

TEC

SP

CP

IF

Americas

0.6642

0.7263

0.7688

0.8501

0.9395

0.78360.5754

0.00 0.25 0.50 0.75 1.00

EPI

TEC

SP

CP

IF

Europe

0.3001

0.4167

0.3583

0.4815

0.6852

0.3862 0.5754

0.00 0.25 0.50 0.75 1.00

EPI

TEC

SP

CP

IF

Africa

0.5462

0.5984

0.6311

0.7471

0.8562

0.6401

0.5754

0.00 0.25 0.50 0.75 1.00

EPI

TEC

SP

CP

IF

Asia

0.3748

0.3839

0.4174

0.5000

0.6914

0.4378 0.5754

0.00 0.25 0.50 0.75 1.00

EPI

TEC

SP

CP

IF

Oceania

Legend:

Linear (global OSI average)

Linear (average OSI for Africa)

Linear (average OSI for Asia)

Linear (average OSI for Europe)

Linear (average OSI for Oaceania)

193 UN Member States

Africa

Asia

Europe

Oceania

Linear (average OSI for the Americas)Americas

193 UN Member States

Americas

Africa

Asia

Europe

Oceania

Very high EGDI
High EGDI
Middle EGDI
Low EGDI

0.4919

0.5363

0.5606

0.6644

0.8079

0.5754

0.00 0.25 0.50 0.75 1.00

EPI

TEC

SP

CP

IF

193 UN Member States Linear (global average OSI)

0.4736

0.5411

0.5797

0.6730

0.8171

0.5797

0.5754

0.00 0.25 0.50 0.75 1.00

EPI

TEC

SP

CP

IF

Americas

0.6642

0.7263

0.7688

0.8501

0.9395

0.78360.5754

0.00 0.25 0.50 0.75 1.00

EPI

TEC

SP

CP

IF

Europe

0.3001

0.4167

0.3583

0.4815

0.6852

0.3862 0.5754

0.00 0.25 0.50 0.75 1.00

EPI

TEC

SP

CP

IF

Africa

0.5462

0.5984

0.6311

0.7471

0.8562

0.6401

0.5754

0.00 0.25 0.50 0.75 1.00

EPI

TEC

SP

CP

IF

Asia

0.3748

0.3839

0.4174

0.5000

0.6914

0.4378 0.5754

0.00 0.25 0.50 0.75 1.00

EPI

TEC

SP

CP

IF

Oceania

Legend:

Linear (global OSI average)

Linear (average OSI for Africa)

Linear (average OSI for Asia)

Linear (average OSI for Europe)

Linear (average OSI for Oaceania)

193 UN Member States

Africa

Asia

Europe

Oceania

Linear (average OSI for the Americas)Americas

193 UN Member States

Americas

Africa

Asia

Europe

Oceania

Very high EGDI
High EGDI
Middle EGDI
Low EGDI

0.4919

0.5363

0.5606

0.6644

0.8079

0.5754

0.00 0.25 0.50 0.75 1.00

EPI

TEC

SP

CP

IF

193 UN Member States Linear (global average OSI)

0.4736

0.5411

0.5797

0.6730

0.8171

0.5797

0.5754

0.00 0.25 0.50 0.75 1.00

EPI

TEC

SP

CP

IF

Americas

0.6642

0.7263

0.7688

0.8501

0.9395

0.78360.5754

0.00 0.25 0.50 0.75 1.00

EPI

TEC

SP

CP

IF

Europe

0.3001

0.4167

0.3583

0.4815

0.6852

0.3862 0.5754

0.00 0.25 0.50 0.75 1.00

EPI

TEC

SP

CP

IF

Africa

0.5462

0.5984

0.6311

0.7471

0.8562

0.6401

0.5754

0.00 0.25 0.50 0.75 1.00

EPI

TEC

SP

CP

IF

Asia

0.3748

0.3839

0.4174

0.5000

0.6914

0.4378 0.5754

0.00 0.25 0.50 0.75 1.00

EPI

TEC

SP

CP

IF

Oceania

Legend:

Linear (global OSI average)

Linear (average OSI for Africa)

Linear (average OSI for Asia)

Linear (average OSI for Europe)

Linear (average OSI for Oaceania)

193 UN Member States

Africa

Asia

Europe

Oceania

Linear (average OSI for the Americas)Americas

193 UN Member States

Americas

Africa

Asia

Europe

Oceania

Very high EGDI
High EGDI
Middle EGDI
Low EGDI

0.4919

0.5363

0.5606

0.6644

0.8079

0.5754

0.00 0.25 0.50 0.75 1.00

EPI

TEC

SP

CP

IF

193 UN Member States Linear (global average OSI)

0.4736

0.5411

0.5797

0.6730

0.8171

0.5797

0.5754

0.00 0.25 0.50 0.75 1.00

EPI

TEC

SP

CP

IF

Americas

0.6642

0.7263

0.7688

0.8501

0.9395

0.78360.5754

0.00 0.25 0.50 0.75 1.00

EPI

TEC

SP

CP

IF

Europe

0.3001

0.4167

0.3583

0.4815

0.6852

0.3862 0.5754

0.00 0.25 0.50 0.75 1.00

EPI

TEC

SP

CP

IF

Africa

0.5462

0.5984

0.6311

0.7471

0.8562

0.6401

0.5754

0.00 0.25 0.50 0.75 1.00

EPI

TEC

SP

CP

IF

Asia

0.3748

0.3839

0.4174

0.5000

0.6914

0.4378 0.5754

0.00 0.25 0.50 0.75 1.00

EPI

TEC

SP

CP

IF

Oceania

Legend:

Linear (global OSI average)

Linear (average OSI for Africa)

Linear (average OSI for Asia)

Linear (average OSI for Europe)

Linear (average OSI for Oaceania)

193 UN Member States

Africa

Asia

Europe

Oceania

Linear (average OSI for the Americas)Americas

193 UN Member States

Americas

Africa

Asia

Europe

Oceania

Very high EGDI
High EGDI
Middle EGDI
Low EGDI

0.4919

0.5363

0.5606

0.6644

0.8079

0.5754

0.00 0.25 0.50 0.75 1.00

EPI

TEC

SP

CP

IF

193 UN Member States Linear (global average OSI)

0.4736

0.5411

0.5797

0.6730

0.8171

0.5797

0.5754

0.00 0.25 0.50 0.75 1.00

EPI

TEC

SP

CP

IF

Americas

0.6642

0.7263

0.7688

0.8501

0.9395

0.78360.5754

0.00 0.25 0.50 0.75 1.00

EPI

TEC

SP

CP

IF

Europe

0.3001

0.4167

0.3583

0.4815

0.6852

0.3862 0.5754

0.00 0.25 0.50 0.75 1.00

EPI

TEC

SP

CP

IF

Africa

0.5462

0.5984

0.6311

0.7471

0.8562

0.6401

0.5754

0.00 0.25 0.50 0.75 1.00

EPI

TEC

SP

CP

IF

Asia

0.3748

0.3839

0.4174

0.5000

0.6914

0.4378 0.5754

0.00 0.25 0.50 0.75 1.00

EPI

TEC

SP

CP

IF

Oceania