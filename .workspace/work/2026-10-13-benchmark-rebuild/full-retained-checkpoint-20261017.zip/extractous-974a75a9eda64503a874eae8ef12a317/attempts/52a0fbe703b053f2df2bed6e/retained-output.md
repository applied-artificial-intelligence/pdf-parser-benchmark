Unlocking Multimodal Document Intelligence:
From Current Triumphs to Future Frontiers of Visual Document Retrieval

Yibo Yan1,2,3, Jiahao Huo1,2,4, Guanbo Feng1, Mingdong Ou2,*, Yi Cao2,
Xin Zou1,3, Shuliang Liu1,3, Yuanhuiyi Lyu1,3, Yu Huang1,2, Jungang Li1, Kening Zheng4,

Xu Zheng1,3, Philip S. Yu4, James Kwok3, Xuming Hu1,3,†

1Hong Kong University of Science and Technology (Guangzhou), 2Alibaba Cloud Computing,
3Hong Kong University of Science and Technology, 4University of Illinois Chicago

yanyibo70@gmail.com, xuminghu@hkust-gz.edu.cn

Abstract
With the rapid proliferation of multimodal in-
formation, Visual Document Retrieval (VDR)
has emerged as a critical frontier in bridging
the gap between unstructured visually rich data
and precise information acquisition. Unlike
traditional natural image retrieval, visual doc-
uments exhibit unique characteristics defined
by dense textual content, intricate layouts, and
fine-grained semantic dependencies. This pa-
per presents the first comprehensive survey
of the VDR landscape, specifically through
the lens of the Multimodal Large Language
Model (MLLM) era. We begin by examin-
ing the benchmark landscape, and subsequently
dive into the methodological evolution, cat-
egorizing approaches into three primary as-
pects: multimodal embedding models, multi-
modal reranker models, and the integration of
Retrieval-Augmented Generation (RAG) and
Agentic systems for complex document intel-
ligence. Finally, we identify persistent chal-
lenges and outline promising future directions,
aiming to provide a clear roadmap for future
multimodal document intelligence.

1 Introduction

Multimodal retrieval, the task of retrieving relevant
multimodal information from a large-scale collec-
tion using queries that span multiple modalities like
text and vision, has become a cornerstone of mod-
ern information retrieval (Mei et al., 2025; Zheng
et al., 2025a). Historically, research in this domain
has predominantly focused on natural image re-
trieval, targeting datasets of photographs and web
images where the primary goal is to match objects,
scenes, or holistic visual concepts (Wu et al., 2024a;
Arslan et al., 2024). However, both academia
and industry begin to turn their attention to a dis-
tinct yet ubiquitous data type: visual documents1.

*Project Lead
†Corresponding Author
1They are also commonly referred to as visually rich docu-

ments, document images, etc. We use “visual documents” as a

Cat

Sofa

(Left) natural image

Query

A cat
sitting on 

a sofa

Chart

Notation

(Right) visual document

Query

Method 
section of 
a paper

Main 
Text

Caption

Figure 1: Comparison of retrieval of natural image (left) and
visual document (right), the focus of this survey.

These documents, ranging from scanned PDFs and
business reports to invoices and academic papers,
are characterized by a dense interplay of textual
content, complex layouts, and graphical elements
(Tang et al., 2023; Li et al., 2024d).

The pivot towards Visual Document Retrieval
(VDR) is driven by three fundamental differences
that distinguish visual documents from natural
images, as illustrated in Figure 1. ❶ Informa-
tion modality and density: unlike natural images
which convey semantic meaning through holistic
scenes, visual documents are hybrid entities where
meaning is co-determined by rich textual informa-
tion and a structured spatial layout. The informa-
tion is dense, hierarchical, and multi-modal by na-
ture. ❷ Semantic granularity: retrieval in natu-
ral images often targets high-level concepts (e.g.,
"a cat sitting on a sofa"), whereas VDR demands
a much finer-grained understanding. Users may
query for specific facts embedded within a table, a
particular sentence in a paragraph, or information
contingent on its document-level position (e.g., "the
methodology section of a paper"). ❸ User intent
and task complexity: VDR is typically geared
towards precise information-seeking, question an-
swering, and evidence-based reasoning, rather than
conceptual or aesthetic matching.

Furthermore, as the general capabilities of Multi-
modal Large Language Models (MLLMs) advance
(Song et al., 2025; Yan et al., 2025b,a), the VDR

unifying term. See more illustrative examples in Appendix A.

1

ar
X

iv
:2

60
2.

19
96

1v
1 

 [
cs

.C
L

] 
 2

3 
Fe

b 
20

26

mailto:yanyibo70@gmail.com
mailto:xuminghu@hkust-gz.edu.cn
https://arxiv.org/abs/2602.19961v1