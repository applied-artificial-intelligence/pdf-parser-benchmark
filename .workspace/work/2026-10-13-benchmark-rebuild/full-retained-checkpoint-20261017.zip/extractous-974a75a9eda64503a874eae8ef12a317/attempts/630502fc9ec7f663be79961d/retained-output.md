Renewables 2025 Chapter 1. Renewable electricity 
Analysis and forecasts to 2030 
 

PAGE | 48  I E
A.

 C
C

 B
Y

 4
.0

. 

Our review of the UNFCCC registry reveals that only 57 of the 196 Parties to the 
Paris Agreement had submitted NDC 3.0s as of 28 September 2025, accounting 
for only 23% of CO2 emissions from fuel combustion. Of these, 11 are advanced 
economies (19% of global CO2 emissions from fuel combustion), while the 
remaining 46 are developing and emerging countries (4%). 

Encouragingly, most submissions (54) mention renewable energy, recognising 
that it has a role to play in lowering GHG emissions. However, only 14 explicitly 
acknowledge the COP28 tripling pledge, and just 5 identify their renewable 
capacity ambitions for 2030, totalling 80 GW. This is less than 1% of the 
11 500 GW needed to meet the global tripling target by the end of the decade.  

Shares of fuel-combustion CO2 emissions in 2023 covered in NDC 3.0s (left) and 
country progress in submitting updates as of 28 September 2025 (right) 

 
IEA. CC BY 4.0. 

Notes: NDC = Nationally Determined Contribution. On 20 January 2025, US Executive Order 14162 on Putting America 
First in International Environmental Agreements withdrew the United States from the Paris Climate Agreement, with official 
notification submitted to the UN on 27 January 2025, making the withdrawal effective on that day. 
 

However, the absence of a 2030 renewable capacity target does not necessarily 
indicate that a country lacks a plan to accelerate renewable capacity. Some 
countries have set their ambitions for 2035 instead of 2030, while others have 
expressed their renewable electricity targets in other units (e.g. share of power 
generation) or have embedded them within broader net-zero strategies.  

Additionally, at the UN climate summit in New York on 24 September 2025, a 
further 10 countries verbally announced their intention to submit NDC 3.0s to the 
UNFCCC registry, but they have not yet done so. For example, China announced 
that it would increase its solar and wind capacity to three times the 2022 level (to 
around 3 600 GW) by 2035 under its planned NDC. 

Not submitted
77%

Emerging and 
developing

4%

Advanced
19%

Submitted
23%

0

 50

 100

 150

 200

 250

Total Parties
in Paris

Agreement

Submitted
NDC3.0s

Mentioned
"renewable"

energy

Acknowledged
COP28 tripling

target

Contained
2030

renewable
capacity
target

N
um

be
r o

f p
ar

tie
s

https://www.carbonbrief.org/analysis-half-of-global-emissions-covered-by-2035-climate-pledges-after-un-summit-in-new-york/?utm_source=chatgpt.com