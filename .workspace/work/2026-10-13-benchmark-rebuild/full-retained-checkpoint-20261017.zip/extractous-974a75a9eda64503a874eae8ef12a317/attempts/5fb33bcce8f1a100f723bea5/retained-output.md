Pharmacovigilance regulatory recommendations for centrally authorised veterinary medicinal products during 2021 
EMA/CVMP/PhVWP/105691/2021 Page 2 of 10 
 

Product 
(active substance(s)) 

CVMP meeting date Recommendation - SPC change  
(additions to text in bold, deletions in strikethrough) 

(see section 4.10). 

Bravecto 

(fluralaner) 
15-17 June 2021 Section 4.6 of SPC for Bravecto spot-on solution for cats: 

Mild and transient skin reactions at the application site, such as erythema and pruritus or 

alopecia were commonly observed in clinical trials (2.2% of treated cats).  

The following other signs shortly after administration were uncommonly observed: 

apathy/tremors/anorexia (0.9% of treated cats) or vomiting/hypersalivation (0.4% of 

treated cats).  

Convulsions have been reported very rarely based on post marketing safety 

experience (pharmacovigilance). 

Bravecto Plus 
(fluralaner/moxidectin)  

5-7 October 2021 Section 4.5 of SPC for Bravecto Plus (under Special precautions for use in 

animals): 

Care should be taken to avoid contact with the eyes of the animal.  

Do not use directly on skin lesions.  

In the absence of available data, treatment of kittens less than 9 weeks of age and cats 

less than 1.2 kg bodyweight is not recommended.  

Treatment of male breeding animals is not recommended.  

This product is for topical use and should not be administered orally.  

Oral uptake of the product at the maximum recommended dose of 93 mg fluralaner + 4.65 

mg moxidectin/kg body weight induced some self-limiting salivation or single incidences 

of vomiting immediately after administration.  

It is important to apply the dose as indicated to prevent the animal from licking and 

ingesting the product (see sections 4.6 and 4.9).  

Do not allow recently treated animals to groom each other.  

NEW