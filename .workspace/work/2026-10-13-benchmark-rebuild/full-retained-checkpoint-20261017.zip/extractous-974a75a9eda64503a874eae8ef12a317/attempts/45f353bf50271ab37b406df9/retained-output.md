Energy Technology Perspectives 2024 Chapter 1: The state of manufacturing and trade 
  

PAGE | 55 I E
A.

 C
C

 B
Y 

4.
0.

 

 Global exports of selected clean technologies and materials, 2010-2023  

 
IEA. CC BY 4.0. 

Notes: For electric cars, the index is based on units (not mass) and scaled in 2015 = 100. Aluminium includes mineral 
inputs, intermediates (such as alumina and scrap), ingots, and semi- and finished products. Iron and steel include mineral 
inputs, intermediates (such as scrap, pig iron and direct reduced iron) and semi- and finished products. Trade in materials 
refers to total trade, not just the materials used for manufacturing clean energy technologies. The trade value of the 
selected technologies reflects only the final exported unit and does not separately account for the value of the materials 
and components embedded in them. 
Source: IEA analysis based on EV Volumes (2024); CEPII (2024); Oxford Economics Limited (2024b); pv-magazine 
(2024b); BNEF (2024a); SPV Market Research (2024); InfoLink (2024); IEA-PVPS (2024); and RTS Corporation (2024). 

Exports of clean energy technologies are increasing rapidly in value and mass terms. 

Global exports for several clean technologies have increased more quickly than 
those of other more established sectors of the economy like food, 
pharmaceuticals, and textiles and clothing over 2010 to 2023. For these three 
sectors, trade increased by between 25% to 50% in mass terms over the period – 
an increase similar to that of the three selected materials and all of their 
precursors. The volume of trade in clean technologies nonetheless remains small: 
in mass terms, the combined exports of the three technologies mentioned above, 
electric cars, solar PV and heat pumps, were around 60% of that of textile and 
clothing and just above 5% of that of food in 2023.  

0

 500

1 000

1 500

2 000

2010 2015 2020

In
de

x 
(2

01
0 

= 
10

0)

Solar PV modules

​

​

​

​

0

 500

1 000

1 500

2 000

2010 2015 2020

Electric cars*

0

 50

 100

 150

 200

2010 2015 2020

Heat pumps

0

 50

 100

 150

 200

2010 2015 2020

In
de

x 
(2

01
0 

= 
10

0)

Aluminum

Value Mass

​
​

​

​

0

 50

 100

 150

 200

2010 2015 2020

Iron and steel

0

 50

 100

 150

 200

2010 2015 2020

Fertiliser