 43 

 

HEALTH AT A GLANCE: EUROPE 2024 © OECD OECD/EUROPEAN UNION 2024 
  

Over the past decade, the decision of many doctors to continue working beyond the standard retirement age has helped to avoid 

an exacerbation of shortages in many EU countries. This trend is evident in the increasing proportion of doctors aged over 65 

between 2012 and 2022, which has been particularly significant in countries such as Italy, the Slovak Republic, Germany, France 

and Belgium (Figure 1.18). 

Figure 1.18. The share of doctors aged 65 and over has increased over the past decade in several EU countries 

 
Source: Eurostat (hlth_rs_phys). 

StatLink 2 https://stat.link/k5rgpc 

Italy stands out with 27% of its medical workforce aged 65 and over, foreshadowing substantial doctor attrition in the coming 

years. The outflow of doctors due to retirement in the country is expected to peak in 2025 with the retirement rate projected to 

return to normal levels only by 2030 (Sumai-ASSOPROF, 2023[33]). To mitigate the impact of this anticipated retirement wave, 

Italy has implemented measures to retain older physicians longer in the system while simultaneously boosting the training of new 

doctors in recent years (Figure 1.13). In 2024, legislation was passed to temporarily suspend the obligation for doctors employed 

by public facilities (NHS) to retire at age 70, allowing them to remain in the ward until they are 72. This legislation also enables 

NHS local authorities to keep medical personnel in service beyond retirement age on a voluntary basis, addressing both the 

serious staff shortage and the training and tutoring needs of newly hired staff. Additionally, those who have retired since 

September 2023 can be readmitted to service within these limits (Consiglio dei ministri, 2023[34]). 

Pension reforms and a potential increase in doctors’ capacity and willingness to work longer may have a significant impact on the 

supply of doctors and replacement needs in the short to medium term. Many EU countries besides Italy have combined efforts to 

increase statutory retirement ages, curb early retirement, and offer incentives for longer working lives along with initiatives to foster 

job flexibility for older workers. Normal retirement ages have increased or are set to increase in most EU countries, reaching an 

average of over 65 years for both men and women starting their careers today. In Denmark, Estonia, the Netherlands and Sweden, 

the normal retirement age is projected to rise to 70 years or more if life expectancy gains materialise as projected and legislated 

links with life expectancy are applied (OECD, 2023[35]). Although there are few studies examining the specific impact of these 

pension reforms on doctors and other health workers, they can be expected to prolong the working lives and expand the supply 

of doctors, nurses and other health workers after age 65 in the coming years. 

According to the 2023 OECD Health System Characteristics Survey, six EU countries (Czechia, Greece, Ireland, Latvia, Portugal 

and Spain) indicated that part of their strategies to maintain or increase the supply of doctors is to prolong their working lives. This 

may be achieved through general pension reforms that increase the retirement age for all workers or through more specific 

incentives targeting doctors to prolong their working lives. 

Italy

Slovak Republic

Germany

France

Belgium

0

5

10

15

20

25

30

2012 2013 2014 2015 2016 2017 2018 2019 2020 2021 2022 .

Share of doctors aged 65 and over

https://stat.link/k5rgpc