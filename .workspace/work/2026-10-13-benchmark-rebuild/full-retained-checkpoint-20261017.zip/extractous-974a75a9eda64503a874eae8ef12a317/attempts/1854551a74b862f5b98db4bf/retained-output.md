Chapter 8. Political Cleavages
Figure 8.2. Educated voters increasingly support the left, whilehigh-income voters continue leaning right

Higher−educated voters voting for left−wing
parties (democratic, labor, social−
democratic, socialist, green, etc.)

Top−income voters voting for right−wing
parties (other parties)

−20%

−15%

−10%

−5%

0%

5%

10%

15%

19
60

−6
4

19
65

−6
9

19
70

−7
4

19
75

−7
9

19
80

−8
4

19
85

−8
9

19
90

−9
4

19
95

−9
9

20
00

−0
4

20
05

−0
9

20
10

−1
4

20
15

−1
9

20
20

−2
5D

iff
er

en
ce

 (
pp

):
 to

p 
10

%
 m

in
us

 
bo

tto
m

 9
0%

 v
ot

in
g 

le
ft

 (% of top 10% educated voting left) minus
(% of bottom 90% educated voting left)

 (% of top 10% earners voting left) minus
(% of bottom 90% earners voting left)

Education and income divides in Western democracies, 1960−2025

Interpretation. In the 1960s, both higher−educated and high−income voters were less likely to vote for left−wing
(democratic / labor / social−democratic / socialist / green) parties than lower−educated and low−income voters by
more than 10 percentage points. The left vote has gradually become associated with higher education voters,
giving rising to a multi−elite party system. Figures correspond to five−year averages for Australia, Britain, Canada,
Denmark, France, Germany, Italy, the Netherlands, Norway, Sweden, Switzerland, and the U.S. Estimates control
for income/education, age, gender, religion, church attendance, rural/urban, region, race/ethnicity, employment
status, and marital status (in country−years for which these variables are available). Sources and series: Gethin
et al. (2021) and World Political Cleavages and Inequality Database (wpid.world).

as education and healthcare workers, publicsector employees, and urban elites, whoseconcerns and political priorities extendbeyond redistribution to issues such asclimate change, minority rights, and genderequality. Meanwhile, less educated votershave turned toward conservative platforms.
This pattern is visible in nearly allWestern democracies, though with varyingintensity. Portugal and Ireland remain partialexceptions, with smaller or delayed reversals.Yet the broader trend is clear: education,once a strong determinant of support forconservative parties, has become a definingpredictor of left voting in most Westerndemocracies.
Contrary to education, the income dividehas remained relatively stable. Figure 8.4shows that higher-income voters continueto lean right. This enduring divide has meantthat even as educational elites shifted left,affluent groups have largely remained on theright.
Yet the income divide has not been static.In many Western democracies, the influenceof income on the vote declined during the

late 20th century, as party competitionincreasingly shifted toward cultural issues. Astriking case is the United States. In recentelections, high-income voters have shiftedto the Democratic Party, becoming morelikely than low-income groups to support theDemocrats. This shift represents a historicreversal of the classic postwar pattern,which highlights how far the U.S. has movedtoward a “high-income-left” coalition andillustrates the weight of sociocultural dividesin shaping political conflict.Figure 8.5 brings these dynamics togetherby plotting income and education gradientssimultaneously. In the 1960s, parties linedup along a diagonal: left-wing parties weresupported by low-income and less educatedvoters, while right-wing parties drew supportfrom high-income and highly educatedvoters. By 2000–2025, this alignmenthas fractured. Parties now cluster acrossdifferent quadrants. Green parties occupythe high-education section but do notdistinguish themselves in terms of income.Anti-immigration movements dominate thelow-education space, appealing to both low-and high-income groups. Conservatives
146