Chapter 3: The role of social investment 

77 

 

A large majority of preschool age children participate in ECEC in the EU, with participation rates 
converging across Member States. (140) The share of children aged three to compulsory school age (CSA) 
participating in ECEC broadly stagnated, going from about 87% in 2014 to 89% in 2023 (Chart 3.2). The COVID-
19 pandemic resulted in a temporary decline in participation and a spike in cross-country differences in 2020. In 
2023, national participation rates still varied considerably. For example, participation was above the Barcelona 
target of 96% (141) in seven Member States (Belgium, Denmark, Spain, France, Hungary, the Netherlands, 
Sweden), but was less than 80% in three countries (Poland, Romania, Slovakia). Cross-country differences 
declined between 2014 and 2023, as countries with lower participation rates caught up with those with higher 
participation. (142) 

While the average ECEC participation rate of the youngest children (0-2 years of age) rose over the 
last decade, disparities across Member States also increased. Over the last ten years, the share of 
children participating rose from about 28% in 2014 to 37% in 2023, with a short lapse during the 2020 closures 
due to the COVID-19 pandemic and an increase by 1.5 pp in 2023 compared to the previous year (Chart 3.2). To 

 
(140) (Eurofound, a). 
(141) Note that the Barcelona target for this age group (3+) is based on UOE data (educ_uoe_enra21) and not on data from EU-SILC survey. 
(142) Standard deviation dropped from 5.3 to 4.7. Beta coefficient is negative (-0.07) and statistically significant at 1% significance level. 

 
 

        

 

 

Box 3.2: Future investment needs in Early Childhood Education and Care

Further investment is needed to increase children’s participation in ECEC to the Barcelona target levels 
at EU level, notably for the under-3s. Such investment would help to address several barriers to children’s access to 
ECEC, including the lack of available places and high access costs. For example, by creating new ECEC places, training, 
hiring and paying new staff, or refurbishing existing/building new facilities, while ensuring accessibility and 
affordability. 

Additional yearly spending on ECEC needed to reach the EU Barcelona Targets by 2030 would amount to 
0.085% of EU GDP (more than EUR 11 billion) according to recent estimates. (1) This amount varies by Member 
State, ranging from 0% (in Member States that have already reached the target) to nearly 0.3% in Greece and around 
0.2% in Germany, Poland and Romania (Chart 1). 
 

Chart 1 

Additional investment needs in ECEC vary by Member State 
Yearly additional investment in ECEC needed to meet the 2030 Barcelona targets (% of GDP), by Barcelona targets 

  

Source: DG EMPL calculations based on Eurostat data. 

 
 

 
(1) The additional investment need is estimated as follows. First, based on current participation rates (Eurostat ilc_caindformal 

dataset), the number of additional children who should be enrolled to meet the Barcelona targets is estimated. This number is 
then multiplied by the yearly average public expenditure on ECEC per participating child (Eurostat educ_uoe_fine09 dataset) to 
obtain the additional yearly spending needs to reach the Barcelona targets. It is assumed that the level of spending per 
participating child remains constant over the years. 

0.0%

0.1%

0.2%

0.3%

EU BE BG CZ DK DE EE IE EL ES FR HR IT CY LV LT LU HU MT NL AT PL PT RO SI SK FI SE

Additional spending needed to reach the 2030 Barcelona target for children from 3 to CSA

Additional spending  needed to reach the 2030 country specific Barcelona target for children below 3