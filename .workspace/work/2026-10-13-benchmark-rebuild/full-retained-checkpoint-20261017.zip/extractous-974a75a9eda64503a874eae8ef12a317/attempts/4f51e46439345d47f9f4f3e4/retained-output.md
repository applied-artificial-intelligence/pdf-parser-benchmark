 113 

 

HEALTH AT A GLANCE: EUROPE 2024 © OECD/EUROPEAN UNION 2024 
  

Figure 3.19. Suicide rate, by sex, 2021 

 
Note: The EU average is weighted. Differences across countries may reflect, at least in part, differences in recording practices. 1. The data for the United Kingdom 

relate to 2020 (the rates have been calculated by the OECD based on the European population structure). 

Source: Eurostat (hlth_cd_asdr2). 

StatLink 2  https://stat.link/x8j1n2 

Figure 3.20. Trends in suicide rates, selected European countries, 2004 to 2021 

 
Note: The EU average is weighted. Differences across countries may reflect, at least in part, differences in recording practices. 

Source: Eurostat (hlth_cd_asdr2). 

StatLink 2  https://stat.link/odgpvz 

Figure 3.21. Symptoms of depression among adults aged over 50, by sex, 2021-22 

 
Note: The EU average is unweighted. Ireland does not participate in the survey. Symptoms of depression are measured using the EURO-D score, with a cut-off point 

of at least 4 out of 12 symptoms. 

Source: SHARE survey (wave 9). 

StatLink 2  https://stat.link/1s9j6g

0

5

10

15

20

25

30

35

40
Age-standardised rate per 100 000 population

Women Men Total

0

5

10

15

20

25

30

35

40

45

2004 2005 2006 2007 2008 2009 2010 2011 2012 2013 2014 2015 2016 2017 2018 2019 2020 2021

Age-standardised rates per 100 000 population

Cyprus EU27 Slovenia Hungary Lithuania

0

10

20

30

40

50

60

Men Women Total

% of population aged 50 and over with a score of 4 or higher

https://stat.link/x8j1n2
https://stat.link/odgpvz
https://stat.link/1s9j6g