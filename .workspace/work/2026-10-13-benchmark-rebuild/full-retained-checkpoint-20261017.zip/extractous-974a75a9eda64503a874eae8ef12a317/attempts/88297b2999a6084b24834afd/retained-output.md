Dividends and share repurchases
Amounts in billions, except as noted. Dollar amounts may not recalculate due to rounding.

• Share repurchases during the 
quarter totaled $4.6 billion 
representing 50.4 million 
shares, at an average price of 
$90.35 per share

• Remaining share repurchase 
authorization is $7.5 billion

Returns to 
shareholders $2.7 $2.7 $2.6 $3.1 $6.4

Returns to shareholders

$1.7 $1.7 $1.7 $1.7 $1.9
$1.1 $1.0 $1.0 $1.4 $4.6

Dividends Share repurchases

Q1 FY25 Q2 FY25 Q3 FY25 Q4 FY25 Q1 FY26

9