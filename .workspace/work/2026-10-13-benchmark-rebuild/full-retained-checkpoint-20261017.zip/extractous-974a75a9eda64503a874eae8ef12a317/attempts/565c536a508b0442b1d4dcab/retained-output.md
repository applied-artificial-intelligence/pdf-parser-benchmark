 181 

OECD EMPLOYMENT OUTLOOK 2024 © OECD 2024 
  

Annex Figure 3.A.2. Country-rankings in the level of earnings losses following displacement in low-
emission industries roughly mirror those for high-emission industries 

Decomposition of the average earnings losses over six years since displacement in low-emission industries into the 

contributions associated with wages, employment and days workers by country, percentage 

 

Note: Bars refer to the average effect of job loss on earnings over six years following displacement for workers in low-emission sectors. Countries 

are sorted based on the level of earnings losses for low-emission sectors. Due to missing information on daily wages and days worked, the bars 

for Australia, Canada, Estonia and Norway are not decomposed into components. 

Source: National linked employer employee data, see Annex Table 3.B.1 for details. 

StatLink 2 https://stat.link/zip64g 

-70 -65 -60 -55 -50 -45 -40 -35 -30 -25 -20 -15 -10 -5 0 5

PRT

EST

ESP

HUN

Average

AUT

FIN

FRA

DNK

NLD

CAN

AUS

DEU

SWE

NOR
%

Wages Employment Days worked Total

https://stat.link/zip64g