Capacity and Energy Assessment 

2024 Long-Term Reliability Assessment  
15 

NPCC-New England 
New England is forecasting unprecedented demand growth driven by electrification of heating and 
transportation. Wind, solar, and batteries make up the projected resource additions, along with 
growth in distributed energy resources. Since the 2023 LTRA, the peak demand forecast is relatively 
unchanged. New England has among the strongest winter demand forecast growth rates of any 
assessment area, rising over 7 GW in the 10-year period, or 35% from its current peak demand 
forecast. 
 
The 2024 ProbA for NPCC-New England reveals increasing risk of load loss and unserved energy 
compared to the 2022 ProbA (see Table 5). Higher-demand forecast and replacement of dispatchable 
resources with more VERs contribute to this trend. In the ProbA modeling, supply shortfall risk is 
limited to the summer months and is associated with periods of above-normal demand and low 
resource output (e.g., low wind, solar, or high thermal outages).  
 

Table 5: NPCC-New England ProbA Summary of Results 
 2026* 2026 2028 
EUE (MWh) 0.55 10.69 67.40 
EUE (PPM) 0.00 0.09 0.06 
LOLH (hours per year) 0.00 0.07 0.03 
Operable On-Peak Margin 27.8% 12.4% 13.7% 
* Year 2026 Results from the 2022 ProbA provided for trending 

 
While NPCC’s ProbA results indicate that the risk of unserved energy in New England is concentrated 
in summer months, a persistent concern is whether there will be sufficient fuel available to satisfy 
electrical energy and operating reserve demands during an extended cold spell or a series of cold 
spells given the existing resource mix and regional fuel delivery infrastructure. Potential natural gas 
transportation constraints can affect supply to generators during extreme cold temperatures, when 
natural gas demand for space heating is also peaking. Most natural-gas-fired generators in the area 
do not have firm natural gas transportation service and can be subject to supply curtailment during 
peak conditions. Many natural-gas-fired generators in New England can also operate with stored oil, 
providing for assured electricity supply in extreme winter conditions while oil stores are procured and 
maintained. Scenarios of extended and extreme cold weather that affect the availability of natural gas 
and oil replenishments present a reliability risk but were not within the scope of the 2024 ProbA.  
 

NPCC-Ontario 
Near- and long-term resource adequacy challenges continue in the NPCC-Ontario assessment area as 
the Independent Electricity System Operator (IESO) manages lengthy refurbishment outages at 
nuclear generators and demand growth driven by agriculture and electrification. The beginning of 
projected shortfalls occurs in 2027 when some contracts for firm capacity are set to expire (see Figure 
6). However, a number of resources with expiring contracts between 2026 and 2029 are anticipated 
to be re-committed for five-year terms through the IESO’s second medium-term procurement, which 
is underway. As such, Ontario’s Anticipated Reserve Margins (ARM) and Prospective Reserve Margins 
shown in Figure 6 (which do not include this set of expiring resources) are conservative. 
Recommitment of these resources is expected to raise margins above the reference level in 2029 and 
help maintain reliability through the end of the decade. In May 2024, the IESO finalized long-term 
commitments for new-build battery storage facilities (1,784 MW) and new-build natural gas and 
biogas facilities (411 MW). Early operation incentives anticipated to bring a portion of these resources 
online as early as 2027 could help alleviate the reserve margin gap. The IESO also launched 
procurements for new capacity and energy-producing resources to be online as early as 2029. In 
addition, the IESO finalized an agreement with Hydro-Québec for capacity sharing in November 2024, 
providing 600 MW of firm imports to Ontario starting in Summer 2025 through Summer 2031. This 
capacity is also expected to help alleviate shortfalls indicated in 2027. 
 

Figure 6: NPCC-Ontario Five-Year Planning Reserve Margin–Summer