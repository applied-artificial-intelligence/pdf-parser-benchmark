Statutory Reports

210-333

210.. Management 
Discussion and Analysis

222.. Business Responsibility and 
Sustainability Report

272.. Board’s Report

Financial Statements
334-503

334.. Consolidated

421.. Standalone

Marico's value delivery framework 
epitomizes a comprehensive approach 
rooted in consumer-centricity, bold 
ambition, responsible growth, member 
empowerment, accountability, and 
agility. By steadfastly adhering to 
these foundational principles, Marico 
maintains its competitive edge and 
solidifies its reputation as a dependable 
purveyor of high-quality products 
and a responsible corporate entity. 
As it navigates the intricacies of the 
business landscape, Marico remains 
resolute in its commitment to delivering 
enduring value to its stakeholders while 
upholding its fundamental principles 
of integrity, innovation, and inclusive 
progress. 

The sixth edition of Marico's Integrated Annual Report, serves as a comprehensive reflection of our performance and strategic alignment 
with the prevailing business landscape. It encapsulates a blend of qualitative and quantitative disclosures pertaining to our financial 
accomplishments, significant ESG initiatives, and efforts dedicated to promoting social inclusivity throughout the year.

Reporting Framework
The financial statements and statutory 
disclosures, including the Board’s Report, 
Management Discussion and Analysis 
(MDA), and Corporate Governance Report, 
comply with the requirements outlined in the 
Companies Act, 2013 (and its associated 
rules), Indian Accounting Standards, the 
SEBI (Listing Obligations and Disclosure 
Requirements) Regulations, 2015, and 
Secretarial Standards prescribed by the 
Institute of Company Secretaries of India.

The non-financial section adheres to the 
guidelines outlined in the International 
Integrated Reporting <IR> framework, 
including the January 2022 amendments, 

investor@marico.com
sustainability@marico.com

Any queries/feedback to be 
directed to

Financial information

Selected non-financial 
performance metrics

All other non-financial  
performance information

The financial statements presented in the report have 
been audited by B S R & Co. LLP

Reasonable Assurance of BRSR Core 
Indicators – BDO India LLP  
Limited Assurance of Marico’s FY24 Scope 3 
Emissions – BDO India LLP

Internally verified and assured by the 
Management

Reporting element Assurance status

inside
What's

Corporate Overview

07-209

07.... About Marico

24.... Global footprint

26.... Chairman’s message

30.... MD & CEOs message

34.... Key performance indicators

36.... Product showcase

44.... Materiality

52.... Business model

54.... Risk management

66.... Strategy

70.... Board of Directors

72.... Leadership team

74.... Stakeholder engagement

78.... Investors

82.... Consumers

112.. People

128.. Value-chain partners

140.. Communities

168.. Environment

206.. Corporate information

208.. Awards and accolades

About this report

The purpose of this Report 
is to provide transparent 
communication to all stakeholders 
regarding our business progress 
while highlighting our continuous 
efforts to identify most significant 
environmental, social, and 
governance (ESG) impacts, risks, 
and opportunities.

Restatements
The reporting scope for some of non-financial impact areas has been expanded based 
on the market drivers, value enablers, and social commitments during the year. These 
have been elaborated in the respective sections of the report.

issued by the International Integrated 
Reporting Council (IIRC), now known 
as the Value Reporting Foundation. 
Key Performance Indicators (KPIs) 
are prepared in reference to 
the Global Reporting Initiative (GRI) 
Standards. Moreover, the Business 
Responsibility and Sustainability Report 
(BRSR) aligns with the nine principles of 
the Ministry of Corporate Affairs' 
National Guidelines on Responsible 
Business Conduct (NGRBC), focusing on 
environmental, social, and governance 
responsibilities of businesses while also 
aligning with the relevant United Nations 
Sustainable Development Goals (UN 
SDGs).

Reporting Boundary 
The financial metrics and data provided 
in the FY24 Integrated Annual Report are 
specific to Marico Limited, encompassing 
both its domestic and international 
business operations, subsidiaries, and 
joint ventures. Non-financial disclosures 

Assurance of Report Content

primarily focus on Marico's operations in 
India unless explicitly stated otherwise in 
relevant sections.

Reporting Period
The FY24 Integrated Annual Report 
covers the financial and non-financial 
performance of the Company from 1st 
April, 2023 to 31st March, 2024. 

Management Responsibility 
Statement 
Marico’s management acknowledges 
its imperative role in ensuring the 
integrity, transparency, and accuracy 
of the information conveyed in the 
Integrated Annual Report. Moreover, 
the management affirms that the report 
thoroughly addresses all pivotal material 
concerns relevant to the organization 
and its stakeholders while effectively 
articulating the organization's capability 
to pursue opportunities and mitigate risks.

Scan to read the 
report online

Performance Trends

GRI Index

Ten years' financial highlights

504

506

511

mailto:investor%40marico.com%20?subject=
mailto:sustainability%40marico.com?subject=