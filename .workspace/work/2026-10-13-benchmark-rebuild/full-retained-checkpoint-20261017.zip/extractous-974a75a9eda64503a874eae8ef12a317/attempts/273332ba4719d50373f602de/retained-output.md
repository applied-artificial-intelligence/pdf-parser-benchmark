Investor Relations 
and Communications 
Starhill Global REIT keeps 
Unitholders and the financial 
community abreast of its latest 
developments and strategic 
direction through equitable, timely 
and effective communication. 
The Manager employs various 
communication channels such as 
announcements, press releases, 
briefing sessions, investor 
presentations, annual reports, 
corporate video, corporate 
website and emails to disseminate 
information on its financial and 
operational performance, business 
plans and latest developments. The 
Manager actively engages investors 
and analysts through regular 
meetings, property tours and 
attending conferences throughout 

the year. In FY 2023/24, the 
Manager conducted 81 investor 
meetings in the financial year. 

As at 30 June 2024, Starhill 
Global REIT is covered by a total 
of five research firms. Starhill 
Global REIT is a component 
stock of FTSE ST All-Share Real 
Estate Investment Trusts Index, 
FTSE ST All-Share Real Estate 
Index, as well as at the FTSE 
EPRA Nareit Global Developed 
Index. The Manager continues to 
be proactive in reaching out to 
Unitholders, prospective investors 
and analysts. It is committed to 
sharing accurate information with 
the investing public in a timely 
manner.

Research Coverage
• CGS-CIMB Research
• DBS Group Research
• OCBC Investment Research
• RHB Securities Singapore
• UBS Global Research

Unitholders’ Enquiries
If you have any enquiries or would 
like to find out more about Starhill 
Global REIT, please contact:

The Manager
YTL Starhill Global REIT 
Management Limited
391B Orchard Road 
#24-03 Ngee Ann City Tower B 
Singapore 238874
Phone: +65 6835 8633
Fax: +65 6835 8644
Email: info@ytlstarhill.com
Website: www.starhillglobalreit.com 

The Unit Registrar
Boardroom Corporate &  
Advisory Services Pte. Ltd.
1 Harbourfront Avenue
#14-07 Keppel Bay Tower
Singapore 098632
Phone: +65 6536 5355
Fax: +65 6438 8710
Website: www.boardroomlimited.com

For depository-related matters 
such as change of details 
pertaining to Unitholders’ 
investment records, please 
contact:

Unitholder Depository
The Central Depository  
(Pte) Limited
4 Shenton Way
#02-01 SGX Centre 2
Singapore 068807
Phone: +65 6535 7511
Email: asksgx@sgx.com 
Website: investors.sgx.com

FY 2023/24 Investor Relations Activities

1Q – FY 2023/24 (1 July 2023 to 30 September 2023)

• Release of financial results for FY 2022/23
• Release of Annual Report for FY 2022/23
• Release of Sustainability Report for FY 2022/23
• RHB Non-Deal Road Show, Bangkok
• RHB Non-Deal Road Show, Kuala Lumpur

2Q – FY 2023/24 (1 October 2023 to 31 December 2023)

• Release of 1Q FY 2023/24 business updates 
• Annual General Meeting

3Q – FY 2023/24 (1 January 2024 to 31 March 2024)

• Release of 1H FY 2023/24 financial results

4Q – FY 2023/24 (1 April 2024 to 30 June 2024)

• Release of 3Q FY 2023/24 business updates

66 STARHILL GLOBAL REIT