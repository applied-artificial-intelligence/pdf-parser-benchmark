84    

OECD EMPLOYMENT OUTLOOK 2024 © OECD 2024 
  

increased demand occupations and green-enhanced skills occupations also increased but at a significantly 

slower rate. However, if those occupations that are both green-driven and GHG-intensive are excluded, 

the growth of the remaining, green-driven occupations (labelled in the chart as “green residual”) is more 

than twice as large (5%). This is because occupations concentrated in high-emission sectors, including 

those occupations that are both green-driven and GHG-intensive,23 experienced a -18% decline over the 

same period.24 

Figure 2.4 suggests that the shares of green-driven and GHG-intensive occupations are positively 

correlated across countries,25 which is, to some extent, linked to countries’ industrial composition. Not the 

entire economy is equally affected by the net-zero transition. While green-driven occupations can be found 

in all sectors, Figure 2.5 shows that, compared to the distribution of employment across sectors, green-

driven occupations are more likely to be found in manufacturing, utilities and mining, construction and 

transports. GHG-intensive occupations, partly as a result of the definition itself (see Box 2.4 above), are 

even more concentrated in these macro-sectors and agriculture (where high emission industries are). 

Other services, which represent more than two-thirds of total employment, are composed mostly by 

occupations that are neither green-driven nor GHG-intensive. 

Figure 2.4. Green new and emerging occupations are growing fast 

Percentage change in the share of green-driven and GHG-intensive occupations in total employment 

 

Note: Europe: unweighted average of Austria, Czechia, Estonia, Finland, France, Hungary, Lithuania, Luxembourg, the Netherlands, Norway, 

Poland, the Slovak Republic, Slovenia, Sweden and Switzerland. Green residual occupations are green-driven occupations excluding those 

occupations that can be both green-driven and GHG-intensive. 

Source: Secretariat’s estimates based on version 24.1 of the O*NET database and the following country-specific sources: United States: Current 

Population Survey; All other countries: EU Labour Force Survey. 

StatLink 2 https://stat.link/h0w8yk 

-25

-20

-15

-10

-5

0

5

10

15

Green-driven occ. Green new and
emerging occ.

Green residual
occ.

GHG-intensive
occ.

%

Europe

-10

-5

0

5

10

15

20

25

30

35

Green-driven occ. Green new and
emerging occ.

Green residual
occ.

GHG-intensive
occ.

%

United States

2011-15 2015-19 2019-22 2011-22

https://stat.link/h0w8yk