Energy Technology Perspectives 2024 Chapter 1: The state of manufacturing and trade 
  

PAGE | 37 I E
A.

 C
C

 B
Y 

4.
0.

 

 Net manufacturing capacity additions for selected clean energy 
technologies by country/region, 2020-2023 

  
IEA. CC BY 4.0. 

Note: RoW = Rest of World.  
Sources: IEA analysis based on S&P Global (2024); WindEurope (2023); BNEF (2024a); GWEC (2023); Wood Mackenzie 
(2024); InfoLink (2024); SPV Market Research (2024); BMI (2024); EV Volumes (2024), BNEF (2024b); BNEF (2024c); 
Oxford Economics Limited (2024b); CEPII (2024); as well as announcements by manufacturers and personal 
communications, gathered by the IEA.  

Clean technology manufacturing capacity surged in 2023, with only heat pumps and 
electric vehicles seeing smaller capacity additions than in 2022. 

In the case of solar PV, manufacturing capacity additions for assembling modules 
have generally exceeded those of the key components – polysilicon, wafers and 
cells – with the notable exception of China over the last 2 years (Figure 1.7). 
However, the utilisation rates of component manufacturing facilities generally 
remain low, averting bottlenecks. Average utilisation rates across PV module 
manufacturing facilities worldwide remained steady in 2023, at around 55%. In 
parallel, facilities for newer technologies like tunnel oxide passivated contact 
(TOPCon), heterojunction (HJT) and back contact (BC) cells are gaining market 
share over the older ones like passivated emitter rear cells (PERC). This has 
driven down prices and led to some downscaling of expansion plans, especially in 
China (Box 1.2).  

Solar PV (modules)

0

 200

 400

 600

2020 2021 2022 2023

G
W

China European Union India Japan United States RoW

0

 12

 24

 36

2020 2021 2022 2023

Wind (nacelles)

0

 250

 500

 750

1 000

2020 2021 2022 2023

G
W

h

Batteries (cells)

0

 5

 10

 15

2020 2021 2022 2023

Electrolysers

0

 5

 10

 15

 20

2020 2021 2022 2023

G
W

Heat pumps

0

 2

 4

 6

 8

2020 2021 2022 2023

M
ill

io
n 

un
its

Electric vehicles