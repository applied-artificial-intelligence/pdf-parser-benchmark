unit4.com

All rights reserved. The information contained in this document is intended for general information only, as it 
is summary in nature and subject to change. Any third-party brand names and/or trademarks referenced are 
either registered or unregistered trademarks of their respective owners. IG230203INT

Copyright © Unit4 N.V.

For more information, go to:

The Professional 
Services Market
The view from 2023

It’s a new year, and it’s time for a new snapshot 
of the professional services industry. Service 
Performance Insight’s annual Professional 
Services Maturity Benchmark™ - now in its 16th 
year - is the leading analysis of the sector. 
Here’s some of the most important topline 
findings from the 2023 report.

Many KPIs have deteriorated since the previous year. Although these are minor 
slips, they should serve as a wake up call to leadership.

PSOs worked harder in 2022 – but not necessarily smarter

Deal pipelines relative to 
bookings forecast: ↓ 21%

Employee billable utilization: 
↓ 2.5%

Projects delivered on time: ↓ 4%

Project margin: ↓ 1.5%

Annual billable revenue per 
consultant: ↓ 1%

% of annual revenue target 
reached: ↓ 3.5%

% of annual margin target 
reached: ↓ 3.3%

Further, the movement to remote working has stalled at around two-thirds
of billable hours. (Although this may be the optimum balance for a highly
people-focused sector.)

But some subsectors are performing better than others: IT consulting leads
the pack. Management consulting continues its downward growth trends –
and advertising agencies, which peaked in 2020, have returned to
pre-pandemic growth levels. 

Revenue growth is also down across the sector

Despite redundancies upping the available talent pool, it still takes 10 days longer 
than in 2021 to hire a new fee earner and for them to become productive.

Many firms are investing heavily in moving to a people-centric model to satisfy 
both their consultants and their clients as a result. But attrition rates still remain 
higher than their 5-year average baseline.

Talent is still a major challenge

The importance of real-time information is now generally understood throughout 
the industry thanks to its ability to enable employees to perform at a higher level.
 
Newer technologies are being implemented in professional services:
capabilities such as collaboration tools, machine learning (ML), artificial
intelligence (AI), and automation are now increasingly being used to boost
operational visibility, automation e�ciency, performance improvement,
and goal achievement.

All aspects of maturity still depend on technology

For all of SPI’s insights into
how professional services
businesses perform – and how
to perform better – download the 
Professional Services Maturity 
Benchmark™ report below.

Want to know more?

Click here

25%

20%

15%

10%

5%

0%

A
nn

ua
l R

ev
en

ue
 G

ro
w

th

IT Consult Mgmt Con. Soft. PS SaaS PS AE Advertise.

2020 2021 2022

13
.4

%

10
.6

%

23
.4

%

18
.3

%

15
.8

%

10
% 12

.4
%

9.
1%

9.
5%

13
.2

%

7.
9%

7.
3%

13
.1%

7.
4% 10

.6
%

10
.2

%

9.
4%

6%

https://info.unit4.com/global-all-pso-2023-ap-spi-benchmark-report_LP.html
https://www.unit4.com