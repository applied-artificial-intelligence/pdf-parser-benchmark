high at the bottom half of the distribution, 
which is again probably where informal em-
ployment among women dominates. When 
comparing country income groups on a de-
cile-by-decile basis, the highest gender wage 
gaps tend to be found in the low-income 
countries – with the exception of the bottom 
decile, where the gender wage gap is higher 
among lower-middle-income countries.

Table 5.1 shows the gender wage gaps esti-
mated among all wage workers in the popu-
lation for each country income group using the 
classic measures for estimating pay difference 
– namely, the raw mean and median gender 
wage gaps. The two measure are presented 
together with estimates of the mean and me-
dian factor-weighted gender wage gap, com-
plementary measures that can help better 

 X  Figure 5.3. Share of women among wage employees in each decile of the hourly wage 
distribution and the decile-specific gender wage gap by country income group, latest 
available year (percentage)

 Notes: Each of the four charts shows two vertical axes: the left-hand axis displays values for the share of women among 
wage workers in each decile, while the right-hand axis displays values for the decile-specific mean and median gender wage 
gaps. All three estimates in each chart by decile are based on the weighted value between all of the countries in the sample 
from the corresponding income group, with weights determined by the size of wage employment in each country and 
decile. The figures displayed in the charts were obtained using data from the most recent available survey (T1 in Appendix I).

 Source: ILO estimates based on national survey data from 82 countries. See Appendix I for the sources of data and year 
of collection.

-4
-2
0
2
4
6
8

10
12
14
16
18
20
22
24
26
28
30

G
en

de
r w

ag
e 

ga
p 

(%
)

0

10

20

30

40

50

60

Fe
m

al
e 

w
ag

e 
w

or
ke

rs
 (%

)

D1 D2 D3 D4 D5 D6 D7 D8 D9 D10

-4
-2
0
2
4
6
8

10
12
14
16
18
20
22
24
26
28
30

G
en

de
r w

ag
e 

ga
p 

(%
)

0

10

20

30

40

50

60

Fe
m

al
e 

w
ag

e 
w

or
ke

rs
 (%

)

D1 D2 D3 D4 D5 D6 D7 D8 D9 D10

Deciles of the hourly wage distribution

Deciles of the hourly wage distribution

-4
-2
0
2
4
6
8

10
12
14
16
18
20
22
24
26
28
30

G
en

de
r w

ag
e 

ga
p 

(%
)

0

10

20

30

40

50

60

Fe
m

al
e 

w
ag

e 
w

or
ke

rs
 (%

)

D1 D2 D3 D4 D5 D6 D7 D8 D9 D10
Deciles of the hourly wage distribution

Low-income countries Lower-middle-income countries

Upper-middle-income countries

-4
-2
0
2
4
6
8

10
12
14
16
18
20
22
24
26
28
30

G
en

de
r w

ag
e 

ga
p 

(%
)

0

10

20

30

40

50

60

Fe
m

al
e 

w
ag

e 
w

or
ke

rs
 (%

)

D1 D2 D3 D4 D5 D6 D7 D8 D9 D10
Deciles of the hourly wage distribution

High-income countries

Mean gender wage gap by decile Median gender wage gap by decileShare of women by decile

38 Global Wage Report 2024–25
5. Wage inequality, where do we stand?