Resource Mix Changes 

2024 Long-Term Reliability Assessment  
28 

interconnection planning process, and the announced plans or timing may be subject to change 
before the retirement is confirmed. Wholesale electricity market areas, where merchant electric 
generators make up a large part of the generating fleet, have more uncertainty around future 
generator retirements, making resource planning and adequacy assessment difficult. Figure 15 shows 
the total capacity of reported retirements (i.e., reported to ISO/RTOs and planning entities) as well as 
owner-announced, unconfirmed retirements of fossil-fueled and nuclear generators across the BPS 
over the next 10 years in each assessment area.19 This total of confirmed and announced-potential 
retirements over the next 10 years is over 115 GW (3 GW lower than 10-year projections in the 2023 
LTRA).  
 

 
Figure 15: Projected Capacity Retirements of Nuclear and Fossil Generation 

2024–2034 
 
 

 
19 Confirmed generator retirements are reported to NERC by each assessment area in this 2024 LTRA development process. NERC obtained data on announced, unconfirmed generator retirements from Energy Ventures Analysis, Inc. and from each assessment 
area. Some sources of information on announced generator retirements include EIA 860 data, trade press, and utility integrated resource plans. 

Natural Gas Fuel Reliance Trends 
Natural-gas-fired generators are and will remain a critical resource for BPS reliability in many areas 
over the 10-year assessment period, especially during winter. These generators provide many 
necessary reliability attributes that are exiting the system as traditional generators retire and inverter-
based renewable resources take their place in the resource mix. Natural-gas-fired generators are 
dispatchable and provide the ERSs of inertia, frequency response, and ramping flexibility. In winter, 
when peak demand in most areas occurs during early morning hours, natural-gas-fired generation is 
at its highest contribution to the resource mix in many areas. Severe winter weather events in 2021 
and 2022 provided stark evidence of the critical nature of natural gas as a generator fuel and the 
importance of secure supplies during times of extreme electricity demand.  
 
As the generation resource mix evolves and becomes more weather-dependent, fuel assurance 
becomes increasingly critical when conducting reliability assessments. Until recently, comparing 
seasonally available capacity to a predetermined PRM level has sufficed as a means to assess resource 
adequacy. However, resource adequacy is now only the first step of a meaningful reliability 
assessment. Energy adequacy must now be layered on top to assess the risk that available capacity 
may be rendered unavailable due to phenomena including low wind or solar output and/or natural 
gas supply and transportation issues.  
 
This year, the Energy Information Administration (EIA) projected that more than 40% of delivered 
natural gas would be consumed by power generators, more than 0.6 Bcf/d higher than was consumed 
by power generators in 2023 and 7% higher than what the EIA had projected for 2024 in the fall of 
last year. Natural-gas-fired power plants generated 42% of the electrical energy consumed by end-
use electricity customers in 2023 and are on track to maintain that share of generation this year. A 
significant percentage of natural-gas-fired power plants rely upon as-available, non-firm gas supply 
and transportation arrangements. Non-firm natural gas supply and transportation is generally 
sufficient for electric generators most of the year. However, during extreme cold weather, demand 
for natural gas by both generators and natural gas distribution companies (generally firm shippers) 
can at the same time dramatically increase. In these instances, generators that lack firm supply and 
transport arrangements are at risk of fuel unavailability, and when winter weather impacts gas 
production facilities, the resulting imbalance in pipeline injections and withdrawals can put at risk 
even firm pipeline customers as preparatory linepack is rapidly depleted.