 145 

OECD EMPLOYMENT OUTLOOK 2024 © OECD 2024 
  

declines are expected to markedly accelerate with respect to the past. In the EU, for example, the projected 

declines in the number of employed, which are expected to average 2.3% per year, are more than twice 

as large as the historical employment decline, which averaged 1.1% between 2000 and 2019 (Figure 3.4). 

The projected pace of decline under EU Fit-for-55 also differs across high-emission industries. For 

example, employment in the manufacturing of chemicals as well as coke and refined petroleum is expected 

to decrease by 3.9% and 5.4% on average per year, respectively, while employment in manufacturing of 

basic metals and other non-metallic minerals as well as in mining and quarrying is expected to decrease 

by 2.5% and 3.3% on average per year. The manufacturing of paper as well as air and water transport see 

somewhat smaller average annual declines of just under 2% of employment, while land transport is 

projected to decline by on average 0.3% per year. Notably, the projections point to an increase in 

employment in electricity, gas, steam and air conditioning supply, which is a result of a strong increase in 

the use of greener sources of electricity generation in the energy mix of EU countries (which are bundled 

together with more GHG-intensive energy production in this industry) as evident from the more finely 

grained projections by Borgonovi et al. (2023[1]) or IEA (2023[26]). For example, employment in fossil-fuel 

powered electricity generation is projected to decline by about 80%, while employment in renewable and 

nuclear electricity generation is expected to substitute for it with an increase by 80%. 

Figure 3.4. The speed of employment declines in high-emission sectors is projected to increase 
significantly 

Past average annual employment changes between 2000 and 2019 and projected average annual employment 

changes between 2019 and 2030 under a 55% emission reduction for EU countries relative to 1990 levels (Fit for 55), 

average across countries, percentage 

 

Note: The figure shows historical changes in employment between 2000 and 2019 as well as projected employment changes between 2019 

and 2030, accounting for the Fit for 55 targets to reduce CO2 – equivalent emissions by 55% in 2030 compared to 1990 levels. Agriculture is 

excluded. More information can be found in Borgonovi et al. (2023[1]). 

Source: ENV-Linkages model. 

StatLink 2 https://stat.link/iadv1g 

3.1.3. Workers in high-emissions sectors are well paid despite comparatively low 

education, more likely to be male and live in rural areas 

The characteristics of workers in high-emission industries differ notably from those of workers in low-

emission industries (Figure 3.5, Panel A). For example, workers in high-emission industries are more likely 

to have low educational attainment (20% versus 15%) and less likely to have high educational attainment 

(25% versus 40%) than workers in low-emission industries. Furthermore, workers in high-emission 

-6

-5

-4

-3

-2

-1

0

1

2

Low
emission

High
emission

Electricity,
gas, steam

and air
conditioning

supply

Land
transport and
transport via

pipelines

Water
transport

Manufacture
of paper

Air
transport

Manufacture
of

basic
metals

Mining and
quarrying

Manufacture
of other

non-metallic
mineral

products

Manufacture
of

chemicals

Manufacture
of coke

and
refined

petroleum

% Past (2000-19) Projections (2019-30)

https://stat.link/iadv1g