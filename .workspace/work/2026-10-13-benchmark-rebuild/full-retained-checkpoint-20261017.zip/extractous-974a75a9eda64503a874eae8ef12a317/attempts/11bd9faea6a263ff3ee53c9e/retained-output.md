Global Outsourcing Survey 2024 | Multidimensional sourcing: Orchestrating the extended workforce ecosystem 

18

“Effective vendor management plays a crucial role in 
the success of our outsourcing programs, reflecting the 
specialized nature of vendor management capabilities 
to enhance agility and responsiveness, allowing our 
organization to optimize its operational efficiency while 
adapting to evolving market demands.”

—Managing director / India GIC lead, global multi-brand restaurant company

Key questions for a 
successful sourcing 
transformation

To succeed in their sourcing 
transformations and sustain the 
benefits long-term, organizations 
must address critical strategic 
questions:

1.   What is our sourcing strategy, 
and who owns it?

2.   What is the case for change?  
What are the strategic objectives?

3.   What are the capabilities / 
skills of the retained and 
digital workforce, GICs, and 
outsourcing vendors? 

4.   How do we integrate various 
talent models, and who governs 
the extended workforce?

5.    How do we align with our 
partners on shared outcomes, 
and what are the metrics for 
success?

6.   How do we ensure technology 
and data systems provide 
visibility into our full workforce 
ecosystem?

7.   How can we mitigate risk and 
drive regulatory compliance 
across all talent models?

8.   How do we manage change and 
support our business partners 
throughout this transformation?

Answering these questions is 
essential for optimizing value from 
sourcing and extended workforce 
strategies, ensuring organizational 
resilience and adaptability while 
managing the sourcing complexity.

Despite the challenges and complexity of sourcing, organizations that invest in a VMO 
are realizing benefits. This benefit can increase as the VMO matures. 

These returns can further increase by expanding the VMO’s remit to include the 
broader extended workforce—creating an EWMO that is responsible for managing 
all talent models and sourcing strategies effectively (see sidebar, “Key questions for a 
successful sourcing transformation”).

Third-party spend reduction that is directly attributed to VMO actions

Developing or Emerging VMO Mature VMO

% organizations that report a reduction 
by 10% or more

77%
90%

% organizations that report a reduction 
by 20% or more

22%

61%