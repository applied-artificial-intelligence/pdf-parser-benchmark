Strategic Long-Term Sustainability Goals1

1 Each SDG icon indicated here signifies Alcoa’s alignment with one of the United Nations Sustainable Development Goals. They are a set of 17 goals with specific indicators agreed to by UN member states for achieving sustainable 
development and they demonstrate how our actions contribute to broader global sustainability efforts.

2 Lower-grade bauxite has contributed to the increase in water intensity because more bauxite needs to be processed to produce each ton of alumina. Additional details can be found in the Water Stewardship section.

SDG Goal Progress

Zero fatalities and serious injuries (life-threatening  
or life-altering injuries and illnesses).

Health and Safety

Zero fatalities; two serious 
injuries in 2023.

By 2030, deploy skills development programs 
in collaboration with Alcoa Foundation and 
Instituto Alcoa to equip members of our host 
communities with the necessary competencies 
to participate in local economic activities.

Local Commitments 
with Communities

Inaugural funds benefited 
81 programs and 15,995 
participants in 2023.

Implement a social performance management 
system (SP360) at all operating locations, 
including the definition of performance metrics 
and long-term goals to be achieved by 2025 
and 2030.

Shared Value Creation

Completed rollout of the 
system across our global 
operations. 

Achieve a more inclusive culture that reflects the 
diversity of the communities where we operate.

Inclusion, Diversity 
and Equity
Increased the percentage of 
women in our global employee 
population from 18.48 percent 
in 2022 to 19.1 percent  
in 2023. 

The percentage of new 
hires from underrepresented 
populations was 44 percent.

SDG Goal Progress

Align our GHG (Scope 1 and 2) emissions 
reduction targets with the “well below 2º C” 
pathway by reducing GHG emission intensity by 
30 percent by 2025 and 50 percent by 2030 from 
a 2015 baseline of 7.1 mt CO2e/mt Al.

The ambition to achieve net zero GHG emissions 
by 2050.

Climate Change

27.2 percent reduction 
from 2015.

From a 2015 baseline of 53 m2/kmt alumina, 
reduce bauxite residue land requirements per 
metric ton of alumina produced by 15 percent 
by 2030.

Impoundment Management

15.5 percent reduction 
from 2015.

Maintain a corporate-wide annual ratio of 1:1 or 
better for mine rehabilitation to mine disturbance.

Biodiversity and 
Mine Rehabilitation

1.31:1 ratio for 2023.

From a 2015 baseline of 131.7mt, reduce 
landfilled waste by 15 percent by 2025 and 25 
percent by 2030.

Emissions and Waste

22.8 percent reduction 
from 2015.

From a 2015 baseline of 3.79 m3 water/mt 
alumina, reduce the intensity of our total water 
use from Alcoa-defined water-scarce locations 
by five percent by 2025 and 10 percent by 2030.

Water Stewardship

2.1 percent increase2 
from 2015.

Overview Governance Social Environment Appendices

12Alcoa 2023 Sustainability Report