Chapter 2: Social convergence in the EU: taking stock 

53 

 

Chart 2.7 

Variations in health outcome measures have remained stable 
Healthy life years at age 65 for women and men, and cross-country variation (measured by standard deviation), 2007-2022, EU-27 

                    

Note: Latest data point is 2022 Standard deviation is a measure of cross-country variation, the higher the standard deviation, the higher the cross-country variation. EU average levels 
are weighted values. 

Source: DG EMPL calculations based on EU-SILC dataset hlth_hlye. 

Click here to download chart. 

 

3. CONVERGENCE IN SOCIOECONOMIC OUTCOMES WITHIN MEMBER STATES 
Understanding patterns of regional convergence within countries can better clarify trends in 
socioeconomic outcomes. Convergence at EU level (across countries or regions as analysed in section 2) does 
not necessarily imply regional convergence within countries, for example when capital and metropolitan regions 
strongly outperform rural and peripheral regions within a country. It is important to look beyond convergence at 
EU level to capture potential challenges to territorial and social cohesion within specific Member States. This 
section provides regional convergence analysis within each of the 19 Member States with more than four NUTS2 
regions. (86) It focuses on the indicators analysed in section 2 for which regional data are available (GDP per 
capita, (un)employment and NEET rates, tertiary and adult education rates, and AROPE rates), covering 2007 to 
2022. It also provides an in-depth look at within-country convergence in median incomes across very small 
territorial units (NUTS3 regions) based on unique administrative data collected in eight Member States 
(Box 2.2(European Commission, )). 

Upward divergence in economic performance at EU level was observed within most EU Member 
States. Sixteen of the 19 Member States analysed saw their national GDP per capita increase since 2007 amid 
growing regional disparities (Table 2.2). The growth in regional disparities was particularly strong (more than 
50%) in Denmark and several central and eastern European countries (Bulgaria, Czechia, Poland, Romania). In 
central and eastern Member States, divergence partly resulted from capital regions outperforming other 
regions. (87) This was not always the case in other countries, e.g.: increases in regional variation in France were 
linked to particularly sluggish growth in regions with low levels of GDP per capita. Only Portugal experienced 
upward convergence in GDP per capita, but this was largely due to low growth in some developed, previously 
dynamic, regions. (88) 

Convergence patterns in labour market outcomes varied from country to country. Employment rates 
grew in most Member States since 2007, sometimes accompanied by regional convergence and sometimes by 
divergence (notably in Romania). Similarly, regional NEET rates converged in some countries and diverged in 
others, while average national rates largely declined. Concerningly, Denmark, France, and Romania all saw strong 
regional divergence in NEET rates. Within-country developments in unemployment rates are more reassuring, 
with 10 of the 18 countries experiencing upward convergence, notably Bulgaria, Czechia, Germany, and Portugal. 
Overall, within-country variation in labour market outcomes was highly sensitive to specific national and regional 
factors, but a detailed analysis is beyond the scope of this report. 

Most countries experienced growth in tertiary education attainment accompanied by regional 
divergence. This was the case for 16 of the 18 countries analysed. In several eastern and central European 
Member States (Czechia, Hungary, Poland, Romania) and Portugal, regional differences grew particularly strongly. 
These developments stemmed from sharp increases in tertiary education attainment in capital regions, reflecting 
a combination of factors including the concentration of universities, high demand for tertiary-educated workers 
and associated wage premiums. By contrast, a lack of tertiary education opportunities and an outflow of highly 

 
(86) Four regions was considered the lowest number reasonable to perform robust convergence analysis. 
(87) (Eurofound, 2021b); (Alcidi et al., 2018) 
(88) (European Commission, 2024b) 

0

1

2

3

4

0

2

4

6

8

10

12

2007 2009 2011 2013 2015 2017 2019 2021

Healthy life years at age 65: women, years

Average (left axis) Standard deviation (right axis)

0

1

2

3

4

0

2

4

6

8

10

12

2007 2009 2011 2013 2015 2017 2019 2021

Healthy life years at age 65: men, years

Average (left axis) Standard deviation (right axis)

https://ec.europa.eu/employment_social/empl_portal/publications/Esde2024/xls/Chap2/Chap2-Chart-2.7.xlsx