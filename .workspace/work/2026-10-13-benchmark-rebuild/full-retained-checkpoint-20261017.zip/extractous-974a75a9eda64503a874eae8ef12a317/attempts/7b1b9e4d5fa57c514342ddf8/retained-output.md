DATA

Responsible
We are focused on improving healthcare around the 
world and helping people live healthier lives. We will 
be intentional with our use of AI. We will use AI to 
deliver meaningful solutions, but we will not sacrifice 
our principles in pursuit of AI. This means that we will 
uphold scientific standards, ensure there is human 
oversight and accountability, and continue to review 
and determine when it makes sense to deploy AI 
solutions and when it does not.

Safe
We will not use AI in any way that could negatively 
impact the quality or safety of any of our products. 
We will design our AI systems to be safe, secure and 
protect data and privacy appropriately. We will test AI 
systems internally and, when an outside perspective 
would help, with external partners to ensure they are 
ready to deploy before use.

Transparent
We will be transparent about our use of AI and how 
we use the data people share with us. We will be 
responsive in communicating with people who have 
questions about our AI systems or features.

Fair
We will use representative and inclusive data sets 
whenever possible to inform and train our AI systems. 
Our goal is to minimize the potential for stereotyping 
and unfair bias in our AI models, and we will continually 
work to test, analyze, correct, and improve our systems.

Impactful
We believe AI should make life better for humans. AI 
has the potential to affect all aspects of society, and 
we will strive to deliver AI solutions to positively impact 
people. We will leverage AI-enabled technologies and 
tools to make life-changing products and services more 
accessible around the world.

E N T E R P R I S E  C Y B E R S E C U R I T Y 

We aim to create a strong cybersecurity foundation  
by reducing cybersecurity risks through:

• Education and awareness
•  Building cybersecurity into our systems  

and applications
• Implementing incident monitoring and  

response efforts
• Protection of sensitive data
• Manufacturing cybersecurity
• Disaster recovery planning efforts

U N D E R S TA N D I N G  C Y B E R S E C U R I T Y  R I S K S

We have taken several steps to strengthen our 
internal understanding of cybersecurity, including 
updating cybersecurity capability training to offer 
employees a variety of role-based learning paths, 
including mentorship and certification. Companywide 
training customized for specific functions within 
the organization helps employees and contractors 
better understand company policies and emerging 
cybersecurity risks. We monitor results to identify 
retraining requirements and help everyone at Abbott 
understand their shared responsibility to protect 
sensitive data and personal information. 

Convening our Medical Device Cybersecurity Council
Our Medical Device Cybersecurity Council consists 
of physicians, Chief Information Officers, and Chief 
Information Security Officers, and other healthcare 
cybersecurity experts along with key Abbott 
stakeholders. The Council meets several times a  
year to advise on Abbott’s cybersecurity program  
and focus areas and offer counsel. 

Additionally, Abbott businesses have dedicated 
cybersecurity leaders to help address cybersecurity 
risks within their business. These leaders provide 
updates to leadership and look at how cybersecurity 
controls are applied across Abbott’s businesses. 

Regional security leaders in key geographies support 
local and regional cybersecurity requirements.

A I  DATA  P R I N C I P L E S 

For 137 years, our goal at Abbott has been to help 
people around the world live fuller, healthier lives. 
Whether we are building cutting-edge heart devices, 
tracking new viruses, or helping people stay hydrated, 
we know that the right combination of science and 
technology can make lives better.

Technology and data are transforming healthcare, 
helping us better manage health and wellness, 
accelerate innovation, tackle business challenges,  
and expand access to care. Perhaps, the most 
transformative tool we are experiencing today is 
artificial intelligence (AI).

AI can harness the power of data in a way that most 
of us have never seen before. For healthcare, where 
systems and workers are continually under pressure 
and time is critical, the potential of AI is immense. We 
believe AI holds great promise for improving access 
to care and optimizing areas, such as clinical research, 
product performance, patient care, and productivity. 
At the same time, the stakes are high, and AI must be 
managed, applied, and interpreted responsibly and 
safely, with the same commitment to transparency, 
scientific standards, and excellence our stakeholders 
expect from us.

As with all that we do, we believe our use of AI must 
remain guided by our values — pioneering, achieving, 
caring, and enduring — and always in service of 
supporting people and making their lives better. 

A B B O T T ’ S  A P P R OAC H  T O  A I  I S  B U I LT  O N  F I V E  K E Y  P R I N C I P L E S :

GLOBAL SUSTAINABILITY REPORT 2024 ABOUT QUALITYACCESS AND AFFORDABILITY WORKFORCE SUPPLY CHAINENVIRONMENT ETHICS AND GOVERNANCE APPENDIX

22