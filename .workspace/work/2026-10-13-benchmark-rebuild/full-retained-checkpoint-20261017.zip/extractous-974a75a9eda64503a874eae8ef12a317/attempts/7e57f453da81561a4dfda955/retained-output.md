 93 

 

DO ADULTS HAVE THE SKILLS THEY NEED TO THRIVE IN A CHANGING WORLD? © OECD 2024 
  

Figure 2.20. Differences in key information-processing skills, by parental education 

Adjusted and unadjusted differences in average literacy, numeracy and adaptive problem solving scores between 

adults (highly educated parents minus low-educated parents) 

 

Note: Adults aged 16-65; does not include adults who were only administered the doorstep interview due to a language barrier, as information 

on parental education was not collected for those respondents (see Box 1.1 in Chapter 1). Respondents are categorised as having highly 

educated parents if at least one parent attained tertiary education; as having medium-educated parents if at least one parent attained upper 

secondary education and none of the parents attained tertiary education; and as having low-educated parents if neither parent attained upper 

secondary education. Unadjusted differences are the differences between the two averages for each contrast category. Adjusted differences 

are based on a regression model that takes into account differences associated with gender, age, education, immigrant background and 

language spoken at home. All differences are statistically significant at the 5% level. *Caution is required in interpreting results due to the high 

share of respondents with unusual response patterns. See the  ote for Poland in the Reader’s Guide. 

Countries and economies are ranked in descending order of the unadjusted difference between adults with highly educated and low-educated 

parents. 

Source: Table A.2.12 (L, N, A) in Annex A. 

Unad u sted Ad usted
G
e
rm

an
y

S
w
it 

er
la
nd

U
ni
te
d 
S
ta
te
s

A
us

tr
ia

H
u
ng

ar
y

 
at
 i
a

E
st
on

ia

Is
ra
el

S
in
g
ap

or
e

C
h
ile

C
 e

ch
ia

F
ra
n
ce

P
o
rt
ug

al

F
le
m
is
h 
R
eg

io
n 
( 

E
 

C
an

ad
a

 
E
C
 
 a
v
er
a
g
e

F
in
la
nd

 
or
ea

E
ng

la
n
d 
(U

 
 

P
o
la
n
d 

 
o
rw

ay

 a
pa

n

 
en

m
a
rk

It
al
y

C
ro
at
ia

Ir
el
an

d

 i
th
ua

n
ia

 
et
he

rl
an

ds

 
e
w
  

ea
la
nd

S
w
ed

e
n

S
lo
 a

k 
R
ep

u
bl
ic

S
pa

in

80

 0

 0

 0

 0

30

20

10

0

 .  iteracy

G
er
m
a
ny

U
ni
te
d 
S
ta
te
s

S
w
it 

e
rl
a
nd

H
un

g
a
ry

C
 e

ch
ia

C
hi
le

 
at
 i
a

E
st
o
ni
a

F
ra
n
ce

A
us

tr
ia

S
in
g
a
po

re

P
o
rt
ug

a
l

E
ng

la
n
d 
(U

 
 

F
le
m
is
h 
R
e
gi
o
n 
( 

E
 

Is
ra
e
l

 
E
C
 
 a
ve

ra
g
e

C
an

ad
a

P
o
la
n
d 

F
in
la
nd

 
or
ea

 
ew

  
ea

la
nd

 
et
he

rl
a
nd

s

 
or
w
ay

S
lo
 a

k 
R
ep

ub
lic

 
e
nm

ar
k

C
ro
a
tia

It
a
ly

Ir
el
a
nd

 a
p
an

 i
th
ua

n
ia

S
w
ed

e
n

S
p
ai
n

80

 0

 0

 0

 0

30

20

10

0

B.  umeracy

G
e
rm

an
y

S
w
it 

er
la
n
d

H
u
ng

ar
y

 a
t 
ia

U
ni
te
d 
S
ta
te
s

C
 e

ch
ia

A
us

tr
ia

E
st
on

ia

F
le
m
is
h 
R
eg

io
n 
( 

E
 

C
h
ile

S
in
g
ap

or
e

F
ra
n
ce

Is
ra
el

P
or
tu
g
al

C
an

ad
a

F
in
la
n
d

 
E
C
 
 a
ve

ra
g
e

E
ng

la
nd

 (
U
 
 

P
ol
a
nd

 

 
or
e
a

 
o
rw

ay

 
en

m
a
rk

 
ew

  
ea

la
n
d

 a
pa

n

 
e
th
e
rl
an

ds

C
ro
at
ia

It
a
ly

Ir
el
an

d

 i
th
ua

n
ia

S
w
e
de

n

S
lo
 a

k 
R
ep

ub
lic

S
pa

in

80

 0

 0

 0

 0

30

20

10

0

C.  daptive problem solving

Score point diffe rence

Score point diffe rence

Score point diffe rence