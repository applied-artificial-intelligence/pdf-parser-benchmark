POWER PLANNING: PART OF OVERALL PLAN 71

4 0 -

35 -

30-

25

20-

15-

5-

0-

Legend
• • Hydroelectric
LSI Gas - Steam
ZZ2 Gas — Turbines
B23 Nuclear

Scenarios:

1986 1990 1995
Years

2000 2015

FIG.2.14. Energy and nuclear power planning study for Algeria: development of installed
capacity by type of power plant according to three scenarios.

effects of a determined development policy, strong population growth and an
increase in energy demand as a result of higher living standards.

2.3.1.5.2. Expansion of generating capacity and the opportunity of introducing
nuclear power

The study was made using the WASP model, a methodology that has become
traditional as a result of its widespread application and distribution by the IAEA.
The procedure still retains its originality because it refrains from providing final
answers which would soon become obsolete owing to changing technical and
economic conditions. It seeks rather to identify in a dynamic way all the factors
to be considered in the decision-making process.

Since the main objective of the study was to determine the role that nuclear
power may play in meeting the demand for energy in Algeria, all alternative