6 Swiss Re Institute sigma 1/2023 In perspective: 2022 and longer-term trends

At over USD 33 billion, global insured losses from severe convective storms (SCS) were 
also above prior-period averages (see Figure 2), driven by thunderstorms with hail and 
tornadoes in the US. Another contributor was the highest-ever annual loss (USD 5 
billion) from hailstorms in France. Global losses from floods were just above average, the 
main event being flooding in eastern Australia in February-March. The flooding resulted 
in insured losses of USD 4.3 billion, the biggest natural catastrophe claims event ever in 
Australia. Another national “costliest ever” event was flooding in Durban in South Africa 
in April, leading to estimated insured losses of USD 1.5 billion.

After a few years with low loss-severity winter storms, in February 2022 a cluster of 
storms (Eunice, Dudley, Franklin) in northwestern Europe triggered combined claims of 
an estimated USD 4.1 billion, bringing the total for this category to almost double the 
previous 10-year average. Winds in winter storms are less severe than in tropical 
cyclones, but large parts of Europe can be impacted by a single storm, and damage in 
different locations can see combined losses accumulate to multi-billion levels. 

At the opposite end of the temperature spectrum, weather variability and anomalous 
atmospheric circulation conditions caused severe drought and heatwaves across the 
world. Heat and drought impacted crop yields in many regions, adding to global food 
inflation pressures and elevated agriculture insurance losses. Table 1 shows the crop loss 
impacts in US dollar terms in select markets. In Europe, the summer of 2022 was the 
hottest on record.2, 3 In Morocco, heat and dry conditions4 coincided with a North 
Atlantic Oscillation phase of rainfall deficit.5 In Brazil, monsoon rains were below 
average.6 Crop yields, particularly for soybean and maize, suffered most.7 Total 
precipitation across contiguous US in 2022 made the year the third driest on record,8 
and crops yield were lower than in 2021.9 And in China, extreme heat and dry conditions 
in the Yangtze River and weak monsoon rains impacted summer crops.10

2 Summer 2022 Europe’s hottest on record, Copernicus, 8 September 2022. 
3 Trockenheit in Europa 2022, Deutscher Wetterdienst, July 2022
4 Drought in western Mediterranean February 2022, European Commission, 22 March 2022.
5 See Climate Prediction Center, National Weather Service.
6 See “Phases of the South American Monsoon System”, Climate Prediction Center, Natl Weather Service 
7 See Crop Explorer - World Agricultural Production Briefs: Brazil, Foreign Agriculture Service, USDA.
8 Record drought gripped much of the US in 2022, National Oceanic and Atmospheric Administration, 

10 January 2023.
9 Corn and soybean production down in 2022, USDA reports Corn stocks down, soybean stocks down from 

year earlier Winter Wheat Seedings up for 2023, USDA, 10 January 2023.
10 “Scientific interpretation of severe drought in the Yangtze River Basin”, Journal of Arid Meteorology, 2022.

Flood and hailstorm events across the 
world also resulted in significant losses.

Figure 2  
Global insured losses from natural catastrophes in 2022 by category, in USD billion at 2022 prices

Source: Swiss Re Institute

0 20 40 60 80 100 120 140

2022

5-year average (2017–2021)

10-year average (2012–2021)

15-year average (2007–2021)

30-year average (1992–2021)

14%

54%

62%

115%

Earthquakes Tropical cyclones Floods Severe convective storms Wildfires

European winter storms Other secondary perils Droughts

2022 insured loss over previous year averages

Losses from winter storms in Europe were 
above average.

Heatwaves and droughts led to crop yield 
losses in many regions.

https://climate.copernicus.eu/copernicus-summer-2022-europes-hottest-record
https://www.dwd.de/DE/Home/_functions/aktuelles/2022/20220706_trockenheit_in_europa_2022.html
https://publications.jrc.ec.europa.eu/repository/handle
https://www.cpc.ncep.noaa.gov/products/precip/CWlink/pna/norm.nao.monthly.b5001.current.ascii.table
https://www.cpc.ncep.noaa.gov/products/Global_Monsoons/American_Monsoons/SAMS-Phases/
https://ipad.fas.usda.gov/cropexplorer/pecad_stories.aspx?regionid=br&ftype=prodbriefs
https://www.noaa.gov/news/record-drought-gripped-much-of-us-in-2022
https://www.nass.usda.gov/Newsroom/2023/01-12-2023.php
https://www.nass.usda.gov/Newsroom/2023/01-12-2023.php
http://www.ghqx.org.cn/EN/article/showChannelArticle.do?id=188