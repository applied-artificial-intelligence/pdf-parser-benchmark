 251 

OECD EMPLOYMENT OUTLOOK 2024 © OECD 2024 
  

Box 5.4. Evolution of labour costs and carbon prices 

Figure 5.10 below reports the growth rate of (nominal) effective carbon rates (ECRs) for households 

compared with inflation (the growth rate of prices, using the consumer price index – CPI) and labour 

costs (in the sectors with the highest and lowest growth rates). For almost all countries, carbon prices in 

households’ budgets grew faster than inflation for all income deciles, indicating the increasing share of 

purchasing power subject to carbon prices. However, average labour costs also grew over that period, 

and at a rate faster than inflation. While the data used in the analysis for this chapter prevents the 

disaggregation of labour cost changes for individual households, Eurostat labour cost data enables the 

disaggregation of labour costs by (broadly-defined) sector, which enables the calculation of growth rates 

of labour costs for the sector with the highest increase and the sector with the lowest increase. For 

Germany, France and Poland, the growth of ECRs in household budgets was higher than labour costs 

growth in the sector with the highest growth rate. Türkiye experienced the opposite, with the ECR growth 

rate for households lower than the labour costs growth rate in the highest growth sector. This indicates 

that in France, Germany and Poland, the welfare effects of increase in carbon prices possibly tended to 

be negative (i.e. earnings increased less than prices), while welfare effects in Türkiye were possibly 

positive for individuals in the sectors with the highest earnings growth. 

Figure 5.10. Growth rates of carbon prices (ECR), of the consumer price index and of labour 
costs 2012-21, by country 

 

Note: Mexico does not appear in the graph for lack of comparable labour costs evolution data. This figure reports the average labour cost 

growth of the lowest growing sector, the highest growing sector, the average CPI growth, and the relative change in nominal ECRs between 

2012 and 2021 by household (equivalised disposable) income decile. ECR: Effective Carbon Rates. LC: Labour Cost. CPI: Consumer Price 

Index. 

Reading: for instance, for the first decile in Germany, the relative change in nominal ECRs is the difference between the average ECR paid 

by households in the first decile in Germany in 2021 and in 2012 divided by the average ECR paid by households in Germany in 2012. 

Source: Eurostat labour costs data, https://ec.europa.eu/eurostat/web/labour-market/information-data/labour-costs and OECD calculations 

using OECD Effective Carbon Rates data, IEA emissions factors for different fuels, household budget surveys (2015 for EU countries and 

2019 for Türkiye) and World Input-Output Database (WIOD) 

StatLink 2 https://stat.link/z9e5kr 

0

0.5

1

1.5

2

2.5

3

3.5

4

1 2 3 4 5 6 7 8 9 10 1 2 3 4 5 6 7 8 9 10 1 2 3 4 5 6 7 8 9 10 1 2 3 4 5 6 7 8 9 10

Germany France Poland Türkiye

% change 2012-21 

Equivalised disposable income decile

ECR(Direct) ECR (Indirect) LC: lowest growing LC: highest growing CPI

https://ec.europa.eu/eurostat/web/labour-market/information-data/labour-costs
https://stat.link/z9e5kr