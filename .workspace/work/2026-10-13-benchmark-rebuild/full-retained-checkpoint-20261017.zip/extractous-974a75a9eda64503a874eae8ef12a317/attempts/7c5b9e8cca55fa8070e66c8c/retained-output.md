Table 2. Control of volunteer RR 2Xtend alfalfa with dicamba, 2,4-D and glufosinate systems in no-till soybean at Rochester, MN in 2018. 
Pest Name VOLUNTEER ALFALFA 
Rating Date Jun-14-2018 Jun-22-2018 Jun-27-2018 Jul-6-2018 Jul-11-2018 Jul-17-2018 
Trt Treatment   Rate Appl PERCENT CONTROL (%) 
PRE (6/4/18) / POST II (6/23/18) 

1 SONIC 6.4 oz wt/a A 24 d 13 g 78 d 68 e 60 c 58 d 
 FLEXSTAR GT 3.5 3 pt/a C             
 N-PAK AMS 2.5 % v/v C             
 NIS 0.5 % v/v C             

2 SONIC 6.4 oz wt/a A 24 d 13 g 60 e 95 abc 98 a 99 a 
 ENLIST DUO 75 fl oz/a C             
 N-PAK AMS 2.5 % v/v C             

6 LIBERTY 280 32 fl oz/a A 82 c 80 e 96 a 93 bcd 92 b 92 c 
 WARRANT ULTRA 3 pt/a A             
 N-PAK AMS 2.5 % v/v A             
 LIBERTY 280 32 fl oz/a C             
 N-PAK AMS 2.5 % v/v C             

PRE (6/4/18) / POST III (6/29/18) 
3 SONIC 6.4 oz wt/a A 87 b 86 d 81 c 94 bcd 97 a 99 a 
 ENLIST DUO 75 fl oz/a A             
 ENLIST DUO 75 fl oz/a D             
 N-PAK AMS 2.5 % v/v D             

4 ENLIST DUO 75 fl oz/a A 88 b 89 c 86 b 99 a 99 a 99 a 
 EVERPREX 16 fl oz/a D             
 2,4-D CHOLINE SALT 32 fl oz/a D             
 LIBERTY 280 32 fl oz/a D             
 N-PAK AMS 2.5 % v/v D             

PRE (6/4/18) / POST IV (7/6/18) 
9 FEXAPAN 44 fl oz/a A 94 a 95 b 95 a 90 d 93 b 97 b 
 ABUNDIT EDGE 32 fl oz/a A             
 DRA 0.5 % v/v A             
 CLASS ACT RIDION 1.0 % v/v A             
 FEXAPAN 22 fl oz/a E             
 ABUNDIT EDGE 32 fl oz/a E             
 DRA 0.5 % v/v E             
 CLASS ACT RIDION 1.0 % v/v E             

10 SONIC 6.4 oz wt/a A 94 a 96 ab 96 a 92 cd 93 b 97 b 
 FEXAPAN 44 fl oz/a A             
 ABUNDIT EDGE 32 fl oz/a A             
 DRA 0.5 % v/v A             
 CLASS ACT RIDION 1.0 % v/v A             
 FEXAPAN 22 fl oz/a E             
 ABUNDIT EDGE 32 fl oz/a E             
 DRA 0.5 % v/v E             
 CLASS ACT RIDION 1.0 % v/v E             

POST I (6/15/18) / POST IV (7/6/18) 
5 ENLIST DUO 75 fl oz/a B 0 e 70 f 96 a 99 a 99 a 99 a 
 N-PAK AMS 2.5 % v/v B             
 EVERPREX 16 fl oz/a B             
 2,4-D CHOLINE SALT 32 fl oz/a E             
 LIBERTY 280 32 fl oz/a E             
 N-PAK AMS 2.5 % v/v E             

7 LIBERTY 280 32 fl oz/a B 0 e 97 a 97 a 96 ab 99 a 99 a 
 N-PAK AMS 2.5 % v/v B             
 WARRANT ULTRA 3 pt/a E             
 LIBERTY 280 32 fl oz/a E             
 N-PAK AMS 2.5 % v/v E             

11 FEXAPAN 22 fl oz/a B 0 e 70 f 86 b 97 ab 98 a 98 ab 
 ABUNDIT EDGE 32 fl oz/a B             
 DRA 0.5 % v/v B             
 CLASS ACT RIDION 1.0 % v/v B             
 WARRANT 3 pt/a E             
 FEXAPAN 22 fl oz/a E             
 ABUNDIT EDGE 32 fl oz/a E             
 DRA 0.5 % v/v E             
 CLASS ACT RIDION 1.0 % v/v E             

LSD P=.10 2.7 2.1 2.5 4.2 2.5 1.5 
Treatments 8 and 12, untreated checks, are not shown in table.   
Means followed by same letter or symbol do not significantly differ (P=.10, LSD).