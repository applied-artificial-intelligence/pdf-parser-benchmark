TRUST FALLS BACK AFTER COVID-19 BUMPS

This year we find lower levels of overall trust in 21 of our 46 markets, 
partly reversing the gains made at the height of the Coronavirus 
pandemic. Eighteen markets are at a similar level, with just seven on 
an upward path. The average level of trust (42%) is also a little lower 
than last year and trust in individual news brands is on a downward 
trend in most countries.

Finland remains the country with the highest levels of overall trust 
(69%) – up four points on last year and 13 points on 2020. At the 
other end of the scale, news trust in the USA (26%) has fallen by 
a further three percentage points and remains the lowest level in 
our survey along with Slovakia (26%). Notable changes in Europe 
include falls in Romania (-9), Croatia (-7), Poland (-6), Switzerland (-5), 
Austria (-5), Greece (-5), Italy (-5), and Spain (-4). In Latin America, 
trust is down in Brazil (-6) and Colombia (-3), but level or slightly up 
elsewhere. It is a mixed picture in Africa, with a fall in Kenya (-4) 
but strong growth in South Africa (+9) and Nigeria (+4). Finally, in 
Asia, trust has risen in the Philippines (+5) and Japan (+2) but is 
down in Malaysia (-5) and Taiwan (-4).

In some regions we find a widening gap between markets with the 
highest levels of trust and those with the lowest. We also find that 
those markets with the most trust – such as Finland – also tend 
to have higher interest in news and lower levels of active news 
avoidance. By contrast, low trust countries, such as the United 
States, France, the United Kingdom, and Slovakia, see some of the 
highest levels of selective avoidance, as well as news disconnection, 
with declining interest in news. 

It is important to put this year’s trust changes in context. In most 
cases the headline trust level is still higher than it was before 
the Coronavirus pandemic reinforced the importance of reliable 
media for many people. On the other hand, the chart below also 
reminds us that, in many countries, trust had been on a downward 
trajectory for some time – partly driven by a series of polarising 
events like Brexit in the UK, the turmoil of the Trump years in the 
United States, and the Gilets Jaunes protests in France. In this 
context, last year’s COVID-19 optimism looks more like a short-
term rally rather than any kind of longer-term renaissance. In all 
the examples below, apart from Finland, trust is still considerably 
lower than in 2015.

REUTERS INSTITUTE FOR THE STUDY OF JOURNALISM / EXECUTIVE SUMMARY GRAPHS

Graph 9

PROPORTION THAT TRUSTS MOST NEWS MOST OF THE TIME 
– ALL MARKETS 

Q6_2016_1. Thinking about news in general, do you agree or disagree with the following 
statements? – I think you can trust most news most of the time. Base: Total sample in each 
market (n ≈ 2000).

0% 25% 50% 75% 100%

Canada
USA

North  
America

42
26

Brazil
Peru
Chile

Colombia
Mexico

Argentina

Latin  
America

48
41

38
37
37

35

Thailand
Japan

Singapore
Australia

Hong Kong
India

Indonesia
Philippines

Malaysia
South Korea

Taiwan

Asia-Pacific 53
44
43

41
41
41

39
37

36
30

27

South Africa
Nigeria

Kenya

Africa 61
58
57

Poland
Bulgaria

Czech Republic
Romania
Hungary
Slovakia

Eastern 
Europe

42
35

34
33

27
26

Portugal
Croatia
Turkey

Italy
Spain

Greece

Southern 
Europe

61
38

36
35

32
27

Netherlands
Belgium

Germany
Switzerland

Austria
France

Western 
Europe

56
51

50
46

41
29

FinlandNorthern 
Europe Denmark

Norway
Ireland

Sweden
UK

69
58

56
52

50
34

REUTERS INSTITUTE FOR THE STUDY OF JOURNALISM / EXECUTIVE SUMMARY GRAPHS

Graph 10

PROPORTION THAT TRUSTS MOST NEWS MOST OF THE TIME 
(2015–22) – SELECTED MARKETS

Q6_2016_1. Thinking about news in general, do you agree or disagree with the following 
statements? – I think you can trust most news most of the time. Base: Total 2015–22 
samples (n≈2000).

Finland Germany UK France USA

Trump elected

Post Brexit fall

General election

Gilet Jaunes protests

Corona
bump

60% 

38% 

32% 

51% 

68% 

50% 

29% 
26% 

34% 

69% 

0%

25%

50%

75%

100%
USA

France

UK

Germany

Finland

 20222021202020192018201720162015 

Reuters Institute for the Study of Journalism   |   Digital News Report 2022 15