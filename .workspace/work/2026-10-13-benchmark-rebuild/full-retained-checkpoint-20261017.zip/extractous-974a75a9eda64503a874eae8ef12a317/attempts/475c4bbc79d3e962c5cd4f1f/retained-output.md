34    

OECD EMPLOYMENT OUTLOOK 2024 © OECD 2024 
  

For Europe, the European Central Bank (ECB) indicator of future wage growth embedded in 

agreements reached in the latest quarter points to continuing growth in nominal wages, without signs 

of acceleration (Lane, 2024[12]). In fact, the latest release saw an increase in negotiated wage growth 

in the first quarter of 2024 to 4.7% – after it slightly moderated from 4.7% in the third quarter 2023 to 

4.5% in the fourth quarter of 2023. Further agreements are expected to be renewed in 2024 which might 

have a significant impact on the dynamics of negotiated wages in the coming quarters. 

Figure 1.12. Real negotiated wages in selected OECD countries 

Year-on-year percentage change in real negotiated wages (i.e. resulting from collective agreements) 

 

Note: International comparability of data on negotiated wages is affected by differences in definitions and measurement. Statistics are 

representative of all employees covered by a collective wage agreement for Austria, Belgium, the Euro Area (20), France, Germany, Italy, 

the Netherlands, Sweden, and the United States. In Canada, statistics refer to collective bargaining settlements of all bargaining units 

covering 500 or more employees (units of 100 or more employees for the Federal Jurisdiction). For Australia and Canada, statistics refer 

only to employees affected by an increase of the negotiated wage at date. Wage increases in Austria, Belgium, the Euro Area (20), Germany, 

Italy, the Netherlands, Sweden, and the United States refers to the average increase in negotiated wages (wages of union workers for the 

United States) weighted by the employment composition for a reference year (Laspeyres index). The reference year of the employment 

composition used is 2009 for Sweden, 2010 for Belgium and the Netherlands, January 2015 for the Euro Area (20), 2015 for Germany and 

Italy, 2016 for Austria, and 2021 for the United States. For Australia, Canada and France, wage increases refer to the average increase in 

negotiated wages weighted by the number of employees affected in the period considered. In Panel B, private sector for Germany refers to 

all industries excluding agriculture, public administration, education, health, and other personal services (Sections B to N of the 

NACE rev. 2). 

LS: wages including lump sums and/or special payments. The trough refers to the quarter where the year-on-year percentage change in 

real negotiated wages was at its lowest value for the indicated country and series (basic wage or wage including lump sums) since Q4 2019. 

Source: OECD calculations based on national data on negotiated wages, see Annex Table 1.C.3.in (Araki et al., 2023[11]) for further details; 

and OECD (2024), “Prices: Consumer prices”, Main Economic Indicators (database), https://doi.org/10.1787/0f2e8000-en (accessed on 

28 June 2024). 

StatLink 2 https://stat.link/g6dcje 

1.2.2. Wages of low pay workers have performed relatively better in many countries 

Statutory minimum wages in real terms are above their 2019 level in virtually all countries 

In May 2024, thanks to significant nominal increases of statutory minimum wages to support the lowest 

paid during the cost-of-living crisis, the real minimum wage was 12.8% higher than in May 2019 on average 

across the 30 OECD countries that have a national statutory minimum wage in place. This average figure 

-12

-10

-8

-6

-4

-2

0

2

4

6

AUT NLD NLD
(LS)

DEU
(LS)

EA20 ITA DEU CAN AUS SWE

%

A. All sectors

-12

-10

-8

-6

-4

-2

0

2

4

6

AUT NLD NLD
(LS)

USA ITA USA
(LS)

DEU
(LS)

CAN DEU FRA AUS BEL SWE

%

B. Private sector

Q1 2024 or latest ( ) Trough since Q4 2019

https://doi.org/10.1787/0f2e8000-en
https://stat.link/g6dcje