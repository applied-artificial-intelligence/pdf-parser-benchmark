B10 | Monday, February 2, 2026 THEWALL STREET JOURNAL.

Luxury Comeback in China Isn’t Likely
Even with a stock market outperforming the S&P 500, Chinese shoppers aren’t flocking to chic brands as they once did

HEARD ON
THESTREET

FINANCIAL ANALYSIS & COMMENTARY

The Louis Vuitton store in Shanghai is shaped like a cruise ship.

RA
UL
AR
IA
NO
/B
LO
OM
BE
RG

NE
W
S

Chinese shoppers are returning
to luxury stores, but with less ap-
petite to spend and in greatly di-
minished numbers. That is disap-
pointing for high-end brands
desperate for fresh growth.
After five years of weak sales,

some luxury brands said their
China business recently turned a
corner. Richemont, which owns
Cartier and Van Cleef & Arpels
jewelry, said sales started to grow
again in China in the third quarter
of 2025. British luxury trench coat
maker Burberry also noticed an
improvement last fall, and said de-
mand accelerated further in the fi-
nal three months of the year.
The recent results of the

world’s biggest luxury goods com-
pany, LVMH, gave a more mixed
picture. Sales to Chinese consum-
ers are stabilizing for LVMH, but
aren’t back to growth yet.
The company is tweaking its

footprint in the country.
LVMH recently agreed to sell its

duty-free business in China, but is
investing, too. The company’s flag-
ship brand, Louis Vuitton, in June
opened a Shanghai boutique,
which is drawing thousands of vis-
itors a day.
If the global luxury industry is

to get back to the 6% annual
growth it averaged over the past
two decades, it needs China to re-
cover. Luxury stocks used to be a
favorite way for investors to get
exposure to the country’s then-
booming middle class.
The Chinese went from barely

being on luxury brands’ radar in
the early 2000s to generating 35%
of the industry’s global sales by
2019, Bernstein estimates. The ap-
petite for luxury goods was so
strong that Chinese tourists flew
to European capitals for the expe-
rience of buying—for example—a
Chanel or Hermès purse at a flag-
ship in Paris.
The pandemic and China’s im-

ploding housing market ended the
good times. The Chinese share of

global luxury spending dropped to
23% last year. They have been
overtaken by Americans, who are
now the industry’s most important
customers. Last year, U.S. shop-
pers generated 31% of global lux-
ury sales, up from 22% before the
pandemic.
This leaves luxury brands heav-

ily reliant on a clutch of wealthy
Americans. The S&P 500 has
gained 17% over the past 12
months, generating an additional
$8.4 trillion of stock-market
wealth.
Most of the benefits have gone

to the richest households, who
have higher-than-average expo-
sure to stocks. This is boosting the
very top of the luxury market, for
goods such as fine jewelry, or
seats in first-class air cabins.
Brands such as Gucci or Saint Lau-
rent that are more dependent on
aspirational shoppers in the U.S.,
defined as customers who spend
up to $2,500 a year on luxury
goods, are suffering.
A recovery in China would pro-

vide a welcome hedge. The Shang-
hai Stock Exchange Composite In-
dex has outperformed the S&P 500
since the start of 2025. But China’s
equity markets are volatile and a
less important driver of consumer
spending than in the U.S. Stocks
make up just a 10th of China’s
household wealth according to
Goldman Sachs. This compares to
35% in the U.S., data from the Fed-
eral Reserve shows.
Home values, which make up

60% of household wealth in China,
are much more important for con-
sumer spending. A property crash
has wiped two-fifths off the value
of Chinese real estate since 2021
in some parts of the country.
Prices for existing homes fell 6%
in 2025, and don’t appear to have
bottomed out yet.
However, prices are stabilizing

in Tier 1 cities in China such as
Shanghai and Shenzhen, where
wealthy residents are also more

likely to own stocks. This could
create pockets of demand for lux-
ury goods this year.
But a widespread recovery is a

long shot. When middle-income
Chinese consumers were splurging
on designer goods several years
ago, their homes were appreciat-
ing in value.
In the decade leading up to the

pandemic, home prices in China’s
top 70 cities rose more than 50%,
data from the National Bureau of
Statistics of China shows. Incomes
were rising 10% a year on average
over the period, more than double
today’s rate.
Chinese households are still

prodigious savers. The average
household is socking away one-
third of its income, compared with
less than 5% in the U.S. This will
limit how much middle-class con-
sumers are willing to spend on
luxury goods.
That said, brands perceived to

offer value for the money are
growing. Ralph Lauren said its
sales in China rose more than 30%
in its latest quarter. Coach’s Chi-
nese business was up 21%. Bur-
berry is having success with Gen Z
consumers, thanks in part to a re-
alistic pricing strategy.
Local luxury players such as

Songmont handbags are also win-
ning over price-sensitive Chinese
shoppers. Their goods sell for four
to five times their manufacturing
cost, compared with a markup of
10 times or higher for Western
luxury brands, Bernstein notes.
Richemont Chief Executive Ni-

colas Bos said on the company’s
latest investor call that the bar for
selling luxury goods in China is
high today. Chinese customers are
“becoming much more demanding,
discerning and differentiating
when it comes to their choice of
brands.” The days when shoppers
queued around the block for a
Chanel or Louis Vuitton handbag
aren’t coming back soon.

—Carol Ryan
*Total exceeds 100 because of rounding.

Feb. 2025 Jan. ’26

–20

–10

0

10

20

30%
Shanghai Composite

S&P 500

Index performance
during the past year

Newhomes

Second-hand homes

China’s house prices,
change froma year earlier

2025

2019

0% 25 50 75 100

Chinese American European

Japanese

Other
Asian

Other
Global luxury spending by nationality*

Sources: Bernstein (spending); FactSet (stock market);
National Bureau of Statistics of China, Bernstein analysis (house prices)

Jan. 2025 Dec.
–10

–8

–6

–4

–2

0%

Cruise Investors Got a Cabin Upgrade
Cruise fans love wave season,

but this year’s prime booking win-
dow was making investors queasy.
They were concerned that de-

mand would soften amid higher
prices and increased capacity. In
the six months ended last Wednes-
day, shares of all three major
oceangoing cruise lines were down,
trailing the S&P 500 by 19% on av-
erage. Weakest of all over that span
was Royal Caribbean.
Then it reported full-year results

on Thursday. The stock surged 17%
after management said Royal Ca-
ribbean had just experienced the
seven highest weeks for bookings
in the company’s history.
Five of those weeks fell during

wave season, which continues
through March.
“What they heard from us today

is that our guests continue to pri-
oritize travel with us and that
they’re willing to pay more,” said
Royal Caribbean CEO Jason Liberty
in an interview.
Shares of competitors Carnival

and Norwegian Cruise Line also
jumped. The best-performing cruise
stock recently had been Viking,
which specializes in more intimate
and sedate river cruises.
That wasn’t so much because of

where its vessels sail as who you’re
likely to find on board. Michael Er-
stad, senior consumer analyst at M
Science, points out that their older,
wealthier clients were seen as more
financially secure. That cohort has
kept spending on other products
and services even as younger peo-
ple with jobs and children have
tightened their belts.
But cruise lines keep confound-

ing expectations. Indeed, after the
industry’s near-death experience
during the pandemic, they’ve be-
come more popular than ever. Ship-
yards that specialize in the vessels

are booked up for years.
Between the three big oceango-

ing companies, combined passenger
ticket sales are seen being almost
50% higher this fiscal year than in
2019. Earnings per share are still
much lower for Carnival and Nor-
wegian, though, because of finan-
cial ballast they picked up to sur-
vive the industry’s shutdown—debt
and stock issued to just stay in
business.
Royal Caribbean navigated the

crisis more skillfully. Now it is re-
turning billions to shareholders
with cash left over to order new
ships. That includes expanding in
an interesting direction: river cruis-
ing. On Thursday, the company an-
nounced the addition of 10 addi-
tional vessels to its Celebrity River
Cruises subsidiary.

Liberty doesn’t view that as an
economic hedge. He said that based
on the copious data the company
has on its many return customers,
river cruises interest many of them.
Ocean vacations are already often
multigenerational trips, he says.
Why has cruise demand been so

buoyant, though? One explanation
might be price. Even though
they’ve become more expensive,
land-based vacations have seen
even steeper inflation.
So how do they do it? This isn’t

the Love Boat. Ships are massive
entertainment complexes and in-
creasingly sail to private beaches or
islands owned by the cruise lines
themselves. That all creates greater
economies of scale.
Cruisers seem to like it, too.

—Spencer Jakab

forced crypto investors to re-
think their riskier holdings.
Some traders are hoping

for relief ahead. Kevin Warsh,
President Trump’s Federal
Reserve chair nominee, has
made supportive comments
about bitcoin in the past, but
some investors fear he could
support tighter monetary pol-
icy and hurt riskier assets.
Wall Street’s stomach for

those riskier bets could be

tested this week, when Strat-
egy reports its earnings. Big
tech names like Palantir, Am-
azon.com and chip maker Ad-
vanced Micro Devices are
also slated to report their fi-
nancial results, and a jobs re-
port from the Labor Depart-
ment is due this coming
Friday.
Investors have yanked a

net $227 million out of spot
bitcoin exchange-traded

MARKETS

underwater.
“It’s a mess out there,”

said Gennaro Salemme, a 32-
year-old car salesman in Chi-
cago. “The vibe right now is
‘stay alive.’”
Salemme still keeps

roughly 40% of his $200,000
portfolio in crypto invest-
ments including ether, XRP
and bitcoin ETFs. He first
bought bitcoin nine years ago
when the price was $3,000,
and said he is “100%” still
bullish on it for the long
term. But holding on can be
excruciating when everyone
else is abandoning ship.
“Everyone wants to leave

when things go south,” Sa-
lemme said. “A lot of this is
emotionally driven.”
After rallying in early

2025, digital assets surren-
dered much of the spotlight
to the artificial-intelligence
race, which sucked up inves-
tors’ capital and powered a
third straight year of double-
digit gains in stocks. A weak-
ening job market and escalat-
ing geopolitical tensions also

funds through Jan. 28, ac-
cording to Morningstar Direct
data.
The bleak mood in crypto-

land is in contrast to the start
of last year, when investors
cheered what many believed
would be a new golden era
for digital assets. Major Wall
Street firms had already
launched spot bitcoin ETFs,
pushing digital tokens into
the mainstream. And Donald
Trump was back in the White
House, promising to turn
America into a “bitcoin su-
perpower.”
Then last summer, Trump

signed into law a measure to
regulate stablecoins, fueling
expectations that clearer
rules could help boost the
crypto industry.
“It was almost like it was

2021 all over again,” said
Lewis Carr, a 19-year-old col-
lege student in Texas who
sold gaming consoles on
Facebook Marketplace to fund
his crypto investments. “Like
you couldn’t lose money.”
But the celebratory mood

eventually gave way to a
hangover.
Carr keeps about one-quar-

ter of his roughly $6,000
portfolio in crypto and still
puts about $50 a week into
bitcoin, ether and XRP. But
the slide has tempered his
optimism.
“Crypto right now is a to-

tal gamble,” he said. “I think
everybody realizes that.”
Will Warden had similarly

high expectations not so long
ago. The commercial real-es-
tate broker, 44, had watched
crypto from the sidelines for
years, then jumped in after
Trump took office last Janu-
ary.
“My expectations were

that by late spring, summer
of 2025, I would have had a
huge return,” he said. “But
that didn’t happen.”
Warden has decided to ride

out the downturn, but his fa-
ther and brother have cashed
out of their crypto holdings.
“A lot of people are ex-
hausted, or irritated, or an-
gry,” he said.

The party in the crypto
market is starting to feel like
a distant memory.
After a disappointing end

to 2025, major cryptocurren-
cies have languished to start
the new year. Bitcoin shed
roughly one-third of its value
since hitting a record in Octo-
ber through Friday, and sank
further on Saturday.
The slump has continued

even though stocks are near
records, with the gains broad-
ening throughout the market
and investors betting the
economy will keep growing. A
weakened dollar pushed in-
vestors toward alternative as-
sets for safety in the so-called
debasement trade.
Yet prices for cryptocur-

rencies have slid.
On Saturday, bitcoin briefly

dipped below the average
price Michael Saylor’s Strat-
egy has paid for the token,
putting the crypto-treasury
company’s bitcoin holdings

BY DALVIN BROWN
ANDHANNAH ERIN LANG

The Vibe in the Crypto Market Right Now: ‘Stay Alive’

S&P 500

Bitcoin

Aug. 2025 Sept. Oct. Nov. Dec. Jan. ’26

Cryptocurrency and index performance, past sixmonths

Sources: FactSet (index); Kraken (ether); CoinDesk (bitcoin)

–30

–20

–10

0

10

20

30%

Ether

Viking 8.8%

–13.5

–21.4

–22.4

Six-month total return through
Wednesday (prior to Royal
Caribbean results)

Source: FactSet

Royal
Caribbean

Norwegian

Carnival

P2JW033000-0-B01000-1--------XA