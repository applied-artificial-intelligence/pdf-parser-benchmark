24 Swiss Re Institute sigma 1/2023 Market dislocation: Hurricane Ian, inflation andinterest rates 

High economic inflation has impacted exposures and demand for coverage directly. The 
supply-side impact has been indirect. Rising prices led to decisive monetary policy 
action by the US Federal Reserve (Fed) and many other central banks. In 2022, the Fed, 
Bank of England (BoE), European Central Bank (ECB) and other central banks raised 
short-term policy rates from zero (or near-zero) to 4.375% (Fed), 3.5% (BoE) and 2.5% 
(ECB). Long-term interest rates also moved up considerably. 

One effect of the higher interest rates has been a decline in financial asset values and 
more specifically shareholder equity. This has had immediate impact on re/insurers, 
whose fixed income portfolios have suffered significant mark-to-market losses. The 
global bond index was down 16% in 2022, and global equity markets also declined (the 
S&P Dow Jones Broad Market Index was down 18% year-on-year). The combined effect 
on reinsurer balance sheets – where invested assets are typically 3-4 times equity – was 
significant. By the end of 2022, reinsurance capital (traditional and alternative) had 
declined by around 20‒25% from year-end 2021. After adjusting for the interest rate 

Figure 16  
Combined ratios, US property lines  
(Fire, Allied, Homeowners), 2011‒2022 (est.)

 Source: S&P Global Capital IQ Pro, Swiss Re Institute

0

20

40

60

80

100

120

Net

Direct

Direct average: 2011-2016, 2017-2022

2022 (est.)20212020201920182017201620152014201320122011

Direct average: 2011–2016, 2017–2022Direct Net

High inflation has sparked interest rates 
hikes...

Figure 17  
Inflation and interest rates in the US and Germany, 2019 – 2022, monthly data 

Source: Swiss Re Institute

0%

2%

4%

6%

8%

10%

20
2

2
:1

2

20
2

2
:0

9

20
2

2
:0

6

20
2

2
:0

3

20
21

:1
2

20
21

:0
9

20
21

:0
6

20
21

:0
3

20
20

:1
2

20
20

:0
9

20
20

:0
6

20
20

:0
3

20
19

:1
2

20
19

:0
9

20
19

:0
6

20
19

:0
3

20
18

:1
2

US

–2%

0%

2%

4%

6%

8%

10%

12%

20
2

2
:1

2

20
2

2
:0

9

20
2

2
:0

6

20
2

2
:0

3

20
21

:1
2

20
21

:0
9

20
21

:0
6

20
21

:0
3

20
20

:1
2

20
20

:0
9

20
20

:0
6

20
20

:0
3

20
19

:1
2

20
19

:0
9

20
19

:0
6

20
19

:0
3

20
18

:1
2

Germany

Inflation Short-term interest rate Long-term interest rate Inflation Short-term interest rate Long-term interest rate

…materially affecting re/insurance capital 
by decreasing asset valuations.