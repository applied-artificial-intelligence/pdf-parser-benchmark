Additional Requirements of Packaging Site
Dimensions: 743 mm x 311,200 mm
TD Reference Drawing/Revision: R-108
Barcode Information: Interleaved 2of5; Magnification: 53.5%; Encodation: 10002082
Other: Prints: Head to Head

Fill Registration mark with text color.
Fill ISEE mark (file provided) with text color.
Please use text color for barcode.
Perforation lines, if applicable, do NOT print.

File information – DRA-MA Only
Issue date of TD:

Product Name and
Component:

Issue date of artwork:

Print colors: Pan Black C

- June 17, 2013

- K01

- Mefloquine Hydrochloride Tablets USP,  250 mg / Outsert

- 24/Apr/2012

Component Number: - 10002082/10

Circular for Correction:

Signature(s): Department: Date: m/d/y

DRA-MA

Graphics 

DRA-MA

Package Engineer

Approvals

10002082

10002082

TIONS). attributable to drug administration cannot be distinguished from those symptoms usually Malaria Treatment in Pediatric Patients 
Vaccines: When mefloquine is taken concurrently with oral live typhoid vaccines, at- attributable to the disease itself. Treatment of mild to moderate malaria in pediatric patients caused by mefloquine-sus­

your liver You may report side effects to FDA at 1-800-FDA-1088. your liver You may report side effects to FDA at 1-800-FDA-1088. 
•	 Use protective clothing, insect repellents, and bednets •	 Use protective clothing, insect repellents, and bednets 

tenuation of immunization cannot be excluded. Vaccinations with attenuated live bacteria Among subjects who received mefloquine for prophylaxis of malaria, the most frequent- ceptible strains of P. falciparum: Dosage: 20 to 25 mg/kg body weight. Splitting the total 
to protect you from being bitten by mosquitoes. Medi- How should I store mefloquine? to protect you from being bitten by mosquitoes. Medi- How should I store mefloquine? should therefore be completed at least 3 days before the first dose of mefloquine hydro- ly observed adverse experience was vomiting (3%). Dizziness, syncope, extrasystoles therapeutic dose into 2 doses taken 6 to 8 hours apart may reduce the occurrence or 

chloride tablets. and other complaints affecting less than 1% were also reported. severity of adverse effects. The pediatric dose should not exceed the adult dose. 
Rifampin (Potent Inducer of CYP3A4): Co-administration of a single 500 mg oral dose Two serious adverse reactions were cardiopulmonary arrest in one patient shortly after Experience with mefloquine in pediatric patients weighing less than 20 kg is limited. 

cine alone does not always stop you from catching •	 Store mefloquine between 59°F to 86°F (15°C to cine alone does not always stop you from catching •	 Store mefloquine between 59°F to 86°F (15°C to 
malaria from mosquito bites. 30°C) malaria from mosquito bites. 30°C) 

of mefloquine and 600 mg of rifampin once daily for 7 days in 7 healthy Thai volunteers ingesting a single prophylactic dose of mefloquine while concomitantly using propranolol The drug shouId not be taken on an empty stomach and should be administered with •	 Safely throw away medicine that is out of date or no •	 Safely throw away medicine that is out of date or no resulted in a decrease in the mean Cmax and AUC of mefloquine by 19% and 68%, re- (see PRECAUTIONS: Drug Interactions), and encephalopathy of unknown etiology dur- ample water. The tablets may be crushed and suspended in a small amount of water, milk 
What should I avoid while taking mefloquine? longer needed. What should I avoid while taking mefloquine? longer needed. spectively, and a decrease in the mean elimination half-life of mefloquine from 305 hours ing prophylactic mefloquine administration. The relationship of encephalopathy to drug or other beverage for administration to small children and other persons unable to swallow 

to 113 hours. Rifampin should be used cautiously in patients taking mefloquine. administration could not be clearly established. them whole. 
Inhibitors and Inducers of CYP3A4: Mefloquine does not inhibit or induce the CYP 450 Among subjects who received mefloquine for treatment, the most frequently observed If a full-treatment course with mefloquine does not lead to improvement within 48 to 72 

Avoid activities such as driving a car or using heavy Keep mefloquine and all medicines out of the reach Avoid activities such as driving a car or using heavy Keep mefloquine and all medicines out of the reach 
machinery or other activities needing alertness and of children. machinery or other activities needing alertness and of children. 

enzyme system. Thus, concomitant administration of mefloquine hydrochloride tablets and adverse experiences included: dizziness, myalgia, nausea, fever, headache, vomiting, hours, mefloquine should not be used for retreatment. An alternative therapy should be careful movements (fine motor coordination) until you careful movements (fine motor coordination) until you substrates of the CYP 450 enzyme system is not expected to result in a drug interaction. chills, diarrhea, skin rash, abdominal pain, fatigue, loss of appetite, and tinnitus. Those used. Similarly, if previous prophylaxis with mefloquine has failed, mefloquine should not 
know how mefloquine affects you. You may feel dizzy General information about the safe and effective use know how mefloquine affects you. You may feel dizzy General information about the safe and effective use However, mefloquine is metabolized by CYP3A4 and inhibitors of CYP3A4 may modify the side effects occurring in less than 1% included bradycardia, hair loss, emotional problems, be used for curative treatment. 

pharmacokinetics/metabolism of mefloquine, leading to an increase in mefloquine plasma pruritus, asthenia, transient emotional disturbances and telogen effluvium (loss of resting In pediatric patients, the administration of mefloquine for the treatment of malaria has 
concentrations and potential risk of adverse reactions. Therefore, mefloquine hydrochlo- hair). Seizures have also been reported. been associated with early vomiting. In some cases, early vomiting has been cited as 

or lose your balance. This could happen for months or of mefloquine. or lose your balance. This could happen for months or of mefloquine. 
years after you stop taking mefloquine and can be per- Medicines are sometimes prescribed for purposes years after you stop taking mefloquine and can be per- Medicines are sometimes prescribed for purposes 

ride tablets should be used with caution when administered concomitantly with CYP3A4 a possible cause of treatment failure (see PRECAUTIONS). If a significant loss of drug 
manent in some cases. See “What are the possible other than those listed in a Medication Guide. Do not manent in some cases. See “What are the possible other than those listed in a Medication Guide. Do not inhibitors. Similarly, inducers of CYP3A4 may modify the pharmacokinetics/metabolism Laboratory product is observed or suspected because of vomiting, a second full dose of mefloquine 
side effects of mefloquine?” use mefloquine for a condition for which it was not pre­ side effects of mefloquine?” use mefloquine for a condition for which it was not pre- of mefloquine, leading to a decrease in mefloquine plasma concentrations and potential The most frequently observed laboratory alterations which could be possibly attribut- should be administered to patients who vomit less than 30 minutes after receiving the 

reduction in efficacy of mefloquine hydrochloride tablets. Therefore, mefloquine hydro- able to drug administration were decreased hematocrit, transient elevation of transami- drug. If vomiting occurs 30 to 60 minutes after a dose, an additional half-dose should be 
chloride tablets should also be used with caution when administered concomitantly with nases, leukopenia and thrombocytopenia. These alterations were observed in patients given. If vomiting recurs, the patient should be monitored closely and alternative malaria 

scribed. Do not give mefloquine to other people, even scribed. Do not give mefloquine to other people, even 
What are the possible side effects of mefloquine? if they have the same symptoms that you have. It may What are the possible side effects of mefloquine? if they have the same symptoms that you have. It may 

CYP3A4 inducers. with acute malaria who received treatment doses of the drug and were attributed to the treatment considered if improvement is not observed within a reasonable period of time. 
See “What is the most important information I harm them. See “What is the most important information I harm them. Substrates and Inhibitors of P-glycoprotein: It has been shown in vitro that mefloquine disease itself. The safety and effectiveness of mefloquine to treat malaria in pediatric patients below 

should know about mefloquine?” This Medication Guide summarizes the most impor­ should know about mefloquine?” This Medication Guide summarizes the most impor­ is a substrate and an inhibitor of P-glycoprotein. Therefore, drug-drug interactions could During prophylactic administration of mefloquine to indigenous populations in malaria- the age of 6 months have not been established.
 
also occur with drugs that are substrates or are known to modify the expression of this endemic areas, the following alterations in laboratory values were observed: transient Malaria Prophylaxis in Pediatric Patients: The recommended prophylactic dose of me-
Mefloquine may cause serious side effects, includ- tant information about mefloquine. If you would like more Mefloquine may cause serious side effects, includ- tant information about mefloquine. If you would like more 
transporter. The clinical relevance of these interactions is not known to date. elevation of transaminases, leukocytosis or thrombocytopenia. floquine hydrochloride is approximately 5 mg/kg body weight once weekly. One 250 mg ing: information, talk with your doctor. You can ask your phar­ ing: information, talk with your doctor. You can ask your phar- Other Potential Interactions: No other drug interactions are known. Nevertheless, the Because of the long half-life of mefloquine, adverse reactions to mefloquine may occur mefloquine hydrochloride tablet should be taken once weekly in pediatric patients weigh­

•	 liver problems macist or doctor for information about mefloquine that is •	 liver problems macist or doctor for information about mefloquine that is effects of mefloquine on travelers receiving concomitant medications, particularly diabet- or persist up to several weeks after discontinuation of the drug. ing over 45 kg. In pediatric patients weighing less than 45 kg, the weekly dose decreases 
ics or patients using anticoagulants, should be checked before departure. Postmarketing in proportion to body weight: 

In clinical trials, the concomitant administration of sulfadoxine and pyrimethamine did Postmarketing surveillance indicates that the same kind of adverse reactions are re- 30 to 45 kg: 3/4 tablet 
Call your healthcare provider right away if you have written for health professionals. Call your healthcare provider right away if you have written for health professionals. 
unexplained symptoms such as nausea or vomiting, unexplained symptoms such as nausea or vomiting, 

not alter the adverse reaction profile of mefloquine. ported during prophylaxis, as well as acute treatment. Because these adverse reactions 20 to 30 kg: 1/2 tablet stomach pain, fever, weakness, itching, unusual tired- What are the ingredients in mefloquine? stomach pain, fever, weakness, itching, unusual tired- What are the ingredients in mefloquine? Carcinogenesis, Mutagenesis, Impairment of Fertility are reported voluntarily from a population of uncertain size, it is not always possible to Experience with mefloquine in pediatric patients weighing less than 20 kg is limited. 
ness, loss of appetite, light colored bowel movements, Active ingredients: mefloquine hydrochloride USP ness, loss of appetite, light colored bowel movements, Active ingredients: mefloquine hydrochloride USP Carcinogenesis: The carcinogenic potential of mefloquine was studied in rats and mice reliably estimate their frequency or establish a causal relationship to mefloquine exposure. 

in 2-year feeding studies at doses of up to 30 mg/kg/day. No treatment-related increases The most frequently reported adverse events are nausea, vomiting, loose stools or diar- HOW SUPPLIED 
in tumors of any type were noted. rhea, abdominal pain, dizziness or vertigo, loss of balance, and neuropsychiatric events 

dark colored urine, yellowing of your skin or the white Inactive ingredients: calcium-ammonium alginate, col- dark colored urine, yellowing of your skin or the white Inactive ingredients: calcium-ammonium alginate, col-
of your eyes. loidal silicon dioxide, crospovidone, lactose (regular), of your eyes. loidal silicon dioxide, crospovidone, lactose (regular), 

Mutagenesis: The mutagenic potential of mefloquine was studied in a variety of as- such as headache, somnolence, and sleep disorders (insomnia, abnormal dreams). These Mefloquine Hydrochloride Tablets USP are supplied as speckled off-white to yellow, The most common side effects of mefloquine include: magnesium stearate, microcrystalline cellulose, polox- The most common side effects of mefloquine include: magnesium stearate, microcrystalline cellulose, polox­ say systems including: Ames test, a host-mediated assay in mice, fluctuation tests and adverse reactions may occur early in the course of mefloquine use. It has been reported that round, flat faced, beveled edge tablets with “54 111” debossed on one side and scored on 
•	 nausea amer 331, povidone, and starch. •	 nausea amer 331, povidone, and starch. a mouse micronucleus assay. Several of these assays were performed with and without dizziness or vertigo, tinnitus and hearing impairment, and loss of balance may continue for the other. Each tablet contains 250 mg of mefloquine hydrochloride USP.
 

prior metabolic activation. In no instance was evidence obtained for the mutagenicity of months after discontinuation of the drug and may be permanent in some cases.
 
mefloquine. More severe neuropsychiatric disorders have been reported such as: sensory and 0054-0025-11 250 mg speckled off-white to yellow tablet, bottle of 25
 

•	 vomiting •	 vomiting 
•	 diarrhea This Medication Guide has been approved by the U.S. •	 diarrhea This Medication Guide has been approved by the U.S. 

Impairment of Fertility: Fertility studies in rats at doses of 5, 20, and 50 mg/kg/day of motor neuropathies (including paresthesia, tremor and ataxia), convulsions, agitation or 
•	 abdominal pain Food and Drug Administration. •	 abdominal pain Food and Drug Administration. mefloquine have demonstrated adverse effects on fertility in the male at the high dose restlessness, anxiety, depression, mood swings, panic attacks, memory impairment, con- Storage 
•	 headache •	 headache of 50 mg/kg/day, and in the female at doses of 20 and 50 mg/kg/day. Histopathological fusion, hallucinations, aggression, psychotic or paranoid reactions and encephalopathy. Mefloquine Hydrochloride Tablets USP should be stored at 25°C (77°F); excursions 

lesions were noted in the epididymides from male rats at doses of 20 and 50 mg/kg/day. Cases of suicidal ideation and suicide have been reported. permitted to 15° to 30°C (59° to 86°F). 
Administration of 250 mg/week of mefloquine (base) in adult males for 22 weeks failed to Other less frequently reported adverse events include: 

The most common side effects in people who take me- Roxane Laboratories, Inc. The most common side effects in people who take me- Roxane Laboratories, Inc. 
floquine for treatment include: Columbus, Ohio 43216 floquine for treatment include: Columbus, Ohio 43216 reveal any deleterious effects on human spermatozoa. Cardiovascular Disorders: circulatory disturbances (hypotension, hypertension, flush- ANIMAL TOXICOLOGY 
•	 muscle pain •	 muscle pain Pregnancy ing, syncope), chest pain, tachycardia or palpitation, bradycardia, irregular heart rate, ex-

Teratogenic Effects: Pregnancy Category B: Data from published studies in pregnant trasystoles, A-V block, and other transient cardiac conduction alterations. Ocular lesions were observed in rats fed mefloquine daily for 2 years. All surviving rats • fever 10002082/10                                    Revised June 2013 • fever 10002082/10                                    Revised June 2013 
women have shown no increase in the risk of teratogenic effects or adverse pregnancy Skin Disorders: rash, exanthema, erythema, urticaria, pruritus, edema, hair loss, ery- given 30 mg/kg/day had ocular lesions in both eyes characterized by retinal degeneration, •	 chills © RLI, 2013 •	 chills © RLI, 2013 outcomes following mefloquine treatment or prophylaxis during pregnancy. Reproduc- thema multiforme, and Stevens-Johnson syndrome. opacity of the lens, and retinal edema. Similar but less severe lesions were observed in •	 skin rash •	 skin rash tion studies in mice, rats and rabbits have shown teratogenic effects at doses similar to Musculoskeletal Disorders: muscle weakness, muscle cramps, myalgia, and arthralgia. 80% of female and 22% of male rats fed 12.5 mg/kg/day for 2 years. At doses of 5 mg/kg/ 

•	 fatigue •	 fatigue the clinical acute treatment dose in humans. Because the studies in humans cannot rule Respiratory Disorders: dyspnea, pneumonitis of possible allergic etiology day, only corneal lesions were observed. They occurred in 9% of rats studied. 
out the possibility of harm, mefloquine should be used during pregnancy only if clearly Hepatobiliary Disorders: drug-related hepatic disorders from asymptomatic transient 
needed. transaminase elevations to hepatic failure Male Wistar rats orally administered-mefloquine daily for 22 days at the equivalent 

•	 loss of appetite •	 loss of appetite 
•	 irregular heart beat •	 irregular heart beat 

Published data on mefloquine use during pregnancy include randomized controlled Blood and Lymphatic System Disorders: agranulocytosis, aplastic anemia human therapeutic plasma concentration showed CNS penetration of mefloquine, withTell your doctor if you have any side effect that bothers Tell your doctor if you have any side effect that bothers trials, intervention trials, prospective and retrospective cohort studies, and case series. Other Symptoms: visual disturbances, asthenia, malaise, fatigue, fever, hyperhidrosis, a 30 to 50 fold greater brain/plasma drug ratio up to 10 days after the final dose admin­
you or that does not go away. These are not all the pos­ you or that does not go away. These are not all the pos- These data showed that pregnant women who took mefloquine at various doses for both chills, dyspepsia and loss of appetite. istered.1 

prevention and treatment of malaria did not have an increased risk of teratogenic effects 
or adverse pregnancy outcomes compared to the background rate in the general popula- OVERDOSAGE REFERENCES

sible side effects of mefloquine. For more information, sible side effects of mefloquine. For more information, 
ask your doctor or pharmacist. ask your doctor or pharmacist. 

tion. These data include more than 700 exposures to mefloquine in the first trimester of 
Call your doctor for medical advice about side effects. Call your doctor for medical advice about side effects. pregnancy and over 2,000 exposures in the second and third trimester. Symptoms and Signs 1. Baudry S., Pham YT., Baune B., Vidrequin S., Crevoisier CH., Gimenez F., Fainotti 

Mefloquine administered to pregnant mice, rats and rabbits was teratogenic at doses In cases of overdosage with mefloquine, the symptoms mentioned under ADVERSE R. (1997). Stereoselective passage of mefloquine through the blood brain barrier in 

Information Wallet Card: Mefloquine Hydrochloride Tablets USP 
It is important that you read the entire Medication Guide for additional information on mefloquine. 

Carry this wallet card with you when you are taking mefloquine. 

Important: You need to take malaria prevention medicine 
before you travel to a malaria area, while you are in a malaria 
area, and after you return from a malaria area. 
Mefloquine can cause serious side effects, including: 
1. Heart problems. 
Do not take halofantrine (used to treat malaria) or ketoconazole 
(used for fungal infections) with mefloquine or within 15 weeks of 
your last dose of mefloquine. You may get serious heart problems 
that can lead to death. Do not take quinine (Qualaquin) or quini-
dine (used to treat malaria or irregular heart beat) with mefloquine. 
You may get serious heart problems. Mefloquine may cause seri-
ous problems with the electrical system of your heart, called 
QT prolongation. 
2. Mental problems. Symptoms of serious mental problems may 
include severe anxiety, paranoia (feelings of mistrust towards oth-
ers), hallucinations (seeing or hearing things that are not there), 
depression, feeling restless, unusual behavior or feeling confused. 
Some people who take mefloquine think about suicide (putting an 
end to their life). Some people who were taking mefloquine com-
mitted suicide. It is not known if mefloquine was responsible for 
those suicides. 
If you have any of these serious mental problems you should con-
tact your doctor right away as it may be necessary to stop taking 
mefloquine and use a different medicine to prevent malaria. 
3. Problems with your body’s nervous system. Do not take 
quinine (Qualaquin) or chloroquine (Aralen) (used to treat malaria) 
with mefloquine. You may have a greater risk for convulsions 
(seizures). 
Symptoms of serious nervous system problems may include 

are unable to sleep (insomnia). 

dizziness, a feeling that you or things around you are moving or 
spinning (vertigo), loss of balance, ringing in your ears (tinnitus), 
convulsions (seizures) in people who already have seizures, or you 

you stop taking mefloquine and can be permanent in some cases. 

These serious mental and nervous system side effects can 
go on for months or years after mefloquine is stopped or may 
become permanent in some people. 
If you are told by a doctor to stop taking mefloquine because of the 
side effects or for other reasons, you will need to take a different 
malaria medicine. 
If you do not have access to a doctor or to a different medicine 
and have to stop taking mefloquine, leave the malaria area and 
contact a doctor as soon as possible because leaving the malaria 
area may not protect you from getting malaria. You will still need to 
take a malaria prevention medicine for another 4 weeks after you 
leave the malaria area. 
Mefloquine may cause serious liver problems. Symptoms of 
liver problems include nausea, vomiting, loss of appetite, unusual 
tiredness, stomach pain, fever, weakness, itching, light-colored 
bowel movements, dark colored urine, yellowing of your skin or the 
white of your eyes. The most common side effects of mefloquine 
include nausea, vomiting, diarrhea, abdominal pain and headache. 
Tell your doctor if you have any side effect that bothers you or that 
does not go away. These are not all the possible side effects of 
mefloquine. For more information, ask your doctor or pharmacist. 
Call your doctor for medical advice about side effects. You may 
report side effects to FDA at 1-800-FDA-1088. 
What should I avoid while taking mefloquine? Avoid activities 
such as driving a car or using heavy machinery or other activities 
needing alertness and careful movements (fine motor coordination) 
until you know how mefloquine affects you. You may feel dizzy or 
lose your balance. This could happen for months or years after 

Card Revised: June 2013 

Information Wallet Card to carry when you are taking Mefloquine Hydrochloride Tablets USP. 

Information Wallet Card: Mefloquine Hydrochloride Tablets USP 
It is important that you read the entire Medication Guide for additional information on mefloquine. 

Carry this wallet card with you when you are taking mefloquine. 

Important: You need to take malaria prevention medicine 
before you travel to a malaria area, while you are in a malaria 
area, and after you return from a malaria area. 
Mefloquine can cause serious side effects, including: 
1. Heart problems. 
Do not take halofantrine (used to treat malaria) or ketoconazole 
(used for fungal infections) with mefloquine or within 15 weeks of 
your last dose of mefloquine. You may get serious heart problems 
that can lead to death. Do not take quinine (Qualaquin) or quini-
dine (used to treat malaria or irregular heart beat) with mefloquine. 
You may get serious heart problems. Mefloquine may cause seri-
ous problems with the electrical system of your heart, called 
QT prolongation. 
2. Mental problems. Symptoms of serious mental problems may 
include severe anxiety, paranoia (feelings of mistrust towards oth-
ers), hallucinations (seeing or hearing things that are not there), 
depression, feeling restless, unusual behavior or feeling confused. 
Some people who take mefloquine think about suicide (putting an 
end to their life). Some people who were taking mefloquine com-
mitted suicide. It is not known if mefloquine was responsible for 
those suicides. 
If you have any of these serious mental problems you should con-
tact your doctor right away as it may be necessary to stop taking 
mefloquine and use a different medicine to prevent malaria. 
3. Problems with your body’s nervous system. Do not take 
quinine (Qualaquin) or chloroquine (Aralen) (used to treat malaria) 
with mefloquine. You may have a greater risk for convulsions 
(seizures). 
Symptoms of serious nervous system problems may include 

are unable to sleep (insomnia). 

dizziness, a feeling that you or things around you are moving or 
spinning (vertigo), loss of balance, ringing in your ears (tinnitus), 
convulsions (seizures) in people who already have seizures, or you 

you stop taking mefloquine and can be permanent in some cases. 

These serious mental and nervous system side effects can 
go on for months or years after mefloquine is stopped or may 
become permanent in some people. 
If you are told by a doctor to stop taking mefloquine because of the 
side effects or for other reasons, you will need to take a different 
malaria medicine. 
If you do not have access to a doctor or to a different medicine 
and have to stop taking mefloquine, leave the malaria area and 
contact a doctor as soon as possible because leaving the malaria 
area may not protect you from getting malaria. You will still need to 
take a malaria prevention medicine for another 4 weeks after you 
leave the malaria area. 
Mefloquine may cause serious liver problems. Symptoms of 
liver problems include nausea, vomiting, loss of appetite, unusual 
tiredness, stomach pain, fever, weakness, itching, light-colored 
bowel movements, dark colored urine, yellowing of your skin or the 
white of your eyes. The most common side effects of mefloquine 
include nausea, vomiting, diarrhea, abdominal pain and headache. 
Tell your doctor if you have any side effect that bothers you or that 
does not go away. These are not all the possible side effects of 
mefloquine. For more information, ask your doctor or pharmacist. 
Call your doctor for medical advice about side effects. You may 
report side effects to FDA at 1-800-FDA-1088. 
What should I avoid while taking mefloquine? Avoid activities 
such as driving a car or using heavy machinery or other activities 
needing alertness and careful movements (fine motor coordination) 
until you know how mefloquine affects you. You may feel dizzy or 
lose your balance. This could happen for months or years after 

Card Revised: June 2013 

Information Wallet Card to carry when you are taking Mefloquine Hydrochloride Tablets USP. similar to the clinical acute treatment dose of 21 to 25 mg/kg, based on body surface area REACTIONS may be more pronounced. the rat. J. Pharm. Pharmacol. 49: 1086-1090. 
comparisons. In all three animal species, CNS effects (e.g., exencephaly, hydrocephaly or Treatment 
partially missing medulla oblongata) and craniofacial malformations were observed. At the Patients should be managed by symptomatic and supportive care following mefloquine Roxane Laboratories, Inc. 
same doses, mefloquine was also embryotoxic in mice and rabbits. All of these findings overdose. There are no specific antidotes. Monitor cardiac function (if possible by ECG) Columbus, Ohio 43216 
were observed at doses that were maternally toxic. and neuropsychiatric status. Provide symptomatic and intensive supportive treatment as 
Nursing Mothers required. 10002082/10 Revised June 2013 

Mefloquine is excreted in human milk in small amounts, the activity of which is un- © RLI, 2013 
known. Based on a study in a few subjects, low concentrations (3% to 4%) of mefloquine DOSAGE AND ADMINISTRATION 
were excreted in human milk following a dose equivalent to 250 mg of the free base. Cau­
tion should be exercised when administered to a nursing woman. Malaria Treatment in Adults 
Pediatric Use Treatment of mild to moderate malaria in adults caused by mefloquine-susceptible 

Use of mefloquine to treat acute, uncomplicated P. falciparum malaria in pediatric pa- strains of P. falciparum or by P. vivax: Dosage: Five tablets (1250 mg) mefloquine hy­
tients is supported by evidence from adequate and well-controlled studies of mefloquine drochloride to be given as a single oral dose. The drug should not be taken on an empty 
in adults with additional data from published open-label and comparative trials using me- stomach and should be administered with at least 8 oz (240 mL) of water. 
floquine to treat malaria caused by P. falciparum in patients younger than 16 years of If a full-treatment course with mefloquine does not lead to improvement within 48 to 72 
age. The safety and effectiveness of mefloquine for the treatment of malaria in pediatric hours, mefloquine should not be used for retreatment. An alternative therapy should be 
patients below the age of 6 months have not been established. used. Similarly, if previous prophylaxis with mefloquine has failed, mefloquine should not 

In several studies, the administration of mefloquine for the treatment of malaria was be used for curative treatment (see INDICATIONS AND USAGE). 
associated with early vomiting in pediatric patients. Early vomiting was cited in some re- Note: Patients with acute P. vivax malaria, treated with mefloquine, are at high risk 
ports as a possible cause of treatment failure. If a second dose is not tolerated, the patient of relapse because mefloquine does not eliminate exoerythrocytic (hepatic phase) 
should be monitored closely and alternative malaria treatment considered if improvement parasites. To avoid relapse after initial treatment of the acute infection with mefloquine, 
is not observed within a reasonable period of time (see WARNINGS and DOSAGE AND patients should subsequently be treated with an 8-aminoquinoline derivative (e.g., pri-
ADMINISTRATION). maquine). 
Geriatric Use Malaria Prophylaxis in Adults: Dosage: One 250 mg mefloquine hydrochloride tablet 

Clinical studies of mefloquine did not include sufficient numbers of subjects aged 65 once weekly. 
and over to determine whether they respond differently from younger subjects. Other re- Prophylactic drug administration should begin 1 week before arrival in an endemic area. 
ported clinical experience has not identified differences in responses between the elderly Subsequent weekly doses should be taken regularly, always on the same day of each 
and younger patients. Since electrocardiographic abnormalities have been observed in week, preferably after the main meal. To reduce the risk of malaria after leaving an endem­
individuals treated with mefloquine (see PRECAUTIONS) and underlying cardiac disease ic area, prophylaxis must be continued for 4 additional weeks to ensure suppressive blood 
is more prevalent in elderly than in younger patients, the benefits of mefloquine therapy levels of the drug when merozoites emerge from the liver. Tablets should not be taken on 
should be weighed against the possibility of adverse cardiac effects in elderly patients. an empty stomach and should be administered with at least 8 oz (240 mL) of water. 

In certain cases, e.g., when a traveler is taking other medication, it may be desirable to 
ADVERSE REACTIONS start prophylaxis 2 to 3 weeks prior to departure, in order to ensure that the combination 

of drugs is well tolerated (see PRECAUTIONS: Drug Interactions). 
Clinical When prophylaxis with mefloquine fails, physicians should carefully evaluate which an-

At the doses used for treatment of acute malaria infections, the symptoms possibly timalarial to use for therapy. 

Reference ID: 3347812 

This label may not be the latest approved by FDA.  
For current labeling information, please visit https://www.fda.gov/drugsatfda