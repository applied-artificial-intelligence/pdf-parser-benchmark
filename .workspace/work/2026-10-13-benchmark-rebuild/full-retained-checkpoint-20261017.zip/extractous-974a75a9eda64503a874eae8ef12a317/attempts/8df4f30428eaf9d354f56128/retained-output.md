276 

Figure 7.1 Proportion (%) of women among all authors in all fields of R&D, by seniority level, 

2018-2022

 

Source: Scopus. 

Notes: Data not available: XK. 

0% 10% 20% 30% 40% 50% 60% 70% 80% 90% 100%

WLD

EU-27

BE

BG

CZ

DK

DE

EE

IE

EL

ES

FR

HR

IT

CY

LV

LT

LU

HU

MT

NL

AT

PL

PT

RO

SI

SK

FI

SE

IS

NO

UK

BA

ME

MD

MK

AL

RS

TR

UA

GE

AM

FO

IL

TN

AR

AU

BR

CA

CN_X_HK

HK

IN

ID

JP

MX

RU

ZA

KR

US

Less than 5 Years Between 5 and 10 Years More than 10 Years

Gender balance