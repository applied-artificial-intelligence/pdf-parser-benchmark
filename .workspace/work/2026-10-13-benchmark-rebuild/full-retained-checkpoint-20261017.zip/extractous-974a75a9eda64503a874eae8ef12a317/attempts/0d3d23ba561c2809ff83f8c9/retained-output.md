/ /

19

Investment in training 
per employee at 
Spanish consulting 
firms (euros)

Investment in training 
per employee in Spain 
(euros)

Training hours per 
employee at Spanish 
consulting firms 
(annual hours)

Investment in training by 
Spanish consulting firms 
(millions of euros)

64.7

348

100

30.5

2018

74.7

370

104

29.1

2019

68.1

335

106

26.5

2020

79

347

109

25.7

2021

78.5

297

112

26.6

2022

92.2

328

120

26.1

2023

102.0

358

125

29.7

2024

58.2

342

94

32.2

2017

53.8

329

91

30.9

2016

Indicators of the investment in training among Spanish consulting firms and 
the economy

Source: AEC (Spanish Association of Consulting Firms)

329

91

342

94

348

100

370

104

2018

335

106

20202019

347

109

2021

297

112

2022

328

120

2023

358

125

202420172016

Sector de la consultoría Economía española

Increase in the investment in training per employee (euros)

Source: AEC (Spanish Association of Consulting Firms)

Investment in training totaled 102 million euros in 2024, which is 10.6% 
higher than the year before

Consultancy industry Spanish economy


	Botón 16: 
	Página 5: 
	Página 7: 
	Página 11: 
	Página 13: 
	Página 15: 
	Página 17: 
	Página 19: 
	Página 21: 
	Página 25: 
	Página 27: 
	Página 29: 
	Página 31: 
	Página 33: 
	Página 35: 
	Página 37: 
	Página 39: 

	  2: 
	Página 5: 
	Página 7: 
	Página 11: 
	Página 13: 
	Página 15: 
	Página 17: 
	Página 19: 
	Página 21: 
	Página 25: 
	Página 27: 
	Página 29: 
	Página 31: 
	Página 33: 
	Página 35: 
	Página 37: 
	Página 39: 

	Botón 17: 
	Página 5: 
	Página 7: 
	Página 11: 
	Página 13: 
	Página 15: 
	Página 17: 
	Página 19: 
	Página 21: 
	Página 25: 
	Página 27: 
	Página 29: 
	Página 31: 
	Página 33: 
	Página 35: 
	Página 37: 
	Página 39: