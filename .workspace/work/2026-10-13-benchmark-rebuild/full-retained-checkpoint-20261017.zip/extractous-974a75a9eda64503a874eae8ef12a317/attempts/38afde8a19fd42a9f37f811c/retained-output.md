32279 Federal Register / Vol. 87, No. 103 / Friday, May 27, 2022 / Rules and Regulations 

using the most current (2021) Implicit 
Price Deflator for the Gross Domestic 
Product. This final withdrawal rule will 
result in an expenditure in at least one 
year that meets or exceeds this amount. 

2. Summary of Costs and Benefits 
The final withdrawal rule will 

withdraw the SUNSET final rule. This 
regulatory action will reduce the time 
spent by the Department performing 
retrospective assessments and reviews 
of its regulations, and time spent by the 
general public on comments related to 
these assessments and reviews 
anticipated under the SUNSET final 
rule. We monetize the likely reductions 
in time spent by the Department and the 
general public and report these impacts 
as cost savings. Our primary estimate of 

these cost savings in 2020 dollars, 
annualized over 10 years, using a 3% 
discount rate, totals $69.9 million. 
Using a 7% discount rate, we estimate 
$75.5 million in annualized cost 
savings. Table 1 reports these primary 
estimates alongside a range of estimates 
that capture uncertainty in the amount 
of time it will take the Department to 
perform each assessment and review, 
and uncertainty in the amount of time 
the public will spend on comments. 

In addition to these monetized effects, 
the final withdrawal rule will also 
reduce regulatory uncertainty and 
regulatory confusion anticipated under 
the SUNSET final rule. Given the scope 
of the SUNSET final rule, these impacts 
would have been experienced by small 

businesses but also the general public, 
larger businesses, Tribes, States, non- 
governmental organizations, and other 
regulated entities and stakeholders 
across a wide range of industrial sectors. 
The final withdrawal rule will also 
reduce the time spent by the 
Department on other activities that we 
have not monetized or quantified, such 
as the time developing Small Entity 
Compliance Guides (SECGs), and it will 
reduce the time spent by the public 
monitoring regulations undergoing 
assessment or review and set to expire. 
The final withdrawal rule will also 
result in a disbenefit with respect to 
forgone information as a result of not 
performing the assessments and 
reviews. 

TABLE 1—SUMMARY OF BENEFITS, COSTS AND DISTRIBUTIONAL EFFECTS OF THE FINAL WITHDRAWAL RULE 

Category Primary 
estimate 

Low 
estimate 

High 
estimate 

Units 

Notes Year 
dollars 

Discount 
rate 
(%) 

Period 
covered 

Benefits: 
Annualized Monetized $millions/year ..................

..................
..................
..................

..................

..................
..................
..................

7 
3 

..................

..................
Annualized Quantified ...................... ..................

..................
..................
..................

..................

..................
..................
..................

7 
3 

..................

..................

Qualitative ........................................ —Reduction in regulatory uncertainty 
and confusion. 
—Disbenefits from the information 
foregone from not performing 
assessments and reviews. 

Costs: 
Annualized Monetized $millions/year ¥$75.5 

¥69.9 
¥$40.1 

¥37.2 
¥$110.9 

¥102.7 
2020 
2020 

7 
3 

2022–2031 
2022–2031 

Cost savings from not performing as-
sessments and reviews, and time 
spent by the public on comments. 

Annualized Quantified ...................... ..................
..................

..................

..................
..................
..................

..................

..................
7 
3 

..................

..................
Qualitative. 

Transfers: 
Federal Annualized Monetized 

$millions/year.
..................
..................

..................

..................
..................
..................

..................

..................
7 
3 

..................

..................

From/To ............................................ From: To: 

Other Annualized Monetized 
$millions/year.

..................

..................
..................
..................

..................

..................
..................
..................

7 
3 

..................

..................

From/To ............................................ From: To: 

Effects: 
State, Local or Tribal Government: 
Small Business: 
Wages: 
Growth: 

3. Summary of Changes 

Compared to the preliminary 
regulatory impact analysis, this final 
regulatory impact analysis expands the 
discussion of regulatory alternatives, 
including a quantitative analysis of two 
additional alternatives recommended in 
public comments. Specifically, we 
analyze a policy option that would 
maintain the general framework of the 
SUNSET final rule but limit its scope to 

regulations that the Department 
previously identified as having a 
significant economic impact on a 
substantial number of small entities. We 
also analyze a policy option that would 
maintain the SUNSET final rule’s 
requirements related to the timeline for 
assessing and reviewing all of the 
Department’s existing regulations, but 
without the automatic expiration 

provision contained in the SUNSET 
final rule. 

We have revised the discussion and 
estimates contained in this regulatory 
impact analysis to reflect regulatory 
action that administratively postponed 
the effective date of the SUNSET final 
rule. This analysis now states that the 
regulatory action will withdraw the 
SUNSET final rule, whereas the 
preliminary regulatory impact analysis 

VerDate Sep<11>2014 18:33 May 26, 2022 Jkt 256001 PO 00000 Frm 00035 Fmt 4701 Sfmt 4700 E:\FR\FM\27MYR2.SGM 27MYR2js
pe

ar
s 

on
 D

S
K

12
1T

N
23

P
R

O
D

 w
ith

 R
U

LE
S

2