The BEAT | June 2025

Over the Past Three Years, Payroll Gains Have Been Driven by the Public Sector

TOP THEMES

Source: Bloomberg, MSIM. As of April 30, 2025. For illustrative purposes only. Not a recommendation to buy or sell any security. It is not possible to invest directly in an index. The views 
and opinions expressed are those of the portfolio management team at the time of writing/of this presentation and are subject to change at any time due to market, economic, or other 
conditions, and may not necessarily come to pass.  Forecasts/estimates are based on current market conditions, subject to change, and may not necessarily come to pass. Past 
performance is not indicative of future results.

Over recent years, the majority of payroll job gains have been in the public sector (government, education, health services), 

resulting in a crowding out of private sector employment. It remains to be seen whether the new administration’s policies can 

lead to a reconvergence in employment trends, which would be positive for labor productivity and inflation.  

Public Sector Employment Has Exploded Since 2022, Resulting in a Crowding Out of the Private Sector

Cumulative growth in total payrolls since 12/31/2022

8

0%

1%

2%

3%

4%

5%

6%

7%

8%

Dec 2022 Mar 2023 Jun 2023 Sep 2023 Dec 2023 Mar 2024 Jun 2024 Sep 2024 Dec 2024 Mar 2025

Private Sector Total Payrolls (ex Govt, Education, Health Svcs) Public Sector Total Payrolls (Gov't, Education, Health Svcs)

... crowding out the 
private sector

Since 2022, public sector 
employment has grown 
substantially...