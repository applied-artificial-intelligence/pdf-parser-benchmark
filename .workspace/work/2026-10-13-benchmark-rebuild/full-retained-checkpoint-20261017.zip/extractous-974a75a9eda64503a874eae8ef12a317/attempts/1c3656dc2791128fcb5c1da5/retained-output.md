CONSULTANCY IN SPAIN / The 2024 industry in figures

16

/ /

Titulados áreas STEM Titulados otras áreas

men Women Total

30.2%

69.8%

44.1%

55.9%

35.1%

64.9%

Source: AEC (Spanish Association of Consulting Firms)

University degree holders from STEM areas 
(percentage in Spain)

Universitarios FP Otros

Men Women Total

63.8%

22.9%

13.3%

70.8%

13.9% 15.3%

65.8%

20.1%
14.1%

Source: AEC (Spanish Association of Consulting Firms)

Most of the consultancy industry’s professionals hold university degrees 
(percentage in Spain)

Due to the type of services offered, consulting fir-
ms attract the most qualified profiles in the job 
market.  65.8%  of the total number of professio-
nals in 2024 were university graduates.  Another 
year again, the percentage of women with a hi-
gher education was above that of men (70.8% ver-
sus 63.8%).

On the other hand, the presence of vocational tra-
ining graduates dropped with respect to the year 
before, representing 20.1% of the total in 2.24.  In 
this case, the percentage of women, 13.9% of the 
total, was less than the men, which represented 
22.9%.

Degree holders in STEM fields Degree holders in other fields

University graduates Vocational training Other


	Botón 18: 
	Página 4: 
	Página 6: 
	Página 10: 
	Página 12: 
	Página 14: 
	Página 16: 
	Página 18: 
	Página 20: 
	Página 22: 
	Página 24: 
	Página 26: 
	Página 28: 
	Página 30: 
	Página 32: 
	Página 34: 
	Página 36: 

	  3: 
	Página 4: 
	Página 6: 
	Página 10: 
	Página 12: 
	Página 14: 
	Página 16: 
	Página 18: 
	Página 20: 
	Página 22: 
	Página 24: 
	Página 26: 
	Página 28: 
	Página 30: 
	Página 32: 
	Página 34: 
	Página 36: 

	Botón 19: 
	Página 4: 
	Página 6: 
	Página 10: 
	Página 12: 
	Página 14: 
	Página 16: 
	Página 18: 
	Página 20: 
	Página 22: 
	Página 24: 
	Página 26: 
	Página 28: 
	Página 30: 
	Página 32: 
	Página 34: 
	Página 36: