Country-sheets

VIETNAM
² 101,598,527 || J e761 (avg. monthly income, PPP)

Inequality in Vietnam
In Vietnam, inequality is moderate andhas remained broadly stable over the pastdecade. The top 10% of earners receive43% of total income, while the bottom50% account for 16%. Wealth is moreconcentrated, with the richest 10% holding59% of total wealth and the top 1% holding25%. Average income per capita is 9,100euros (PPP), and average wealth standsat 38,700 euros (PPP). The income gapbetween the top 10% and the bottom50% increased slightly from 26.7 to 27.2between 2014 and 2024, indicating stablebut persistent disparities. Female laborparticipation remained nearly unchanged,moving from 39.6% to 38.8%. Overall,Vietnam shows stable income distributionalongside a persistent concentration ofwealth at the top. ‘

Table 1: Inequality outlook – Vietnam

Avg. 

Income 

(PPP €)

Share 

of 

total (%)

Avg. 

Wealth 

(PPP €)

Share 

of 

total (%)

Full 

pop.
9,126 100.0% 38,655 100.0%

Bottom 

50%
1,448 15.8% 1,778 4.6%

Middle 

40%
9,368 41.1% 35,079 36.3%

Top 

10%
39,382 43.2% 228,062 59.0%

Top 

1%
141,660 15.5% 954,768 24.7%

2014 2024

26.7 27.2

39.6% 38.8%

Income Wealth

Year

Top 10% to Bot. 50% 

Income gap

Female labor share

Interpretation: Country has a transparency index of 5/20. All values are estimated at percapita (full population) level. See glossary for all definitions of concepts and indicators.
Sources and series: wir2026.wid.world/methodology.

Figure 1: Top 10% and bottom 50% income shares in Vietnam,
1980-2024

Interpretation: The Top 10% income share is equal to 43% in 2024. Income is measuredafter the operation of pensions and unemployment insurance systems and beforeincome tax.
Sources and series: wir2026.wid.world/methodology.

198