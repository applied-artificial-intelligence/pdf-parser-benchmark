Outside Western countries – especially in Latin America and Africa 
– we find a much higher proportion of our sample using social media 
for news, but we also find different networks in play. In African 
countries such as Nigeria, South Africa, and Kenya, WhatsApp 
(55%) and Telegram (18%) combined are more important for 
finding, sharing, and discussing news than Facebook (59%). Latin 
Americans tend to use a combination of all the main networks, 
while it is a mixed picture in Asia, with almost three-quarters (73%) 
using Facebook for news in the Philippines but just 5% in Japan, 
where Twitter (18%) and Line (16%) are more popular. YouTube 
(44%) is the main social network for news in South Korea, along 
with home-grown app KakaoTalk (24%) and KakaoStory (5%).

TikTok emerges as a significant new player in the news ecosystem

In our data, we find significant and rapidly growing usage of TikTok, 
especially in Africa, Asia, and Latin America as well as across Eastern 
Europe. Usage is mostly still with under 25s, but is extending into all 
age brackets in countries with higher levels of usage, such as Kenya, 
South Africa, Thailand, Indonesia, Brazil, and Peru. This quote from 
our Brazil qualitative research sums up how perceptions of content 
on TikTok have changed in the last year or so.

When TikTok was launched, it was just about dancing, 
choreography; not today, even though the videos are 
fast, they bring immediate information.
Male, 24, Brazil

The Russia-Ukraine conflict has increased the profile of the network 
globally. Ukrainians have been documenting their experience of the 
war, including leaving their homes as refugees, clocking up millions 
of views in the process (see picture above right). As we noted last 
year, many publishers have been increasing their investment, but 
some worry that a platform where entertainment content is so 
sought-after may not be the most effective place for news. BBC 
News originally decided to avoid TikTok, but has now set up channels 
in Russian and English after seeing misleading information being 
shared on the platform around the war in Ukraine.

In contrast to traditional networks such as Facebook or Twitter, the 
content of the main TikTok feed is driven less by who you follow and 
more by an algorithm that takes into account what you like and what 
others are watching. 

It’s so addictive … and where it lacks in trustworthiness, 
it excels in presentation. It’s a news source I end up 
consuming because I’m also often scrolling TikTok for 
other reasons, but the algorithm ends up providing 
news anyways.
Female, 22, USA

But others remain sceptical about the value of very short videos 
designed for popularity.

I greatly dislike everything about the presentation of 
TikTok [and Instagram]. Everything about it screams a 
lack of professionalism and research and I cannot trust 
it, along with it being obnoxiously loud.
Male, 18, USA

REUTERS INSTITUTE FOR THE STUDY OF JOURNALISM / EXECUTIVE SUMMARY GRAPHS

Graph 33

PROPORTION THAT USED EACH SOCIAL NETWORK FOR NEWS IN THE LAST WEEK – SELECTED REGIONS

Europe

Facebook

Instagram

FB Messenger

Twitter

Telegram

TikTok

YouTube

WhatsApp

Asia Latin America AfricaNorth America

16%

23%

6%

25%

24%

34%

34%

10%

43%

18%

16%

57%

28% 29%

15%

59%

55%

42% 35% 44%

35%

40%

14%

13% 11%

14%11%

11%11%

9%

4%

5%

2%

6%

9%

9%

6%

11%

18%

14%

Q12B. Which, if any, of the following have you used for news in the last week? Base: Total sample in each region. Europe = 48,836, North America = 4048, Asia = 20,349, Latin America = 12,104, Africa = 6057. 
Note: Africa average is Kenya, South Africa, and Nigeria only (English speakers in South Africa and Nigeria).

REUTERS INSTITUTE FOR THE STUDY OF JOURNALISM / EXECUTIVE SUMMARY GRAPHS

Graph 34

40%
of 18-24s use  

TikTok for any 
purpose

15%
of 18-24s use  

TikTok for  
news

(Across all markets)

Kenya 43%/15%

Thailand 42%/22%

South Africa 41%/15%

Peru 37%/16%

Mexico 35%/10%

Markets with highest usage (all ages) % for any purpose/for news

Q12a/b. Which, if any, of the following have you used in the last week for any purpose/news? 
Base: Total sample in each market (n ≈ 2000).

Reuters Institute for the Study of Journalism   |   Digital News Report 2022 25