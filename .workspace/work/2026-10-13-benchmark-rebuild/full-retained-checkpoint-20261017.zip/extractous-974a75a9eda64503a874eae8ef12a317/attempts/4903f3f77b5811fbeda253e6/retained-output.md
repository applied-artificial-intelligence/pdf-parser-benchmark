2024 UN E-GovErNmENt SUrvEy

66

C
h

ap
ter 2

countries, representing a 1.3 per cent decline). The only upturn has been a 2.7 per cent increase in 
the number of countries providing services for older people (148 countries in 2024 versus 144 in 
2022). Further studies are required to examine the possible reasons for such deline. On a positive 
note, the provision of services that can be transacted fully online has increased by an average of 1 
to 7 per cent for all groups except immigrants. countries are moving steadily towards improving the 
convenience and efficiency of services for users. 

Europe remains the most homogeneous region in terms of the provision of online services for 
people in vulnerable situations (94 per cent of countries), and for 45 per cent of those services (the 
highest proportion among the regions), transactions can be completed online. While there has been 
a downturn in the provision of online services to vulnerable populations, the majority of the UN 
Member States (more than 80 per cent) still offer such services; in regional terms, Europe accounts 
for the highest proportion, followed the Americas (80 per cent), Asia (79 per cent), Oceania (70 per 
cent), and Africa (56 per cent). The Americas and Asia have comparable shares of countries offering 
services to people in vulnerable situations; however, fully digitalized services are offered by more 
countries in Asia (30 per cent) than in the Americas (23 per cent).  

Figure 2.25 Percentage of countries offering services for people in vulnerable situations that can be  
 completed partially or fully online, 2022 and 2024

Sources: 2022 and 2024 United Nations E-Government Surveys.

193 UN Member States

Americas

Africa

Asia

Europe

Oceania

Very high EGDI
High EGDI
Middle EGDI
Low EGDI

21%

26%

23%

26%

23%

26%

52%

50%

46%

54%

54%

53%

-13.5%

2.7%

-1.3%

-8.6%

-1.9%

22%

19%

20%

22%

19%

25%

63%

55%

55%

60%

65%

55%

Immigrants

Older people

Persons living below poverty line

Persons with disabilities

Women

Youth

193 UN Member States

AvailableFully digitalized AvailableFully digitalized
2024 2022

Percentage change
since 2022

6%

6%

4%

6%

4%

6%

41%

48%

39%

54%

59%

67%

23%

26%

20%

23%

26%

23%

51%

60%

51%

69%

54%

57%

26%

36%

28%

30%

32%

30%

57%

43%

49%

49%

51%

45%

37%

44%

44%

53%

42%

51%

60%

51%

51%

47%

44%

40%

14%

21%

21%

21%

21%

50%

57%

29%

57%

71%

57%

Immigrants

Older people

Persons living below poverty line

Persons with disabilities

Women

Youth

Africa Americas Asia Europe Oceania

Available
Fully
digitalized Available

Fully
digitalized Available

Fully
digitalized Available

Fully
digitalized Available

Fully 
digitalized

-8.3%