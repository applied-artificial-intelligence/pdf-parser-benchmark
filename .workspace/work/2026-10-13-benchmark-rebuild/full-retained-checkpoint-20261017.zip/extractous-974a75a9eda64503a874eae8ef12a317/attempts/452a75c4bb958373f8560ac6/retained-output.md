118    

 

DO ADULTS HAVE THE SKILLS THEY NEED TO THRIVE IN A CHANGING WORLD? © OECD 2024 
  

Figure 3.8. Change in the gap in literacy proficiency between highly and low-educated adults  

Adjusted and unadjusted change between cycles in the average score difference between adults with tertiary 

education and adults with below upper secondary education (Cycle 2 minus Cycle 1); 25-65 year-olds 

 

Note: Does not include adults who in Cycle 2 were only administered the doorstep interview due to a language barrier, to maximise the 

comparability across cycles (see Box 1.1 in Chapter 1 and Box 3.2). See Note 2 for an explanation of the classification of educational attainment. 

Unadjusted changes in the proficiency gap are the changes in the difference between the two contrast categories across the cycles. Adjusted 

changes are obtained by subtracting the coefficients of regression models estimated separately for each cycle. These coefficients show the 

difference between the categories in each cycle, after accounting for: gender, immigrant background, age, parental education and language 

spoken at home. Darker colours denote differences that are statistically significant at the 5% level. 

In Chile and the United States, more than 20% of the subsample of adults with below upper secondary education only completed the assessment 

of reading and numeracy components in the second cycle. As the methodology for estimating the proficiency of adults who only took the 

components assessment has changed between the cycles, the change in the proficiency gap is not reported for these countries. *Caution is 

required in interpreting results due to the high share of respondents with unusual response patterns. See the Note for Poland in the Reader’s 

Guide. 

Countries and economies are ranked in descending order of the unadjusted change in the gap. 

Source: OECD (2018[4]; 2015[5]; 2012[6]), Survey of Adult Skills (PIAAC) databases, http://www.oecd.org/skills/piaac/publicdataandanalysis/  

(accessed on 23 September 2024); Tables A.3.12 (L) and A.3.13 (L) in Annex A. 

The numeracy proficiency gap between low- and highly educated adults widened significantly in 

11 countries and economies, with large increases (over 20 points) in Austria, Japan and New Zealand. In 

Singapore, the gap in numeracy narrowed due to improvements among the low-educated, while in Israel 

and the Slovak Republic it narrowed because of proficiency declines among tertiary-educated adults (see 

Tables A.3.11 (N) and A.3.12 (N) in Annex A). 

Changes in skills proficiency by educational attainment among younger and older adults 

When interpreting proficiency trends for different education groups, it is important to consider that the 

proficiency of younger and older adults with the same educational attainment may have evolved differently 

due to their different educational experiences. Older adults may have received a very different education 

from that received by younger people today. The relationship between older adults’ formal education and 

their proficiency is also presumably weaker due to the length of time they have been out of education. In 

contrast, trends in the proficiency of younger adults with different attainment levels are more influenced by 

 a
p
an

A
us

tr
ia

F
ra
n
ce

 
or
w
ay

E
st
o
ni
a

G
er
m
a
ny

E
ng

la
n
d 
(U

 
 

F
in
la
nd

F
le
m
is
h 
R
e
gi
o
n 
( 

E
 

 
e
nm

ar
k

Ir
el
a
nd

C
 e

ch
ia

 
or
ea

 
et
he

rl
a
n
ds

C
an

ad
a

It
al
y

S
pa

in

S
lo
 a

k 
R
ep

u
bl
ic

S
w
ed

e
n

P
o
la
n
d 

 
ew

  
ea

la
nd

 i
th
ua

n
ia

S
in
g
a
p
or
e

Is
ra
e
l

H
un

g
a
ry

Score point
diffe rence

 0

3 

30

2 

20

1 

10

 

0

  

 10

 1 

 20

Ad ustedUnad u sted

Round, Cycle 1:    

http://www.oecd.org/skills/piaac/publicdataandanalysis/