C O N N E C T I v I T y   27

FIGURE 2 .1 Mobile network coverage, by country income group, 2022 and 2024

0

20

40

60

80

100

Region
2G 3G 4G 5G

35

57

32

24

41

51

0 01
24

75

1
15

84

1 1

49

48

2
1

32

65

34

85

6

42

58

35

15

35

39

1

11

28

49

4

2022 2024 2022 2024 2022 2024 2022 2024 2022 2024
 Global  HICs  UMICs LMICs  LICs

Population covered by mobile network (%)

Source: Original figure for this publication using calculations from the International Telecommunication Union (https://datahub.itu.int/).
Note: HICs = high-income countries; LICs = low-income countries; LMICs = lower-middle-income countries; UMICs = upper-middle 
-income countries.

The recent rise in the availability of satellite internet worldwide has been driven by significant 
growth in satellite constellations. As of 2023, there were slightly more than 7,560 satellites in orbit, 
of which approximately 5,300 are commercial communications satellites providing connectivity 
services in addition to traditional fixed and mobile networks (Sebastian 2005). The presence of 
large constellations of nongeosynchronous-orbit (NGSO) satellites covering the earth’s surface 
remains the main driver of increased availability of satellite connectivity. Since 2015, the number 
of communications satellites in orbit deployed for commercial purposes has increased more than 
14 times, with LEO satellites constituting the bulk of launches (refer to figure 2.2). LEO satellites 
now make up 90 percent of all satellites in orbit providing communications and connectivity services.

New business models and price points are increasing the adoption of satellite communications 
services globally. Although GSO satellites stationed approximately 36,000 kilometers above the 
Earth’s surface have historically provided effective communications services, primarily focused on 
business and government clients, and played a vital role in enhancing global navigation, backhauling 
for telecommunications providers, and emergency response capabilities, recent breakthroughs in 
technology (leading to a significant reduction in launch costs) and business models are changing the 
landscape of satellite connectivity. NGSO satellite constellations such as Starlink and OneWeb offer 
solutions with improved speeds, better prices, and reduced latency, making satellite connectivity 
attractive to end users seeking improved experiences in developing countries. A 2023 study by 
Ookla found that in Nigeria and Rwanda, SpaceX’s Starlink recorded median download speeds 
almost two times faster than those of other fixed broadband providers.1 NGSO satellites also 
provide a viable connectivity solution for rural and remote areas that are hard to reach with 
terrestrial fixed and mobile networks because of financial, demographic, or geographic constraints, 
democratizing broadband access to unserved populations. Countries also have their own regulatory 
processes to decide which providers are best for their own contexts (Stein and Natanson 2025).

https://datahub.itu.int/