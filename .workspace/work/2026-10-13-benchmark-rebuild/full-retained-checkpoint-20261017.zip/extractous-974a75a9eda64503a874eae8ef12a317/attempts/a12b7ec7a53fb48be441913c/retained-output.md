Formulating the Future of BRI BRIVOLUTION 2.0

BRI is currently carrying out a transformation to realize its vision to become "The Most Valuable Banking Group in Southeast Asia and Champion of Financial Inclusion" with a target of a $75 
billion market cap, 90% financial inclusion, and an increasing number of enablers. The goal is supported by the vision of each business directorate and other support directorates formulated 
to maintain the Company's solid and sustainable business growth.

BRIVOLUTION 2.0 is implemented through 3 (three) phases:

Strengthen Sustain
Scale up & 
Scope up

In the "strengthening" stage, BRI devised strategies 
to strengthen its core business in all aspects 
to achieve future growth. Improvements in 
distribution networks, information technology, 
human resources, corporate culture, risk 
management and all business supporting 
elements were required to strengthen the 
foundations of BRI and its subsidiaries. BRI also 
managed to tackle the impact of the COVID-19 
pandemic by implementing selective growth 
strategies, maintaining asset quality, and 
increasing efficiency.

In the "scaling-up and scoping-up” stage, 
BRI and its subsidiaries are focused on new 
levels of growth and expansion of scope, 
including product and service offerings through 
digitalization. In 2023, BRI realized this aspirational 
theme by prioritizing "strengthening of retail 
banking capabilities" by building a sustainable 
business ecosystem. In 2024, BRI has set the 
target of greater contributions from its subsidiaries 
compared to that of the previous years to achieve 
profitability targets. Also in 2024, BRI is committed 
to becoming a leader in banking transactions by 
developing digital products and services.

In the "sustaining" stage, BRI hopes to develop 
into a bigger and stronger company and to 
be able to maintain business in a sustainable 
manner. BRI has managed to realize its 
commitment as "The Most Valuable Banking 
group in Southeast Asia and Champion of 
Financial Inclusion." This milestone serves as 
an important foundation for BRI to continue to 
progress and continue to create economic and 
social value for every stakeholder. 

“Strengthen the core for growth”
2021-2022

“Sustain top-tier position in Southeast Asia”
2025 Accelerate CASA Growth

“Scale up new growth engines and beyond 
banking” 

2023-2024

A Brief Look at BRI

To realize these aspirations, BRI has established 6 main 
strategies, namely:

1. Creating New Growth Engine
Creating a new business engine through several 
initiatives such as: Ultra Micro, Business Ecosystem, 
hyperlocal micro ecosystem, and a B2B SME 
Ecosystem.

2. Accelerating CASA Growth
Increasing CASA through several strategic initiatives.

3. Enhancing Cross-Sell to Boost Fee Income
Initiatives that support increasing service income 
through the scaling up of wealth business, SME 
banking applications, subsidiary cross-selling , as well 
as through non-credit financial products such as 
insurance, trade finance, pawnbroking and others.

4. Containing Credit Cost 
Managing credit costs by changing and updating 
business credit processes.

5. Improving Customer Experience 
Improving customer experience through the use of 
the latest technology.

6. Adapting Cultures & Capabilities
An initiative group that functions as an enabler 
in the transformation process at BRI, specifically 
regarding the culture and capabilities of HR, IT and 
risk management.

Sustainability Report 2023
PT Bank Rakyat Indonesia (Persero) Tbk.

16

Introduction AppendicesGovernance:
Maintaining Good Corporate Governance

Message from the Board A Brief Look at BRI Our Sustainability Strategy Business and ESGHighlights Alignment with SDGs ESG Ratings & Recognitions

Social:
Empowering The People 

Environmental:
Nurturing The Planet 

About This Sustainability Report